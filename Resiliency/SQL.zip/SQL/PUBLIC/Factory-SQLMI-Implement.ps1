﻿<#if(Get-Module -Name Az.Sql) {
    Write-Host "Az.Sql Module already installed" -ForegroundColor Green
}
else {
    Install-Module Az.Sql -RequiredVersion 6.0 -Force
}

Import-Module -Name Az.Sql
#>

$NSnetworkModels = "Microsoft.Azure.Commands.Network.Models"
$NScollections = "System.Collections.Generic"

function exitCode{
    Write-Host "-Ending Execution"
    return
}

CLS
#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------*
 
write-host "                                                                                                                                           " -BackgroundColor DarkMagenta
Write-Host "               Welcome to Factory Resiliency (High Availability and Disaster Recovery) for Azure SQL PaaS (SQL DB and SQL MI)              " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                                                      (OSS DB Migration Factory)                                                           " -BackgroundColor DarkMagenta
write-host "                                                                                                                                           " -BackgroundColor DarkMagenta
Write-Host " "

$folder = $PSScriptRoot #"C:\Users\v-arunkumarg\Downloads\SQLMI\SQLMI"
$csvPath = Get-ChildItem -Path "$Folder\Output\" | Sort-Object CreationTime -Descending | select -First 1 #"$Folder\Output\SQL_HADR_Discovery_20250404_141549.csv"

Write-Host $csvPath.FullName -ForegroundColor Green

# Check if the CSV path is valid
if (-not (Test-Path $csvPath.FullName)) {
    Write-Host "Error: The specified CSV file path is invalid or does not exist." -BackgroundColor Red
    return
}

try {
    $csvData = Import-Csv -Path $csvPath.FullName

    $Approved_Rows = $csvData | Where-Object { $_.Authorize.toupper() -eq "YES" -and $_.Type -eq "SQL MI" }

    ####### Validation of Input csv file #######
    $exitcode=$false
    $backupredundancychk = ($Approved_Rows | Where-Object { ($_.BackupRedundancy -eq "Local") -and ((($_.Geo.ToUpper().trim() -eq "YES") -and ($_.Zone.ToUpper().trim() -eq "YES")) -or (($_.Geo.trim().length -eq 0) -and ($_.Zone.trim().length -eq 0))) } | Select-Object Server_Name).Server_Name
    if($backupredundancychk.Count -gt 0) {
        Write-Host "Please fill as 'Yes' for either Zone or Geo for the MI(s) [$($backupredundancychk -join ", ")]" -ForegroundColor Magenta
        $exitcode=$true
    }
    $validate_empty_cols=@('primaryvNet','EnableHA','FailoverGroupName','SecondaryServerName','SecondaryServerUsername','SecondaryServerPassword','SecondaryRG','FailoverLocation','vCore','SubscriptionID','vNetName','defaultSubnetName','SubnetName','Edition','maxStorage','ComputeGeneration','License','NetworkSecurityGroupName','routeTableName','primary_peer_name','secondary_peer_name')
    foreach($cols in $validate_empty_cols){
        $res = ($Approved_Rows | Where-Object { $_.($cols).trim().length -eq 0 } | Select-Object Server_Name).Server_Name
        if($res.count -gt 0){
            Write-Host "`n'$cols' is not valid/not exists for the server(s)[$($res -join ", ")]' in the input file."  -ForegroundColor Red
            $exitcode=$true
        }
    }
    if($exitcode){
        Write-host "Please validate the input CSV. Kindly check and retrigger the automation"
        exitcode
    }
    ####### Validation of Input csv file #######

    $ConfigList = $Approved_Rows | Group-Object -Property 'Host_Name' | ForEach-Object { $_.Group }
}
catch {
    Write-Host "Error: Failed to read the CSV file. Please ensure it's correctly formatted." -BackgroundColor Red
    return
}

# SQL MI implementation

foreach ($entry in $ConfigList) {
     if ($entry.Type -eq "SQL MI") {

        $servername                 = $entry.Server_Name
        $DBName                     = $entry.DB_Name
        $resourceGroupName          = $entry.ResourceGroup
        $zoneredundant              = $entry.ZoneRedundant
        $primaryVNet                = $entry.primaryvNet
        $location                   = $entry.Location
        $failoverlocation           = $entry.FailoverLocation
        $servicetier                = $entry.ServiceTier
        $backupredundancy           = $entry.BackupRedundancy
        $failovergroupname          = $entry.FailoverGroupName
        $secondaryservername        = $entry.SecondaryServerName
        $secondaryRG                = $entry.SecondaryRG
        $secondaryserveruser        = $entry.SecondaryServerUsername
        $secondaryserverpass        = $entry.SecondaryServerPassword
        $vcore                      = $entry.vCore
        $subscriptionID             = $entry.SubscriptionID
        $secondaryvNet              = $entry.vNetName
        $vNetAddressPrefix          = "10.0.0.0/16"
        $defaultSubnetAddressPrefix = "10.0.0.0/24"
        $defaultSubnetName          = $entry.defaultSubnetName
        $miSubnetName               = $entry.SubnetName
        $miSubnetAddressPrefix      = "100.80.0.0/24"
        $edition                    = $entry.Edition #"General Purpose"
        $maxStorage                 = $entry.maxStorage
        $computeGeneration          = $entry.ComputeGeneration
        $license                    = $entry.License  #"LicenseIncluded" #"BasePrice" or LicenseIncluded if you have don't have SQL Server licence that can be used for AHB discount
        $NetworkSecurityGroupName   = $entry.NetworkSecurityGroupName
        $routeTableName             = $entry.routeTableName
        $primary_secondary          = $entry.primary_peer_name
        $secondary_primary          = $entry.secondary_peer_name
        $zone                       = $entry.Zone
        $geo                        = $entry.Geo
        
     
        if(($backupredundancy -eq "Local") -and ($geo.ToUpper() -eq "YES")) {
            $backupredundancy = "Geo"
        }
        elseif(($backupredundancy -eq "Local") -and ($zone.ToUpper() -eq "YES")) {
            $backupredundancy = "Zone"
        }
        
        #Write-Host "`n$servername - $backupredundancy" -ForegroundColor Cyan
        
        # Configure virtual network, subnets, network security group, and routing table
        $networkSecurityGroupParams = @{
            Name = $NetworkSecurityGroupName #'myNetworkSecurityGroupMiManagementService01'
            ResourceGroupName = $resourceGroupName
            Location = $failoverlocation
        }
        ################ Check & Create Network Security Group ################
        if(((Get-AzNetworkSecurityGroup -ResourceGroupName $resourceGroupName).Name) -contains $NetworkSecurityGroupName.Trim()) {
            Write-Host "`nNetwork security group '$($NetworkSecurityGroupName)' already exists...!!!" -ForegroundColor Green
        }
        else {
            $networkSecurityGroupMiManagementService = New-AzNetworkSecurityGroup @networkSecurityGroupParams
        }

        $routeTableParams = @{
            Name = $routeTableName  #'myRouteTableMiManagementService01'
            ResourceGroupName = $resourceGroupName
            Location = $failoverlocation
        }
        if(((Get-AzRouteTable -ResourceGroupName $resourceGroupName).Name) -contains $routeTableName.Trim()) {
            Write-Host "`nRoute table '$($routeTableName)' already exists...!!!" -ForegroundColor Green
        }
        else {
            $routeTableMiManagementService = New-AzRouteTable @routeTableParams
        }

        $virtualNetworkParams = @{
            ResourceGroupName = $resourceGroupName
            Location = $failoverlocation
            Name = $secondaryvNet
            AddressPrefix = "100.80.0.0/16" #$vNetAddressPrefix
        }

        if((Get-AzVirtualNetwork -ResourceGroupName $resourceGroupName).Name -contains $secondaryvNet.Trim() ) {
            Write-Host "`nVirtual network '$($secondaryvNet)' already exists...!!!" -ForegroundColor Green
        }
        else {
            $virtualNetwork = New-AzVirtualNetwork @virtualNetworkParams
        }

        $subnetConfigParams = @{
            Name = $miSubnetName
            VirtualNetwork = $virtualNetwork
            AddressPrefix = $miSubnetAddressPrefix
            NetworkSecurityGroup = $networkSecurityGroupMiManagementService
            RouteTable = $routeTableMiManagementService
        }
        $subnetName = $subnetConfigParams.Name
        if($virtualNetwork.Subnets.Name -eq $subnetName) {
            Write-Host "Subnet '$subnetName' already exists" -ForegroundColor Red
        }
        else {
            $subnetConfig = Add-AzVirtualNetworkSubnetConfig @subnetConfigParams | Set-AzVirtualNetwork
        }

        $virtualNetwork = Get-AzVirtualNetwork -Name $secondaryvNet -ResourceGroupName $resourceGroupName

        $subnet= $virtualNetwork.Subnets[0]

        # Create a delegation
        $subnet.Delegations = New-Object "$NScollections.List``1[$NSnetworkModels.PSDelegation]"
        $delegationName = "dgManagedInstance" + (Get-Random -Maximum 1000)
        $delegationParams = @{
            Name = $delegationName
            ServiceName = "Microsoft.Sql/managedInstances"
        }
        $delegation = New-AzDelegation @delegationParams
        $subnet.Delegations.Add($delegation)

        Set-AzVirtualNetwork -VirtualNetwork $virtualNetwork

        $miSubnetConfigId = $subnet.Id

        $allowInParameters = @{
            Access = 'Allow'
            Protocol = 'Tcp'
            Direction= 'Inbound'
            SourcePortRange = '*'
            SourceAddressPrefix = 'VirtualNetwork'
            DestinationAddressPrefix = '*'
        }
        $denyInParameters = @{
            Access = 'Deny'
            Protocol = '*'
            Direction = 'Inbound'
            SourcePortRange = '*'
            SourceAddressPrefix = '*'
            DestinationPortRange = '*'
            DestinationAddressPrefix = '*'
        }
        $allowOutParameters = @{
            Access = 'Allow'
            Protocol = '*'
            Direction = 'Outbound'
            SourcePortRange = '*'
            SourceAddressPrefix = 'VirtualNetwork'
            DestinationPortRange = '*'
            DestinationAddressPrefix = '*'
        }
        $denyOutParameters = @{
            Access = 'Deny'
            Protocol = '*'
            Direction = 'Outbound'
            SourcePortRange = '*'
            SourceAddressPrefix = '*'
            DestinationPortRange = '*'
            DestinationAddressPrefix = '*'
        }

        $networkSecurityGroupParams = @{
            ResourceGroupName = $resourceGroupName
            Name = $NetworkSecurityGroupName #"myNetworkSecurityGroupMiManagementService"
        }

        $networkSecurityGroup = Get-AzNetworkSecurityGroup @networkSecurityGroupParams

        $allowInRuleParams = @{
            Access = 'Allow'
            Protocol = 'Tcp'
            Direction = 'Inbound'
            SourcePortRange = '*'
            SourceAddressPrefix = 'VirtualNetwork'
            DestinationAddressPrefix = '*'
        }

        $denyInRuleParams = @{
            Access = 'Deny'
            Protocol = '*'
            Direction = 'Inbound'
            SourcePortRange = '*'
            SourceAddressPrefix = '*'
            DestinationPortRange = '*'
            DestinationAddressPrefix = '*'
        }

        $denyOutRuleParams = @{
            Access = 'Deny'
            Protocol = '*'
            Direction = 'Outbound'
            SourcePortRange = '*'
            SourceAddressPrefix = $defaultSubnetAddressPrefix
            DestinationPortRange = '*'
            DestinationAddressPrefix = '*'
        }

        $validate_rule = $networkSecurityGroup.SecurityRules.Name

        if($validate_rule -contains "allow_tds_inbound") {
            Write-Host "Rule 'allow_tds_inbound' is already exists...!!!" -ForegroundColor Red
        }
        else {
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @allowInRuleParams -Priority 1000 -Name "allow_tds_inbound" -DestinationPortRange 1433,5022
            #Set-AzNetworkSecurityGroup
        }
        if($validate_rule -contains "allow_redirect_inbound") {
            Write-Host "Rule 'allow_redirect_inbound' is already exists...!!!" -ForegroundColor Red
        }
        else {
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @allowInRuleParams -Priority 1100 -Name "allow_redirect_inbound" -DestinationPortRange 11000-11999 
            #Set-AzNetworkSecurityGroup
        }
        if($validate_rule -contains "deny_all_inbound") {
            Write-Host "Rule 'deny_all_inbound' is already exists...!!!" -ForegroundColor Red
        }
        else {
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @denyInRuleParams -Priority 4096 -Name "deny_all_inbound"
            #Set-AzNetworkSecurityGroup
        }
        if($validate_rule -contains "deny_all_outbound") {
            Write-Host "Rule 'deny_all_outbound' is already exists...!!!" -ForegroundColor Red
        }
        else {
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @denyOutRuleParams -Priority 4096 -Name "deny_all_outbound"
        }
        Set-AzNetworkSecurityGroup -NetworkSecurityGroup $networkSecurityGroup

        <#if($validate_rule -notcontains "allow_tds_inbound") { 
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @allowInRuleParams -Priority 1000 -Name "allow_tds_inbound" -DestinationPortRange 1433,5022
            Set-AzNetworkSecurityGroup
        }
        if($validate_rule -notcontains "allow_redirect_inbound") { 
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @allowInRuleParams -Priority 1100 -Name "allow_redirect_inbound" -DestinationPortRange 11000-11999 
            Set-AzNetworkSecurityGroup
        }
        if($validate_rule -notcontains "deny_all_inbound") {
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @denyInRuleParams -Priority 4096 -Name "deny_all_inbound"
            Set-AzNetworkSecurityGroup
        }
        if($validate_rule -notcontains "deny_all_outbound") {
            $networkSecurityGroup | Add-AzNetworkSecurityRuleConfig @denyOutRuleParams -Priority 4096 -Name "deny_all_outbound"
            Set-AzNetworkSecurityGroup
        }
        Set-AzNetworkSecurityGroup #>

        # </CreateVirtualNetwork>

        # <CreateManagedInstance>

        if($secondaryserverpass -ne $null) {
            
            $secpasswd = ConvertTo-SecureString $secondaryserverpass -AsPlainText -Force
            $cred = New-Object System.Management.Automation.PSCredential ($secondaryserveruser, $secpasswd)
        }
        else {
            Write-Host "Secondary server password is empty, please enter password and try again" -ForegroundColor Red
        }

        # Get Managed Instances
        $primaryMI = Get-AzSqlInstance -Name $servername -ResourceGroupName $resourceGroupName -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
        $primaryMIID = $primaryMI.Id
        $secondaryMI = Get-AzSqlInstance -Name $secondaryservername -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

        $managedInstanceParams = @{
            Name = $secondaryservername
            ResourceGroupName = $resourceGroupName
            Location = $failoverlocation
            SubnetId = $miSubnetConfigId
            AdministratorCredential = $cred
            StorageSizeInGB = $maxStorage
            VCore = $vcore
            Edition = $edition
            ComputeGeneration = $computeGeneration
            LicenseType = $license
            DNSZonePartner = $primaryMIID
        }

        #if ((Get-AzSqlInstance | Where-Object { $_.ManagedInstanceName -eq $secondaryservername.Trim() }).Count -eq 0) {

        if (-not([bool](Get-AzSqlInstance | Where-Object { $_.ManagedInstanceName -contains $secondaryservername.Trim() }))) {
                try {
                    Write-Host "Creating secondary instance at $(Get-Date)" -ForegroundColor Green
                    New-AzSqlInstance @managedInstanceParams
                    Write-Host "Creating secondary instance completed at $(Get-Date)" -ForegroundColor Green
                }
                catch {
                    $_ | Format-List -Force
                }
        }
        else {
            Write-Host "`nSecondary MI is already exists" -ForegroundColor Cyan
        }


        # Create global virtual network peering
        $primaryVirtualNetwork  = Get-AzVirtualNetwork -Name $primaryVNet -ResourceGroupName $resourceGroupName
        $secondaryVirtualNetwork = Get-AzVirtualNetwork -Name $secondaryvNet -ResourceGroupName $secondaryRG
        
        # Peering from Primary to Secondary Instance
        #$primarypeername = Get-AzVirtualNetworkPeering -ResourceGroupName $resourceGroupName -VirtualNetworkName $primaryVirtualNetwork.Name
        Write-host "`nPeering primary VNet to secondary VNet..." -ForegroundColor Cyan
            Add-AzVirtualNetworkPeering -Name $primary_secondary -VirtualNetwork $primaryVirtualNetwork -RemoteVirtualNetworkId $secondaryVirtualNetwork.Id -AllowForwardedTraffic -AllowGatewayTransit
        Write-host "`nPrimary VNet peered to secondary VNet successfully." -ForegroundColor Green

        # Peering from Secondary to Primary Instance
        Write-host "`nPeering secondary VNet to primary VNet..." -ForegroundColor Cyan
            Add-AzVirtualNetworkPeering -Name $secondary_primary -VirtualNetwork $secondaryVirtualNetwork -RemoteVirtualNetworkId $primaryVirtualNetwork.Id -AllowForwardedTraffic -AllowGatewayTransit #-UseRemoteGateways
        Write-host "`nSecondary VNet peered to primary VNet successfully." -ForegroundColor Green

        #Create failover group between the two servers
            #$primary_failover = Get-AzSqlDatabaseInstanceFailoverGroup -ResourceGroupName $resourceGroupName -Location $location
            Write-Host "Creating Failovergroup at $(Get-Date)" -ForegroundColor Green
            $failover = az sql instance-failover-group create --name $failoverGroupName --source-mi $servername --resource-group $resourceGroupName --partner-mi $secondaryservername --partner-resource-group $secondaryRG --failover-policy Automatic --grace-period 1
            Write-Host "Creating Failovergroup completed at $(Get-Date)" -ForegroundColor Green

            if($failover) {
                Write-Host "Failover group $failoverGroupName has been created successfully...!!!" -ForegroundColor Green
            }
            else {
                Write-Host "Failovergroup creation failed" -ForegroundColor Red
            }
    }
}
