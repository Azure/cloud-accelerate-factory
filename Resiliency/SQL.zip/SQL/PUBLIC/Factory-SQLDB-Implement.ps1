﻿CLS
#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------*
 
write-host "                                                                                                                                     " -BackgroundColor DarkMagenta
Write-Host "               Welcome to Factory Resiliency (High Availability and Disaster Recovery) for Azure SQL PaaS (SQL DB)                   " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                                                      (OSS DB Migration Factory)                                                     " -BackgroundColor DarkMagenta
write-host "                                                                                                                                     " -BackgroundColor DarkMagenta
Write-Host " "

$folder = $PSScriptRoot #"C:\Users\v-arunkumarg\Downloads\SQLMI\SQLMI"
$csvPath = Get-ChildItem -Path "$Folder\Output\" | Sort-Object CreationTime -Descending | select -First 1 #"$Folder\Output\SQL_HADR_Discovery_20250404_141549.csv"

Write-Host $csvPath.FullName -ForegroundColor Green

    # Check if the CSV path is valid
    if (-not (Test-Path $csvPath.FullName)) {
        Write-Host "Error: The specified CSV file path is invalid or does not exist." -BackgroundColor Red
        return
    }

    try {
        $csvData = Import-Csv -Path $csvPath.FullName

        $Approved_Rows = $csvData | Where-Object { $_.Authorize.ToUpper() -eq "YES" -and $_.Type -eq "SQL DB" }

        $exitcode=$false
        $backupredundancychk = ($Approved_Rows | Where-Object { ($_.BackupRedundancy -eq "Local") -and ((($_.Geo.ToUpper().trim() -eq "YES") -and ($_.Zone.ToUpper().trim() -eq "YES")) -or (($_.Geo.trim().length -eq 0) -and ($_.Zone.trim().length -eq 0))) } | Select-Object Server_Name).Server_Name
        if($backupredundancychk.Count -gt 0) {
            Write-Host "Please fill as 'Yes' for either Zone or Geo for the DB(s) [$($backupredundancychk -join ", ")]" -ForegroundColor Magenta
            $exitcode=$true
        }
        if($exitcode){
            Write-host "Please validate the input CSV. Kindly check and retrigger the automation"
            exitcode
        }

        $ConfigList = $Approved_Rows | Group-Object -Property 'Host_Name' | ForEach-Object { $_.Group }
    }
    catch {
        Write-Host "Error: Failed to read the CSV file. Please ensure it's correctly formatted." -BackgroundColor Red
        return
    }

    foreach ($entry in $ConfigList) {
        if($entry.Type -eq "SQL DB") {

            $servername          = $entry.Server_Name
            $DBName              = $entry.DB_Name
            $resourcegroup       = $entry.ResourceGroup
            $zoneredundant       = $entry.ZoneRedundant
            $location            = $entry.Location
            $failoverlocation    = $entry.FailoverLocation
            $servicetier         = $entry.ServiceTier
            $failovergroupname   = $entry.FailoverGroupName
            $secondaryservername = $entry.SecondaryServerName
            $secondaryRG         = $entry.SecondaryRG
            $secondaryserveruser = $entry.SecondaryServerUsername
            $secondaryserverpass = $entry.SecondaryServerPassword
            $zone                = $entry.Zone
            $geo                 = $entry.Geo
            $enableha            = $entry.EnableHA
            }

            $enableha = $entry.'EnableHA'
            if(($enableha -eq $null) -or ($enableha -eq "")) {
			    Write-Host "'EnableHA' is not valid/not exists for the '$servername server' in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			    Continue
		    }

            <#Write-Host $servername - $backupredundancy -ForegroundColor Green
            if(($backupredundancy -eq "Local") -and ($geo -eq $geo.ToUpper("yes")) -and ($zone -eq $zone.ToUpper("yes"))) {
                Write-Host "Please fill as 'Yes' for either Zone or Geo for the MI $servername" -ForegroundColor Magenta
                exitcode
            }
            elseif(($backupredundancy -eq "Local") -and ($geo -eq $geo.ToUpper("yes"))) {
                $backupredundancy = "Geo"
            }
            elseif(($backupredundancy -eq "Local") -and ($zone -eq $zone.ToUpper("yes"))) {
                $backupredundancy = "Zone"
            }
        
            #Write-Host "`n$servername - $backupredundancy" -ForegroundColor Cyan #>

            if($secondaryserverpass -ne $null) {
                #Write-Host $secondaryserverpass -ForegroundColor Magenta
                $secpasswd = ConvertTo-SecureString $secondaryserverpass -AsPlainText -Force
                $cred = New-Object System.Management.Automation.PSCredential ($secondaryserveruser, $secpasswd)
            }
            else {
                Write-Host "Secondary server password is empty, please enter password and try again" -ForegroundColor Red
            }
 
            #New-AzSqlServer -ResourceGroupName "MyResourceGroup" -ServerName "myuniquesqlservername" Location "East US" -AdministratorLogin $cred.UserName -AdministratorLoginPassword $cred.GetNetworkCredential().Password

                # SQL DB implementation
                Write-Host "Enabling HA and DR for [$($servername)]" -ForegroundColor Green
                if(($servicetier -eq "Basic") -or ($servicetier -like "*Premium*")) {
                    Set-AzSqlDatabase -ResourceGroupName $resourcegroup -ServerName $servername -DatabaseName $DBName -ZoneRedundant $zoneredundant
                }

                # Create secondary server
                if ($servername -notcontains $secondaryservername) {
                    New-AzSqlServer -ResourceGroupName $resourcegroup -ServerName $secondaryServerName -Location $failoverlocation -SqlAdministratorCredentials $cred #(New-Object -TypeName PSCredential -ArgumentList $secondaryserveruser, $secondaryserverpass)
                    Write-Host "`nSecondary server has been created successfully!!!" -ForegroundColor Green
                }
                else {
                    Write-Host "`nSecondary server name is already exists in primary!!!" -ForegroundColor Red
                }

                # Create failover group between the two servers
                    Write-Host "`nCreating FailoverGroup is in progress..." -ForegroundColor Green
                    $dbfailover = New-AzSqlDatabaseFailoverGroup -ResourceGroupName $resourcegroup -ServerName $servername -PartnerServerName $secondaryservername -FailoverGroupName $failovergroupname -FailoverPolicy Automatic -GracePeriodWithDataLossHours 1 -PartnerResourceGroupName $resourcegroup
                    $dbfailovername = $dbfailover.FailoverGroupName

                    if($dbfailover) {
                        Write-Host "`nNew AZ SQL DB Failover group $dbfailovername has been created" -ForegroundColor Green
                    }
                    else {
                        Write-Host "Failover group creation failed" -ForegroundColor Red
                    }


                # Adding database to failover group
                Set-AzSqlDatabaseFailoverGroup -ResourceGroupName $resourcegroup -ServerName $servername -FailoverGroupName $failovergroupname #-Database $DBName
    }
Write-Host "DB Implementation completed...!!!" -ForegroundColor Green