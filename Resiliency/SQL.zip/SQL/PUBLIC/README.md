# Steps To-Do:<br />

**OS Support**<br />
This script is compatible with the following operating systems:<br />
Windows 10 or later<br />
Linux RHEL v7 or later , Ubuntu v14 or later<br />

**Pre-requisites**<br />

Execute below prior running Powershell scripts<br />
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy bypass

***Windows***<br />
Powershell -   https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-windows?view=powershell-7.4<br /> 
Azure CLI (For Single Server and Microsoft Entra ID authentication only) - https://aka.ms/installazurecliwindows )<br /> 

***Linux***PENDING***<br />
Powershell - https://learn.microsoft.com/en-us/powershell/scripting/install/install-rhel?view=powershell-7.4<br /> 
Azure CLI (For Single Server and Microsoft Entra ID) - https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux/<br /> 

**Note**: - Add PATH in Enviornment Variables<br />

***Windows***<br />
Azure CLI  ( e.g. C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin )<br />

***Linux***<br />
Azure CLI  ( e.g. /usr/bin/az )<br />

## Step1. Azure CLI Info Gathering (Only for Azure Database for SQL Servers)
1.	Download the package zip file named `SQL-Resiliency.zip`
2.	Extract the `unzip SQL-Resiliency.zip` file.
3.	Open the Input file `Azure_Subscription.csv` (Provide the Tenant ID & Subscription ID, add Multiple rows for Multiple Subscriptions)  
4.	Execute `powershell.exe .\Factory-SQLDB-SQLMI-Discovery.ps1` (Windows)
5.	Upon completion, the script generates a CSV file named `Factory-SQL-HADR-Discovery.csv` in the Output directory. This file lists all SQL Servers within your subscriptions..
6.  Once execution completed, you can check the Output & Logs folders(contain execution log).

    Note:- Script support Multiple Subscription within single tenant. If you have multiple Tenent, follow each steps for individual Tenant.<br />
	       For any reason if you need to re-execute "Factory-PostgreSQL-CLI-Windows.ps1" script again...
		   Rename or clear the "output" folder before each execution to prevent overwritten output.

## Step2. Update Factory-SQL-HADR-Discovery.csv(For Resiliency)
"Type, Server_Name, DB_Name, Location, ResourceGroup, ServiceTier, BackupRedundancy, ZoneRedundantSupportability,ZoneRedundant,**"Zone(Yes/No)"**, **Authorize**"

**Note:-**<br />
. Highlighted are **Mandatory Fields**<br />
<br />
1. Authorize should be 'yes' for the servers(row in csv) you want to enable HA or read replica.
2. Depends on requirement, EnableHA and/or AddReplica should be set to TRUE for the individual servers.
   If both EnableHA and AddReplica are FALSE, the script skips the server, even when Approval_Status is yes. 
3. When AddReplica is set to TRUE, ReplicaServerName and ReplicaLocation should also be specified.
   If ReplicaServerName is specified and ReplicaLocation is left blank, the replica will be created in the same region as the source server.
   
   
## Step 3. Execute SQL Scripts for SQL DB or SQL MI
1. Once CSV has been updated as per step2, Execute `powershell.exe .\Factory-SQLDB-Implement.ps1`(for SQL DB) and `powershell.exe .\Factory-SQLMI-Implement.ps1`(for SQL MI)
2. Once the execution completed, you can check the output & Logs folder.

If there is/are any queries, please let us know, we will connect and check.


**Disclaimer:**
These scripts are intended for use of Info Gather Assessment utility and do not interact with the user databases or gather any sensitive information (e.g passwords, PI data etc.). 
These scripts are provided as-is to merely capture metadata information ONLY. While every effort has been made to ensure that accuracy and reliability of the scripts, 
it is recommended to review and test them in a non-production environment before deploying them in a production environment.
It is important to note that these scripts should be modified with consultation of Microsoft.