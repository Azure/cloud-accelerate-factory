#  Schedule       : Ad-Hoc / On-Demand
#  Date           : 16-june-2025
#  Author         : Rackimuthu Kandaswamy , Madan, Arun, Mukesh
#  Version        : 1.0
#   
#  INPUT          : NONE
#  VARIABLE       : NONE
#  PARENT         : NONE
#  CHILD          : NONE
 
 
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#
#  IMPORTANT NOTE : The script has to be run on Non-Mission-Critical systems ONLY and not on any production server...
#
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#Set-ExecutionPolicy Bypass -Scope currentuser
CLS
 
# Step 1: Setup environment
if ($psISE)
{
    $folder = Split-Path -Path $psISE.CurrentFile.FullPath 
}
else
{
    $folder=$PSScriptRoot
}

$today_date = Get-Date -Format "MM_dd_yyyy_HH_mm"
Write-Host "=============================================================================================================="
Start-Transcript -Path  "$folder\Logs\SQL_HADR_Discovery_Transcript_$today_date.txt" -Append
Write-Host "=============================================================================================================="

# Function to exit script with a message
function exitCode {
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}
CLS
# Function to create a folder if it doesn't exist
function createFolder([string]$newFolder) {
    if (Test-Path $newFolder) {
        Write-Host "-Folder '$newFolder' exists..."
    } else {
        New-Item $newFolder -ItemType Directory | Out-Null
        Write-Host "-$newFolder folder created..."
    }
}
# Define a mock Check-ZoneRedundancyCompatibility function (or replace it with your own)
function Check-ZoneRedundancyCompatibility {
    param (
        [string]$serviceTier
    )
    
    # Example logic for zone redundancy compatibility
    if ($serviceTier -ieq "Basic" -or $serviceTier -ieq "standard") {
        return $false
    } else {
        return $true
    }
}

CLS
#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------*
 
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to Factory - Enabling HA & DR for SQL DB & SQL MI              " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                     (OSS DB Migration Factory)                             " -BackgroundColor DarkMagenta
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host " "

# Create necessary folders
createFolder "$folder\Logs"
createFolder "$folder\Output"


$inputfile = $folder+"\Azure_Subscription.csv"

   

    # Check if the input CSV path exists
    if (-not (Test-Path $inputfile)) {
        Write-Host "Error: The specified input file does not exist. Please check the file path."
        return
    }

    # Import the CSV input file which contains Tenant ID and Subscription ID
    try {
        $inputCsv = Import-Csv -Path $inputfile
    }
    catch {
        Write-Host "Error reading the CSV file. Please check the file format and content."
        return
    }

    $TenantID = $inputCsv.TenantID
    $SubscriptionID = $inputCsv.SubscriptionID

    # Ensure Tenant ID and Subscription ID are provided
    if (-not $TenantID -or -not $SubscriptionID) {
        Write-Host "Error: Tenant ID and Subscription ID are required in the input file."
        return
    }

    # Login to Azure using the provided Tenant ID
    try {
        Write-Host "Logging into Azure with Tenant ID: $TenantID"
        #$loginoutput = az login --use-device-code --tenant $TenantID --only-show-errors
         $loginoutput = az login --tenant $TenantID
        if ($loginoutput) {
            Write-Host "Logged in successfully...!!!"
        } else {
            Write-Host "`n`nError: Login failed. Please check the Tenant & Subscription IDs in the Azure_Subscription.csv file" -ForegroundColor Red
            return
        }
    }
    catch {
        Write-Host "Error: Failed to log in with the provided Tenant ID."
        return
    }

   
Write-Host "=============================================================================================================="
Write-Host "Starting SQL HA/DR configuration..."  -ForegroundColor Green
Write-Host "=============================================================================================================="


# Step 1: Discovery Phase - Fetch SQL Databases, Managed Instances, and SQL Servers
Write-Host "Fetching SQL Databases, Managed Instances, and SQL Servers..." -ForegroundColor Green
$output = @()
   $sqlDatabases = @()
try {
    # Fetch SQL Managed Instances
    $sqlManagedInstances = az sql mi list --output json | ConvertFrom-Json

 
    # Fetch SQL Servers and Resource Groups
    $sqldbServers = az sql server list --output json | ConvertFrom-Json 
    $sqldbservercount = $sqldbServers.Count

 
    #$sqlDatabases = az sql server list --output json | ConvertFrom-Json 
 
    
    # Fetch SQL Databases
   foreach  ($sqldbServer in $sqldbServers) {
 #       $i=8
        $sqldbserverName = $sqldbServer.name #fullyQualifiedDomainName
        $rg = $sqldbServer.resourcegroup
       # Write-host "fatching server info for   $servname &    $rg" 

     # $rg="RG-ALLRegion-Racki-Team"
     # $sqldbserverName="sqldbhadr-jp"
        $SQLdatabaseList = az sql db list --resource-group $rg --server $sqldbserverName --output json | ConvertFrom-Json
   
    #$SQLdatabaseList[0]
    # Process SQL Databases
foreach ($sqlDatabases in $SQLdatabaseList) {
    $serverName       = $sqldbserverName
    $sqlDatabase      = $sqlDatabases.name
  
    $serviceTier      = $sqlDatabases.sku.tier
    $backupRedundancy = $sqlDatabases.currentBackupStorageRedundancy
    $location         = $sqlDatabases.location
    $resourceGroup    = $sqlDatabases.resourceGroup
    

    # Check Zone Redundancy Compatibility
    $ZoneRedundantSupportability = Check-ZoneRedundancyCompatibility $serviceTier

    # Create output object for SQL Database
    $outputObj = [PSCustomObject]@{
        "Type"                  = "SQL DB"
        "Server_Name"           = $serverName
        "DB_Name"               = $sqlDatabase
        "ResourceGroup"         = $resourceGroup
        "Location"              = $location
        "ServiceTier"           = $serviceTier
        "BackupRedundancy"      = $backupRedundancy
        "ZoneRedundantSupportability"  = $ZoneRedundantSupportability
          "ZoneRedundant"   = $null
     
        "Authorize"             = $null
    }
    if($outputObj.ServiceTier -ne "System") {
        $output+= $outputObj
    }
}



    }
    

}
catch {
    Write-Host "Error: Failed to fetch SQL Databases, Managed Instances, or SQL Servers." -BackgroundColor Red
    exit 1
}





# Process SQL Managed Instances
foreach ($sqlMI in $sqlManagedInstances) {
    $miName = $sqlMI.name
    $sqlMIName = $sqlMI.name
    $serviceTier = $sqlMI.sku.tier
    $backupRedundancy = $sqlMI.currentBackupStorageRedundancy
    $location = $sqlMI.location
    $resourceGroup = $sqlMI.resourceGroup

    # Check Zone Redundancy Compatibility
    $ZoneRedundantSupportability = Check-ZoneRedundancyCompatibility $serviceTier

    # Create output object for Managed Instance
    $outputObj = [PSCustomObject]@{
        "Type"                  = "SQL MI"
        "Server_Name"           = $miName
        "DB_Name"               = $miName
        "ResourceGroup"         = $resourceGroup
        "Location"              = $location
        "ServiceTier"           = $serviceTier
        "BackupRedundancy"      = $backupRedundancy
        "ZoneRedundantSupportability"   = $ZoneRedundantSupportability
        "ZoneRedundant"     = $null
        "Authorize"             = $null
       
    }
    $output += $outputObj
}

# Define output folder and CSV file path

$combinedCsv = "$folder\SQL_HADR_Discovery_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"



# Export output to CSV
try {
   $output|Select-Object Type, Server_Name, DB_Name, Location, ResourceGroup, ServiceTier, BackupRedundancy, ZoneRedundantSupportability,ZoneRedundant,"Zone(Yes/No)", Authorize | Export-Csv -NoTypeInformation -Path $combinedCsv -Force
    Write-Host "Discovery completed. Results exported to $combinedCsv" -ForegroundColor Green
}
catch {
    Write-Host "Error: Failed to export results to CSV. Ensure the file path is valid and accessible." -BackgroundColor Red
}
Stop-Transcript