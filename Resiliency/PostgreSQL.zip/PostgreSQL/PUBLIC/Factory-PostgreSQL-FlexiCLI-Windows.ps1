#---------------------------------------------------------------------------------------------------------------------------*
#  Purpose        : Script for Information gathering of Azure MySQL Flexi Server
#  Schedule       : Ad-Hoc / On-Demand
#  Date           : 25-Nov-2024
#  Author         : Rackimuthu Kandaswamy, ArunKumar, Lekshmy MK, Madan Agrawal
#  Version        : 2.1
#   
#  INPUT          : NONE
#  VARIABLE       : NONE
#  PARENT         : NONE
#  CHILD          : NONE
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#
#  IMPORTANT NOTE : The script has to be run on Non-Mission-Critical systems ONLY and not on any production server...
#
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
# Usage:
# Powershell.exe -File .\Factory-PostgreSQL-CLI-Windows.ps1
#
<#
    Change Log
    ----------
•	Customer consent to install Azure CLI
•	Progress bar addition with server in progress
•	Included Multi-subscription support        
#>

Set-ExecutionPolicy Bypass -Scope currentuser
clear-host


#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------

write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to Factory - PostgreSQL_Resiliency_Automation                  " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                     (OSS DB Migration Factory)                             " -BackgroundColor DarkMagenta
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host " "

if ($psISE)
{
    $folder = Split-Path -Path $psISE.CurrentFile.FullPath 
}
else
{
    $folder=$PSScriptRoot
}

$today_date=Get-Date -Format "MM_dd_yyyy_HH_mm"
Write-Host "=============================================================================================================="  
Start-Transcript -path  $folder\Logs\Factory-PostgreSQL_Info_Gathering_Automation_Transcript_$today_date.txt  -Append
Write-Host "=============================================================================================================="
   
function exitCode
{
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}

function createFolder([string]$newFolder) 
{
   if(Test-Path $newFolder)
    {
        Write-Host "-Folder'$newFolder' Exist..."
    }
    else
    {
        $cfolder=New-Item $newFolder -ItemType Directory
        Write-Host "-$newFolder folder created..."
    }
}

createFolder $folder\Logs\
createFolder $folder\Output\



# Read the input config CSV and validate
$inputfile = $folder+"\Azure_Subscription.csv"
Write-Host "Input file is $inputfile " -ForegroundColor Green
Write-Host "=============================================================================================================="  


if (-not(Test-Path -Path $inputfile -PathType Leaf)) 
{
    try 
    {    
        Write-Host "=============================================================================================================="   
        Write-Host "Unable to read the input file [$inputfile]. Check file & its permission...  "  -BackgroundColor Red
        Write-Host "=============================================================================================================="  
        Write-Host "Please see the error below Execution has been stopped          "  
        throw $_.Exception.Message                      
    }
    catch 
    {
        throw $_.Exception.Message
    }
}
else
{
    try 
    {
        $ConfigList = Import-CSV -Path $inputfile  
    }

    catch 
    {
        Write-Host "=============================================================================================================="  
        Write-Host "The file [$inputfile] does not have the woksheet named Azure_Subscription "  -BackgroundColor Red 
        Write-Host "=============================================================================================================="   
        Write-Host "Please see the error below & Azure PostgreSQL Resiliency has been stopped"  
        throw $_.Exception.Message
        exitcode
    }
}    
 
$ColumnList=$ConfigList | Get-Member -MemberType NoteProperty | %{"$($_.Name)"}

if (($ColumnList.Contains("Tenant")) -and
($ColumnList.Contains("Subscription_ID")))
{
    Write-Host "CSV validation is done successfully " 
}
else 
{
    Write-Host "There are mismatches in the CSV column . Kindly check and retrigger the automation "  -BackgroundColor Red
    exitCode
}


Unblock-File $folder/Validation_Scripts/Check_PowerShell_Version.ps1
Unblock-File $folder/Validation_Scripts/azurecli.ps1
      
# Check PowerShell version
$Validation=@()
$Outfiledata=@()
$Validation+=& "$folder/Validation_Scripts/Check_PowerShell_Version.ps1"
$Validation+=& "$folder/Validation_Scripts/azurecli.ps1"

Write-Host "=============================================================================================================="  
Write-Host "Below are the Validation Results"  -ForegroundColor Green  
Write-Host "=============================================================================================================="  
Write-Host ($Validation | select Validation_Type,Status,Comments | Format-Table | Out-String)

If($Validation.Status.Contains("FAILED"))
{
    Write-Host "There are errors during validation . Terminating the execution ."  -ForegroundColor Red
    exitcode  
}


$tenant=$ConfigList.Tenant|Get-Unique

if ([string]::IsNullOrWhitespace($tenant))
{
    Write-Host "Tenant listed Azure_Subscription worksheet is not valid. Kindly check and retrigger the automation  "  -BackgroundColor Red 
    exitCode
}
elseif($tenant.count -gt 1)
{
    Write-Host "Azure_Subscription.csv has multiple Tenant. This script doesn't support multiple Tenant but you can add multiple Subscription. `nKindly check and retrigger the automation for each Tenant separately."  -BackgroundColor Red 
    exitCode
}
else
{
    #AZ login to corresponsing Tenant and subscription
    #$loginoutput=az login --tenant $tenant --only-show-errors
    $loginoutput=az login --use-device-code --tenant $tenant --only-show-errors
}

if (!$loginoutput) 
{
    Write-Error "Error connecting to Tenant: $tenant"
    exitcode
}
$Subscriptions= $ConfigList.Subscription_ID|Sort-Object -Unique

foreach ($Subscription in $Subscriptions)
{

    if ([string]::IsNullOrWhitespace($Subscription))
    {
        Write-Host "$Subscription is not valid in the Azure_Subscription worksheet. Kindly check and retrigger the automation  "  -BackgroundColor Red 
        continue
    } 


    Write-Host "==============================================================================================================" 
    Write-Host "Processing Subscription: $Subscription" -ForegroundColor Green
    Write-Host "==============================================================================================================" 
   
    #AZ Connect to provided subscription
   
    $loginoutput=az account set --subscription $Subscription 2>&1
    $stat = $LASTEXITCODE


    If( $stat -ne 0)
    {
        Write-Host "Failed to execute [az account set --subscription $Subscription]" -ForegroundColor Red
        Write-Host "The file [$inputfile] does not have valid Subscription.`n"  -ForegroundColor Red
        continue
    }
     
    #Server list fetch for Flexi Server
    $Flexi_list_Out = az postgres flexible-server list | Out-File $folder\Output\Flexi_Server_List.json -Append
    $ser_details = az postgres flexible-server list|ConvertFrom-Json

    $count=  $ser_details.count
    $k=1

    if ($count -eq 0)
    {
        Write-Host "There is no PostgreSQL Flexible server on Subscription [$Subscription] for Tenant [$tenant]" -ForegroundColor Red
        Write-host "Please check Subscription on input file: Azure_Subscription.csv" -ForegroundColor Red
    }
    foreach ($i in $ser_details)
    {

      #Updating input file with server details
      $ServerName= $i.name
      $Flexi_User_Name = $i.administratorLogin
      $ser_rg = $i.resourceGroup  
      $domain_name = $i.fullyQualifiedDomainName
      $dom = $domain_name.Split(".")
      $ser_dom = $dom[0]
      $Logon_User=$Flexi_User_Name + "@" + $ser_dom
      $sku=$i.sku.name
      $tier=$i.sku.tier
      $Location=$i.Location
	  $storageSizeGb=$i.storage.storageSizeGb
      $userVisibleState=$i.state
      $HA=$i.highAvailability.mode
      $replicationRole=$i.replicationRole
      $geoRedundantBackup=$i.backup.geoRedundantBackup
      $StorageAutoGrow=$i.storage.autoGrow
      $sourceServerResourceId =  $i.sourceServerResourceId
	  $version=$i.version

      $zrhasupport = az postgres flexible-server list-skus --location $Location
      $zrhasupport = $zrhasupport | ConvertFrom-Json

      $zrhaenableornot = $zrhasupport.zoneRedundantHaSupported
      
      $per_complete=[math]::round($k/$count*100)

 
      Write-Progress -Activity "Server:$ServerName is in Progress..." -Status "$per_complete% Complete:" -PercentComplete $per_complete
      $k++
      $Outfiledata+=New-Object psobject -Property @{Host_Name=$ServerName;Version=$version;Resource_Group=$ser_rg;Status=$userVisibleState;sku=$sku;tier=$tier;Location=$Location;storageSizeGb=$storageSizeGb;HA_Mode=$HA;replicationRole=$replicationRole;sourceServerResourceId=$sourceServerResourceId;geoRedundantBackup=$geoRedundantBackup;StorageAutoGrow=$StorageAutoGrow;Recommendation="";EnableHAMode="";Tenant=$tenant;Subscription_ID=$Subscription;EnableHA="False";AddReplica="False";Approval_Status="No"}
      if ($userVisibleState -notmatch "Ready")
      {           
        Write-Host "PostgreSQL Flexi server [$ServerName] is in ""$userVisibleState"" state. To enable HA or to add a replica, Server should be in Ready state." -ForegroundColor Red
      }
  }
}

if($Outfiledata -ne $null)
{
    $Outfiledata | select Host_Name,Version,Resource_Group,Status,sku,tier,Location,storageSizeGb,HA_Mode,replicationRole,sourceServerResourceId,geoRedundantBackup,StorageAutoGrow,tenant,Subscription_ID,Recommendation,EnableHA,EnableHAMode,AddReplica,ReplicaServerName, ReplicaLocation,Approval_Status | Export-Csv -NoTypeInformation $folder\Factory_PostgreSQL_Flexi_Server_Input_file.csv
}
Write-Host "=============================================================================================================="  
Write-Host "Information gathered ==> $folder\ " -ForegroundColor Green -BackgroundColor Black
Write-Host "PostgreSQL Flexible Server List created ==> $folder\Factory_PostgreSQL_Flexi_Server_Input_file.csv" -ForegroundColor Green -BackgroundColor Black
Write-Host "Update mandatory fields along with ""Approval_Status"" column in above CSV and execute script ""Factory_PostgreSQL_EnableHA_AddReplica-Windows.ps1"" to enable HA or add a replica." -ForegroundColor Yellow -BackgroundColor Black
Write-Host "==============================================================================================================" 


exitcode
