#!/usr/bin/pwsh
Set-ExecutionPolicy Bypass -Scope Process -Force
Clear-Host

#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------

Write-Host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to Factory - PostgreSQL_Resiliency_Automation (Linux Version)  " -ForegroundColor White -BackgroundColor DarkMagenta
Write-Host "                     (OSS DB Migration Factory)                             " -BackgroundColor DarkMagenta
Write-Host "                                                                            " -BackgroundColor DarkMagenta
Write-Host " "

# Detect folder path
if ($PSCommandPath) {
    $folder = Split-Path -Parent $PSCommandPath
}
else {
    $folder = (Get-Location).Path
}

$today_date = Get-Date -Format "MM_dd_yyyy_HH_mm"
Write-Host "=============================================================================================================="
Start-Transcript -Path "$folder/Logs/Factory-PostgreSQL_Info_Gathering_Automation_Transcript_$today_date.txt" -Append
Write-Host "=============================================================================================================="

function exitCode {
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}

function createFolder([string]$newFolder) {
    if (Test-Path $newFolder) {
        Write-Host "-Folder '$newFolder' exists..."
    }
    else {
        New-Item -ItemType Directory -Path $newFolder | Out-Null
        Write-Host "-$newFolder folder created..."
    }
}

# Folder structure
createFolder "$folder/Logs/"
createFolder "$folder/Output/"

# Read the input config CSV and validate
$inputfile = "$folder/Azure_Subscription.csv"
Write-Host "Input file is $inputfile " -ForegroundColor Green
Write-Host "=============================================================================================================="

if (-not (Test-Path -Path $inputfile -PathType Leaf)) {
    Write-Host "=============================================================================================================="
    Write-Host "Unable to read the input file [$inputfile]. Check file & permissions..." -BackgroundColor Red
    Write-Host "=============================================================================================================="
    exitCode
}
else {
    try {
        $ConfigList = Import-Csv -Path $inputfile
    }
    catch {
        Write-Host "=============================================================================================================="
        Write-Host "The file [$inputfile] is invalid or unreadable." -BackgroundColor Red
        Write-Host "=============================================================================================================="
        exitCode
    }
}

$ColumnList = $ConfigList | Get-Member -MemberType NoteProperty | ForEach-Object { $_.Name }

if (($ColumnList.Contains("Tenant")) -and ($ColumnList.Contains("Subscription_ID"))) {
    Write-Host "CSV validation successful"
}
else {
    Write-Host "There are mismatches in the CSV columns. Kindly check and retry." -BackgroundColor Red
    exitCode
}

# Unblock equivalent not required in Linux
# Check validations
$Validation = @()
$Outfiledata = @()

$Validation += & "$folder/Validation_Scripts/Check_PowerShell_Version.ps1"
$Validation += & "$folder/Validation_Scripts/azurecli_linux.ps1"

Write-Host "=============================================================================================================="
Write-Host "Below are the Validation Results" -ForegroundColor Green
Write-Host "=============================================================================================================="
Write-Host ($Validation | Select-Object Validation_Type, Status, Comments | Format-Table | Out-String)

If ($Validation.Status -contains "FAILED") {
    Write-Host "There are errors during validation. Terminating execution." -ForegroundColor Red
    exitCode
}

$tenant = $ConfigList.Tenant | Get-Unique

if ([string]::IsNullOrWhiteSpace($tenant)) {
    Write-Host "Tenant value in Azure_Subscription.csv is not valid. Kindly check and retry." -BackgroundColor Red
    exitCode
}
elseif ($tenant.Count -gt 1) {
    Write-Host "Azure_Subscription.csv has multiple Tenants. This script supports only one Tenant at a time." -BackgroundColor Red
    exitCode
}
else {
    Write-Host "Logging in to Azure Tenant: $tenant"
    $loginoutput = az login --use-device-code --tenant $tenant --only-show-errors 2>&1
}

if (!$loginoutput) {
    Write-Error "Error connecting to Tenant: $tenant"
    exitCode
}

$Subscriptions = $ConfigList.Subscription_ID | Sort-Object -Unique

foreach ($Subscription in $Subscriptions) {

    if ([string]::IsNullOrWhiteSpace($Subscription)) {
        Write-Host "$Subscription is not valid in the input file. Kindly check and retry." -BackgroundColor Red
        continue
    }

    Write-Host "=============================================================================================================="
    Write-Host "Processing Subscription: $Subscription" -ForegroundColor Green
    Write-Host "=============================================================================================================="

    az account set --subscription $Subscription 2>&1
    $stat = $LASTEXITCODE

    If ($stat -ne 0) {
        Write-Host "Failed to execute [az account set --subscription $Subscription]" -ForegroundColor Red
        Write-Host "The file [$inputfile] does not have valid Subscription." -ForegroundColor Red
        continue
    }

    # Server list fetch for Flexible Server
    az postgres flexible-server list | Out-File "$folder/Output/Flexi_Server_List.json" -Append
    $ser_details = az postgres flexible-server list | ConvertFrom-Json

    $count = $ser_details.Count
    $k = 1

    if ($count -eq 0) {
        Write-Host "No PostgreSQL Flexible server found in Subscription [$Subscription] for Tenant [$tenant]" -ForegroundColor Red
        continue
    }

    foreach ($i in $ser_details) {
        $ServerName = $i.name
        $Flexi_User_Name = $i.administratorLogin
        $ser_rg = $i.resourceGroup
        $domain_name = $i.fullyQualifiedDomainName
        $ser_dom = $domain_name.Split(".")[0]
        $Logon_User = "$Flexi_User_Name@$ser_dom"
        $sku = $i.sku.name
        $tier = $i.sku.tier
        $Location = $i.Location
        $storageSizeGb = $i.storage.storageSizeGb
        $userVisibleState = $i.state
        $HA = $i.highAvailability.mode
        $replicationRole = $i.replicationRole
        $geoRedundantBackup = $i.backup.geoRedundantBackup
        $StorageAutoGrow = $i.storage.autoGrow
        $sourceServerResourceId = $i.sourceServerResourceId
        $version = $i.version

        $zrhasupport = az postgres flexible-server list-skus --location $Location | ConvertFrom-Json
        $zrhaenableornot = $zrhasupport.zoneRedundantHaSupported

        $per_complete = [math]::Round(($k / $count) * 100)
        Write-Progress -Activity "Server: $ServerName is in progress..." -Status "$per_complete% Complete:" -PercentComplete $per_complete
        $k++

        $Outfiledata += [pscustomobject]@{
            Host_Name            = $ServerName
            Version              = $version
            Resource_Group       = $ser_rg
            Status               = $userVisibleState
            sku                  = $sku
            tier                 = $tier
            Location             = $Location
            storageSizeGb        = $storageSizeGb
            HA_Mode              = $HA
            replicationRole      = $replicationRole
            sourceServerResourceId = $sourceServerResourceId
            geoRedundantBackup   = $geoRedundantBackup
            StorageAutoGrow      = $StorageAutoGrow
            Recommendation       = ""
            EnableHAMode         = ""
            Tenant               = $tenant
            Subscription_ID      = $Subscription
            EnableHA             = "False"
            AddReplica           = "False"
            Approval_Status      = "No"
        }

        if ($userVisibleState -notmatch "Ready") {
            Write-Host "PostgreSQL Flexi server [$ServerName] is in '$userVisibleState' state. To enable HA or add a replica, the server must be in Ready state." -ForegroundColor Red
        }
    }
}

if ($Outfiledata -ne $null) {
    $Outfiledata | Select-Object Host_Name, Version, Resource_Group, Status, sku, tier, Location, storageSizeGb, HA_Mode, replicationRole, sourceServerResourceId, geoRedundantBackup, StorageAutoGrow, Tenant, Subscription_ID, Recommendation, EnableHA, EnableHAMode, AddReplica, Approval_Status |
    Export-Csv -NoTypeInformation "$folder/Factory_PostgreSQL_Flexi_Server_Input_file.csv"
}

Write-Host "=============================================================================================================="
Write-Host "Information gathered ==> $folder/" -ForegroundColor Green -BackgroundColor Black
Write-Host "PostgreSQL Flexible Server List created ==> $folder/Factory_PostgreSQL_Flexi_Server_Input_file.csv" -ForegroundColor Green -BackgroundColor Black
Write-Host 'Update mandatory fields and "Approval_Status" column in the CSV, then run "Factory_PostgreSQL_EnableHA_AddReplica-Linux.ps1" to enable HA or add a replica.' -ForegroundColor Yellow -BackgroundColor Black
Write-Host "=============================================================================================================="

exitCode
