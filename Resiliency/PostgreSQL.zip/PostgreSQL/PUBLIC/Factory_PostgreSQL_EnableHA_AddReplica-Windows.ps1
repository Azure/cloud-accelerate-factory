﻿#  Schedule       : Ad-Hoc / On-Demand
#  Date           : 16-june-2025
#  Author         : Rackimuthu Kandaswamy , Madan, Arun, Mukesh
#  Version        : 1.0
#   
#  INPUT          : NONE
#  VARIABLE       : NONE
#  PARENT         : NONE
#  CHILD          : NONE
 
 
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#
#  IMPORTANT NOTE : The script has to be run on Non-Mission-Critical systems ONLY and not on any production server...
#
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#Set-ExecutionPolicy Bypass -Scope currentuser
#az login --tenant $tenant --only-show-errors
#
CLS

# Step 1: Setup environment
if ($psISE)
{
    $folder = Split-Path -Path $psISE.CurrentFile.FullPath 
}
else
{
    $folder=$PSScriptRoot
}

$today_date = Get-Date -Format "MM_dd_yyyy_HH_mm"

Write-Host "=============================================================================================================="
Start-Transcript -Path  "$folder\Logs\SQL_HADR_Discovery_Transcript_$today_date.txt" -Append
Write-Host "=============================================================================================================="

# Function to exit script with a message
function exitCode {
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}
# Function to create a folder if it doesn't exist
function createFolder([string]$newFolder) {
    if (Test-Path $newFolder) {
        Write-Host "-Folder '$newFolder' exists..."
    } else {
        New-Item $newFolder -ItemType Directory | Out-Null
        Write-Host "-$newFolder folder created..."
    }
}

# function to Check if database is already zone redundant
function Check-SQLDBZoneRedundancy {
    param (
        [string]$RG,
        [string]$dbname
    )
    
     $DBMetaData = az postgres db show -g $RG -n $dbname |ConvertFrom-Json
       # $DBMetaData = az sql mi show -g RG-APAC-RupeshSingh -n demosqlmi1603 |ConvertFrom-Json

    # Example logic for zone redundancy compatibility
   
        return $DBMetaData.zoneRedundant
    
}


<#function Check-SQLMIZoneRedundancy {
    param (
        [string]$RG,
        [string]$dbname
    )
    
     $DBMetaData = az postgres mi show -g $RG -n $dbname |ConvertFrom-Json
       # $DBMetaData = az sql mi show -g RG-APAC-RupeshSingh -n demosqlmi1603 |ConvertFrom-Json

    # Example logic for zone redundancy compatibility
   
        return $DBMetaData.zoneRedundant
    
}
#>





# function to Check if database is already zone redundant
function ExecuteCLI {
    param (
        [string]$command
    )
    
    try {

       $command1=$command.Substring(0, $command.Length - 5)
       $output=Invoke-Expression $command
      # $command="az sql db update -g RG-ALLRegion-Racki-Team -s sqldbhadr-jp  -n gildasqldb --backup-storage-redundancy zone 2>&1"

    if ($LASTEXITCODE -eq 0) {
        $message = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - SUCCESS:""$command1"" executed successfully."
        Write-Host $message -ForegroundColor Green
        return $true
      
    } 
else {
        throw $output
    }

}

catch {
   # $errorMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - ERROR: Failed to update Managed Instance '$servername'. Details: $($_)"
 $errorMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - ERROR: Failed to execute ""$command1"". `nDetails: $($_)"

        Write-Host $errorMessage -ForegroundColor Red

    return $false   
}
   
       
    
}
  



#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------*
 
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to Factory - Enable Zone redundancy for POSTGRESQL Flexible    " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                     (Cloud Accelerate Factory)                             " -BackgroundColor DarkMagenta
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "============================================================================"

# Create necessary folders
createFolder "$folder\Logs"
createFolder "$folder\Output"

$InputCsv = "$folder\Factory_PostgreSQL_Flexi_Server_Input_file.csv"
  

    <# Check if the input CSV path exists
    if (-not (Test-Path $InputCsv)) {
        Write-Host "Error: The specified input file $InputCsv does not exist. Please check the file path." -ForegroundColor Red
        return
    }
    #>
    
    try {
        $csvData = Import-Csv -Path $InputCsv

        $Approved_Rows = $csvData | Where-Object { $_.Approval_Status.toupper() -eq "YES" }

       # $ConfigList = $Approved_Rows | Group-Object -Property 'Host_Name' | ForEach-Object { $_.Group }
    }
    catch {
        Write-Host "Error: The CSV file $InputCsv could not be read. Please ensure that the file is in the correct format and accessible!!!" -BackgroundColor Red
        return
    }


    if($Approved_Rows.Host_Name.count -ge 1)
    {
      Write-Host "============================================================================"
      Write-host "`nThe following PostgreSQL Flexible servers are authorized for enabling zone redundancy."
      $Approved_Rows |select Host_Name,Resource_Group,StorageAutoGrow,EnableHA,AddReplica,Approval_Status |  Format-Table
      Write-host "StorageAutoGrow will be updated as per input CSV file." -ForegroundColor Cyan
      $validInputs_Yes_No = "y", "n"
     
          
            
            do {
            
              $response = read-host "Please press 'Y' to proceed or 'N' to terminate the execution"
            if(-not $validInputs_Yes_No.Contains($response)){
            #write-host "Please Enter a valid input (Y or N )"
            } 
    
            }until ($validInputs_Yes_No.Contains($response.ToLower()))
             if($response -eq "n"){exitcode}

   }
   else
   {
        Write-host "None of PostgreSQL servers are approved to enable zone redundant. Please review Input file and re-run the script again." -BackgroundColor red
   }

     foreach ($AzurePostgreSQL in $Approved_Rows) { 

 
            $Host_Name                      = $AzurePostgreSQL.Host_Name  
            $Subscription                   = $AzurePostgreSQL.Subscription_ID
            $Location                       = $AzurePostgreSQL.Location
            $resourcegroup                  = $AzurePostgreSQL.Resource_Group
            $sku                            = $AzurePostgreSQL.sku
            $tier                           = $AzurePostgreSQL.tier
            $geoRedundantBackup             = $AzurePostgreSQL.geoRedundantBackup
            $replicationRole                = $AzurePostgreSQL.replicationRole
            $StorageAutoGrow                = $AzurePostgreSQL.StorageAutoGrow
            $EnableHA                       = $AzurePostgreSQL.EnableHA
            $AddReplica                     = $AzurePostgreSQL.AddReplica
            $ReplicaServerName              = $AzurePostgreSQL.ReplicaServerName
            $ReplicaLocation                = $AzurePostgreSQL.ReplicaLocation
           
     
      # Setting subscription as per input file
           
           $loginoutput=az account set --subscription $Subscription 2>&1
           $stat = $LASTEXITCODE
           
            If( $stat -ne 0)
                {
                   # seems to have failed
                   #$errorMessage = $Error[0].Exception.Message
                     Write-Host "Failed to execute [az account set --subscription $Subscription]" -ForegroundColor Red
                     Write-Host "The file [$inputfile] does not have valid Subscription.`n"  -ForegroundColor Red
                    continue
                }



               Write-Host "============================================================================"
               Write-Host "Processing PostgreSQL Flexible server [$Host_Name] " -ForegroundColor yellow
               Write-Host "============================================================================"
               
                if( $replicationRole -ieq "Replica")
                {
                Write-host "High availability/Read Replica is not supported for replica server [$Host_Name]." -ForegroundColor Red
                continue
                }

                if( $tier -ieq "Burstable")
                {
                Write-host "Please Change Server [$Host_Name] Compute tier to either GeneralPurpose or BusinessCritical and rerun the automation!" -ForegroundColor Red
                continue
                }

                if( $EnableHA -ieq "false" -and $AddReplica -ieq "false")
                {
                Write-host "High availability/Read Replica are not opted to enable on input CSV file. Skipping server [$Host_Name]" -ForegroundColor Red
                continue
                }

#Checking for HA enable requirement.
  if  ($EnableHA  -ieq "true")
    {
        Write-Host "`nProcessing server $Host_Name for Zone Redundancy" -ForegroundColor Yellow
    
        $HACheck=az postgres flexible-server show --resource-group $resourcegroup --name $Host_Name --query "highAvailability.mode" --output tsv
        if($HACheck -ieq "Disabled")
        {
          #checking current storage autogrow staus
          Write-Host "Checking for storage autogrow on [$Host_Name] " -ForegroundColor yellow
            $current_StorageAutoGrow=az postgres flexible-server show --resource-group $resourcegroup --name $Host_Name --query "storage.autoGrow" --output tsv

            if  ($current_StorageAutoGrow -ieq "Disabled")
            {
            if($StorageAutoGrow -ieq "Enabled" -or $StorageAutoGrow -ieq "Enable")
            {
            Write-host "Enabling Storage AutoGrow for server [$Host_Name]" 
            #$ag=az postgres flexible-server update --resource-group $resourcegroup --name $Host_Name --storage-auto-grow Enabled --output tsv
            $ag=az postgres flexible-server update --resource-group $resourcegroup --name $Host_Name --storage-auto-grow Enabled  #| ConvertFrom-Json
            #$autoGrow = $ag.storage.autoGrow


            $AutoGrow = $ag -replace "'",'"'

            # $AutoGrow = "[" + $Autogrow + "]"
             $AutoGrow= $AutoGrow | ConvertFrom-Json
             if($AutoGrow.storage.autoGrow -ieq "Enabled")
             {
              Write-host "Storage AutoGrow is enabled Succcessfully on [$Host_Name]"  -ForegroundColor green
             }

            }
            Else
            {
             Write-host "Please Confirm to Enable Storage AutoGrow for server [$Host_Name] in input CSV file"
             continue
            }
            }
            else
            {
             Write-host "Storage AutoGrow is already enabled on [$Host_Name]"  -ForegroundColor green
            }

            Write-Host "Enabling same zone HA for PostgreSQL Flexible [$Host_Name] " -ForegroundColor yellow
            $command = "az postgres flexible-server update --resource-group $resourcegroup --name $Host_Name --high-availability SameZone 2>&1"

            $value = ExecuteCLI -command $command 

        $ZoneRedunantData = @()
                   
        if($value -ieq "True")
        {
            $SamezoneHA=az postgres flexible-server show --resource-group $resourcegroup --name $Host_Name --query "highAvailability.mode" --output tsv
    
            if( $SamezoneHA -ieq "SameZone")
            {
              $ZoneRedunantData += New-Object psobject -Property @{Host_Name=$Host_Name;Resource_Group= $resourcegroup;HA_Mode=$SamezoneHA;Status="Success"}
            }

        }
        else
        {
           $ZoneRedunantData += New-Object psobject -Property @{Host_Name=$Host_Name;Resource_Group= $resourcegroup;HA_Mode=$SamezoneHA;Status="Failed"}
        }
            #az mysql flexible-server update --resource-group $resourcegroup --name $Host_Name --high-availability ZoneRedundant
  
      }   #az : ERROR: This region is single availability zone. Zone redundant high availability is not supported in a single availability zone region.
        else
        {
         Write-Host "HA is already enabled for PostgreSQL Flexible [$Host_Name] " -ForegroundColor Green
        }
    }

    

#Checking for Replication(read replica) enable requirement.

  if  ($AddReplica  -ieq "true")
    {
  Write-Host "`nProcessing server $Host_Name for Read Replication" -ForegroundColor Yellow

    if( $ReplicaServerName -eq "")
    {
    Write-host "Please add Replica ServerName in Input CSV file and rerun the script." -ForegroundColor Red
    continue
    }
    
    if($ReplicaLocation  -eq $null)
      {
      $ReplicaLocation  =  $Location   
      }
  #az mysql flexible-server replica create --replica-name  $ReplicaServerName --resource-group $resourcegroup  --source-server $Host_Name  --location $ReplicaLocation 
   $replica= "az postgres flexible-server replica create --replica-name  $ReplicaServerName --resource-group $resourcegroup  --source-server $Host_Name  --location '$Location' 2>&1" 
    $value = ExecuteCLI -command $replica
                        
if($value -ieq "True")
{
Write-host "Read Replica [$ReplicaServerName] has been successfully created for source server  $Host_Name" -ForegroundColor Green
 $ReadReplicaData+=New-Object psobject -Property @{Host_Name=$Host_Name;Resource_Group= $resourcegroup;Read_Replica=$ReplicaServerName;Status="Success"}
}  
else{
 $ReadReplicaData+=New-Object psobject -Property @{Host_Name=$Host_Name;Resource_Group= $resourcegroup;Read_Replica=$ReplicaServerName;Status="Failed"}
}
  }
  
  if  ($ZoneRedunantData -ne $null)
  {
      Write-Host "============================================================================"
        Write-Host "Here is the final status of Zone Redundancy Execution"
      Write-Host "============================================================================"
  $ZoneRedunantData | select Host_Name,Resource_Group,HA_Mode,Status | Format-Table -Autosize
    
      }
        if  ($ReadReplicaData -ne $null)
  {
      Write-Host "============================================================================"
        Write-Host "Here is the final status of Read Replica Execution"
      Write-Host "============================================================================"
  $ReadReplicaData | select Host_Name,Resource_Group,Read_Replica,Status | Format-Table -Autosize
    
      }
            }
  Write-Host "============================================================================"            
exitCode

