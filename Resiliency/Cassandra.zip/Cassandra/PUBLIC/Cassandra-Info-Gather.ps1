﻿# Schedule       : Ad-Hoc / On-Demand
# Date           : 06-AUG-2025
# Author         : Rackimuthu Kandaswamy,Sharad, ArunKumar, Mukesh
# Version        : 0.1 (Cross-Platform)

# INPUT          : NONE
# VARIABLE       : NONE
# PARENT         : NONE
# CHILD          : NONE

# ---------------------------------------------
# IMPORTANT NOTE : For Non-Production use only!
# ---------------------------------------------

# --------------------------------------------------- SETUP ------------------------------------------------------------


Set-ExecutionPolicy Bypass -Scope currentuser
CLS

#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------

write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to cassandra  Information Gathering Automation                 " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host " "



# Parameters
$resourceGroupName = "RG-ALLRegion-Sharad-Team"
$outputFolder = "$PSScriptRoot\CassandraDiscovery"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outputCsv = "$outputFolder\Cassandra_Discovery_$timestamp.csv"
$jsonDebug = "$outputFolder\RawClusterData_$timestamp.log"

# Ensure output folder exists
if (-not (Test-Path $outputFolder)) {
    New-Item -Path $outputFolder -ItemType Directory -Force | Out-Null
}

# Counters for summary
$totalClusters    = 0
$totalDatacenters = 0

# Get Cassandra clusters in the resource group
Write-Host "Fetching Cassandra clusters in resource group '$resourceGroupName'..." -ForegroundColor Cyan
$clustersJson = az managed-cassandra cluster list --resource-group $resourceGroupName --output json
$clusters = $clustersJson | ConvertFrom-Json

# Save raw cluster JSON for debugging
$clustersJson | Out-File -FilePath $jsonDebug -Force

if (-not $clusters -or $clusters.Count -eq 0) {
    Write-Host " No Cassandra clusters found in resource group '$resourceGroupName'." -ForegroundColor Red
    return
}

# Output collection
$output = @()

foreach ($cluster in $clusters) {
    $totalClusters++
    $clusterName = $cluster.name
    $clusterLocation = $cluster.location
    $clusterresourceGroup= $cluster.resourceGroup
    $clusterazureConnectionMethod= $cluster.properties.azureConnectionMethod
    $clusterbackupRetentionPeriodInHours= $cluster.properties.backupRetentionPeriodInHours
    $clusterbackupSchedules= $cluster.properties.backupSchedules
    $clustercassandraAuditLoggingEnabled= $cluster.properties.cassandraAuditLoggingEnabled
    $clustercassandraVersion= $cluster.properties.cassandraVersion
    $clusterclusterType= $cluster.properties.clusterType
    $clusterdelegatedManagementSubnetId= $cluster.properties.delegatedManagementSubnetId
    $clusterextensions= $cluster.properties.extensions
    $clusterexternalDataCenters= $cluster.properties.externalDataCenters
    $clusterexternalSeedNodes= $cluster.properties.externalSeedNodes
    $clusterrepairEnabled= $cluster.properties.repairEnabled
    $clusterprovisioningState = $cluster.properties.provisioningState

    Write-Host "`nFound cluster: $clusterName (Location: $clusterLocation)" -ForegroundColor Cyan

    # Get datacenters
    $dcJson = az managed-cassandra datacenter list --resource-group $resourceGroupName --cluster-name $clusterName --output json
    $datacenters = $dcJson | ConvertFrom-Json

    # Save raw datacenter data per cluster
    $dcJson | Out-File "$outputFolder\Datacenter_${clusterName}_$timestamp.log" -Force

    if (-not $datacenters -or $datacenters.Count -eq 0) {
        Write-Host " No datacenters found for cluster '$clusterName'" -ForegroundColor Yellow
        continue
    }

    foreach ($dc in $datacenters) {
        $totalDatacenters++

        # Extract values safely
        $nodeCount    = $dc.properties.nodeCount
        $sku          = $dc.properties.sku
        $diskGb       = $dc.properties.diskCapacity
        $az           = $dc.properties.availabilityZone
        $externalSeed = $dc.properties.seedNodes

        # Construct data row
        $outputObj = [PSCustomObject]@{
            Cluster_Name          = $clusterName
            Datacenter_Name       = $dc.name
            Location              = $clusterLocation
            ResourceGroup         = $clusterresourceGroup
            azureConnectionMethod = $clusterazureConnectionMethod
            backupRetentionPeriodInHours = $clusterbackupRetentionPeriodInHours
            backupSchedules       = ($clusterbackupSchedules | ConvertTo-Json -Compress)
            cassandraAuditLoggingEnabled = $clustercassandraAuditLoggingEnabled
            cassandraVersion      = $clustercassandraVersion
            clusterType           = $clusterclusterType
            delegatedManagementSubnetId = $clusterdelegatedManagementSubnetId
            extensions            = ($clusterextensions | ConvertTo-Json -Compress)
            externalDataCenters   = ($clusterexternalDataCenters | ConvertTo-Json -Compress)
            externalSeedNodes     = ($clusterexternalSeedNodes | ConvertTo-Json -Compress)
            repairEnabled         = $clusterrepairEnabled
            provisioningState     = $clusterprovisioningState
            Node_Count            = $nodeCount
            SKU                   = $sku
            Disk_Capacity_GB      = $diskGb
            Availability_Zone     = $az
            External_Seed_Nodes   = ($externalSeed | ConvertTo-Json -Compress)
        }

        $output += $outputObj
    }
}



# Summary presentation
Write-Host "`n==================== SUMMARY ====================" -ForegroundColor White
Write-Host ("Cluster: {0} | Datacenters: {1}" -f $clusterName, $dcCount) -ForegroundColor Green
Write-Host "CSV Output File          : $outputCsv" -ForegroundColor Yellow
Write-Host "JSON Debug File          : $jsonDebug" -ForegroundColor Yellow
Write-Host "==================================================" -ForegroundColor White

# Per-cluster datacenter count
$output | Group-Object Cluster_Name | ForEach-Object {
    $clusterName = $_.Name
    $dcCount = $_.Count
}

# Export to CSV
if ($output.Count -gt 0) {
    $output | Export-Csv -NoTypeInformation -Path $outputCsv -Force
    Write-Host "`nCassandra discovery completed." -ForegroundColor Green
} else {
    Write-Host "`nNo datacenter data found to export." -ForegroundColor Yellow
}
