﻿CLS
#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------

write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to Factory - MongoDB vCore Resiliency Automation               " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                     (OSS DB Migration Factory)                             " -BackgroundColor DarkMagenta
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host " "

$folder = $PSScriptRoot

function exitCode
{
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}

function createFolder([string]$newFolder) 
{
   if(Test-Path $newFolder)
    {
        Write-Host "-Folder'$newFolder' Exist..."
    }
    else
    {
        $cfolder=New-Item $newFolder -ItemType Directory
        Write-Host "-$newFolder folder created..."
    }
}

createFolder $folder\Logs\
createFolder $folder\Output\

$today_date=Get-Date -Format "MM_dd_yyyy_HH_mm"
Write-Host "=============================================================================================================="  
Start-Transcript -path  $folder\Logs\Factory-MongovCore_Info_Gathering_Automation_Transcript_$today_date.txt  -Append
Write-Host "=============================================================================================================="


# Read the input config CSV and validate
$inputfile = $folder+"\Azure_Subscription.csv"
Write-Host "Input file is $inputfile " -ForegroundColor Green
Write-Host "=============================================================================================================="  


if (-not(Test-Path -Path $inputfile -PathType Leaf)) 
{
    try 
    {    
        Write-Host "=============================================================================================================="   
        Write-Host "Unable to read the input file [$inputfile]. Check file & its permission...  "  -BackgroundColor Red
        Write-Host "=============================================================================================================="  
        Write-Host "Please see the error below Execution has been stopped          "  
        throw $_.Exception.Message                      
    }
    catch 
    {
        throw $_.Exception.Message
    }
}
else
{
    try 
    {
        $ConfigList = Import-CSV -Path $inputfile  
    }

    catch 
    {
        Write-Host "=============================================================================================================="  
        Write-Host "The file [$inputfile] does not have the woksheet named Azure_Subscription "  -BackgroundColor Red 
        Write-Host "=============================================================================================================="   
        Write-Host "Please see the error below & Azure PostgreSQL Resiliency has been stopped"  
        throw $_.Exception.Message
        exitcode
    }
}    
 
$ColumnList=$ConfigList | Get-Member -MemberType NoteProperty | %{"$($_.Name)"}

if (($ColumnList.Contains("Tenant")) -and
($ColumnList.Contains("Subscription_ID")))
{
    Write-Host "CSV validation is done successfully " 
}
else 
{
    Write-Host "There are mismatches in the CSV column . Kindly check and retrigger the automation "  -BackgroundColor Red
    exitCode
}

$tenant=$ConfigList.Tenant|Get-Unique

if ([string]::IsNullOrWhitespace($tenant))
{
    Write-Host "Tenant listed Azure_Subscription worksheet is not valid. Kindly check and retrigger the automation  "  -BackgroundColor Red 
    exitCode
}
elseif($tenant.count -gt 1)
{
    Write-Host "Azure_Subscription.csv has multiple Tenant. This script doesn't support multiple Tenant but you can add multiple Subscription. `nKindly check and retrigger the automation for each Tenant separately."  -BackgroundColor Red 
    exitCode
}
else
{
    $loginoutput=az login --use-device-code --tenant $tenant --only-show-errors
}

if (!$loginoutput) 
{
    Write-Error "Error connecting to Tenant: $tenant"
    exitcode
}

$mongoresources = Get-AzResource -ResourceType "Microsoft.DocumentDB/mongoClusters" -ExpandProperties

$output = @()

foreach ($res in $mongoresources)
{
    $location = $res.Location
    $resourcegroupname = $res.ResourceGroupName
    $kind = $res.Kind
    $resname = $res.Name
    $sku = $res.Sku
    $cluster_status = $res.Properties.clusterStatus
    $storagesize = $res.Properties.storage.sizeGb
    $compute = $res.Properties.compute.tier
    $connection_string = $res.Properties.connectionString
    $ha = $res.Properties.highAvailability.targetMode
    $replicarole = $res.Properties.replica.role
    $replicastate = $res.Properties.replica.replicationState
    $serverversion = $res.Properties.serverVersion
    $shardcount = $res.Properties.sharding.shardCount
    $SubscriptionID = $res.SubscriptionId

    Write-Host "`n`nDetails of $resname are: " -NoNewline -ForegroundColor Green
    Write-Host "
    Resource Name     : $resname
    Location          : $location
    ResourceGroupName : $resourcegroupname
    Server_Version    : $serverversion
    Shardcount        : $shardcount
    Kind              : $kind
    SKU               : $sku 
    Cluster_Status    : $cluster_status
    Storage(GB)       : $storagesize
    Compute Tier      : $compute
    HA                : $ha
    Replicarole       : $replicarole
    Replica_State     : $replicastate
    Connection_String : $connection_string
    SubscriptionID    : $SubscriptionID
    EnableHA(Yes/No)  : No" -ForegroundColor Cyan

    $outputObj = [PSCustomObject]@{
        "Cluster_Name" = $resname
        "ResourceGroup" = $resourcegroupname
        "Location" = $location
        "Server_Version" = $serverversion
        "ShardCount" = $shardcount
        "Kind" = $kind
        "SKU" = $sku
        "Cluster_Status" = $cluster_status
        "Storage(GB)" = $storagesize
        "Tier" = $compute
        "HA_Status" = $ha
        "ReplicaRole" = $replicarole
        "Replica_State" = $replicastate
        "Connection_String" = $connection_string
        "SubscriptionID" = $SubscriptionID
        "EnableHA(Yes/No)" = "No"
    }
    $output += $outputObj
}
# Define output folder and CSV file path
$OutputFolder = "$folder"
$combinedCsv = "$folder\Factory-Mongovcore-Input-File.csv"

# If output folder doesn't exist, create it
If (-Not (Test-Path -Path $OutputFolder)) {
    New-Item -Path $OutputFolder -ItemType Directory
}

# Export output to CSV
try {
    $output | Select-Object Cluster_Name, ResourceGroup, Location, Server_Version, ShardCount, Kind, SKU, Cluster_Status, 'Storage(GB)', Tier, HA_Status, ReplicaRole, Replica_State, SubscriptionID, Connection_String, 'EnableHA(Yes/No)' | Export-Csv -NoTypeInformation -Path $combinedCsv -Force
    Write-Host "Execution completed. Results exported to $combinedCsv" -ForegroundColor Green
}
catch {
    Write-Host $_ -ForegroundColor Cyan
    Write-Host "Error: Failed to export results to CSV. Ensure the file path is valid and accessible." -BackgroundColor Red
}
Stop-Transcript
#>