# Steps To-Do:<br />

**OS Support**<br />
This script is compatible with the following operating systems:<br />
Windows 10 or later<br />
Linux RHEL v7 or later , Ubuntu v14 or later<br />

**Pre-requisites**<br />

Execute below prior running Powershell scripts<br />
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy bypass

***Windows***<br />
Powershell -   https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-windows?view=powershell-7.4<br /> 
Azure CLI (For Single Server and Microsoft Entra ID authentication only) - https://aka.ms/installazurecliwindows )<br /> 

***Linux***<br />
Powershell - https://learn.microsoft.com/en-us/powershell/scripting/install/install-rhel?view=powershell-7.4<br /> 
Azure CLI (For Single Server and Microsoft Entra ID) - https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux/<br /> 

**Note**: - Add PATH in Enviornment Variables<br />

***Windows***<br />
Azure CLI  ( e.g. C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin )<br />

***Linux***<br />
Azure CLI  ( e.g. /usr/bin/az )<br />

## Step1. Azure CLI Info Gathering (Only for Azure Database for MongovCore Clusters)
1.	Download the package zip file named `MongovCore_Resiliency.zip`
2.	Extract the `unzip MongovCore_Resiliency.zip` file.
3.	Open the Input file `Azure_Subscription.csv` (Provide the Tenant ID & Subscription ID, add Multiple rows for Multiple Subscriptions)  
4.	Execute `powershell.exe .\Factory-MongovCore-Info-Gather.ps1` (Windows)
5.	Upon completion, the script generates a CSV file named `Factory-Mongovcore.csv` in the root directory. This file lists all MongovCore clusters within your subscriptions..
6.  Also, you can check the output(contain JSON) & Logs folders(contain execution log).

    Note:- Script support Multiple Subscription within single tenant. If you have multiple Tenent, follow each steps for individual Tenant.<br />
    For any reason if you need to re-execute "Factory-MongovCore-Info-Gather.ps1" script again...
    Rename or clear the "output" folder before each execution to prevent overwritten output.

## Step2. Update Factory-Mongovcore.csv(For Resiliency)
"Cluster_Name, ResourceGroup, Location, Server_Version, ShardCount, Kind, SKU, Cluster_Status, 'Storage(GB)', Tier, HA_Status, ReplicaRole, Replica_State, SubscriptionID, Connection_String, **EnableHA(Yes/No)**"

## Step3. Enabling MongovCore Clusters
1. Once the Step2 completed, execute `Factory-Enable-Mongo-HA.ps1` to enable the HA for the selected clusters.
2. Upon completion, you can check the output(contain JSON) & Logs (contain execution log) folders.

**Note:-**<br />
. Highlighted are **Mandatory Fields**<br />
<br />
1. 'EnableHA(Yes/No)' should be 'yes' for the servers(row in csv) you want to enable HA or read replica.
2. Depends on requirement, EnableHA and/or AddReplica should be set to TRUE for the individual servers.
   If both EnableHA and AddReplica are FALSE, the script skips the server, even when Approval_Status is yes. 
3. When AddReplica is set to TRUE, ReplicaServerName and ReplicaLocation should also be specified.
   If ReplicaServerName is specified and ReplicaLocation is left blank, the replica will be created in the same region as the source server.


If there is/are any queries, please let us know, we will connect and check.


**Disclaimer:**
These scripts are intended for use of Info Gather Assessment utility and do not interact with the user databases or gather any sensitive information (e.g passwords, PI data etc.). 
These scripts are provided as-is to merely capture metadata information ONLY. While every effort has been made to ensure that accuracy and reliability of the scripts, 
it is recommended to review and test them in a non-production environment before deploying them in a production environment.
It is important to note that these scripts should be modified with consultation of Microsoft.