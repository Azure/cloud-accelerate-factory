﻿#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------

write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host "     Welcome to Factory - MongoDB vCore Resiliency - Enable HA              " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                     (OSS DB Migration Factory)                             " -BackgroundColor DarkMagenta
write-host "                                                                            " -BackgroundColor DarkMagenta
Write-Host " "

$folder = "C:\Users\v-arunkumarg\Documents\Resiliency\csu-resiliency-mf\MongovCore\PUBLIC" #$PSScriptRoot

function exitCode
{
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}

function createFolder([string]$newFolder) 
{
   if(Test-Path $newFolder)
    {
        Write-Host "-Folder'$newFolder' Exist..."
    }
    else
    {
        $cfolder=New-Item $newFolder -ItemType Directory
        Write-Host "-$newFolder folder created..."
    }
}

createFolder $folder\Logs\
createFolder $folder\Output\

$today_date=Get-Date -Format "MM_dd_yyyy_HH_mm"
Write-Host "=============================================================================================================="  
Start-Transcript -path  $folder\Logs\Factory-MongovCore_Info_Gathering_Automation_Transcript_$today_date.txt  -Append
Write-Host "=============================================================================================================="

$InputCsv = "$folder\Factory-Mongovcore-Input-File.csv"

try 
{
    $csvData = Import-Csv -Path $InputCsv
    $Approved_Row = $csvData | Where-Object { $_.'EnableHA(Yes/No)'.toupper() -eq "YES" }
}
catch 
{
    Write-Host "Error: The CSV file $InputCsv could not be read. Please ensure that the file is in the correct format and accessible!!!" -BackgroundColor Red
    return
}

if($Approved_Row.Cluster_Name.count -ge 1)
{
    foreach($Approved_Rows in $Approved_Row)
    {
        $cluster = $Approved_Rows.Cluster_Name
        $resourceGroupName = $Approved_Rows.ResourceGroup
        $SubscriptionID = $Approved_Rows.SubscriptionID

        Start-Sleep 3
        # Enable HA
        Write-Host "Enabling HA for the cluster $($cluster) is started..." -ForegroundColor Green

        Start-Sleep 3
        $enableha = az rest --method PATCH `
            --uri "https://management.azure.com/subscriptions/$($SubscriptionID)/resourceGroups/$($resourceGroupName)/providers/Microsoft.DocumentDB/mongoClusters/$($cluster)?api-version=2024-02-15-preview" `
            --headers "Content-Type=application/json" `
            --body "@$folder\body-content.json"
        Start-Sleep 3
        if($enableha) 
        {
            Write-Host "`nEnabling HA for the $($cluster) is success...!!!" -ForegroundColor Green
        }
        else
        {
            Write-Host "`nEnabling HA for the $($cluster) is failed...!!!" -ForegroundColor Red
        }
    }
}
else
{
    Write-host "None of MongovCore clusters are approved to enable zone redundant. Please review Input file and re-run the script again." -BackgroundColor red
}
