# Steps To-Do:<br />

**OS Support**<br />
This script is compatible with the following operating systems:<br />
Windows 10 or later<br />
Linux RHEL v7 or later , Ubuntu v14 or later<br />

**Pre-requisites**<br />

Execute below prior running Powershell scripts<br />
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy bypass

***Windows***<br />
Powershell -   https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-windows?view=powershell-7.4<br /> 
Azure CLI (For Single Server and Microsoft Entra ID authentication only) - https://aka.ms/installazurecliwindows )<br /> 

***Linux***PENDING***<br />
Powershell - https://learn.microsoft.com/en-us/powershell/scripting/install/install-rhel?view=powershell-7.4<br /> 
Azure CLI (For Single Server and Microsoft Entra ID) - https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux/<br /> 

**Note**: - Add PATH in Enviornment Variables<br />

***Windows***<br />
Azure CLI  ( e.g. C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin )<br />

***Linux***<br />
Azure CLI  ( e.g. /usr/bin/az )<br />

## Step1. Azure CLI Info Gathering (Only for Azure Database for MySQL Flexible Servers)
1.	Download the package zip file named `MySQL_Resiliency.zip`
2.	Extract the `unzip MySQL_Resiliency.zip` file.
3.	Open the Input file `Azure_Subscription.csv` (Provide the Tenant ID & Subscription ID, add Multiple rows for Multiple Subscriptions)  
4.	Execute `powershell.exe .\Factory-MySQL-FlexiCLI-Windows.ps1` (Windows)
5.      Execute `pwsh ./Factory-MySQL-FlexiCLI-Linux.ps1` (Linux).
6.	Upon completion, the script generates a CSV file named Factory_MySQL_Flexi_Server_Input_file.csv in the root directory. This file lists all MySQL flexible servers within your subscriptions..
7.      Also, you can check the output(contain JSON) & Logs folders(contain execution log).

    Note:- Script support Multiple Subscription within single tenant. If you have multiple Tenent, follow each steps for individual Tenant.<br />
    For any reason if you need to re-execute "Factory-MySQL-CLI-Windows.ps1" script again...
    Rename or clear the "output" folder before each execution to prevent overwritten output.

## Step2. Update Factory_MySQL_Flexi_Server_Input_file.csv(For Resiliency)
"Host_Name,Resource_Group,sku,tier,Location,HA_Mode,replicationRole,sourceServerResourceId,geoRedundantBackup,StorageAutoGrow,Tenant,Subscription_ID,Recommendation,**EnableHA**,**AddReplica**,**ReplicaServerName**,**ReplicaLocation**,**Approval_Status**"

**Note:-**<br />
. Highlighted are **Mandatory Fields**<br />
<br />
1. Approval status should be 'yes' for the servers(row in csv) you want to enable HA or read replica.
2. Depends on requirement, EnableHA and/or AddReplica should be set to TRUE for the individual servers.
   If both EnableHA and AddReplica are FALSE, the script skips the server, even when Approval_Status is yes. 
3. When AddReplica is set to TRUE, ReplicaServerName and ReplicaLocation should also be specified.
   If ReplicaServerName is specified and ReplicaLocation is left blank, the replica will be created in the same region as the source server.

## Step3. Enable HA and/or read replica.
1.	Once CSV has been updated as per step2, Execute `powershell.exe .\Factory_MySQL_EnableHA_AddReplica-Windows.ps1` ( Windows )
2.      Execute `pwsh ./Factory_MySQL_EnableHA_AddReplica-Linux.ps1` ( Linux )
3.	Once the execution completed, you can check the output & Logs folder.


## Step4. Verification
1.    Create a copy of input CSV file Factory_MySQL_Flexi_Server_Input_file.csv(or rename) re-run script mentioned on step1.
2.    A new input file will be created with Resiliency status of each of the servers.
3.    Zip and share the input file, output, log folders with Factory team for review.

If there is/are any queries, please let us know, we will connect and check.


**Disclaimer:**
These scripts are intended for use of Info Gather Assessment utility and do not interact with the user databases or gather any sensitive information (e.g passwords, PI data etc.). 
These scripts are provided as-is to merely capture metadata information ONLY. While every effort has been made to ensure that accuracy and reliability of the scripts, 
it is recommended to review and test them in a non-production environment before deploying them in a production environment.
It is important to note that these scripts should be modified with consultation of Microsoft.



# Appendix -

1. Refer below for regions supporting HA for Azure Database for MySQL.
https://learn.microsoft.com/en-us/azure/mysql/flexible-server/overview#azure-regions


LIMITATIONS:

HA :

Here are some considerations to keep in mind when you use high availability:

Zone-redundant high availability can only be configured during server creation.

High availability isn't supported in the burstable compute tier.

Restarting the primary database server to pick up static parameter changes also restarts the standby replica.

GTID mode will be turned on as the HA solution uses GTID. Check whether your workload has restrictions or limitations on replication with GTIDs.

If you are enabling same-zone HA post the server create, you need to make sure the server parameters enforce_gtid_consistency" and "gtid_mode" is set to ON before enabling HA.

Storage autogrow is default enabled for a High-Availability configured server and can not to be disabled.


Read-Replica:

The read replica feature is only available for Azure Database for MySQL Flexible Server instances in the General Purpose or Business Critical pricing tiers. Ensure the source server is in one of these pricing tiers.

There's no automated failover between source and replica servers.

Since replication is asynchronous, there's lag between the source and the replica.

It's recommended to SET enforce_gtid_consistency to ON before you can set gtid_mode=ON.

References: 

https://learn.microsoft.com/en-us/azure/mysql/flexible-server/concepts-high-availability#limitations
https://learn.microsoft.com/en-us/azure/mysql/flexible-server/concepts-high-availability
https://learn.microsoft.com/en-us/azure/mysql/flexible-server/concepts-high-availability#frequently-asked-questions-faq
https://docs.azure.cn/en-us/mysql/how-to-troubleshoot-replication-latency
https://learn.microsoft.com/en-us/azure/mysql/flexible-server/concepts-read-replicas
