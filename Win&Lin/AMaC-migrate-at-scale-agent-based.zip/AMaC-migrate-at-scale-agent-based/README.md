# Scale migration of VMs using Azure Site Recovery for physical Simplified approach
This automation help you with the migration of large number of VMs to Azure using Azure Migrate physical/agent-based (Simplified) approach using the input CSV file. These scripts can be used to migrate VMware (Agent-based), AWS, GCP VMs and physical servers to Azure. You can also use these scripts to migrate Hyper-V VMs if you migrate the VMs as physical servers. These scripts are based on the REST API. 

## Current Limitations:
- Does not support setting up the static IP for replications
- By default all disks are included and only one Disk SKU

## How does it work?




### Pre-requisites
Before you get started, you need to do the following:
- Ensure that the Azure Migrate Project is setup and the discovery and replication appliances are registered and configured successfully.
- Ensure that the servers supposed to be migrated are added in the replication appliance with respective credentials to push the mobility service.(replication discovery)
- Ensure that the target artefacts in Azure are created
    - Target Resource Group
    - Target Storage Account (and its Resource Group) - Create a premium storage account if you plan to migrate to premium disks
    - Target Cache Storage Account (and its Resource Group) - Create a standard storage account in the same region as the vault
    - Target Virtual Network for failover (and its Resource Group)
    - Target Subnet
    - Target Virtual Network for Test failover (and its Resource Group)
    - Availability Set (if needed)
    - Target Network Security Group and its Resource Group
- Ensure that you have decided on the properties of the target VM
    - Target VM name
    - Target VM size in Azure (can be decided using Azure Migrate assessment)

### CSV Input file
Once you have all the pre-requisites completed, you need to create a CSV file which has data for each source machine that you want to migrate. The input CSV must have a header line with the input details and a row with details for each machine that needs to be migrated. All the scripts are designed to work on the same CSV file. A sample CSV template is available in the folder for your reference.

- [Input CSV template](input_template.csv)
- [Sample CSV](samplecsv.csv)

#### CSV Fields
The CSV file requires the following fields. Each field is described below with a sample value and explanation:

| Field | Sample Value | Explanation |
|-------|--------------|-------------|
| VAULT_SUBSCRIPTION_ID | 95642268-5116-484d-9b88-7dfce8c20ce4 | The Azure subscription ID where the Site Recovery vault is located. |
| VAULT_RESOURCE_GROUP_NAME | rg-infra-garinep-automation-demo | Resource group name containing the Site Recovery vault. |
| VAULT_NAME | pkgdemo-MigrateVault-2111897092 | Name of the Azure Site Recovery vault. |
| SOURCE_MACHINE_NAME | windemo7.contoso.com | Fully qualified domain name (FQDN) or IP address of the source virtual machine. |
| TARGET_MACHINE_NAME | windemo7 | Desired name for the migrated VM in Azure. |
| MACHINE_SIZE | Standard_D2s_v3 | Azure VM size (e.g., SKU) for the target VM, determined from Azure Migrate assessments. |
| PROCESS_SERVER | replication1 | Name of the process server configured in the ASR environment. |
| TARGET_SUBSCRIPTION_ID | 95642268-5116-484d-9b88-7dfce8c20ce4 | Azure subscription ID for the target resources (can be the same as vault subscription). |
| TARGET_RESOURCE_GROUP | rg-infra-garinep-automation-demo | Resource group where the target VM will be created. |
| CACHE_STORAGE_ACCOUNT | stpkgmigratecache | Name of the cache storage account used for replication data. |
| CACHE_STORAGE_ACCOUNT_RG | rg-infra-garinep-automation-demo | Resource group of the cache storage account. |
| TARGET_BOOTDIAG_STORAGE_ACCOUNT | stpkgmigratecache | Storage account for VM boot diagnostics (can be the same as cache). |
| TARGET_BOOTDIAG_STORAGE_ACCOUNT_RG | rg-infra-garinep-automation-demo | Resource group of the boot diagnostics storage account. |
| TARGET_VNET | pkg-vnet | Name of the target virtual network for the migrated VM. |
| TARGET_VNET_RG | rg-infra-garinep-automation-demo | Resource group of the target virtual network. |
| TARGET_SUBNET | app | Name of the subnet within the target virtual network. |
| REPLICATION_POLICY | 24-hour-replication-policy | Name of the ASR replication policy associated with the configuration server. |
| CREDENTIAL_FRIENDLY_NAME | wincred | Friendly name of the credential used for accessing the source VM. |
| AVAILABILITY_SET |  | Name of the availability set (leave empty if not using availability sets). |
| AVAILABILITY_ZONE |  | Availability zone number (leave empty if not using zones). |
| PROXIMITY_PLACEMENT_GROUP |  | Name of the proximity placement group (leave empty if not applicable). |
| PRIVATE_IP |  | Static private IP address for the primary NIC (leave empty for dynamic IP). |
| TESTFAILOVER_RESOURCE_GROUP |  | Resource group for test failover VMs (leave empty if not needed). |
| TESTFAILOVER_VNET | pkg-vnet | Virtual network for test failover. |
| TESTFAILOVER_VNET_RG | rg-infra-garinep-automation-demo | Resource group of the test failover virtual network. |
| TESTFAILOVER_SNET | testSubnet | Subnet for test failover VMs. |
| TARGET_NSG_NAME |  | Name of the Network Security Group to assign to the target VM's NIC. |
| TARGET_NSG_RESOURCE_GROUP |  | Resource group of the target NSG. |
| RECOVERY_VM_MANAGED_DISK_TYPE | Standard_LRS | Managed disk type for the target VM (e.g., Standard_LRS, Premium_LRS). |
| LICENSE_TYPE | NotSpecified | Windows license type. Allowed values: `WindowsServer` (Azure Hybrid Benefit), `NoLicenseType` (Pay-As-You-Go), `NotSpecified` (default, treated as PAYG). |
| LINUX_LICENSE_TYPE | NotSpecified | Linux license type. Allowed values: `NotSpecified`, `NoLicenseType`, `LinuxServer`. |
| SQL_SERVER_LICENSE_TYPE | NotSpecified | SQL Server license type. Allowed values: `AHUB` (Azure Hybrid Use Benefit), `PAYG` (Pay-As-You-Go), `NoLicenseType` (explicit PAYG), `NotSpecified` (implicit default, treated as PAYG). |
| TARGET_NIC_TAGS |  | Tags for the target VM's NIC in JSON format (e.g., {"key":"value"}). |
| TARGET_VM_TAGS | {"env":"prod","team":"migration","cost-center":"12345"} | Tags for the target VM in JSON format. |

### Script execution
Once the CSV is ready, you can execute the following steps to perform migration of the on-premises VMs:

**Step #** | **Script Name** | **Description**
--- | --- | ---
1 | AzMigrate_StartReplication.ps1 | Enable replication for all the VMs listed in the CSV. The script creates a CSV output with the job details for each VM.
2 | AzMigrate_Check_Replication_Properties.ps1 | Check the status of replication. The script creates a CSV with the status for each VM.
3 | AzMigrate_Update_Replication_Properties.ps1 | Once the VMs are replicated/protected, use this script to update the target properties of the VM (Compute and Network properties).
4 | AzMigrate_Check_Replication_Properties.ps1 | Verify if the properties are appropriately updated after the update script.
5 | AzMigrate_TestMigrate.ps1 | Start the test failover of the VMs listed in the CSV. The script creates a CSV output with the job details for each VM.
6 | AzMigrate_CleanupTestMigrate.ps1 | Once you manually validate the VMs that were test failed-over, you can use this script to clean up the test failover VMs.
7 | AzMigrate_Cutover.ps1 | Perform an unplanned failover for the VMs listed in the CSV. The script creates a CSV output with the job details for each VM. The script does not shut down the on-prem VMs before triggering the failover; for application consistency, it is recommended that you manually shut down the VMs before executing the script.
8 | AzMigrate_Cutover.ps1 | Perform the commit operation on the VMs after failover to finalize the migration and delete the ASR entities.
9 | AzMigrate_Update_Replication_Properties.ps1 | If you plan to assign network security groups to the NICs post-failover, you can use this script to do that. It assigns an NSG to any one NIC in the target VM.

### Execute scripts

#### List Protected Items and status from Vault

```
.\AzMigrate_List_Protected_Items.ps1 <vaultSubscriptionId> <vault_resource_group_name> <vault_name>
.\AzMigrate_List_Protected_Items.ps1 95642268-5116-484d-9b88-7dfce8c20ce4 rg-infra-winmig-amer-v-pgarine-poc gpkdemo-MigrateVault-662672658
```

Windows licenseType (OS license / AHB)

| Value | AHB Enabled | Windows License Charged | Meaning |
|------|------------|-------------------------|--------|
| `WindowsServer` | ✅ Yes | ❌ No | Use Azure Hybrid Benefit for Windows Server (BYOL with SA) |
| `NoLicenseType` | ❌ No | ✅ Yes | Explicit Pay‑As‑You‑Go Windows licensing |
| `NotSpecified` | ❌ No | ✅ Yes | Implicit default (treated as Pay‑As‑You‑Go) |

linuxLicenseType (Linux OS licensing)

| Value | Description |
|------|-------------|
| `NotSpecified` | Implicit default |
| `NoLicenseType` | No license type specified |
| `LinuxServer` | Linux Server license |

sqlServerLicenseType (SQL Server licensing)

| Value | SQL AHB | SQL License Charged | Meaning |
|------|---------|---------------------|--------|
| `AHUB` | ✅ Yes | ❌ No | Azure Hybrid Use Benefit for SQL Server (BYOL with SA) |
| `PAYG` | ❌ No | ✅ Yes | Pay‑As‑You‑Go SQL Server licensing |
| `NoLicenseType` | ❌ No | ✅ Yes | Explicit PAYG (no AHB applied) |
| `NotSpecified` | ❌ No | ✅ Yes | Implicit default (treated as PAYG) |


Tags:

{"env":"prod","team":"migration","cost-center":"12345"}

env=prod;team=migration;cost-center=12345


## References

- [Azure Site Recovery REST API - Create Replication Protected Items](https://learn.microsoft.com/en-us/rest/api/site-recovery/replication-protected-items/create?view=rest-site-recovery-2025-08-01)
- [InMageRcmEnableProtectionInput](https://learn.microsoft.com/en-us/rest/api/site-recovery/replication-protected-items/create?view=rest-site-recovery-2025-08-01#inmageRcmEnableProtectionInput)
- [Azure Availability Sets](https://learn.microsoft.com/en-us/azure/virtual-machines/availability-set-overview)
- [Azure Availability Zones](https://learn.microsoft.com/en-us/azure/reliability/availability-zones-overview)
