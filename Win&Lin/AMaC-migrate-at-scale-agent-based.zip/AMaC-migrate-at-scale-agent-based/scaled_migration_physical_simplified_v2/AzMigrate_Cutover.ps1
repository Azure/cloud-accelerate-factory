Param(
    [parameter(Mandatory = $true)]
    $CsvFilePath
)

$ErrorActionPreference = "Stop"

$scriptsPath = $PSScriptRoot
if ($PSScriptRoot -eq "") {
    $scriptsPath = "."
}

. "$scriptsPath\AzMigrate_Logger.ps1"
. "$scriptsPath\AzMigrate_ASR_Common.ps1"
. "$scriptsPath\AzMigrate_CSV_Processor.ps1"

Function ProcessItemImpl($processor, $csvItem, $reportItem) {
    $reportItem | Add-Member NoteProperty "ProtectableStatus" $null
    $reportItem | Add-Member NoteProperty "ProtectionState" $null
    $reportItem | Add-Member NoteProperty "ProtectionStateDescription" $null
    $reportItem | Add-Member NoteProperty "ReplicationJobId" $null

    $vaultSubscriptionId = $csvItem.VAULT_SUBSCRIPTION_ID
    $vaultResourceGroupName = $csvItem.VAULT_RESOURCE_GROUP_NAME
    $vaultName = $csvItem.VAULT_NAME
    $sourceMachineName = $csvItem.SOURCE_MACHINE_NAME
    $processServer = $csvItem.PROCESS_SERVER
    $replicationPolicy = $csvItem.REPLICATION_POLICY
    $runAsAccountName = $csvItem.CREDENTIAL_FRIENDLY_NAME
    
    # Ensure vault exists and collect related context
    $vaultContext = $asrCommon.GetVaultContext(
        $vaultSubscriptionId,
        $vaultResourceGroupName,
        $vaultName,
        $processServer,
        $replicationPolicy,
        $runAsAccountName,
        $sourceMachineName
    )

    $processor.Logger.LogTrace("Vault with name '$($vaultContext.VaultServer.Name)' found.")
    $processor.Logger.LogTrace("Fabric Name : '$($vaultContext.FabricName)'")
    $processor.Logger.LogTrace("Process Server Id : '$($vaultContext.ProcessServerId)'")
    $processor.Logger.LogTrace("Replication Policy Id : '$($vaultContext.ReplicationPolicyId)'")
    $processor.Logger.LogTrace("RunAs Account Id : '$($vaultContext.RunAsAccountId)'")
    $processor.Logger.LogTrace("Fabric discovery machine Id : '$($vaultContext.FabricDiscoveryMachineId)'")
    $processor.Logger.LogTrace("Protection Container Name : '$($vaultContext.ProtectionContainerName)'")

    # Use cached context values from GetVaultContext (avoid extra REST calls)
    $fabricName = $vaultContext.FabricName
    $fabricDiscoveryMachineId = $vaultContext.FabricDiscoveryMachineId
    $protectionContainerName = $vaultContext.ProtectionContainerName

    if ($null -eq $fabricDiscoveryMachineId) {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' not found in fabric discovery for vault '$($vaultName)'")
    }

    # Get protected item details for the source machine if it is already a protected item in the vault
    $protectedItemResponse = $asrCommon.GetProtectedItemFromVault($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    $protectedVM = ($protectedItemResponse.Content | ConvertFrom-Json -Depth 100).value | Where-Object { $_.properties.friendlyName -eq $sourceMachineName } 
    $replicatedProtectedItemName = $protectedVM.name
     
    if ($protectedVM) {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' is a protected item in vault '$($vaultName)'")
        $processor.Logger.LogTrace("protectionState: '$($protectedVM.properties.protectionState)'")
        $processor.Logger.LogTrace("protectionStateDescription: '$($protectedVM.properties.protectionStateDescription)'")
        $processor.Logger.LogTrace("replicationHealth: '$($protectedVM.properties.replicationHealth)'")
        $processor.Logger.LogTrace("failoverHealth: '$($protectedVM.properties.failoverHealth)'")
        
        if ($protectedVM.properties.allowedOperations -contains "UnplannedFailover") {

            if ($protectedVM.properties.replicationHealth -eq "Normal" -and $protectedVM.properties.failoverHealth -eq "Normal") {
            
                $unplannedFailoverUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems/${replicatedProtectedItemName}/unplannedFailover?api-version=2025-08-01"
                $processor.Logger.LogTrace("Unplanned Failover Uri : '$($unplannedFailoverUri)'")
                $body = @{
                    properties = @{
                        failoverDirection       = "PrimaryToRecovery"
                        sourceSiteOperations    = "NotRequired"
                        providerSpecificDetails = @{
                            instanceType                     = "InMageRcm"
                            #osUpgradeVersion = ""
                            performShutdown                  = "true"
                            recoveryPointId                  = "" # if empty, it will failover to latest recovery point
                            targetCapacityReservationGroupId = "" # optional parameter to specify capacity reservation group for the target VM in case the replication provider supports it
                        }
                    }
                } | ConvertTo-Json -Depth 10

                $processor.Logger.LogTrace("Starting the Migration for machine '$($sourceMachineName)'")
                $processor.Logger.LogTrace("Unplanned Failover Request Body: '$body'")
                
                $unplannedFailoverJob = Invoke-AzRestMethod -Method POST -Uri $unplannedFailoverUri -Payload $body

                if ($unplannedFailoverJob.StatusCode -eq 202) {
                    $processor.Logger.LogTrace("Failover started successfully for machine '$($sourceMachineName)'")
                }
                else {
                    $processor.Logger.LogError("Failed to start Failover for machine '$($sourceMachineName)'. Status Code: '$($unplannedFailoverJob.StatusCode)'. Response: '$($unplannedFailoverJob.Content)'")
                }
            } 
            else {
                $processor.Logger.LogError("The replication Health or Failover Health for machine '$($sourceMachineName)' is not in a valid state. Status Code: '$($protectedVM.properties.replicationHealth)'. Response: '$($protectedVM.properties.failoverHealth)'")
            }
        }
        else {
            $processor.Logger.LogTrace("The Failover is not allowed for machine '$($sourceMachineName)' with current Protection state  '$($protectedVM.properties.protectionState)'")
        }
    }
    else {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' is not a protected item in vault '$($vaultName)'")
    }
}
Function ProcessItem($processor, $csvItem, $reportItem) {
    try {
        ProcessItemImpl $processor $csvItem $reportItem
    }
    catch {
        $exceptionMessage = $_ | Out-String
        $processor.Logger.LogError($exceptionMessage)
        throw
    }
}
$logger = New-AsrLoggerInstance -CommandPath $PSCommandPath
$asrCommon = New-AsrCommonInstance -Logger $logger
$processor = New-CsvProcessorInstance -Logger $logger -ProcessItemFunction $function:ProcessItem
$processor.ProcessFile($CsvFilePath)