Param(
    [parameter(Mandatory = $true)]
    $CsvFilePath
)

$ErrorActionPreference = "Stop"

$scriptsPath = $PSScriptRoot
if ($PSScriptRoot -eq "") {
    $scriptsPath = "."
}

. "$scriptsPath\AzMigrate_Logger.ps1"
. "$scriptsPath\AzMigrate_ASR_Common.ps1"
. "$scriptsPath\AzMigrate_CSV_Processor.ps1"

Function NeedsUpdate($currentValue, $expectedValue) {
    if ($null -eq $currentValue -and $null -eq $expectedValue) {
        return $false
    }
    if ($null -eq $currentValue -or $null -eq $expectedValue) {
        return $true
    }
    return $currentValue -ne $expectedValue
}

<# Function GetStorageAccountId($targetSubscriptionId,$targetBootDiagStorageAccountRG,$targetBootDiagStorageAccountName) {
    return "/subscriptions/$targetSubscriptionId/resourceGroups/$targetBootDiagStorageAccountRG/providers/Microsoft.Storage/storageAccounts/$targetBootDiagStorageAccountName"
}

Function GetVirtualNetworkId($targetSubscriptionId, $vnetRG, $vnetName) {
    return "/subscriptions/$targetSubscriptionId/resourceGroups/$vnetRG/providers/Microsoft.Network/virtualNetworks/$vnetName"
}

Function GetResourceGroupId($targetSubscriptionId,$targetPostFailoverResourceGroup) {
    return "/subscriptions/$targetSubscriptionId/resourceGroups/$targetPostFailoverResourceGroup"
} #>

Function InvokeProtectedItemUpdate(
    $logger,
    $vaultSubscriptionId,
    $vaultResourceGroupName,
    $vaultName,
    $fabricName,
    $protectionContainerName,
    $protectedItemName,
    $updateProperties
)
{
    $logger.LogTrace("Invoking REST API to update protected item '$($protectedItemName)' in vault '$($vaultName)'")
    
    $updateUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems/${protectedItemName}?api-version=2025-08-01"
    
    # According to ASR REST API docs, update is a PATCH operation and properties are inside request body 'properties.providerSpecificDetails'
    $requestBody = @{
        properties = @{
            providerSpecificDetails = $updateProperties
        }
    } | ConvertTo-Json -Depth 100
    
    $logger.LogTrace("Update URI: $updateUri")
    $logger.LogTrace("Update payload: $requestBody")
    
    try {
        $response = Invoke-AzRestMethod -Method PATCH -Uri $updateUri -Payload $requestBody
        
        $logger.LogTrace("REST API response status: $($response.StatusCode)")
        
        if ($response.StatusCode -eq 200 -or $response.StatusCode -eq 202) {
            $logger.LogTrace("Successfully invoked update for protected item. Status: $($response.StatusCode)")
            return $response
        }
        else {
            $logger.LogError("Failed to update protected item. Status: $($response.StatusCode). Response: $($response.Content)")
            throw "Update failed with status $($response.StatusCode): $($response.Content)"
        }
    }
    catch {
        $logger.LogError("Error invoking REST API for update: $_")
        throw
    }
}

Function ProcessItemImpl($processor, $csvItem, $reportItem) {
    $reportItem | Add-Member NoteProperty "UpdateStatus" $null
    $reportItem | Add-Member NoteProperty "UpdateDetails" $null
    $reportItem | Add-Member NoteProperty "UpdateErrors" $null

    $vaultSubscriptionId = $csvItem.VAULT_SUBSCRIPTION_ID
    $vaultResourceGroupName = $csvItem.VAULT_RESOURCE_GROUP_NAME
    $vaultName = $csvItem.VAULT_NAME
    $sourceMachineName = $csvItem.SOURCE_MACHINE_NAME
    $targetMachineName = $csvItem.TARGET_MACHINE_NAME
    $targetVmSize = $csvItem.MACHINE_SIZE
    #$processServer = $csvItem.PROCESS_SERVER
    $targetSubscriptionId = $csvItem.TARGET_SUBSCRIPTION_ID
    $targetPostFailoverResourceGroup = $csvItem.TARGET_RESOURCE_GROUP
    $cacheStorageAccountName = $csvItem.CACHE_STORAGE_ACCOUNT
    $cacheStorageAccountRG = $csvItem.CACHE_STORAGE_ACCOUNT_RG
    $targetBootDiagStorageAccountName = $csvItem.TARGET_BOOTDIAG_STORAGE_ACCOUNT
    $targetBootDiagStorageAccountRG = $csvItem.TARGET_BOOTDIAG_STORAGE_ACCOUNT_RG
    $targetVNETRG = $csvItem.TARGET_VNET_RG
    $targetVNET = $csvItem.TARGET_VNET
    $targetSubnet = $csvItem.TARGET_SUBNET
    #$replicationPolicy = $csvItem.REPLICATION_POLICY
    #$runAsAccountName = $csvItem.CREDENTIAL_FRIENDLY_NAME
    #$sourceConfigurationServer = $csvItem.CONFIGURATION_SERVER
    $availabilitySet = $csvItem.AVAILABILITY_SET
    $proximityPlacementGroup = $csvItem.PROXIMITY_PLACEMENT_GROUP
    $testFailoverVNET = $csvItem.TESTFAILOVER_VNET
    $testFailoverVNET_RG = $csvItem.TESTFAILOVER_VNET_RG
    $testSubnet = $csvItem.TESTFAILOVER_SNET
    #$recoveryVmManagedDiskType = $csvItem.RECOVERY_VM_MANAGED_DISK_TYPE
    $licenseType = $csvItem.LICENSE_TYPE
    $linuxLicenseType = $csvItem.LINUX_LICENSE_TYPE
    $sqlServerLicenseType = $csvItem.SQL_SERVER_LICENSE_TYPE

    try {
        # Ensure vault exists and fetch vault details
        $vaultResponse = $asrCommon.GetAndEnsureVaultContext($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $processor.Logger.LogTrace("Successfully retrieved vault context for vault '$($vaultResponse.Name)' in subscription '$($vaultSubscriptionId)'")

        # Get protected item details for the source machine if it is already a protected item in the vault
        $protectedItemResponse = $asrCommon.GetProtectedItemFromVault($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $protectedVM = ($protectedItemResponse.Content | ConvertFrom-Json -Depth 100).value | Where-Object { $_.properties.friendlyName -eq $sourceMachineName }
        
        if ($protectedVM) {
            $processor.Logger.LogTrace("Found protected VM: '$($sourceMachineName)'")
            
            # Construct full resource IDs from CSV values
            #$targetResourceGroupId = GetResourceGroupId $targetSubscriptionId $targetPostFailoverResourceGroup
            #$targetBootDiagStorageAccountId = GetStorageAccountId $targetSubscriptionId $targetBootDiagStorageAccountRG $targetBootDiagStorageAccountName
            #$targetNetworkId = GetVirtualNetworkId $targetSubscriptionId $targetVNETRG $targetVNET
            #$testNetworkId = GetVirtualNetworkId $targetSubscriptionId $testFailoverVNET_RG $testFailoverVNET

            # Get current values from protected VM
            $currentTargetRGName = ($protectedVM.properties.providerSpecificDetails.targetResourceGroupId -split "/")[-1]
            $currentTargetVmName = $protectedVM.properties.providerSpecificDetails.targetVmName
            $currentTargetVmSize=$protectedVM.properties.providerSpecificDetails.targetVmSize
            $currentTargetBootDiagStorageAccountName = ($protectedVM.properties.providerSpecificDetails.targetBootDiagnosticsStorageAccountId -split "/")[-1]
            #$currentTargetNetworkName = ($protectedVM.properties.providerSpecificDetails.targetNetworkId -split "/")[-1]
            #$currentTestNetworkName = ($protectedVM.properties.providerSpecificDetails.testNetworkId -split "/")[-1]
            $currentLicenseType = $protectedVM.properties.providerSpecificDetails.licenseType
            $currentLinuxLicenseType = $protectedVM.properties.providerSpecificDetails.linuxLicenseType
            $currentSqlServerLicenseType = $protectedVM.properties.providerSpecificDetails.sqlServerLicenseType
            $currentTargetAvailabilitySetId = $protectedVM.properties.providerSpecificDetails.targetAvailabilitySetId
            $currentTargetProximityPlacementGroupId = $protectedVM.properties.providerSpecificDetails.targetProximityPlacementGroupId
            
            # Construct target proximity placement group ARM ID if provided
            $targetProximityPlacementGroupIdValue = $null
            if ($proximityPlacementGroup -and $proximityPlacementGroup -ne "" -and $proximityPlacementGroup -ne "Pending" -and $proximityPlacementGroup -ne "Not possible?") {
                # Check if already an ARM ID or needs to be constructed
                if ($proximityPlacementGroup.StartsWith("/subscriptions/")) {
                    $targetProximityPlacementGroupIdValue = $proximityPlacementGroup
                }
                else {
                    # Construct ARM ID from proximity placement group name
                    $targetProximityPlacementGroupIdValue = "/subscriptions/$targetSubscriptionId/resourceGroups/$targetPostFailoverResourceGroup/providers/Microsoft.Compute/proximityPlacementGroups/$proximityPlacementGroup"
                }
                $processor.Logger.LogTrace("Target Proximity Placement Group Id : '$($targetProximityPlacementGroupIdValue)'")
            }
            
            # Validate target environment details from CSV (also ensures the referenced resources exist and are accessible)

            $targetEnv = $asrCommon.ValidateTargetEnvironment(
            $targetSubscriptionId,
            $targetPostFailoverResourceGroup,
            $targetVNET,
            $targetVNETRG,
            $targetSubnet,
            $testFailoverVNET,
            $testFailoverVNET_RG,
            $testSubnet,
            $targetBootDiagStorageAccountName,
            $targetBootDiagStorageAccountRG,
            $cacheStorageAccountName,
            $cacheStorageAccountRG,
            $licenseType, 
            $linuxLicenseType,
            $sqlServerLicenseType,
            $availabilitySet,
            $targetProximityPlacementGroupIdValue
        )

          $targetResourceGroupId = $targetEnv.TargetResourceGroupId
          #$targetNetworkId = $targetEnv.TargetNetworkId
          #$testNetworkId = $targetEnv.TestNetworkId
          $targetBootDiagStorageAccountId = $targetEnv.TargetBootDiagnosticsStorageAccountId
          $targetAvailabilitySetId = $targetEnv.TargetAvailabilitySetId
          $targetProximityPlacementGroupId = $targetEnv.TargetProximityPlacementGroupId

            # Collect updates needed
            $propertiesNeedingUpdate = @{}
            $propertiesNeedingUpdate["instanceType"] = "InMageRcm" # the provider-specific update object is polymorphic and is discriminated by instanceType.
            $updatesLog = @()

            if (NeedsUpdate $currentTargetRGName $targetPostFailoverResourceGroup) {
                $propertiesNeedingUpdate["targetResourceGroupId"] = $targetResourceGroupId
                $updatesLog += "targetResourceGroupId: '$currentTargetResourceGroupId' -> '$targetResourceGroupId'"
                $processor.Logger.LogTrace("Update needed for targetResourceGroupId")
            }

            if (NeedsUpdate $currentTargetVmName $targetMachineName) {
                $propertiesNeedingUpdate["targetVmName"] = $targetMachineName
                $updatesLog += "targetVmName: '$currentTargetVmName' -> '$targetMachineName'"
                $processor.Logger.LogTrace("Update needed for targetVmName")
            }

            if (NeedsUpdate $currentTargetVmSize $targetVmSize) {
                $propertiesNeedingUpdate["targetVmSize"] = $targetVmSize
                $updatesLog += "targetVmSize: '$currentTargetVmSize' -> '$targetVmSize'"
                $processor.Logger.LogTrace("Update needed for targetVmSize")
            }

            if (NeedsUpdate $currentTargetBootDiagStorageAccountName $targetBootDiagStorageAccountName) {
                $propertiesNeedingUpdate["targetBootDiagnosticsStorageAccountId"] = $targetBootDiagStorageAccountId
                $updatesLog += "targetBootDiagnosticsStorageAccountId: '$currentTargetBootDiagStorageAccountId' -> '$targetBootDiagStorageAccountId'"
                $processor.Logger.LogTrace("Update needed for targetBootDiagnosticsStorageAccountId")
            }

             # The subnet updates are not supported on service side due to some known issues. 

<#             if (NeedsUpdate $currentTargetNetworkName $targetVNET) {
                $propertiesNeedingUpdate["targetNetworkId"] = $targetNetworkId
                $updatesLog += "targetNetworkId: '$currentTargetNetworkId' -> '$targetNetworkId'"
                $processor.Logger.LogTrace("Update needed for targetNetworkId")
            }

            if (NeedsUpdate $currentTestNetworkName $testFailoverVNET) {
                $propertiesNeedingUpdate["testNetworkId"] = $testNetworkId
                $updatesLog += "testNetworkId: '$currentTestNetworkId' -> '$testNetworkId'"
                $processor.Logger.LogTrace("Update needed for testNetworkId")
            } #>

            if (NeedsUpdate $currentLicenseType $licenseType) {
                $propertiesNeedingUpdate["licenseType"] = $licenseType
                $updatesLog += "licenseType: '$currentLicenseType' -> '$licenseType'"
                $processor.Logger.LogTrace("Update needed for licenseType")
            }

            if (NeedsUpdate $currentLinuxLicenseType $linuxLicenseType) {
                $propertiesNeedingUpdate["linuxLicenseType"] = $linuxLicenseType
                $updatesLog += "linuxLicenseType: '$currentLinuxLicenseType' -> '$linuxLicenseType'"
                $processor.Logger.LogTrace("Update needed for linuxLicenseType")
            }

            if (NeedsUpdate $currentSqlServerLicenseType $sqlServerLicenseType) {
                $propertiesNeedingUpdate["sqlServerLicenseType"] = $sqlServerLicenseType
                $updatesLog += "sqlServerLicenseType: '$currentSqlServerLicenseType' -> '$sqlServerLicenseType'"
                $processor.Logger.LogTrace("Update needed for sqlServerLicenseType")
            }

            if (NeedsUpdate $currentTargetAvailabilitySetId $targetAvailabilitySetId) {
                $propertiesNeedingUpdate["targetAvailabilitySetId"] = $targetAvailabilitySetId
                $updatesLog += "targetAvailabilitySetId: '$currentTargetAvailabilitySetId' -> '$targetAvailabilitySetId'"
                $processor.Logger.LogTrace("Update needed for targetAvailabilitySetId")
            }

            if (NeedsUpdate $currentTargetProximityPlacementGroupId $targetProximityPlacementGroupId) {
                $propertiesNeedingUpdate["targetProximityPlacementGroupId"] = $targetProximityPlacementGroupId
                $updatesLog += "targetProximityPlacementGroupId: '$currentTargetProximityPlacementGroupId' -> '$targetProximityPlacementGroupId'"
                $processor.Logger.LogTrace("Update needed for targetProximityPlacementGroupId")
            }

            # If no updates needed
            if ($propertiesNeedingUpdate.Count -eq 0) {
                $processor.Logger.LogTrace("No updates needed for machine '$($sourceMachineName)'")
                $reportItem.UpdateStatus = "NoChangesNeeded"
                $reportItem.UpdateDetails = "All properties match CSV values"
                return
            }

            # Perform the update
            $processor.Logger.LogTrace("Updating $($propertiesNeedingUpdate.Count) properties for machine '$($sourceMachineName)'")
            
            $fabricName = $asrCommon.GetFabricServer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
            $protectionContainerName = $asrCommon.GetProtectionContainer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
            $protectedItemName = $protectedVM.name

            $updateResponse = InvokeProtectedItemUpdate `
                -logger $processor.Logger `
                -vaultSubscriptionId $vaultSubscriptionId `
                -vaultResourceGroupName $vaultResourceGroupName `
                -vaultName $vaultName `
                -fabricName $fabricName `
                -protectionContainerName $protectionContainerName `
                -protectedItemName $protectedItemName `
                -updateProperties $propertiesNeedingUpdate

            if ($updateResponse.StatusCode -eq 200 -or $updateResponse.StatusCode -eq 202) {
                $processor.Logger.LogTrace("Update operation accepted for protected item '$($sourceMachineName)'. Status: $($updateResponse.StatusCode)")
                $reportItem.UpdateStatus = "Success"
                $reportItem.UpdateDetails = ($updatesLog -join "; ")
                $processor.Logger.LogTrace("Successfully updated protected item '$($sourceMachineName)'")
            }
        }
        else {
            $processor.Logger.LogTrace("Machine '$($sourceMachineName)' is not a protected item in vault '$($vaultName)'. Skipping update.")
            $reportItem.UpdateStatus = "Skipped"
            $reportItem.UpdateDetails = "Machine not found as protected item in vault"
        }
    }
    catch {
        $processor.Logger.LogError("Error processing item: $_")
        $reportItem.UpdateStatus = "Failed"
        $reportItem.UpdateErrors = $_ | Out-String
    }  
 }

Function ProcessItem($processor, $csvItem, $reportItem) {
    try {
        ProcessItemImpl $processor $csvItem $reportItem
    }
    catch {
        $exceptionMessage = $_ | Out-String
        $processor.Logger.LogError($exceptionMessage)
        throw
    }
}

$logger = New-AsrLoggerInstance -CommandPath $PSCommandPath
$asrCommon = New-AsrCommonInstance -Logger $logger
$processor = New-CsvProcessorInstance -Logger $logger -ProcessItemFunction $function:ProcessItem
$processor.ProcessFile($CsvFilePath)
