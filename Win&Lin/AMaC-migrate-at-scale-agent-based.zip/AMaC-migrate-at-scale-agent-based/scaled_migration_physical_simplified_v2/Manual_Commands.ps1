    Connect-AzAccount -Tenant "0e478cd4-3e52-496d-ac3a-419ca58ba7ac" # Contoso
    $vaultSubscriptionId = "95642268-5116-484d-9b88-7dfce8c20ce4"
    $vaultResourceGroupName = "rg-infra-garinep-automation-demo"
    $vaultName = "pkgdemo-MigrateVault-2111897092"
    $sourceMachineName = "OraLinuxVm1.contoso.com"
    $targetMachineName ="WindVM2019App1"
    $processServer = "replication1"
    $targetSubscriptionId = "95642268-5116-484d-9b88-7dfce8c20ce4"
    $targetPostFailoverResourceGroup = "rg-infra-garinep-automation-demo"
    $CacheStorageAccountName = "migrate95642lsa708041"
    $CacheStorageAccountRG = "rg-infra-garinep-automation-demo"
    $targetBootDiagStorageAccountName = "migrate95642lsa708041"
    $targetBootDiagStorageAccountRG = "rg-infra-garinep-automation-demo"
    $targetVNET = "target-vnet"
    $targetVNETRG = "rg-infra-garinep-automation-demo"
    $targetSubnet = "app"
    $replicationPolicy = "24-hour-replication-policy"
    $runAsAccountName = "wincred"
    $targetVmSize = "Standard_B2s"
    #$sourceConfigurationServer = $csvItem.CONFIGURATION_SERVER
    $testFailoverVNET = "target-vnet"
    $testFailoverVNET_RG = "rg-infra-garinep-automation-demo"
    $testSubnet = "testSubnet"
    $recoveryVmManagedDiskType = "Standard_LRS"

    # List fabaric servers in vault
    $fabricuri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics?api-version=2025-08-01"
    $fabricName = ((Invoke-AzRestMethod -Method GET -Uri $fabricuri).Content | ConvertFrom-Json -Depth 100).value.where({$_.properties.customDetails.instanceType -eq 'InMageRCM'}).name
    Write-Output "InMage RCM Fabric Server : $fabricName"

    # Get details of Inmage RCM fabric server associated with the vault
    $inMagefabricuri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/${fabricName}?api-version=2025-08-01"
    $inMageFabricResponse = Invoke-AzRestMethod -Method GET -Uri $inMagefabricuri
    $processServerId = ($inMageFabricResponse.Content | ConvertFrom-Json -Depth 100).properties.customDetails.processServers | Where-Object { $_.Name -eq $processServer } | Select-Object -ExpandProperty id
    $physicalSiteId = ($inMageFabricResponse.Content | ConvertFrom-Json -Depth 100).properties.customDetails.physicalSiteId
    $physicalSiteName = $physicalSiteId.Split("/") | Select-Object -Last 1
    Write-Output "Process Server Id : $processServerId"
    Write-Output "Physical SiteName : $physicalSiteName"
    
    # Get protection container name
    $protectionContainerUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers?api-version=2025-08-01"
    $protectionContainerResponse = Invoke-AzRestMethod -Method GET -Uri $protectionContainerUri
    $protectionContainerName = ($protectionContainerResponse.Content | ConvertFrom-Json -Depth 100).value.name
    Write-Output "Protection Container Name : $protectionContainerName"

    # Get replication policy id
    $policyuri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationPolicies/${replicationPolicy}?api-version=2025-08-01"
    $policyResponse = Invoke-AzRestMethod -Method GET -Uri $policyuri
    $replicationPolicyId = ($policyresponse.Content | ConvertFrom-Json -Depth 100).id
    Write-Output "Replication Policy Id : $replicationPolicyId"

    # Get runAsAccount details from the vault 
    $runAsAccountUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.OffAzure/ServerSites/$physicalSiteName/runasaccounts?api-version=2023-06-06"
    $runAsAccountResponse = Invoke-AzRestMethod -Method GET -Uri $runAsAccountUri
    $runAsAccountId = ($runAsAccountResponse.Content | ConvertFrom-Json -Depth 100).value.where({ $_.properties.displayName -eq $runAsAccountName }).id 
    Write-Output "RunAs Account Id : '$($runAsAccountId)'"

    # Get details of discovered server details associated with the vault
    $fabricDiscoveryUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.OffAzure/ServerSites/$physicalSiteName/machines?api-version=2023-06-06"
    $fabricDiscoveryResponse = Invoke-AzRestMethod -Method GET -Uri $fabricDiscoveryUri
    $discoveredMachines = ($fabricDiscoveryResponse.Content | ConvertFrom-Json -Depth 100).value.properties.displayName
    Write-Output "Discovered Machines : $discoveredMachines"
    $fabricDiscoveryMachineId = ($fabricDiscoveryResponse.Content | ConvertFrom-Json -Depth 100).value.where({$_.properties.displayName -eq $sourceMachineName}).id
    Write-Output "Fabric Discovery Machine Id : '$($fabricDiscoveryMachineId)'"
    
<#     # Get details of protectable item
    $protectableItemUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectableItems/${sourceMachineName}?api-version=2025-08-01"
    # All protectable Items
    $protectableItemUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectableItems?api-version=2025-08-01"
    $protectableItemResponse = Invoke-AzRestMethod -Method GET -Uri $protectableItemUri

    if ($protectableItemResponse.StatusCode -ne 200)
    {
        Write-Output "Machine '$($sourceMachineName)' not found as protectable item in vault '$($vaultName)' Check if the mobility agent is installed."
        return
    }
 #>    
    # Get details of protected Item
    $protectedItemUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems?api-version=2025-08-01"
    $protectedItemResponse = Invoke-AzRestMethod -Method GET -Uri $protectedItemUri
    $protectedVM = ($protectedItemResponse.Content | ConvertFrom-Json -Depth 100).value | Where-Object { $_.properties.friendlyName -eq $sourceMachineName } 
     
    if ($protectedVM) {
        Write-Output "Machine '$($sourceMachineName)' is already a protected item in vault '$($vaultName)'"
        Write-Output "ProtectionState: '$($protectedVM.properties.protectionState)'"
        Write-Output "ProtectionDescription: '$($protectedVM.properties.protectionStateDescription)'"
        Write-Output "Skipping the replication enablement for machine '$($sourceMachineName)' as it is already protected with state '$($protectedVM.properties.protectionState)'"
    }
  
    # Create replication protection item name
    $slug = ($sourceMachineName.ToLower() -replace '\\', '-' -replace '_', '-' )
    $replicationProtectedItemName = "{0}-{1}" -f $slug, ([guid]::NewGuid().ToString())
    Write-Output "Replication Protected Item Name : '$($replicationProtectedItemName)'"

    $currentContext = Get-AzContext
    # Switch to target subscription
    Set-AzContext -SubscriptionId $targetSubscriptionId | Out-Null

            $targetRG = Get-AzResourceGroup -Name $targetPostFailoverResourceGroup -ErrorAction SilentlyContinue
            if ($null -eq $targetRG) {
                Write-Output "Target resource group '$($targetPostFailoverResourceGroup)' does not exist."
            }
            $targetResourceGroupId = $targetRG.ResourceId

            $targetVnet = Get-AzVirtualNetwork -Name $targetVNET -ResourceGroupName $targetVNETRG -ErrorAction SilentlyContinue
            if ($null -eq $targetVnet) {
                Write-Output "Target VNET '$($targetVNET)' in resource group '$($targetVNETRG)' does not exist."
            }
            $targetNetworkId = $targetVnet.Id

            # Validate Target Subnet
            $targetSubnetObj = $targetVnet.Subnets | Where-Object { $_.Name -eq $targetSubnet }
            if ($null -eq $targetSubnetObj) {
                Write-Output "Target subnet '$($targetSubnet)' does not exist in VNET '$($targetVNET)'."
            }
            Write-Output "Target VNET Id : '$($targetNetworkId)'"

            $testVnet = Get-AzVirtualNetwork -Name $testFailoverVNET -ResourceGroupName $testFailoverVNET_RG -ErrorAction SilentlyContinue
            if ($null -eq $testVnet) {
                Write-Output "Test Failover VNET '$($testFailoverVNET)' in resource group '$($testFailoverVNET_RG)' does not exist."
            }
            $testNetworkId = $testVnet.Id
            Write-Output "Test Failover VNET Id : '$($testNetworkId)'"
            # Validate Test Subnet
            $testSubnetObj = $testVnet.Subnets | Where-Object { $_.Name -eq $testSubnet }
            if ($null -eq $testSubnetObj) {
                Write-Output "Test Failover subnet '$($testSubnet)' does not exist in VNET '$($testFailoverVNET)'."
            }

            $targetBootDiagStorageAccount = Get-AzStorageAccount -Name $targetBootDiagStorageAccountName -ResourceGroupName $targetBootDiagStorageAccountRG
            if ($null -eq $targetBootDiagStorageAccount) {
                Write-Output "Boot diagnostics storage account '$($targetBootDiagStorageAccountName)' in resource group '$($targetBootDiagStorageAccountRG)' does not exist."
            }
            $targetBootDiagStorageAccountId = $targetBootDiagStorageAccount.Id
            Write-Output "Target Boot Diagnostics Storage Account Id : '$($targetBootDiagStorageAccountId)'"

            $cacheStorageAccount = Get-AzStorageAccount -Name $cacheStorageAccountName -ResourceGroupName $cacheStorageAccountRG
            if ($null -eq $cacheStorageAccount) {
                Write-Output "Cache storage account '$($cacheStorageAccountName)' in resource group '$($cacheStorageAccountRG)' does not exist."
            }
            $cacheStorageAccountId = $cacheStorageAccount.Id
            Write-Output "Cache Storage Account Id : '$($cacheStorageAccountId)'"

        # Restore original subscription
        Set-AzContext -SubscriptionId $currentContext.Subscription.Id | Out-Null

        # Start Replication for the source machine
        $startReplicationUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems/${replicationProtectedItemName}?api-version=2025-08-01"
    
        Write-Output "Start Replication Uri : '$($startReplicationUri)'"
        $processor.Logger.LogTrace("Start Replication Uri : '$($startReplicationUri)'") 
        $provider = [ordered]@{
            disksDefault = [ordered]@{
                diskType = $recoveryVmManagedDiskType
                logStorageAccountId = $CacheStorageAccountId
            }
            #disksToInclude
            fabricDiscoveryMachineId = $fabricDiscoveryMachineId
            instanceType             = "InMageRcm"
            #licenseType             = $LicenseType
            #linuxLicenseType        = $LinuxLicenseType
            #multiVmGroupName        
            #multiVmGroupName
            processServerId          = $processServerId
            runAsAccountId           = $runAsAccountId
            #seedManagedDiskTags
            #sqlServerLicenseType
            #targetAvailabilitySetId
            #targetAvailabilityZone
            targetBootDiagnosticsStorageAccountId = $targetBootDiagStorageAccountId
            #targetCapacityReservationGroupId
            #targetManagedDiskTags
            targetNetworkId = $targetNetworkId
            #targetNicTags
            #targetProximityPlacementGroupId
            targetResourceGroupId = $targetResourceGroupId
            targetSubnetName = $targetSubnet
            targetVmName = $targetMachineName
            targetVmSecurityProfile = $targetVmSecurityProfile
            targetVmSize = $targetVmSize
            #targetVmTags
            testNetworkId = $testNetworkId
            testSubnetName = $testSubnet
            userSelectedOSName = $userSelectedOSName
        }

        $body = [ordered]@{
            properties = @{
                policyId = $replicationPolicyId
                providerSpecificDetails = $provider
                protectableItemId = ""
            }
        } | ConvertTo-Json -Depth 100

        $startReplicationJob = Invoke-AzRestMethod -Method PUT -Uri $startReplicationUri -Payload $body

        if ($startReplicationJob.StatusCode -eq 202) {
            Write-Output "Replication started successfully for machine '$($sourceMachineName)'"
        }
        else {
            Write-Output "Failed to start replication for machine '$($sourceMachineName)'. Status Code: $($startReplicationJob.StatusCode), Response: $($startReplicationJob.Content)"
        }
       


###############

# Update Properties

$protectedItemName = $protectedVM.name

$testNetworkId = "/subscriptions/$targetSubscriptionId/resourceGroups/$testFailoverVNET_RG/providers/Microsoft.Network/virtualNetworks/$testFailoverVNET"

$updateProperties = @{
    # Example: Update the target VM size
    targetVmSize = $targetVmSize
    testNetworkId = $testNetworkId
}

$updateUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems/${protectedItemName}?api-version=2025-08-01"


    $requestBody = @{
        properties = @{
             "providerSpecificDetails"= @{
                 "instanceType"  = "InMageRcm" 
                 "targetVmSize" = $targetVmSize
                 "testNetworkId" = $testNetworkId
             }
        }
    } | ConvertTo-Json -Depth 100
    
    $logger.LogTrace("Update URI: $updateUri")
  Write-Output "Update payload: $requestBody"

    $response = Invoke-AzRestMethod -Method PATCH -Uri $updateUri -Payload $requestBody

############


#######

# Test Migrate

$testFailoverUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems/${replicatedProtectedItemName}/testFailover?api-version=2025-08-01"

            $body = @{
                properties = @{
                    failoverDirection = "PrimaryToRecovery"
                    networkType = "VmNetworkAsInput"
                    networkId = $testFailoverVNETObj.Id
                }
            } | ConvertTo-Json -Depth 10

            Write-Output "Starting Test Failover for machine '$($sourceMachineName)'"
            Write-Output "Test Failover Request Body: '$body'"
            #########
     
   



