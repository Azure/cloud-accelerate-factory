param(
    [Parameter(Mandatory = $true)]
    $VaultSubscriptionId,
    [Parameter(Mandatory = $true)]
    $VaultResourceGroupName,
    [Parameter(Mandatory = $true)]
    $VaultName
)

$ErrorActionPreference = 'Stop'

$scriptsPath = $PSScriptRoot
if ($PSScriptRoot -eq "") {
    $scriptsPath = "."
}

. "$scriptsPath\AzMigrate_ASR_Common.ps1"
. "$scriptsPath\AzMigrate_Logger.ps1"

$logger = New-AsrLoggerInstance -CommandPath $PSCommandPath
$asrCommon = New-AsrCommonInstance -Logger $logger

# Generate CSV output path with VaultName prefix and timestamp
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$CSVOutputPath = Join-Path -Path $PSScriptRoot -ChildPath "$($VaultName)_GetDiscoveredItems_$($timestamp).csv"

Write-Output "Retrieving discovered items from vault '$($VaultName)' in subscription     '$($VaultSubscriptionId)'..." 
 
$discoveredItemResponse = $asrCommon.GetDiscoveredMachines($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
 
if ($discoveredItemResponse.StatusCode -eq 200) {
    Write-Output "Retrieved discovered items from vault '$($VaultName)'. Status code: $($discoveredItemResponse.StatusCode)."
}
else {
    Write-Output "Failed to retrieve discovered items from vault '$($VaultName)'. Status code: $($discoveredItemResponse.StatusCode). Response content: $($discoveredItemResponse.Content)"
    return
}

$discoveredItemList = @()

$items = ($discoveredItemResponse.Content | ConvertFrom-Json -Depth 100).value
if (-not $items) {
    Write-Output "No discovered items found in vault '$($VaultName)'"
    return
}

foreach ($machine in $items) {
    # Extract disk details
    $disks = @()
    foreach ($disk in $machine.properties.disks) {
        $diskInfo = [PSCustomObject]@{
            Name = $disk.name
            DiskType = $disk.diskType
            LUN = $disk.lun
            Path = $disk.path
            MaxSizeBytes = $disk.maxSizeInBytes
            UsedSpaceBytes = $disk.usedSpaceInBytes
            LogicalSectorSizeBytes = $disk.logicalSectorSizeInBytes
        }
        $disks += $diskInfo
    }

    # If no disks, create one entry with null disk info
    if ($disks.Count -eq 0) {
        $pi = [PSCustomObject]@{
            DisplayName = $machine.properties.displayName
            FQDN = $machine.properties.fqdn
            OSType = $machine.properties.operatingSystemDetails.osType
            OSName = $machine.properties.operatingSystemDetails.osName
            OSVersion = $machine.properties.operatingSystemDetails.osVersion
            OSArchitecture = $machine.properties.operatingSystemDetails.osArchitecture
            ProcessorName = $machine.properties.processorInfo.name
            NumberOfSockets = $machine.properties.processorInfo.numberOfSockets
            CoresPerSocket = $machine.properties.processorInfo.numberOfCoresPerSocket
            TotalCores = $machine.properties.numberOfProcessorCore
            MemoryMB = $machine.properties.allocatedMemoryInMB
            TotalDiskSizeGB = $machine.properties.totalDiskSizeInGB
            IPAddresses = $machine.properties.ipAddresses
            SupportStatus = $machine.properties.productSupportStatus.supportStatus
            SupportEndDate = $machine.properties.productSupportStatus.supportEndDate
            CreatedTimestamp = $machine.properties.createdTimestamp
            UpdatedTimestamp = $machine.properties.updatedTimestamp
            DiskName = $null
            DiskType = $null
            DiskLUN = $null
            DiskPath = $null
            DiskMaxSizeBytes = $null
            DiskUsedSpaceBytes = $null
            DiskLogicalSectorSizeBytes = $null
        }
        $discoveredItemList += $pi
    } else {
        # Create one entry per disk
        foreach ($disk in $disks) {
            $pi = [PSCustomObject]@{
                DisplayName = $machine.properties.displayName
                FQDN = $machine.properties.fqdn
                OSType = $machine.properties.operatingSystemDetails.osType
                OSName = $machine.properties.operatingSystemDetails.osName
                OSVersion = $machine.properties.operatingSystemDetails.osVersion
                OSArchitecture = $machine.properties.operatingSystemDetails.osArchitecture
                ProcessorName = $machine.properties.processorInfo.name
                NumberOfSockets = $machine.properties.processorInfo.numberOfSockets
                CoresPerSocket = $machine.properties.processorInfo.numberOfCoresPerSocket
                TotalCores = $machine.properties.numberOfProcessorCore
                MemoryMB = $machine.properties.allocatedMemoryInMB
                TotalDiskSizeGB = $machine.properties.totalDiskSizeInGB
                IPAddresses = $machine.properties.ipAddresses
                SupportStatus = $machine.properties.productSupportStatus.supportStatus
                SupportEndDate = $machine.properties.productSupportStatus.supportEndDate
                CreatedTimestamp = $machine.properties.createdTimestamp
                UpdatedTimestamp = $machine.properties.updatedTimestamp
                DiskName = $disk.Name
                DiskType = $disk.DiskType
                DiskLUN = $disk.LUN
                DiskPath = $disk.Path
                DiskMaxSizeBytes = $disk.MaxSizeBytes
                DiskUsedSpaceBytes = $disk.UsedSpaceBytes
                DiskLogicalSectorSizeBytes = $disk.LogicalSectorSizeBytes
            }
            $discoveredItemList += $pi
        }
    }
}

# Ensure output folder exists
$outputDir = Split-Path -Parent $CSVOutputPath
if (-not (Test-Path -Path $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
}

$discoveredItemList | Export-Csv -Path $CSVOutputPath -NoTypeInformation -Force
Write-Output "Exported discovered item list to: $CSVOutputPath"