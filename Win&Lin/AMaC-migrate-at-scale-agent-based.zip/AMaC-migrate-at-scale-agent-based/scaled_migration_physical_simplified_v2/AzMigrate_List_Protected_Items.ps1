param(
    [Parameter(Mandatory = $true)]
    $VaultSubscriptionId,
    [Parameter(Mandatory = $true)]
    $VaultResourceGroupName,
    [Parameter(Mandatory = $true)]
    $VaultName
)

$ErrorActionPreference = 'Stop'

$scriptsPath = $PSScriptRoot
if ($PSScriptRoot -eq "") {
    $scriptsPath = "."
}

. "$scriptsPath\AzMigrate_ASR_Common.ps1"
. "$scriptsPath\AzMigrate_Logger.ps1"

$logger = New-AsrLoggerInstance -CommandPath $PSCommandPath
$asrCommon = New-AsrCommonInstance -Logger $logger

# Generate CSV output path with VaultName prefix and timestamp
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$CSVOutputPath = Join-Path -Path $PSScriptRoot -ChildPath "$($VaultName)_GetProtectedItems_$($timestamp).csv"

class ProtectedItemInfo 
 {
    [string]$ProcessServerName
    [string]$FriendlyName
    [string]$OsName    
    [string]$ProtectionState
    [string]$ProtectionStateDescription
    [string]$ReplicationHealth    
    [string]$TestFailoverState
    [string]$TestFailoverStateDescription
    [string]$InitialReplicationProgressPercentage
    [string]$InitialReplicationProgressHealth
 }

Write-Output "Retrieving protected items from vault '$($VaultName)' in subscription     '$($VaultSubscriptionId)'..." 
 
$protectedItemResponse = $asrCommon.GetProtectedItemFromVault($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)

if ($protectedItemResponse.StatusCode -eq 200) {
    Write-Output "Retrieved protected items from vault '$($VaultName)'. Status code: $($protectedItemResponse.StatusCode)."
}
else {
    Write-Output "Failed to retrieve protected items from vault '$($VaultName)'. Status code: $($protectedItemResponse.StatusCode). Response content: $($protectedItemResponse.Content)"
    return
}

$protectedItemList = @()

$items = ($protectedItemResponse.Content | ConvertFrom-Json -Depth 100).value
if (-not $items) {
    Write-Output "No protected items found in vault '$($VaultName)'"
    return
}

foreach ($item in $items) {
    $pi = [ProtectedItemInfo]::new()

    if ($item.properties) {
        $pi.ProcessServerName = if ($item.properties.providerSpecificDetails -and $item.properties.providerSpecificDetails.processServerName) { $item.properties.providerSpecificDetails.processServerName } else { $null }
        $pi.FriendlyName = $item.properties.friendlyName
        $pi.OsName = if ($item.properties.providerSpecificDetails -and $item.properties.providerSpecificDetails.osName) { $item.properties.providerSpecificDetails.osName } else { $null }
        $pi.ProtectionState = $item.properties.protectionState
        $pi.ProtectionStateDescription = $item.properties.protectionStateDescription
        $pi.ReplicationHealth = $item.properties.replicationHealth
        $pi.TestFailoverState = $item.properties.testFailoverState
        $pi.TestFailoverStateDescription = $item.properties.testFailoverStateDescription
        $pi.InitialReplicationProgressPercentage = $item.properties.providerSpecificDetails.initialReplicationProgressPercentage
        $pi.InitialReplicationProgressHealth = $item.properties.providerSpecificDetails.initialReplicationProgressHealth
    }

    $protectedItemList += $pi
}

# Ensure output folder exists
$outputDir = Split-Path -Parent $CSVOutputPath
if (-not (Test-Path -Path $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
}

$protectedItemList | Export-Csv -Path $CSVOutputPath -NoTypeInformation -Force
Write-Output "Exported protected item list to: $CSVOutputPath"