Param(
    [parameter(Mandatory = $true)]
    $CsvFilePath
)

$ErrorActionPreference = "Stop"

$scriptsPath = $PSScriptRoot
if ($PSScriptRoot -eq "") {
    $scriptsPath = "."
}

. "$scriptsPath\AzMigrate_Logger.ps1"
. "$scriptsPath\AzMigrate_ASR_Common.ps1"
. "$scriptsPath\AzMigrate_CSV_Processor.ps1"


function ParseTagsFromString($logger, [string]$tagsString) {
    <#
    .DESCRIPTION
    Parses JSON tag input and returns an array of UserCreatedResourceTag objects:
    [ { "tagName": "key1", "tagValue": "value1" }, ... ]

    Accepted input formats:
      - JSON object: { "env":"prod", "team":"migration" }
      - JSON array: [ { "tagName":"env", "tagValue":"prod" }, ... ]

    Returns an array of hashtables or $null if input is empty/pending.
    #>
    
    if ([string]::IsNullOrWhiteSpace($tagsString) -or $tagsString -eq "Pending") {
        return $null
    }
    
    try {
        $tagObject = $tagsString | ConvertFrom-Json
        if ($null -eq $tagObject) {
            return $null
        }
        
        $tagArray = @()
        if ($tagObject -is [System.Collections.IEnumerable] -and -not ($tagObject -is [string])) {
            foreach ($item in $tagObject) {
                if ($item.PSObject.Properties.Name -contains 'tagName' -and $item.PSObject.Properties.Name -contains 'tagValue') {
                    $tagArray += @{ tagName = $item.tagName; tagValue = $item.tagValue }
                }
                elseif ($item.PSObject.Properties.Count -eq 2 -and $item.PSObject.Properties.Name -contains 'key' -and $item.PSObject.Properties.Name -contains 'value') {
                    $tagArray += @{ tagName = $item.key; tagValue = $item.value }
                }
            }
        }
        else {
            foreach ($property in $tagObject.PSObject.Properties) {
                $tagArray += @{ tagName = $property.Name; tagValue = $property.Value }
            }
        }
        
        if ($tagArray.Count -gt 0) {
            $logger.LogTrace("Tags parsed into UserCreatedResourceTag[]: $($tagArray | ConvertTo-Json -Compress)")
            return $tagArray
        }
        return $null
    }
    catch {
        $logger.LogWarning("Failed to parse tags from JSON string '$tagsString'. Error: $_. Tags will be ignored.")
        return $null
    }
}


function CheckParameter($logger, [string]$parameterName, [string]$ExpectedValue,[string]$ActualValue) {
    $logger.LogTrace("Checking parameter '$parameterName'. Expected Value: '$ExpectedValue', Actual Value: '$ActualValue'")
    if ($ExpectedValue -ne $ActualValue) {
        $logger.LogError("Parameter '$parameterName' does not match the expected value. Expected: '$ExpectedValue', Actual: '$ActualValue'")
        throw "Parameter '$parameterName' does not match the expected value. Expected: '$ExpectedValue', Actual: '$ActualValue'"
    }
    else {
        $logger.LogTrace("Parameter '$parameterName' matches the expected value.")
    }
}


Function ProcessItemImpl($processor, $csvItem, $reportItem) {
    $reportItem | Add-Member NoteProperty "ProtectableStatus" $null
    $reportItem | Add-Member NoteProperty "ProtectionState" $null
    $reportItem | Add-Member NoteProperty "ProtectionStateDescription" $null
    $reportItem | Add-Member NoteProperty "ReplicationJobId" $null

    $vaultSubscriptionId = $csvItem.VAULT_SUBSCRIPTION_ID
    $vaultResourceGroupName = $csvItem.VAULT_RESOURCE_GROUP_NAME
    $vaultName = $csvItem.VAULT_NAME
    $sourceMachineName = $csvItem.SOURCE_MACHINE_NAME
    $targetMachineName = $csvItem.TARGET_MACHINE_NAME
    $targetVmSize = $csvItem.MACHINE_SIZE
    $processServer = $csvItem.PROCESS_SERVER
    $targetSubscriptionId = $csvItem.TARGET_SUBSCRIPTION_ID
    $targetPostFailoverResourceGroup = $csvItem.TARGET_RESOURCE_GROUP
    $cacheStorageAccountName = $csvItem.CACHE_STORAGE_ACCOUNT
    $cacheStorageAccountRG = $csvItem.CACHE_STORAGE_ACCOUNT_RG
    $targetBootDiagStorageAccountName = $csvItem.TARGET_BOOTDIAG_STORAGE_ACCOUNT
    $targetBootDiagStorageAccountRG = $csvItem.TARGET_BOOTDIAG_STORAGE_ACCOUNT_RG
    $targetVNETRG = $csvItem.TARGET_VNET_RG
    $targetVNET = $csvItem.TARGET_VNET
    $targetSubnet = $csvItem.TARGET_SUBNET
    $replicationPolicy = $csvItem.REPLICATION_POLICY
    $runAsAccountName = $csvItem.CREDENTIAL_FRIENDLY_NAME
    #$sourceConfigurationServer = $csvItem.CONFIGURATION_SERVER
    $testFailoverVNET = $csvItem.TESTFAILOVER_VNET
    $testFailoverVNET_RG = $csvItem.TESTFAILOVER_VNET_RG
    $testSubnet = $csvItem.TESTFAILOVER_SNET
    $recoveryVmManagedDiskType = $csvItem.RECOVERY_VM_MANAGED_DISK_TYPE
    $licenseType = $csvItem.LICENSE_TYPE
    $linuxLicenseType = $csvItem.LINUX_LICENSE_TYPE
    $sqlServerLicenseType = $csvItem.SQL_SERVER_LICENSE_TYPE
    $availabilitySet = $csvItem.AVAILABILITY_SET
    $availabilityZone = $csvItem.AVAILABILITY_ZONE
    $proximityPlacementGroup = $csvItem.PROXIMITY_PLACEMENT_GROUP
    $targetVmTags = $csvItem.TARGET_VM_TAGS

    # Ensure vault exists and collect related context
    $vaultContext = $asrCommon.GetVaultContext(
        $vaultSubscriptionId,
        $vaultResourceGroupName,
        $vaultName,
        $processServer,
        $replicationPolicy,
        $runAsAccountName,
        $sourceMachineName
    )

    $processor.Logger.LogTrace("Vault with name '$($vaultContext.VaultServer.Name)' found.")
    $processor.Logger.LogTrace("Fabric Name : '$($vaultContext.FabricName)'")
    $processor.Logger.LogTrace("Process Server Id : '$($vaultContext.ProcessServerId)'")
    $processor.Logger.LogTrace("Replication Policy Id : '$($vaultContext.ReplicationPolicyId)'")
    $processor.Logger.LogTrace("RunAs Account Id : '$($vaultContext.RunAsAccountId)'")
    $processor.Logger.LogTrace("Fabric discovery machine Id : '$($vaultContext.FabricDiscoveryMachineId)'")
    $processor.Logger.LogTrace("Protection Container Name : '$($vaultContext.ProtectionContainerName)'")

    # Use cached context values from GetVaultContext (avoid extra REST calls)
    $fabricName = $vaultContext.FabricName
    $processServerId = $vaultContext.ProcessServerId
    $replicationPolicyId = $vaultContext.ReplicationPolicyId
    $runAsAccountId = $vaultContext.RunAsAccountId
    $fabricDiscoveryMachineId = $vaultContext.FabricDiscoveryMachineId
    $protectionContainerName = $vaultContext.ProtectionContainerName

    if ($null -eq $fabricDiscoveryMachineId) {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' not found in fabric discovery for vault '$($vaultName)'")
    }

    # Get protected item details for the source machine if it is already a protected item in the vault
    $protectedItemResponse = $asrCommon.GetProtectedItemFromVault($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    $protectedVM = ($protectedItemResponse.Content | ConvertFrom-Json -Depth 100).value | Where-Object { $_.properties.friendlyName -eq $sourceMachineName } 
     
    if ($protectedVM) {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' is already a protected item in vault '$($vaultName)'")
        $processor.Logger.LogTrace("ProtectionState: '$($protectedVM.properties.protectionState)'")
        $processor.Logger.LogTrace("ProtectionDescription: '$($protectedVM.properties.protectionStateDescription)'")
        $processor.Logger.LogTrace("Skipping the replication enablement for machine '$($sourceMachineName)' as it is already protected with state '$($protectedVM.properties.protectionState)'")
        Write-Host "Machine '$($sourceMachineName)' is already a protected item in vault '$($vaultName)' with protection state '$($protectedVM.properties.protectionState)'. Skipping replication enablement." -ForegroundColor Yellow -BackgroundColor Yellow 
    }
    else {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' is not a protected item in vault '$($vaultName)'")
        $processor.Logger.LogTrace("Starting replication for machine '$($sourceMachineName)'")
        # Create replication protection item name
        $slug = ($sourceMachineName.ToLower() -replace '\\', '-' -replace '_', '-' )
        $replicationProtectedItemName = "{0}-{1}" -f $slug, ([guid]::NewGuid().ToString())
        $processor.Logger.LogTrace("Replication Protected Item Name : '$($replicationProtectedItemName)'")
       
        # Validate target environment details before starting replication (Exit on failure)
        $targetEnv = $asrCommon.ValidateTargetEnvironment(
            $targetSubscriptionId,
            $targetPostFailoverResourceGroup,
            $targetVNET,
            $targetVNETRG,
            $targetSubnet,
            $testFailoverVNET,
            $testFailoverVNET_RG,
            $testSubnet,
            $targetBootDiagStorageAccountName,
            $targetBootDiagStorageAccountRG,
            $cacheStorageAccountName,
            $cacheStorageAccountRG,
            $licenseType, 
            $linuxLicenseType,
            $sqlServerLicenseType,
            $availabilitySet,
            $targetProximityPlacementGroupIdValue
        )

        $targetResourceGroupId = $targetEnv.TargetResourceGroupId
        $targetNetworkId = $targetEnv.TargetNetworkId
        $testNetworkId = $targetEnv.TestNetworkId
        $targetBootDiagStorageAccountId = $targetEnv.TargetBootDiagnosticsStorageAccountId
        $CacheStorageAccountId = $targetEnv.CacheStorageAccountId
        $targetAvailabilitySetId = $targetEnv.TargetAvailabilitySetId
        $targetProximityPlacementGroupId = $targetEnv.TargetProximityPlacementGroupId

        # Parse availability zone if provided
        $targetAvailabilityZoneValue = $null
        if ($availabilityZone -and $availabilityZone -ne "" -and $availabilityZone -ne "Pending") {
            $targetAvailabilityZoneValue = $availabilityZone
            $processor.Logger.LogTrace("Target Availability Zone : '$($targetAvailabilityZoneValue)'")
        }

        # Construct target proximity placement group ARM ID if provided
        $targetProximityPlacementGroupIdValue = $null
        if ($proximityPlacementGroup) {
            # Check if already an ARM ID or needs to be constructed
            if ($proximityPlacementGroup.StartsWith("/subscriptions/")) {
                $targetProximityPlacementGroupIdValue = $proximityPlacementGroup
            }
            else {
                # Construct ARM ID from proximity placement group name
                $targetProximityPlacementGroupIdValue = "/subscriptions/$targetSubscriptionId/resourceGroups/$targetPostFailoverResourceGroup/providers/Microsoft.Compute/proximityPlacementGroups/$proximityPlacementGroup"
            }
            $processor.Logger.LogTrace("Target Proximity Placement Group Id : '$($targetProximityPlacementGroupIdValue)'")
        }

        # Validate that both availability zone and availability set are not specified together
        if ($null -ne $targetAvailabilityZoneValue -and $null -ne $targetAvailabilitySetId) {
            $processor.Logger.LogError("Machine '$($sourceMachineName)' cannot have both availability zone '$($targetAvailabilityZoneValue)' and availability set '$($targetAvailabilitySetId)' specified. These are mutually exclusive options in Azure.")
            throw "Virtual machine '$($sourceMachineName)' cannot be part of both availability zone and availability set. Specify either availability zone or availability set as the target setting and retry."
        }

        # Warn if proximity placement group is used with availability zone
        if ($null -ne $targetProximityPlacementGroupId -and $null -ne $targetAvailabilityZoneValue) {
            $processor.Logger.LogWarning("Machine '$($sourceMachineName)' has both proximity placement group '$($targetProximityPlacementGroupId)' and availability zone '$($targetAvailabilityZoneValue)' specified. Proximity placement groups work best with availability sets. Verify this configuration is intentional.")
        }

        # Parse target VM tags
        $targetVmTagsHashtable = ParseTagsFromString $processor.Logger $targetVmTags
        if ($targetVmTagsHashtable) {
            $processor.Logger.LogTrace("Target VM Tags: $($targetVmTagsHashtable | ConvertTo-Json -Compress)")
        }

        # Start Replication for the source machine
        $processor.Logger.LogTrace("Starting replication for machine '$($sourceMachineName)' ")
        $startReplicationUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$fabricName/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems/${replicationProtectedItemName}?api-version=2025-08-01"
        $processor.Logger.LogTrace("Start Replication Uri : '$($startReplicationUri)'")
        $provider = [ordered]@{
            disksDefault = [ordered]@{
                diskType = $recoveryVmManagedDiskType
                logStorageAccountId = $CacheStorageAccountId
            }
            #disksToInclude
            fabricDiscoveryMachineId = $fabricDiscoveryMachineId
            instanceType             = "InMageRcm"
            licenseType              = $licenseType
            linuxLicenseType         = $linuxLicenseType
            sqlServerLicenseType     = $sqlServerLicenseType
            #multiVmGroupName        
            #multiVmGroupName
            processServerId          = $processServerId
            runAsAccountId           = $runAsAccountId
            #seedManagedDiskTags
            targetAvailabilitySetId = $targetAvailabilitySetId
            targetAvailabilityZone = $targetAvailabilityZoneValue
            targetBootDiagnosticsStorageAccountId = $targetBootDiagStorageAccountId
            #targetCapacityReservationGroupId
            #targetManagedDiskTags
            targetNetworkId = $targetNetworkId
            #targetNicTags
            targetProximityPlacementGroupId = $targetProximityPlacementGroupId
            targetResourceGroupId = $targetResourceGroupId
            targetSubnetName = $targetSubnet
            targetVmName = $targetMachineName
            targetVmSecurityProfile = $targetVmSecurityProfile
            targetVmSize = $targetVmSize
            targetVmTags = $targetVmTagsHashtable
            testNetworkId = $testNetworkId
            testSubnetName = $testSubnet
            #userSelectedOSName = $userSelectedOSName
        }
        $body = [ordered]@{
            properties = @{
                policyId = $replicationPolicyId
                providerSpecificDetails = $provider
                protectableItemId = ""
            }
        } | ConvertTo-Json -Depth 100
        $startReplicationJob = Invoke-AzRestMethod -Method PUT -Uri $startReplicationUri -Payload $body
        $processor.Logger.LogTrace(" Json body is '$($body)'" )
        if ($startReplicationJob.StatusCode -eq 202) {
            $processor.Logger.LogTrace("Replication started successfully for machine '$($sourceMachineName)'")
            Write-Host "Replication started successfully for machine '$($sourceMachineName)'" -ForegroundColor Green -BackgroundColor Black
        }
        else {
            $processor.Logger.LogError("Failed to start replication for machine '$($sourceMachineName)'. Status Code: '$($startReplicationJob.StatusCode)'. Response: '$($startReplicationJob.Content)'")
        }
    }
}
Function ProcessItem($processor, $csvItem, $reportItem) {
    try {
        ProcessItemImpl $processor $csvItem $reportItem
    }
    catch {
        $exceptionMessage = $_ | Out-String
        $processor.Logger.LogError($exceptionMessage)
        throw
    }
}
$logger = New-AsrLoggerInstance -CommandPath $PSCommandPath
$asrCommon = New-AsrCommonInstance -Logger $logger
$processor = New-CsvProcessorInstance -Logger $logger -ProcessItemFunction $function:ProcessItem
$processor.ProcessFile($CsvFilePath)