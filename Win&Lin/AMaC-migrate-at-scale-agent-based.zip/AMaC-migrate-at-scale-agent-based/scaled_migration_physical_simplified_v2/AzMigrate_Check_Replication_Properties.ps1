Param(
    [parameter(Mandatory = $true)]
    $CsvFilePath
)

$ErrorActionPreference = "Stop"

$scriptsPath = $PSScriptRoot
if ($PSScriptRoot -eq "") {
    $scriptsPath = "."
}

. "$scriptsPath\AzMigrate_Logger.ps1"
. "$scriptsPath\AzMigrate_ASR_Common.ps1"
. "$scriptsPath\AzMigrate_CSV_Processor.ps1"

Function CheckParameter($logger, [string]$parameterName, [string]$ExpectedValue, [string]$ActualValue) {
    if ($ExpectedValue -ne $ActualValue) {
        $logger.LogTrace("Check FAILED for parameter '$parameterName'. Expected value: '$ExpectedValue', Actual value: '$ActualValue'")
        throw "Check failed for parameter '$parameterName'. Expected value: '$ExpectedValue', Actual value: '$ActualValue'"
     } else{             
        $logger.LogTrace("Check passed for parameter '$parameterName'. Expected value: '$ExpectedValue', Actual value: '$ActualValue'")
     }
    }

Function ProcessItemImpl($processor, $csvItem, $reportItem) {
    $reportItem | Add-Member NoteProperty "SourceMachineNameCheck" $null  #properties.friendlyName
    $reportItem | Add-Member NoteProperty "TargetMachineNameCheck" $null  #properties.targetVmName
    $reportItem | Add-Member NoteProperty "TargetResourceGroupCheck" $null #properties.targetResourceGroupId
    $reportItem | Add-Member NoteProperty "BootDiagStorageAccountCheck" $null #properties.targetBootDiagnosticsStorageAccountId
    $reportItem | Add-Member NoteProperty "BootDiagStorageAccountRGCheck" $null #properties.targetBootDiagnosticsStorageAccountId
    $reportItem | Add-Member NoteProperty "TargetMachineSizeCheck" $null   #properties.targetVmSize
    $reportItem | Add-Member NoteProperty "TargetVNETRGCheck" $null    #properties.targetNetworkId
    $reportItem | Add-Member NoteProperty "TargetVNETCheck" $null      #properties.targetNetworkId
    #$reportItem | Add-Member NoteProperty "TargetSubnetCheck" $null      # ASR will not store subnet info, only vnet level
    $reportItem | Add-Member NoteProperty "TestVNETRGCheck" $null      #properties.testNetworkId
    $reportItem | Add-Member NoteProperty "TestVNETCheck" $null        #properties.testNetworkId
    #$reportItem | Add-Member NoteProperty "TestSubnetCheck" $null      # # ASR will not store subnet info, only vnet level
    $reportItem | Add-Member NoteProperty "LicenseTypeCheck" $null #licenseType
    $reportItem | Add-Member NoteProperty "LinuxLicenseTypeCheck" $null #linuxLicenseType
    $reportItem | Add-Member NoteProperty "SQLServerLicenseTypeCheck" $null   #sqlServerLicenseType

    $vaultSubscriptionId = $csvItem.VAULT_SUBSCRIPTION_ID
    $vaultResourceGroupName = $csvItem.VAULT_RESOURCE_GROUP_NAME
    $vaultName = $csvItem.VAULT_NAME
    $sourceMachineName = $csvItem.SOURCE_MACHINE_NAME
    $targetMachineName = $csvItem.TARGET_MACHINE_NAME
    $targetPostFailoverResourceGroup = $csvItem.TARGET_RESOURCE_GROUP
    $targetBootDiagStorageAccountName = $csvItem.TARGET_BOOTDIAG_STORAGE_ACCOUNT
    $targetBootDiagStorageAccountRG = $csvItem.TARGET_BOOTDIAG_STORAGE_ACCOUNT_RG
    $targetVNETRG = $csvItem.TARGET_VNET_RG
    $targetVNET = $csvItem.TARGET_VNET
    #$targetSubnet = $csvItem.TARGET_SUBNET
    #$replicationPolicy = $csvItem.REPLICATION_POLICY
    #$runAsAccountName = $csvItem.CREDENTIAL_FRIENDLY_NAME
    $targetVmSize = $csvItem.MACHINE_SIZE
    #$sourceConfigurationServer = $csvItem.CONFIGURATION_SERVER
    $testFailoverVNET = $csvItem.TESTFAILOVER_VNET
    $testFailoverVNET_RG = $csvItem.TESTFAILOVER_VNET_RG
    #$testSubnet = $csvItem.TESTFAILOVER_SUBNET
    $licenseType = $csvItem.LICENSE_TYPE
    $linuxLicenseType = $csvItem.LINUX_LICENSE_TYPE
    $sqlServerLicenseType = $csvItem.SQL_SERVER_LICENSE_TYPE

    
    # Ensure vault exists and fetch vault details
    $vaultResponse = $asrCommon.GetAndEnsureVaultContext($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    $processor.Logger.LogTrace("Successfully retrieved vault context for vault '$($vaultResponse.Name)' in subscription '$($vaultSubscriptionId)'")

    # Get protected item details for the source machine if it is already a protected item in the vault
    $protectedItemResponse = $asrCommon.GetProtectedItemFromVault($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    $protectedVM = ($protectedItemResponse.Content | ConvertFrom-Json -Depth 100).value | Where-Object { $_.properties.friendlyName -eq $sourceMachineName } 
     
    if ($protectedVM) {
        $reportItem.SourceMachineNameCheck = "Pass"
        
        # TargetMachineNameCheck
        try {
            CheckParameter $processor.Logger "TARGET_MACHINE_NAME" $targetMachineName $protectedVM.properties.providerSpecificDetails.targetVmName
            $reportItem.TargetMachineNameCheck = "Pass"
        }
        catch {
            $reportItem.TargetMachineNameCheck = "Fail"
        }

        #TargetResourceGroupCheck 
        try {
            CheckParameter $processor.Logger "TARGET_RESOURCE_GROUP" $targetPostFailoverResourceGroup ($protectedVM.properties.providerSpecificDetails.targetResourceGroupId -split "/")[-1]
            $reportItem.TargetResourceGroupCheck = "Pass"
        }
        catch {
            $reportItem.TargetResourceGroupCheck = "Fail"
        }
        
        # BootDiagStorageAccountCheck  
        try {
            CheckParameter $processor.Logger "TARGET_BOOTDIAG_STORAGE_ACCOUNT" $targetBootDiagStorageAccountName ($protectedVM.properties.providerSpecificDetails.targetBootDiagnosticsStorageAccountId -split "/")[-1]
            $reportItem.BootDiagStorageAccountCheck = "Pass"
        }
        catch {
            $reportItem.BootDiagStorageAccountCheck = "Fail"
        } 
        
        # BootDiagStorageAccountRGCheck  
        try {
            
            $targetBootDiagnosticsStorageAccountId = $protectedVM.properties.providerSpecificDetails.targetBootDiagnosticsStorageAccountId
            CheckParameter $processor.Logger "TARGET_BOOTDIAG_STORAGE_ACCOUNT_RG" $targetBootDiagStorageAccountRG ($targetBootDiagnosticsStorageAccountId -split "/")[($targetBootDiagnosticsStorageAccountId -split "/").IndexOf("resourceGroups") + 1]
            $reportItem.BootDiagStorageAccountRGCheck = "Pass"
        }
        catch {
            $reportItem.BootDiagStorageAccountRGCheck = "Fail"
        } 
         
       # TargetMachineSizeCheck
        
        try {
            CheckParameter $processor.Logger "MACHINE_SIZE" $targetVmSize $protectedVM.properties.providerSpecificDetails.targetVmSize
            $reportItem.TargetMachineSizeCheck = "Pass"
        }
        catch {
            $reportItem.TargetMachineSizeCheck = "Fail"
        } 

        # TargetVNETRGCheck  

        try {
            CheckParameter $processor.Logger "TARGET_VNET_RG" $targetVNETRG ($protectedVM.properties.providerSpecificDetails.targetNetworkId -split "/")[($protectedVM.properties.providerSpecificDetails.targetNetworkId -split "/").IndexOf("resourceGroups") + 1]
            $reportItem.TargetVNETRGCheck = "Pass" 
        }
        catch {
            $reportItem.TargetVNETRGCheck = "Fail"
        } 

        # TargetVNETCheck  
        try {
            CheckParameter $processor.Logger "TARGET_VNET" $targetVNET ($protectedVM.properties.providerSpecificDetails.targetNetworkId -split "/")[-1]
            $reportItem.TargetVNETCheck = "Pass" 
        }
        catch {
            $reportItem.TargetVNETCheck = "Fail"
        }
        
        # TestVNETRGCheck  
        try {
            CheckParameter $processor.Logger "TESTFAILOVER_VNET_RG" $testFailoverVNET_RG ($protectedVM.properties.providerSpecificDetails.testNetworkId -split "/")[($protectedVM.properties.providerSpecificDetails.testNetworkId -split "/").IndexOf("resourceGroups") + 1]
            $reportItem.TestVNETRGCheck = "Pass" 
        }
        catch {
            $reportItem.TestVNETRGCheck = "Fail"
        }

        # TestVNETCheck  
        try {     
            CheckParameter $processor.Logger "TESTFAILOVER_VNET" $testFailoverVNET ($protectedVM.properties.providerSpecificDetails.testNetworkId -split "/")[-1]
            $reportItem.TestVNETCheck = "Pass" 
        }
        catch {
            $reportItem.TestVNETCheck = "Fail"
        }

        # LicenseTypeCheck  
        try {      
            CheckParameter $processor.Logger "LICENSE_TYPE" $licenseType $protectedVM.properties.providerSpecificDetails.licenseType
            $reportItem.LicenseTypeCheck = "Pass" 
        }
        catch {
            $reportItem.LicenseTypeCheck = "Fail"
        }

        # LinuxLicenseTypeCheck  
        try {      
            CheckParameter $processor.Logger "LINUX_LICENSE_TYPE" $linuxLicenseType $protectedVM.properties.providerSpecificDetails.linuxLicenseType
            $reportItem.LinuxLicenseTypeCheck = "Pass" 
        }
        catch {
            $reportItem.LinuxLicenseTypeCheck = "Fail"
        }   

        # SQLServerLicenseTypeCheck  
        try {      
            CheckParameter $processor.Logger "SQL_SERVER_LICENSE_TYPE" $sqlServerLicenseType $protectedVM.properties.providerSpecificDetails.sqlServerLicenseType
            $reportItem.SQLServerLicenseTypeCheck = "Pass" 
        }
        catch {
            $reportItem.SQLServerLicenseTypeCheck = "Fail"
        }
    }
    else {
        $processor.Logger.LogTrace("Machine '$($sourceMachineName)' is not a protected item in vault '$($vaultName)'")

    }
}   
Function ProcessItem($processor, $csvItem, $reportItem) {
    try {
        ProcessItemImpl $processor $csvItem $reportItem
    }
    catch {
        $exceptionMessage = $_ | Out-String
        $processor.Logger.LogError($exceptionMessage)
        throw
    }
}
$logger = New-AsrLoggerInstance -CommandPath $PSCommandPath
$asrCommon = New-AsrCommonInstance -Logger $logger
$processor = New-CsvProcessorInstance -Logger $logger -ProcessItemFunction $function:ProcessItem
$processor.ProcessFile($CsvFilePath)