class AsrCommon
{
    [psobject]$Logger
    [hashtable]$FabricServerCache = @{}
    [hashtable]$InMageFabricDetailsCache = @{}
    [hashtable]$InMageFabricDetailsJsonCache = @{}
    [hashtable]$ProtectionContainerCache = @{}
    [hashtable]$RunAsAccountCache = @{}
    [hashtable]$DiscoveredMachinesCache = @{}
    [hashtable]$ReplicationPolicyCache = @{}

    AsrCommon($logger)
    {
        $this.Logger = $logger
    }

    [string] GetVaultCacheKey($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        return "$vaultSubscriptionId|$vaultResourceGroupName|$vaultName"
    }

    # Ensure vault exists
    [psobject] GetAndEnsureVaultContext($vaultSubscriptionId,$vaultResourceGroupName,$vaultName)
    {
        $this.Logger.LogTrace("Ensuring services vault exists '$($vaultName)'")
        $tenantId = (Get-AzContext).Tenant.Id  # Only scan vaults in the current tenant context to avoid cross-tenant issues in Get-AzRecoveryServicesVault call. The vault subscription can be different from the current subscription context, but it must be in the same tenant.
        Set-AzContext -TenantId $tenantId -SubscriptionId $vaultSubscriptionId | Out-Null
        $targetVault = Get-AzRecoveryServicesVault -Name $vaultName -ResourceGroupName $vaultResourceGroupName
        if ($null -eq $targetVault)
        {
            $this.Logger.LogError("Vault with name '$($vaultName)' unable to find")
        }
        #Set-AzRecoveryServicesAsrVaultContext -Vault $targetVault  # Vault Context is deprecated in ASR Powershell cmdlets, so skipping this step. ASR cmdlets will automatically find the vault based on the subscription and resource group context.
        return $targetVault
        $this.targetVault = $targetVault
    }

    # Get a consolidated vault context (cached internally by other calls)
    [psobject] GetVaultContext(
        $vaultSubscriptionId,
        $vaultResourceGroupName,
        $vaultName,
        $processServerName,
        $replicationPolicy,
        $runAsAccountName,
        $sourceMachineName
    )
    {
        $vaultServer = $this.GetAndEnsureVaultContext($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        if ($null -eq $vaultServer) {
            $this.Logger.LogErrorAndThrow("Vault with name '$($vaultName)' unable to find")
            throw "Vault with name '$($vaultName)' unable to find"
        }

        $fabricName = $this.GetFabricServer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $inMageRCMfabricServer = $this.GetInmageRCMFabricDetails($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)

        $inMageRCMfabricJson = $this.GetInmageRCMFabricDetailsJson($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $processServerId = (
            $inMageRCMfabricJson.properties.customDetails.processServers |
            Where-Object { $_.Name -eq $processServerName }
        ).id

        $replicationPolicyResponse = $this.GetReplicationPolicy($vaultSubscriptionId, $vaultResourceGroupName, $vaultName, $replicationPolicy)
        $replicationPolicyId = ($replicationPolicyResponse.Content | ConvertFrom-Json -Depth 100).id

        $runAsAccountResponse = $this.GetRunAsAccount($vaultSubscriptionId, $vaultResourceGroupName, $vaultName, $runAsAccountName)
        $runAsAccountId = ($runAsAccountResponse.Content | ConvertFrom-Json -Depth 100).value.where({ $_.properties.displayName -eq $runAsAccountName }).id

        $fabricDiscoveryResponse = $this.GetDiscoveredMachines($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $fabricDiscoveryMachineId = ($fabricDiscoveryResponse.Content | ConvertFrom-Json -Depth 100).value.where({$_.properties.displayName -eq $sourceMachineName}).id

        $protectionContainerName = $this.GetProtectionContainer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)

        return [pscustomobject]@{
            VaultServer = $vaultServer
            FabricName = $fabricName
            InMageRCMFabricServer = $inMageRCMfabricServer
            ProcessServerId = $processServerId
            ReplicationPolicyId = $replicationPolicyId
            RunAsAccountId = $runAsAccountId
            FabricDiscoveryMachineId = $fabricDiscoveryMachineId
            ProtectionContainerName = $protectionContainerName
        }
    }

    # Get fabric server reference (cached per vault)
    [psobject] GetFabricServer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        $cacheKey = $this.GetVaultCacheKey($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        if ($this.FabricServerCache.ContainsKey($cacheKey)) {
            return $this.FabricServerCache[$cacheKey]
        }

        $this.Logger.LogTrace("Getting fabric servers for vault '$($vaultName)'")
        $fabricuri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics?api-version=2025-08-01"
        $inmageFabricServer = ((Invoke-AzRestMethod -Method GET -Uri $fabricuri).Content | ConvertFrom-Json -Depth 100).value.where({$_.properties.customDetails.instanceType -eq 'InMageRCM'}).name

        if ($null -eq $inmageFabricServer)
        {
            $this.Logger.LogError("Unable to find InMage RCM fabric server for vault '$($vaultName)'")
        }
        else {
            $this.FabricServerCache[$cacheKey] = $inmageFabricServer
        }

        return $inmageFabricServer
    }

    # Get details of Inmage RCM fabric server associated with the vault (cached per vault)
    [psobject] GetInmageRCMFabricDetails($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        $cacheKey = $this.GetVaultCacheKey($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        if ($this.InMageFabricDetailsCache.ContainsKey($cacheKey)) {
            return $this.InMageFabricDetailsCache[$cacheKey]
        }

        $inmageFabricServer = $this.GetFabricServer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $inMagefabricuri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/${inmageFabricServer}?api-version=2025-08-01"
        $inMageFabricResponse = Invoke-AzRestMethod -Method GET -Uri $inMagefabricuri

        $this.InMageFabricDetailsCache[$cacheKey] = $inMageFabricResponse
        return $inMageFabricResponse
    }

    # Get parsed JSON of the InMage RCM fabric server response (cached per vault)
    [psobject] GetInmageRCMFabricDetailsJson($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        $cacheKey = $this.GetVaultCacheKey($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        if ($this.InMageFabricDetailsJsonCache.ContainsKey($cacheKey)) {
            return $this.InMageFabricDetailsJsonCache[$cacheKey]
        }

        $inMageFabricResponse = $this.GetInmageRCMFabricDetails($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $inMageFabricJson = $inMageFabricResponse.Content | ConvertFrom-Json -Depth 100

        $this.InMageFabricDetailsJsonCache[$cacheKey] = $inMageFabricJson
        return $inMageFabricJson
    }

    # Get details of replication policy id from the vault (cached per vault + policy)
    [psobject] GetReplicationPolicy($vaultSubscriptionId, $vaultResourceGroupName, $vaultName, $replicationPolicy)
    {
        $cacheKey = "$vaultSubscriptionId|$vaultResourceGroupName|$vaultName|$replicationPolicy"
        if ($this.ReplicationPolicyCache.ContainsKey($cacheKey)) {
            return $this.ReplicationPolicyCache[$cacheKey]
        }

        $this.Logger.LogTrace("Getting replication policy for vault '$($vaultName)'")
        $policyuri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationPolicies/${replicationPolicy}?api-version=2025-08-01"
        $policyResponse = Invoke-AzRestMethod -Method GET -Uri $policyuri

        $this.ReplicationPolicyCache[$cacheKey] = $policyResponse
        return $policyResponse
    }
    # Get runAsAccount details from the vault (cached per vault + account)
    [psobject] GetRunAsAccount($vaultSubscriptionId, $vaultResourceGroupName, $vaultName, $runAsAccountName)
    {
        $cacheKey = "$vaultSubscriptionId|$vaultResourceGroupName|$vaultName|$runAsAccountName"
        if ($this.RunAsAccountCache.ContainsKey($cacheKey)) {
            return $this.RunAsAccountCache[$cacheKey]
        }

        $inMageRCMfabricJson = $this.GetInmageRCMFabricDetailsJson($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $physicalSiteId = $inMageRCMfabricJson.properties.customDetails.physicalSiteId
        $physicalSiteName = $physicalSiteId.Split("/") | Select-Object -Last 1
        $this.Logger.LogTrace("Getting RunAs account for vault '$($vaultName)'")
        $runAsAccountUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.OffAzure/ServerSites/$physicalSiteName/runasaccounts?api-version=2023-06-06"
        $runAsAccountResponse = Invoke-AzRestMethod -Method GET -Uri $runAsAccountUri

        $this.RunAsAccountCache[$cacheKey] = $runAsAccountResponse
        return $runAsAccountResponse
    }
    # Get details of discovered server details associated with the vault (cached per vault)
    [psobject] GetDiscoveredMachines($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        $cacheKey = $this.GetVaultCacheKey($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        if ($this.DiscoveredMachinesCache.ContainsKey($cacheKey)) {
            return $this.DiscoveredMachinesCache[$cacheKey]
        }

        $inMageRCMfabricJson = $this.GetInmageRCMFabricDetailsJson($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $physicalSiteId = $inMageRCMfabricJson.properties.customDetails.physicalSiteId
        $physicalSiteName = $physicalSiteId.Split("/") | Select-Object -Last 1
        $this.Logger.LogTrace("Physical SiteName : '$($physicalSiteName)'")
       
        $fabricDiscoveryUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.OffAzure/ServerSites/$physicalSiteName/machines?api-version=2023-06-06"
        $fabricDiscoveryResponse = Invoke-AzRestMethod -Method GET -Uri $fabricDiscoveryUri

        $this.DiscoveredMachinesCache[$cacheKey] = $fabricDiscoveryResponse
        return $fabricDiscoveryResponse
    }

    # Get protection container reference for fabric server (cached per vault)
    [psobject] GetProtectionContainer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        $cacheKey = $this.GetVaultCacheKey($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        if ($this.ProtectionContainerCache.ContainsKey($cacheKey)) {
            return $this.ProtectionContainerCache[$cacheKey]
        }

        $inmageFabricServer = $this.GetFabricServer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $protectionContainerUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$inmageFabricServer/replicationProtectionContainers?api-version=2025-08-01"
        $protectionContainerResponse = Invoke-AzRestMethod -Method GET -Uri $protectionContainerUri
        $protectionContainerName = ($protectionContainerResponse.Content | ConvertFrom-Json -Depth 100).value.name

        $this.ProtectionContainerCache[$cacheKey] = $protectionContainerName
        return $protectionContainerName
    }
        # Get protected item details for the source machine if it is already a protected item in the vault 
    [psobject] GetProtectedItemFromVault($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
    {
        $inmageFabricServer = $this.GetFabricServer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $protectionContainerName = $this.GetProtectionContainer($vaultSubscriptionId, $vaultResourceGroupName, $vaultName)
        $protectedItemUri = "https://management.azure.com/subscriptions/$vaultSubscriptionId/resourceGroups/$vaultResourceGroupName/providers/Microsoft.RecoveryServices/vaults/$vaultName/replicationFabrics/$inmageFabricServer/replicationProtectionContainers/$protectionContainerName/replicationProtectedItems?api-version=2025-08-01"
        $protectedItemResponse = Invoke-AzRestMethod -Method GET -Uri $protectedItemUri
        return $protectedItemResponse
    }

    # Validate target environment (subscription, resource group, vnets, subnets, and storage accounts)
    [psobject] ValidateTargetEnvironment(
        $targetSubscriptionId,
        $targetPostFailoverResourceGroup,
        $targetVNET,
        $targetVNETRG,
        $targetSubnet,
        $testFailoverVNET,
        $testFailoverVNET_RG,
        $testSubnet,
        $targetBootDiagStorageAccountName,
        $targetBootDiagStorageAccountRG,
        $cacheStorageAccountName,
        $cacheStorageAccountRG,
        $licenseType,
        $linuxLicenseType,
        $sqlServerLicenseType,
        $targetAvailabilitySetId,
        $targetProximityPlacementGroupId
    )
    {
        $currentContext = Get-AzContext
        $tenantId = (Get-AzContext).Tenant.Id  # Only scan vaults in the current tenant context to avoid cross-tenant issues in Get-AzRecoveryServicesVault call. The vault subscription can be different from the current subscription context, but it must be in the same tenant.
        try {
             Set-AzContext -TenantId $tenantId -SubscriptionId $targetSubscriptionId | Out-Null
            $targetRG = Get-AzResourceGroup -Name $targetPostFailoverResourceGroup -ErrorAction SilentlyContinue
            if ($null -eq $targetRG) {
                $this.Logger.LogErrorAndThrow("Target resource group '$($targetPostFailoverResourceGroup)' does not exist.")
            }
            $targetResourceGroupId = $targetRG.ResourceId

            $targetVnet = Get-AzVirtualNetwork -Name $targetVNET -ResourceGroupName $targetVNETRG -ErrorAction SilentlyContinue
            if ($null -eq $targetVnet) {
                $this.Logger.LogErrorAndThrow("Target VNET '$($targetVNET)' in resource group '$($targetVNETRG)' does not exist.")
            }
            $targetNetworkId = $targetVnet.Id

            # Validate Target Subnet
            $targetSubnetObj = $targetVnet.Subnets | Where-Object { $_.Name -eq $targetSubnet }
            if ($null -eq $targetSubnetObj) {
                $this.Logger.LogErrorAndThrow("Target subnet '$($targetSubnet)' does not exist in VNET '$($targetVNET)'.")
            }
            $this.Logger.LogTrace("Target VNET Id : '$($targetNetworkId)'")

            $testVnet = Get-AzVirtualNetwork -Name $testFailoverVNET -ResourceGroupName $testFailoverVNET_RG -ErrorAction SilentlyContinue
            if ($null -eq $testVnet) {
                $this.Logger.LogErrorAndThrow("Test Failover VNET '$($testFailoverVNET)' in resource group '$($testFailoverVNET_RG)' does not exist.")
            }
            $testNetworkId = $testVnet.Id
            $this.Logger.LogTrace("Test Failover VNET Id : '$($testNetworkId)'")

            # Validate Test Subnet
            $testSubnetObj = $testVnet.Subnets | Where-Object { $_.Name -eq $testSubnet }
            if ($null -eq $testSubnetObj) {
                $this.Logger.LogErrorAndThrow("Test Failover subnet '$($testSubnet)' does not exist in VNET '$($testFailoverVNET)'.")
            }

            $targetBootDiagStorageAccount = Get-AzStorageAccount -Name $targetBootDiagStorageAccountName -ResourceGroupName $targetBootDiagStorageAccountRG
            if ($null -eq $targetBootDiagStorageAccount) {
                $this.Logger.LogErrorAndThrow("Boot diagnostics storage account '$($targetBootDiagStorageAccountName)' in resource group '$($targetBootDiagStorageAccountRG)' does not exist.")
            }
            $targetBootDiagStorageAccountId = $targetBootDiagStorageAccount.Id
            $this.Logger.LogTrace("Target Boot Diagnostics Storage Account Id : '$($targetBootDiagStorageAccountId)'")

            $cacheStorageAccount = Get-AzStorageAccount -Name $cacheStorageAccountName -ResourceGroupName $cacheStorageAccountRG
            if ($null -eq $cacheStorageAccount) {
                $this.Logger.LogErrorAndThrow("Cache storage account '$($cacheStorageAccountName)' in resource group '$($cacheStorageAccountRG)' does not exist.")
            }
        $cacheStorageAccountId = $cacheStorageAccount.Id
        $this.Logger.LogTrace("Cache Storage Account Id : '$($cacheStorageAccountId)'")
        
        # Validate license types
        $validLicenseTypes = @('WindowsServer', 'NoLicenseType', 'NotSpecified')
        if ($licenseType -notin $validLicenseTypes) {
            $this.Logger.LogErrorAndThrow("Invalid license type '$($licenseType)'. Allowed values are: $($validLicenseTypes -join ', ')")
        }
        
        $validLinuxLicenseTypes = @('NotSpecified', 'NoLicenseType', 'LinuxServer')
        if ($linuxLicenseType -notin $validLinuxLicenseTypes) {
            $this.Logger.LogErrorAndThrow("Invalid Linux license type '$($linuxLicenseType)'. Allowed values are: $($validLinuxLicenseTypes -join ', ')")
        }
        
        $validSqlServerLicenseTypes = @('AHUB', 'PAYG', 'NoLicenseType', 'NotSpecified')
        if ($sqlServerLicenseType -notin $validSqlServerLicenseTypes) {
            $this.Logger.LogErrorAndThrow("Invalid SQL Server license type '$($sqlServerLicenseType)'. Allowed values are: $($validSqlServerLicenseTypes -join ', ')")
        }

        # Validate target availability set if provided
        $validatedAvailabilitySetId = $null
        if ($targetAvailabilitySetId -and $targetAvailabilitySetId -ne "" -and $targetAvailabilitySetId -ne "Pending" -and $targetAvailabilitySetId -ne "Not possible?") {
            $this.Logger.LogTrace("Validating target availability set: '$($targetAvailabilitySetId)'")
            try {
                $availabilitySetResource = Get-AzResource -ResourceId $targetAvailabilitySetId -ErrorAction SilentlyContinue
                if ($null -eq $availabilitySetResource) {
                    $this.Logger.LogErrorAndThrow("Target availability set with ID '$($targetAvailabilitySetId)' does not exist.")
                }
                if ($availabilitySetResource.ResourceType -ne 'Microsoft.Compute/availabilitySets') {
                    $this.Logger.LogErrorAndThrow("Resource '$($targetAvailabilitySetId)' is not a valid availability set. Found resource type: '$($availabilitySetResource.ResourceType)'.")
                }
                $validatedAvailabilitySetId = $targetAvailabilitySetId
                $this.Logger.LogTrace("Target availability set validated successfully: '$($validatedAvailabilitySetId)'")
            }
            catch {
                $this.Logger.LogErrorAndThrow("Failed to validate target availability set: $_")
            }
        }

        # Validate target proximity placement group if provided
        $validatedProximityPlacementGroupId = $null
        if ($targetProximityPlacementGroupId -and $targetProximityPlacementGroupId -ne "" -and $targetProximityPlacementGroupId -ne "Pending" -and $targetProximityPlacementGroupId -ne "Not possible?") {
            $this.Logger.LogTrace("Validating target proximity placement group: '$($targetProximityPlacementGroupId)'")
            try {
                $proximityPlacementGroupResource = Get-AzResource -ResourceId $targetProximityPlacementGroupId -ErrorAction SilentlyContinue
                if ($null -eq $proximityPlacementGroupResource) {
                    $this.Logger.LogErrorAndThrow("Target proximity placement group with ID '$($targetProximityPlacementGroupId)' does not exist.")
                }
                if ($proximityPlacementGroupResource.ResourceType -ne 'Microsoft.Compute/proximityPlacementGroups') {
                    $this.Logger.LogErrorAndThrow("Resource '$($targetProximityPlacementGroupId)' is not a valid proximity placement group. Found resource type: '$($proximityPlacementGroupResource.ResourceType)'.")
                }
                $validatedProximityPlacementGroupId = $targetProximityPlacementGroupId
                $this.Logger.LogTrace("Target proximity placement group validated successfully: '$($validatedProximityPlacementGroupId)'")
            }
            catch {
                $this.Logger.LogErrorAndThrow("Failed to validate target proximity placement group: $_")
            }
        }

        return [pscustomobject]@{
                TargetResourceGroupId             = $targetResourceGroupId
                TargetNetworkId                   = $targetNetworkId
                TestNetworkId                     = $testNetworkId
                TargetBootDiagnosticsStorageAccountId = $targetBootDiagStorageAccountId
                CacheStorageAccountId             = $cacheStorageAccountId
                TargetAvailabilitySetId          = $validatedAvailabilitySetId
                TargetProximityPlacementGroupId  = $validatedProximityPlacementGroupId
            }
        }
        finally {
            # Restore original subscription context (even on failure)
            Set-AzContext -TenantId $tenantId -SubscriptionId $currentContext.Subscription.Id | Out-Null
        }
    }
}

Function New-AsrCommonInstance($Logger)
{
  return [AsrCommon]::new($Logger)
}