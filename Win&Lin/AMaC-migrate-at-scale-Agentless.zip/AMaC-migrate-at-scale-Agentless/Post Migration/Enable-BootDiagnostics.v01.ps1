# Connect to Azure (uncomment when ready)
# Connect-AzAccount

# Import CSV
$vms = Import-Csv "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Process VMs in parallel
$vms | ForEach-Object -Parallel {
    # Import required modules in parallel thread
    Import-Module Az.Accounts, Az.Compute -Force

    $vmEntry = $_
    $VMName = $vmEntry.VMName
    $ResourceGroup = $vmEntry.ResourceGroup

    Write-Host "`n🔄 Processing VM: $VMName" -ForegroundColor Yellow

    try {
        # Get current VM configuration
        $vm = Get-AzVM -ResourceGroupName $ResourceGroup -Name $VMName -ErrorAction Stop
        
        # STEP 1: Force managed storage by clearing existing custom URI
        if ($vm.DiagnosticsProfile.BootDiagnostics -and $vm.DiagnosticsProfile.BootDiagnostics.StorageUri) {
            Write-Host " !!! Clearing old custom storage URI... !!!" -ForegroundColor Cyan
            $vm.DiagnosticsProfile.BootDiagnostics.StorageUri = $null
            $null = Update-AzVM -ResourceGroupName $ResourceGroup -VM $vm
            $vm = Get-AzVM -ResourceGroupName $ResourceGroup -Name $VMName  # Refresh VM object
        }

        # STEP 2: Enable boot diagnostics with MANAGED storage account (RECOMMENDED)
        Write-Host " Enabling boot diagnostics (Managed)..." -ForegroundColor Green
        Set-AzVMBootDiagnostic -VM $vm -Enable
        $null = Update-AzVM -ResourceGroupName $ResourceGroup -VM $vm

        Write-Host "SUCCESS: $VMName - Boot Diagnostics ENABLED with Managed Storage Account" -ForegroundColor Green
    }
    catch {
        Write-Error "FAILED: $VMName - $($_.Exception.Message)"
    }

    Write-Host "----------------------------------------" -ForegroundColor Gray
} -ThrottleLimit 20

Write-Host "All VMs processed! Check Azure Portal to verify 'Managed Storage Account (recommended)'" -ForegroundColor Magenta
