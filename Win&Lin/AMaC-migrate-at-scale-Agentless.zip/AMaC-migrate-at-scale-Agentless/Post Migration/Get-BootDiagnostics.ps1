$csvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# ===================== AUTHENTICATE =====================
Write-Host "Authenticating to Azure..." -ForegroundColor Cyan
#Connect-AzAccount -ErrorAction Stop | Out-Null

# ===================== DISCOVER ALL SUBSCRIPTIONS =====================
$allSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
$currentContext   = Get-AzContext
Write-Host "Connected tenant : $($currentContext.Tenant.Id)" -ForegroundColor Cyan
Write-Host "Subscriptions    : $($allSubscriptions.Count) enabled" -ForegroundColor Cyan

# ===================== HELPER — find VM across all subscriptions =====================
function Find-AzVMCrossSub {
    param(
        [Parameter(Mandatory)][string]$VmName,
        [string]$ResourceGroup,
        [Parameter(Mandatory)][array]$Subscriptions
    )
    foreach ($sub in $Subscriptions) {
        try { Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null } catch { continue }
        $found = if (-not [string]::IsNullOrWhiteSpace($ResourceGroup)) {
            Get-AzVM -Name $VmName -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
        } else {
            Get-AzVM -Name $VmName -ErrorAction SilentlyContinue
        }
        if ($found) { return [PSCustomObject]@{ VM = $found; SubscriptionId = $sub.Id; SubscriptionName = $sub.Name } }
    }
    return $null
}

# ===================== MAIN =====================
$vms = Import-Csv $csvPath
Write-Host "Loaded $($vms.Count) VM(s) from CSV`n" -ForegroundColor Green

$results = foreach ($vmEntry in $vms) {
    $vmName = ([string]$vmEntry.VMName).Trim()
    $csvRg  = if ($null -ne $vmEntry.ResourceGroup) { ([string]$vmEntry.ResourceGroup).Trim() } else { '' }

    if ([string]::IsNullOrWhiteSpace($vmName)) { continue }

    $match = Find-AzVMCrossSub -VmName $vmName -ResourceGroup $csvRg -Subscriptions $allSubscriptions

    if (-not $match) {
        [PSCustomObject]@{ VMName = $vmName; ResourceGroup = $csvRg; SubscriptionName = ''; BootDiagnosticsStatus = 'VM Not Found'; ManagedBootDiagnostics = 'N/A' }
        continue
    }

    $vm       = $match.VM
    $bootDiag = $vm.DiagnosticsProfile.BootDiagnostics

    if ($bootDiag.Enabled -and -not $bootDiag.StorageUri) {
        $status  = 'Enabled (Managed Storage)'
        $managed = 'Yes'
    } elseif ($bootDiag.Enabled) {
        $status  = 'Enabled (Custom Storage)'
        $managed = 'No'
    } else {
        $status  = 'Disabled'
        $managed = 'No'
    }

    [PSCustomObject]@{
        VMName                 = $vm.Name
        ResourceGroup          = $vm.ResourceGroupName
        SubscriptionName       = $match.SubscriptionName
        BootDiagnosticsStatus  = $status
        ManagedBootDiagnostics = $managed
    }
}

# ===================== OUTPUT =====================
$col = @{ VMName = 30; ResourceGroup = 35; SubscriptionName = 35; BootDiagnosticsStatus = 28; ManagedBootDiagnostics = 10 }

# Header
Write-Host (
    'VMName'.PadRight($col.VMName) +
    'ResourceGroup'.PadRight($col.ResourceGroup) +
    'SubscriptionName'.PadRight($col.SubscriptionName) +
    'BootDiagnosticsStatus'.PadRight($col.BootDiagnosticsStatus) +
    'Managed'
) -ForegroundColor White
Write-Host ('-' * 145) -ForegroundColor DarkGray

foreach ($r in $results) {
    $managedColor = switch ($r.ManagedBootDiagnostics) {
        'Yes'      { 'Green' }
        'No'       { 'Yellow' }
        'N/A'      { 'DarkYellow' }
        default    { 'Gray' }
    }
    $statusColor = switch -Wildcard ($r.BootDiagnosticsStatus) {
        'Enabled (Managed*)'  { 'Green' }
        'Enabled (Custom*)'   { 'Yellow' }
        'Disabled'            { 'Red' }
        'VM Not Found'        { 'DarkYellow' }
        default               { 'Gray' }
    }

    Write-Host $r.VMName.PadRight($col.VMName)               -NoNewline -ForegroundColor Cyan
    Write-Host $r.ResourceGroup.PadRight($col.ResourceGroup)  -NoNewline -ForegroundColor Gray
    Write-Host $r.SubscriptionName.PadRight($col.SubscriptionName) -NoNewline -ForegroundColor Gray
    Write-Host $r.BootDiagnosticsStatus.PadRight($col.BootDiagnosticsStatus) -NoNewline -ForegroundColor $statusColor
    Write-Host $r.ManagedBootDiagnostics                      -ForegroundColor $managedColor
}

Write-Host ('-' * 145) -ForegroundColor DarkGray

# Optional: Export to CSV
# $results | Export-Csv "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\BootDiagnosticsReport.csv" -NoTypeInformation