﻿# Path to your CSV file
$CSVPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Script that will run inside each VM (single-quoted here-string!)
$Script = @'
Write-Output "================================"
Write-Output "        RDP STATUS CHECK        "
Write-Output "================================"

# ================================
# CHECK 1: RDP Service Running?
# ================================
$rdpService = Get-Service -Name TermService -ErrorAction SilentlyContinue

if ($rdpService -and $rdpService.Status -eq "Running") {
    Write-Output "RDP Service (TermService): RUNNING"
}
else {
    Write-Output "RDP Service (TermService): NOT RUNNING"
}

# ================================
# CHECK 2: Port 3389 Listening?
# ================================
$portCheck = netstat -ano | Select-String ":3389"

if ($portCheck) {
    Write-Output "RDP Port 3389 Listening: YES"
}
else {
    Write-Output "RDP Port 3389 Listening: NO"
}

# ================================
# CHECK 3: RDP Responsiveness Test
# ================================
try {
    $tcp = New-Object System.Net.Sockets.TcpClient
    $async = $tcp.BeginConnect("127.0.0.1", 3389, $null, $null)
    $success = $async.AsyncWaitHandle.WaitOne(2000, $false)

    if ($success -and $tcp.Connected) {
        Write-Output "RDP Connection Test: RESPONDING"
        $tcp.Close()
    }
    else {
        Write-Output "RDP Connection Test: NOT RESPONDING"
    }
}
catch {
    Write-Output "RDP Connection Test: ERROR - $($_.Exception.Message)"
}
'@

# Import CSV
$VMList = Import-Csv -Path $CSVPath

foreach ($entry in $VMList) {

    $VMName = $entry.VMName
    $RGName = $entry.ResourceGroup

    Write-Host "Running RDP check on VM '$VMName' in RG '$RGName'..." -ForegroundColor Yellow

    try {
        $Result = Invoke-AzVMRunCommand `
            -ResourceGroupName $RGName `
            -Name $VMName `
            -CommandId "RunPowerShellScript" `
            -ScriptString $Script `
            -ErrorAction Stop

        Write-Host "Output from $VMName" -ForegroundColor Cyan
        $Result.Value.Message | Write-Output

        Write-Host "Completed on $VMName" -ForegroundColor Green
    }
    catch {
        Write-Host "Failed on $VMName ($RGName): $($_.Exception.Message)" -ForegroundColor Red
    }
}
