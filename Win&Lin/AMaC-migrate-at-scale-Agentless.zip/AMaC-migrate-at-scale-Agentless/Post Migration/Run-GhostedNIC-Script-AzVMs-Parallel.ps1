<#
.SYNOPSIS
Runs a local PowerShell guest script on multiple Azure Windows VMs in parallel using Invoke-AzVMRunCommand.

.DESCRIPTION
- Reads VM targets from CSV.
- Submits Run Command jobs in parallel (throttled).
- Prints per-VM result output in console only.
- Does not write CSV output files.

.NOTES
- Author: Deepak Tyagi
- Requires Az.Accounts and Az.Compute modules.
- Requires VM Agent + Run Command support on target VMs.
- This runner executes the script you provide; if that script performs cleanup/removal,
  those changes will run inside target VMs.

.EXAMPLE
.\Run-GhostedNIC-Script-AzVMs-Parallel.ps1 `
  -CsvPath .\Script-Run-Data-File\ServerNames-Mig.csv `
  -VmNameColumn VMName `
  -ResourceGroupColumn ResourceGroup `
  -DefaultSubscriptionId c98ba209-886d-4fe2-8acf-3c4f39296612 `
  -ThrottleLimit 10

.EXAMPLE
.\Run-GhostedNIC-Script-AzVMs-Parallel.ps1 -CompactOutput
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$CsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv",

    [Parameter(Mandatory = $false)]
    [string]$VmNameColumn = "VMName",

    [Parameter(Mandatory = $false)]
    [string]$ResourceGroupColumn = "ResourceGroup",

    [Parameter(Mandatory = $false)]
    [string]$SubscriptionIdColumn = "SubscriptionId",

    [Parameter(Mandatory = $false)]
    [string]$DefaultResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$DefaultSubscriptionId,

    [Parameter(Mandatory = $false)]
    [int]$ThrottleLimit = 10

    ,

    [Parameter(Mandatory = $false)]
    [switch]$CompactOutput
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Section {
    param([string]$Title)

    $line = ("=" * 88)
    Write-Host ""
    Write-Host $line -ForegroundColor DarkCyan
    Write-Host $Title -ForegroundColor Cyan
    Write-Host $line -ForegroundColor DarkCyan
}

if ($ThrottleLimit -lt 1) {
    $ThrottleLimit = 1
}

if (-not (Test-Path -Path $CsvPath -PathType Leaf)) {
    throw "CSV file not found: $CsvPath"
}

$embeddedGuestScript = @'
<# 
Disclaimer
    The sample scripts are not supported under any Microsoft standard support program or service. 
    The sample scripts are provided AS IS without warranty of any kind.
    Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability
    or of fitness for a particular purpose.
    The entire risk arising out of the use or performance of the sample scripts and documentation remains with you.
    In no event shall Microsoft, its authors, or anyone else involved in the creation, production,
    or delivery of the scripts be liable for any damages whatsoever (including, without limitation,
    damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss)
    arising out of the use of or inability to use the sample scripts or documentation,
    even if Microsoft has been advised of the possibility of such damages.

.SYNOPSIS
    Detects ghosted (disconnected) and valid network interface cards (NICs) on Windows.
    
.DESCRIPTION
    This script scans the Windows registry for network adapters on PCI and VMBUS buses,
    identifies ghosted (disconnected) NICs, and will remove them up from the registry.
    It uses SYSTEM privileges to remove registry keys and runs pnpclean to clean up device entries.
    Useful for troubleshooting or cleaning up old NICs.

.NOTES
    Requires administrator privileges.
    Tested on Windows Server 2016+.

.EXAMPLE
    Run as administrator:
    PS> .\Windows_GhostedNIC_Removal_time.ps1
#>

function Assert-Admin {
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $isAdmin) {
        Write-Host "Please run this script as Administrator." -ForegroundColor Red
        exit 1
    }
}
Assert-Admin

Write-Host "Collecting all current network adapter PnPDeviceIDs..."
$AllAdaptersPnPIDs = (Get-NetAdapter).PnpDeviceID
$global:FoundGhostNICs = 0
$global:FoundValidNICs = 0
$global:RemovedGhostNICs = 0
$global:GhostedNICsToDelete = @()

Function ExecuteAsSystem($cmd) {
    Try {
        $taskName = "TempSystemTask_$([guid]::NewGuid().ToString())"
        $TaskArgs = '-NoProfile -WindowStyle Hidden -Command "###cmd###"'
        $TaskArgs = $TaskArgs -replace '###cmd###',$cmd
        $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $TaskArgs
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
        $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)

        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal | Out-Null
        Start-ScheduledTask -TaskName $taskName

        While ((Get-ScheduledTask -TaskName $taskName).State -eq "Running" -Or (Get-ScheduledTaskInfo -TaskName $taskName).LastRunTime -notmatch (Get-Date).ToString("yyyy")) {
            Start-Sleep -Seconds 1
        }

        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false | Out-Null
    } Catch {
        Write-Error "Failed to execute command as SYSTEM: $_"
    }
}

Function ScanRegistryForNICs($BusName) {
    $RootPath = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\"
    $RegistryPath = "$($RootPath.Replace("HKEY_LOCAL_MACHINE\","HKLM:\"))$($BusName)"

    Try {
        If (Test-Path -Path $RegistryPath) {
            Get-ChildItem $RegistryPath -Depth 0 | ForEach-Object {
                $Bus = $_
                $BusPath = $Bus.Name.ToString().Replace("HKEY_LOCAL_MACHINE\","HKLM:\")

                Get-ChildItem $BusPath -Depth 0 | ForEach-Object {
                    $Bus = $_
                    $BusPath = $Bus.Name.ToString().Replace("HKEY_LOCAL_MACHINE\","HKLM:\")
                    $BusRelativeName = $Bus.Name.ToString().Replace($RootPath,"")

                    Try { $ServiceType = (Get-ItemProperty -Path $BusPath -Name Service -ErrorAction SilentlyContinue).Service } Catch { $ServiceType = $null }
                    Try { $DeviceDesc = (Get-ItemProperty -Path $BusPath -Name DeviceDesc -ErrorAction SilentlyContinue).DeviceDesc } Catch { $DeviceDesc = $null }
                    Try { $DevIndex = (Get-ItemProperty -Path $($BusPath + "\Device Parameters") -Name InstanceIndex -ErrorAction SilentlyContinue).InstanceIndex } Catch { $DevIndex = $null }

                    If ($DeviceDesc) {
                        Try {
                            $Split = $DeviceDesc -split ";"
                            $DeviceDescription = $Split[1]
                            If ($DevIndex -and $DevIndex -ne 1) {
                                $DeviceDescription += " #$($DevIndex)"
                            }
                        } Catch {
                            $DeviceDescription = "Unknown Device"
                        }
                    } Else {
                        $DeviceDescription = "Unknown Device"
                    }

                    If ($ServiceType -in ("netvsc", "mlx5", "mlx4_bus")) {
                        $MatchesPnpID = $AllAdaptersPnPIDs | Where-Object { $_ -eq $BusRelativeName }
                        If ($MatchesPnpID) {
                            $global:FoundValidNICs++
                            Write-Host "Valid NIC: $($DeviceDescription)" -ForegroundColor Green
                        } Else {
                            $global:FoundGhostNICs++
                            $global:GhostedNICsToDelete += $BusPath
                            Write-Host "Ghosted NIC: $($DeviceDescription)" -ForegroundColor Yellow
                        }
                    }
                }
            }
        }
    } Catch {
        Write-Error "Error while scanning registry: $_"
    }
}

Function CheckRootKeys() {
    Write-Host "Checking for empty root keys in registry..."
    $EmptyRootKeysToDelete = @()

    Try {
        $GhostedNICsToDelete | ForEach-Object {
            $ParentKey = Split-Path -Path $_ -Parent
            If (Test-Path -Path $ParentKey) {
                If ((Get-ChildItem $ParentKey -Depth 0 | Measure-Object).Count -eq 0) {
                    If (-Not $EmptyRootKeysToDelete.Contains($ParentKey)) {
                        $EmptyRootKeysToDelete += $ParentKey
                    }
                }
            }
        }
    } Catch {
        Write-Error "Error while checking root keys: $_"
    }

    $EmptyRootKeysToDelete | ForEach-Object {
        If (Test-Path -Path $_) {
            Write-Host "Deleting empty root key $($_)..."
            ExecuteAsSystem "Remove-Item -Path '$($_)' -Recurse -Confirm:`$false -Force"
        }
    }
}

Function DeleteGhostedNICs() {
    Write-Host "Cleaning ghosted NIC(s) using pnpclean..."

    Try {
        Invoke-Command {c:\windows\system32\RUNDLL32.exe c:\windows\system32\pnpclean.dll,RunDLL_PnpClean /Devices /Maxclean}
        Start-Sleep -Seconds 10

        $GhostedNICsToDelete | ForEach-Object {
            If (Test-Path -Path $_) {
                Write-Host "Deleting registry key for ghosted NIC: $($_)..."
                $global:RemovedGhostNICs++
                ExecuteAsSystem "Remove-Item -Path '$($_)' -Recurse -Confirm:`$false -Force"
            }
        }
    } Catch {
        Write-Error "Error while deleting ghosted NICs: $_"
    }

    CheckRootKeys
}

ScanRegistryForNICs("PCI")
ScanRegistryForNICs("VMBUS")

Write-Host "`r`n"
Write-Host "Found ghosted NIC(s): $($FoundGhostNICs)" -ForegroundColor Red
Write-Host "Found valid NIC(s): $($FoundValidNICs)" -ForegroundColor Green

If ($FoundGhostNICs -gt 0) {
    Write-Host "`r`n"
    Write-Host "NOTE: Cleanup may take time depending on the number of ghosted NICs detected." -ForegroundColor Yellow
    Write-Host " - Up to 30 minutes if ~600 ghosted NICs are found." -ForegroundColor Yellow
    Write-Host " - Up to 60+ minutes if over 1000 ghosted NICs are found." -ForegroundColor Yellow
    Write-Host "`r`n"

    DeleteGhostedNICs
}

Write-Host "Removed ghosted NIC(s): $($RemovedGhostNICs)" -ForegroundColor Cyan

#Write-Host "`r`nAdditional Information: https://aka.ms/AzVmGhostedNicCleanup" -ForegroundColor Cyan
Write-Host "`r`nScript completed successfully." -ForegroundColor Cyan
'@

Import-Module Az.Accounts -ErrorAction Stop
Import-Module Az.Compute -ErrorAction Stop

if (-not (Get-AzContext)) {
    Write-Host "No Azure context found. Running Connect-AzAccount..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

$runStart = Get-Date
Write-Section -Title "Azure VM RunCommand Parallel Runner"
Write-Host ("CSV Path        : {0}" -f $CsvPath) -ForegroundColor Gray
Write-Host ("Throttle Limit  : {0}" -f $ThrottleLimit) -ForegroundColor Gray
Write-Host ("Output Mode     : {0}" -f ($(if ($CompactOutput) { "Compact" } else { "Detailed" }))) -ForegroundColor Gray
Write-Host ("Started At      : {0}" -f ($runStart.ToString("yyyy-MM-dd HH:mm:ss"))) -ForegroundColor Gray

$guestScriptContent = $embeddedGuestScript

$rows = Import-Csv -Path $CsvPath
if (-not ($rows | Get-Member -Name $VmNameColumn -MemberType NoteProperty)) {
    throw "Column '$VmNameColumn' not found in CSV."
}

$hasRgColumn = ($rows | Get-Member -Name $ResourceGroupColumn -MemberType NoteProperty)
$hasSubColumn = ($rows | Get-Member -Name $SubscriptionIdColumn -MemberType NoteProperty)

$targets = foreach ($row in $rows) {
    $vmName = [string]$row.$VmNameColumn
    if ([string]::IsNullOrWhiteSpace($vmName)) { continue }

    $rgName = $null
    if ($hasRgColumn) {
        $rgName = [string]$row.$ResourceGroupColumn
    }
    if ([string]::IsNullOrWhiteSpace($rgName)) {
        $rgName = $DefaultResourceGroup
    }

    $subId = $null
    if ($hasSubColumn) {
        $subId = [string]$row.$SubscriptionIdColumn
    }
    if ([string]::IsNullOrWhiteSpace($subId)) {
        $subId = $DefaultSubscriptionId
    }

    [PSCustomObject]@{
        VMName = $vmName.Trim()
        ResourceGroup = if ([string]::IsNullOrWhiteSpace($rgName)) { "" } else { $rgName.Trim() }
        SubscriptionId = if ([string]::IsNullOrWhiteSpace($subId)) { "" } else { $subId.Trim() }
    }
}

$targets = @($targets | Where-Object { -not [string]::IsNullOrWhiteSpace($_.VMName) } | Select-Object -Unique VMName, ResourceGroup, SubscriptionId)

if ($targets.Count -eq 0) {
    throw "No valid VM targets found in CSV."
}

Write-Section -Title "Target Discovery"
Write-Host ("Total targets from CSV: {0}" -f $targets.Count) -ForegroundColor Cyan

$jobMap = @{}
$submitFailed = @()
$completedSummary = [System.Collections.ArrayList]::new()

function Process-CompletedJobs {
    param(
        [hashtable]$Map,
        [System.Collections.ArrayList]$Summary,
        [int]$TotalTargets,
        [bool]$Compact
    )

    $done = @(Get-Job | Where-Object { $_.State -in @("Completed", "Failed", "Stopped") })
    foreach ($job in $done) {
        if (-not $Map.ContainsKey($job.Id)) {
            continue
        }

        $meta = $Map[$job.Id]
        $vmName = $meta.VMName
        $rgName = $meta.ResourceGroup
        $subId = $meta.SubscriptionId

        if ($job.State -eq "Completed") {
            try {
                $result = Receive-Job -Id $job.Id -ErrorAction Stop
                $messages = @($result.Value | ForEach-Object { $_.Message })
                $outputText = ($messages -join [Environment]::NewLine).Trim()
                $doneCount = $Summary.Count + 1

                if ($Compact) {
                    Write-Host ("[{0}/{1}] [SUCCESS] VM: {2}" -f $doneCount, $TotalTargets, $vmName) -ForegroundColor Green
                }
                else {
                    Write-Host ""
                    Write-Host ("[{0}/{1}] [SUCCESS] VM: {2} | RG: {3} | SUB: {4}" -f $doneCount, $TotalTargets, $vmName, $rgName, $subId) -ForegroundColor Green
                    if ([string]::IsNullOrWhiteSpace($outputText)) {
                        Write-Host "RunCommand completed with no message output." -ForegroundColor DarkGray
                    }
                    else {
                        Write-Host $outputText
                    }
                }

                $foundGhosted = 0
                $removedGhosted = 0

                $foundMatch = [regex]::Match($outputText, 'Found ghosted NIC\(s\):\s*(\d+)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
                if ($foundMatch.Success) {
                    [void][int]::TryParse($foundMatch.Groups[1].Value, [ref]$foundGhosted)
                }

                $removedMatch = [regex]::Match($outputText, 'Removed ghosted NIC\(s\):\s*(\d+)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
                if ($removedMatch.Success) {
                    [void][int]::TryParse($removedMatch.Groups[1].Value, [ref]$removedGhosted)
                }

                [void]$Summary.Add([PSCustomObject]@{
                    VMName            = $vmName
                    ResourceGroup     = $rgName
                    SubscriptionId    = $subId
                    Status            = "Success"
                    FoundGhostedNICs  = $foundGhosted
                    RemovedGhostedNICs= $removedGhosted
                })
            }
            catch {
                Write-Host ("RunCommand receive failed for VM '{0}': {1}" -f $vmName, $_.Exception.Message) -ForegroundColor Red
                [void]$Summary.Add([PSCustomObject]@{
                    VMName             = $vmName
                    ResourceGroup      = $rgName
                    SubscriptionId     = $subId
                    Status             = "Failed"
                    FoundGhostedNICs   = 0
                    RemovedGhostedNICs = 0
                })
            }
        }
        else {
            $errText = $null

            if ($job.ChildJobs -and $job.ChildJobs.Count -gt 0) {
                $child = $job.ChildJobs[0]

                if ($child.JobStateInfo -and $child.JobStateInfo.Reason) {
                    $errText = [string]$child.JobStateInfo.Reason.Message
                }

                if ([string]::IsNullOrWhiteSpace($errText) -and $child.Error -and $child.Error.Count -gt 0) {
                    $errText = ($child.Error | ForEach-Object {
                        if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { [string]$_ }
                    } | Select-Object -Unique) -join " | "
                }
            }

            if ([string]::IsNullOrWhiteSpace($errText)) {
                try {
                    $failedResult = Receive-Job -Id $job.Id -ErrorAction SilentlyContinue
                    if ($failedResult -and $failedResult.Value) {
                        $resultMessages = @($failedResult.Value | ForEach-Object { $_.Message })
                        $resultText = ($resultMessages -join [Environment]::NewLine).Trim()
                        if (-not [string]::IsNullOrWhiteSpace($resultText)) {
                            $errText = $resultText
                        }
                    }
                }
                catch {
                    # Ignore receive errors and keep fallback message.
                }
            }

            if ([string]::IsNullOrWhiteSpace($errText)) {
                $errText = "Job state: $($job.State)"
            }

            $doneCount = $Summary.Count + 1
            if ($Compact) {
                Write-Host ("[{0}/{1}] [FAILED] VM: {2} | Reason: {3}" -f $doneCount, $TotalTargets, $vmName, $errText) -ForegroundColor Red
            }
            else {
                Write-Host ""
                Write-Host ("[{0}/{1}] [FAILED] VM: {2} | RG: {3} | SUB: {4}" -f $doneCount, $TotalTargets, $vmName, $rgName, $subId) -ForegroundColor Red
                Write-Host ("Reason: {0}" -f $errText) -ForegroundColor Red
            }
            [void]$Summary.Add([PSCustomObject]@{
                VMName             = $vmName
                ResourceGroup      = $rgName
                SubscriptionId     = $subId
                Status             = "Failed"
                FoundGhostedNICs   = 0
                RemovedGhostedNICs = 0
            })
        }

        Remove-Job -Id $job.Id -Force -ErrorAction SilentlyContinue
        $Map.Remove($job.Id) | Out-Null
    }
}

$submittedCount = 0
$targetIndex = 0
Write-Section -Title "Submitting RunCommand Jobs"

foreach ($target in $targets) {
    $targetIndex++

    if ([string]::IsNullOrWhiteSpace($target.ResourceGroup)) {
        Write-Host ("[{0}/{1}] [SKIPPED] VM: {2} | Reason: Resource group missing (set column '{3}' or -DefaultResourceGroup)." -f $targetIndex, $targets.Count, $target.VMName, $ResourceGroupColumn) -ForegroundColor Yellow
        $submitFailed += $target
        continue
    }

    try {
        if (-not [string]::IsNullOrWhiteSpace($target.SubscriptionId)) {
            $ctx = Get-AzContext
            if (-not $ctx -or $ctx.Subscription.Id -ne $target.SubscriptionId) {
                Set-AzContext -SubscriptionId $target.SubscriptionId -ErrorAction Stop | Out-Null
            }
        }

        # Skip local OS model inspection and let RunCommand return VM-side execution errors.

        while (@(Get-Job | Where-Object { $_.State -eq "Running" }).Count -ge $ThrottleLimit) {
            $trackedJobs = @(Get-Job -Id @($jobMap.Keys) -ErrorAction SilentlyContinue)
            if ($trackedJobs.Count -gt 0) {
                Wait-Job -Job $trackedJobs -Any -Timeout 5 | Out-Null
            }
            Process-CompletedJobs -Map $jobMap -Summary $completedSummary -TotalTargets $targets.Count -Compact $CompactOutput.IsPresent
        }

        Write-Host ("[{0}/{1}] [SUBMIT] VM: {2} | RG: {3}" -f $targetIndex, $targets.Count, $target.VMName, $target.ResourceGroup) -ForegroundColor Cyan

        $job = Invoke-AzVMRunCommand `
            -ResourceGroupName $target.ResourceGroup `
            -Name $target.VMName `
            -CommandId "RunPowerShellScript" `
            -ScriptString $guestScriptContent `
            -AsJob `
            -ErrorAction Stop

        $jobMap[$job.Id] = [PSCustomObject]@{
            VMName = $target.VMName
            ResourceGroup = $target.ResourceGroup
            SubscriptionId = if ([string]::IsNullOrWhiteSpace($target.SubscriptionId)) { "CurrentContext" } else { $target.SubscriptionId }
        }

        $submittedCount++
    }
    catch {
        Write-Host ("[{0}/{1}] [SUBMIT-FAILED] VM: {2} | Reason: {3}" -f $targetIndex, $targets.Count, $target.VMName, $_.Exception.Message) -ForegroundColor Red
        $submitFailed += $target
    }
}

while ($jobMap.Count -gt 0) {
    $trackedJobs = @(Get-Job -Id @($jobMap.Keys) -ErrorAction SilentlyContinue)
    if ($trackedJobs.Count -gt 0) {
        Wait-Job -Job $trackedJobs -Any -Timeout 5 | Out-Null
    }
    Process-CompletedJobs -Map $jobMap -Summary $completedSummary -TotalTargets $targets.Count -Compact $CompactOutput.IsPresent
}

$successCount = @($completedSummary | Where-Object { $_.Status -eq "Success" }).Count
$failedCount = @($completedSummary | Where-Object { $_.Status -eq "Failed" }).Count + $submitFailed.Count
$totalFoundGhosted = ($completedSummary | Where-Object { $_.Status -eq "Success" } | Measure-Object -Property FoundGhostedNICs -Sum).Sum
$totalRemovedGhosted = ($completedSummary | Where-Object { $_.Status -eq "Success" } | Measure-Object -Property RemovedGhostedNICs -Sum).Sum

$runEnd = Get-Date
$durationText = ((New-TimeSpan -Start $runStart -End $runEnd).ToString())

Write-Section -Title "Execution Summary"
$summaryTable = @(
    [PSCustomObject]@{ Metric = "Total Targets"; Value = $targets.Count }
    [PSCustomObject]@{ Metric = "Submitted"; Value = $submittedCount }
    [PSCustomObject]@{ Metric = "Success"; Value = $successCount }
    [PSCustomObject]@{ Metric = "Failed"; Value = $failedCount }
    [PSCustomObject]@{ Metric = "Total Found ghosted NIC(s)"; Value = $(if ($null -ne $totalFoundGhosted) { [int]$totalFoundGhosted } else { 0 }) }
    [PSCustomObject]@{ Metric = "Total Removed ghosted NIC(s)"; Value = $(if ($null -ne $totalRemovedGhosted) { [int]$totalRemovedGhosted } else { 0 }) }
    [PSCustomObject]@{ Metric = "Started At"; Value = $runStart.ToString("yyyy-MM-dd HH:mm:ss") }
    [PSCustomObject]@{ Metric = "Finished At"; Value = $runEnd.ToString("yyyy-MM-dd HH:mm:ss") }
    [PSCustomObject]@{ Metric = "Duration"; Value = $durationText }
)

$summaryTable | Format-Table -AutoSize

if ($completedSummary.Count -gt 0) {
    Write-Section -Title "Per-Server Ghost NIC Summary"
    $completedSummary |
        Select-Object VMName, ResourceGroup, Status, FoundGhostedNICs, RemovedGhostedNICs |
        Sort-Object VMName |
        Format-Table -AutoSize
}

if ($submitFailed.Count -gt 0) {
    Write-Section -Title "Failed Or Skipped Submissions"
    $submitFailed | Select-Object VMName, ResourceGroup, SubscriptionId | Format-Table -AutoSize
}
