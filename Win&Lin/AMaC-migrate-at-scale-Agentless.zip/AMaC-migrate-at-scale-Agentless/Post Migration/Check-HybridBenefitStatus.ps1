﻿# Path to input CSV
$inputCsv = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# ===================== AUTHENTICATE =====================
Write-Host "Authenticating to Azure..." -ForegroundColor Cyan
#Connect-AzAccount -ErrorAction Stop | Out-Null

# ===================== DISCOVER ALL SUBSCRIPTIONS =====================
$allSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
$currentContext   = Get-AzContext
Write-Host "Connected tenant : $($currentContext.Tenant.Id)" -ForegroundColor Cyan
Write-Host "Subscriptions    : $($allSubscriptions.Count) enabled" -ForegroundColor Cyan

# ===================== HELPER — find VM across all subscriptions =====================
function Find-AzVMCrossSub {
    param(
        [Parameter(Mandatory)]
        [string]$VmName,
        [string]$ResourceGroup,
        [Parameter(Mandatory)]
        [array]$Subscriptions
    )

    foreach ($sub in $Subscriptions) {
        try { Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null } catch { continue }

        $found = if (-not [string]::IsNullOrWhiteSpace($ResourceGroup)) {
            Get-AzVM -Name $VmName -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
        } else {
            Get-AzVM -Name $VmName -ErrorAction SilentlyContinue
        }

        if ($found) {
            return [PSCustomObject]@{ VM = $found; SubscriptionId = $sub.Id; SubscriptionName = $sub.Name }
        }
    }
    return $null
}

# ===================== MAIN =====================
$vms = Import-Csv -Path $inputCsv
Write-Host "Loaded $($vms.Count) VM(s) from CSV`n" -ForegroundColor Green

$results = foreach ($vm in $vms) {
    $vmName = ([string]$vm.VMName).Trim()
    $csvRg  = if ($null -ne $vm.ResourceGroup) { ([string]$vm.ResourceGroup).Trim() } else { '' }

    if ([string]::IsNullOrWhiteSpace($vmName)) { continue }

    try {
        $match = Find-AzVMCrossSub -VmName $vmName -ResourceGroup $csvRg -Subscriptions $allSubscriptions

        if (-not $match) {
            [PSCustomObject]@{ VMName = $vmName; ResourceGroup = $csvRg; SubscriptionName = ''; LicenseType = 'N/A'; AHBEnabled = 'NotFound'; Details = 'VM not found across all enabled subscriptions' }
            continue
        }

        $vmInfo      = $match.VM
        $licenseType = if ($vmInfo.LicenseType) { $vmInfo.LicenseType } else { 'Not Enabled' }
        $ahbEnabled  = if ($licenseType -eq 'Windows_Server' -or $licenseType -like '*BYOS*') { 'YES' } else { 'NO' }

        [PSCustomObject]@{
            VMName           = $vmInfo.Name
            ResourceGroup    = $vmInfo.ResourceGroupName
            SubscriptionName = $match.SubscriptionName
            LicenseType      = $licenseType
            AHBEnabled       = $ahbEnabled
            Details          = ''
        }
    }
    catch {
        [PSCustomObject]@{ VMName = $vmName; ResourceGroup = $csvRg; SubscriptionName = ''; LicenseType = 'N/A'; AHBEnabled = 'Error'; Details = $_.Exception.Message }
    }
}

# ===================== OUTPUT =====================
$col = @{ VMName = 30; ResourceGroup = 35; SubscriptionName = 35; LicenseType = 20 }

Write-Host (
    'VMName'.PadRight($col.VMName) +
    'ResourceGroup'.PadRight($col.ResourceGroup) +
    'SubscriptionName'.PadRight($col.SubscriptionName) +
    'LicenseType'.PadRight($col.LicenseType) +
    'AHBEnabled'
) -ForegroundColor White
Write-Host ('-' * 145) -ForegroundColor DarkGray

foreach ($r in $results) {
    $ahbColor = switch ($r.AHBEnabled) {
        'YES'      { 'Green' }
        'NO'       { 'Yellow' }
        'NotFound' { 'DarkYellow' }
        'Error'    { 'Red' }
        default    { 'Gray' }
    }
    Write-Host $r.VMName.PadRight($col.VMName)                    -NoNewline -ForegroundColor Cyan
    Write-Host $r.ResourceGroup.PadRight($col.ResourceGroup)       -NoNewline -ForegroundColor Gray
    Write-Host $r.SubscriptionName.PadRight($col.SubscriptionName) -NoNewline -ForegroundColor Gray
    Write-Host $r.LicenseType.PadRight($col.LicenseType)           -NoNewline -ForegroundColor Gray
    Write-Host $r.AHBEnabled                                       -ForegroundColor $ahbColor
}
Write-Host ('-' * 145) -ForegroundColor DarkGray
