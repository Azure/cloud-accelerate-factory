﻿#Connect-AzAccount

# Variables — change these to match your setup
$resourceGroupName = "RG-AM-CUS-Prod-AzureMigrateCUS" # "RG-EU-UKSouth-AZMigrate"  Azure Migrate Resource Group Name
$migrateProjectName = "Azuremigrate-AM-CUS-VMwareEOL" # Azure Migrate Project Name

#$resourceGroupName = "RG-AM-EastUS-NonProd-AZMigrate2" # "RG-EU-UKSouth-AZMigrate"  Azure Migrate Resource Group Name
#$migrateProjectName = "AzmigVMEOLSAPxtra" # Azure Migrate Project Name

$csvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\Tags.csv" # Path to CSV file    

# Read CSV file
$vmList = Import-Csv -Path $csvPath

# Get Azure Migrate project
$MigrateProject = Get-AzMigrateProject `
    -ResourceGroupName $resourceGroupName `
    -Name $migrateProjectName

foreach ($vm in $vmList) {

    $vmName = $vm.VMName.Trim()
    if ([string]::IsNullOrWhiteSpace($vmName)) {
        Write-Host "Skipping row: VMName is empty" -ForegroundColor Red
        continue
    }

    Write-Host "`nProcessing VM: $vmName" -ForegroundColor Cyan

    # Build tag hashtable from CSV columns except VMName
    $tagHashtable = @{}
    $vm.PSObject.Properties |
        Where-Object { $_.Name -ne "VMName" -and $_.Value } |
        ForEach-Object { $tagHashtable[$_.Name] = $_.Value }

    Write-Host "Tags to apply:" ($tagHashtable | Out-String)

    # Get replicating server
    $replicating = Get-AzMigrateServerReplication `
        -ProjectName $MigrateProject.Name `
        -ResourceGroupName $resourceGroupName `
        -MachineName $vmName

    if (-not $replicating) {
        Write-Host "VM not found in Azure Migrate: $vmName" -ForegroundColor Red
        continue
    }

    # Get full object
    $replicating = Get-AzMigrateServerReplication -TargetObjectID $replicating.Id

    # Apply tags to VM + DISKS + NICS
    $updateJob = Set-AzMigrateServerReplication `
        -InputObject $replicating `
        -UpdateTag $tagHashtable `
        -UpdateTagOperation "Merge"

    # ---- SAFE NORMALIZATION ----
    if ($updateJob -is [array]) {
        $updateJob = $updateJob | Select-Object -First 1
    }

    if ($updateJob -is [bool] -or $updateJob -eq $null) {
        Write-Host "No job returned. Assuming success for $vmName." -ForegroundColor Yellow
        Write-Host "✅ Tags applied to VM + DISKS + NICS for $vmName" -ForegroundColor Green
        continue
    }

    # Wait for job
    Write-Host "Waiting for tag update job..."

    do {
        Start-Sleep -Seconds 5
        $updateJob = Get-AzMigrateJob -InputObject $updateJob

        if ($updateJob -is [array]) {
            $updateJob = $updateJob | Select-Object -First 1
        }

    } while ($updateJob.State -in ("InProgress", "NotStarted"))

    # Result
    if ($updateJob.State -eq "Succeeded") {
        Write-Host "✅ Tags applied to VM + DISKS + NICS for $vmName" -ForegroundColor Green
    }
    else {
        Write-Host "Tag update FAILED for $vmName" -ForegroundColor Red
    }
}
