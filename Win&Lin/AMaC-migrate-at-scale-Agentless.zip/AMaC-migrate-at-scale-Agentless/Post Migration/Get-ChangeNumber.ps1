<#
.SYNOPSIS
    Pulls Azure VM tag ChangeNumber for VMs listed in ServerNames-Mig.csv.

.DESCRIPTION
    Reads VM names from CSV, queries Azure VM resources,
    and prints VMName + ChangeNumber tag value in console.

    CSV required header:
        VMName

    Optional CSV header:
        ResourceGroup (not required for lookup)
#>

[CmdletBinding()]
param(
    [string]$DefaultSubscriptionId = "",
    [string]$ServerCsv             = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv",
    [string]$OutputCsv             = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig-ChangeNumber-Result.csv",
    [switch]$SearchAllSubscriptions
)

Import-Module Az.Accounts, Az.Compute

if (-not (Test-Path -Path $ServerCsv)) {
    Write-Error "CSV not found: $ServerCsv"
    return
}

Write-Host "Authenticating to Azure..." -ForegroundColor Cyan
#Connect-AzAccount -ErrorAction Stop | Out-Null

if (-not [string]::IsNullOrWhiteSpace($DefaultSubscriptionId)) {
    Set-AzContext -SubscriptionId $DefaultSubscriptionId -ErrorAction Stop | Out-Null
}

$allSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
$subNameById = @{}
foreach ($sub in $allSubscriptions) {
    $subNameById[$sub.Id] = $sub.Name
}

$currentContext = Get-AzContext
Write-Host "`nConnected tenant: $($currentContext.Tenant.Id)" -ForegroundColor Cyan
Write-Host "Default subscription context: $($currentContext.Subscription.Name) [$($currentContext.Subscription.Id)]" -ForegroundColor Cyan
Write-Host "Reading Azure VM tags (ChangeNumber)" -ForegroundColor Cyan

function Set-SubscriptionContextSafe {
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId
    )

    try {
        Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

function Get-TargetVm {
    param(
        [Parameter(Mandatory)]
        [string]$VmName,
        [string]$ResourceGroup,
        [string]$RowSubscriptionId,
        [string]$DefaultSubscriptionId,
        [bool]$SearchAllSubscriptions,
        [array]$AllSubscriptions,
        [string]$CurrentSubscriptionId
    )

    $candidateSubIds = @()

    if (-not [string]::IsNullOrWhiteSpace($RowSubscriptionId)) {
        $candidateSubIds += $RowSubscriptionId
    }
    elseif (-not [string]::IsNullOrWhiteSpace($DefaultSubscriptionId)) {
        $candidateSubIds += $DefaultSubscriptionId
    }
    else {
        $candidateSubIds += $CurrentSubscriptionId
        # Always include all enabled subscriptions in the connected tenant.
        $candidateSubIds += ($AllSubscriptions | Select-Object -ExpandProperty Id)
    }

    $candidateSubIds = $candidateSubIds | Select-Object -Unique

    foreach ($subId in $candidateSubIds) {
        if (-not (Set-SubscriptionContextSafe -SubscriptionId $subId)) {
            continue
        }

        if (-not [string]::IsNullOrWhiteSpace($ResourceGroup)) {
            $vm = Get-AzVM -Name $VmName -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
            if ($vm) {
                return [PSCustomObject]@{ VM = $vm; SubscriptionId = $subId }
            }
            continue
        }

        $vmCandidates = Get-AzVM -Status -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq $VmName }

        if ($vmCandidates.Count -gt 1) {
            throw "Multiple VMs found with same name in subscription $subId. Provide ResourceGroup in CSV for '$VmName'."
        }

        if ($vmCandidates.Count -eq 1) {
            return [PSCustomObject]@{ VM = $vmCandidates[0]; SubscriptionId = $subId }
        }
    }

    return $null
}

$serverList = Import-Csv -Path $ServerCsv
if (-not $serverList -or $serverList.Count -eq 0) {
    Write-Warning "No rows found in CSV: $ServerCsv"
    return
}

$results = @()
$success = 0
$notFound = 0
$failed = 0

Write-Host "Loaded $($serverList.Count) VM(s) from CSV`n" -ForegroundColor Green

foreach ($row in $serverList) {
    $vmName = if ($null -ne $row.VMName) { ([string]$row.VMName).Trim() } else { '' }
    $csvResourceGroup = if ($null -ne $row.ResourceGroup) { ([string]$row.ResourceGroup).Trim() } else { '' }
    $csvSubscriptionId = if ($null -ne $row.SubscriptionId) { ([string]$row.SubscriptionId).Trim() } else { '' }

    if ([string]::IsNullOrWhiteSpace($vmName)) {
        continue
    }

    try {
        $target = Get-TargetVm `
            -VmName $vmName `
            -ResourceGroup $csvResourceGroup `
            -RowSubscriptionId $csvSubscriptionId `
            -DefaultSubscriptionId $DefaultSubscriptionId `
            -SearchAllSubscriptions $true `
            -AllSubscriptions $allSubscriptions `
            -CurrentSubscriptionId $currentContext.Subscription.Id

        $vm = $null
        $matchedSubscriptionId = ''
        if ($target) {
            $vm = $target.VM
            $matchedSubscriptionId = $target.SubscriptionId
        }

        if (-not $vm) {
            $notFound++
            $results += [PSCustomObject]@{
                VMName       = $vmName
                ResourceGroup = $csvResourceGroup
                SubscriptionId = $csvSubscriptionId
                SubscriptionName = ''
                ChangeNumber = ''
                Status       = 'NotFound'
                Details      = 'Azure VM not found across enabled subscriptions in current tenant'
            }
            continue
        }

        $changeNumber = ''
        if ($null -ne $vm.Tags -and $vm.Tags.ContainsKey('ChangeNumber')) {
            $changeNumber = [string]$vm.Tags['ChangeNumber']
        }

        if ([string]::IsNullOrWhiteSpace($changeNumber)) {
            $success++
            $results += [PSCustomObject]@{
                VMName       = $vmName
                ResourceGroup = $vm.ResourceGroupName
                SubscriptionId = $matchedSubscriptionId
                SubscriptionName = if ($subNameById.ContainsKey($matchedSubscriptionId)) { $subNameById[$matchedSubscriptionId] } else { '' }
                ChangeNumber = ''
                Status       = 'Success'
                Details      = 'ChangeNumber tag not present on Azure VM'
            }
        }
        else {
            $success++
            $results += [PSCustomObject]@{
                VMName       = $vmName
                ResourceGroup = $vm.ResourceGroupName
                SubscriptionId = $matchedSubscriptionId
                SubscriptionName = if ($subNameById.ContainsKey($matchedSubscriptionId)) { $subNameById[$matchedSubscriptionId] } else { '' }
                ChangeNumber = $changeNumber
                Status       = 'Success'
                Details      = ''
            }
        }
    }
    catch {
        $failed++
        $results += [PSCustomObject]@{
            VMName       = $vmName
            ResourceGroup = $csvResourceGroup
            SubscriptionId = $csvSubscriptionId
            SubscriptionName = ''
            ChangeNumber = ''
            Status       = 'Error'
            Details      = $_.Exception.Message
        }
    }
}

Write-Host "`nDetailed Results" -ForegroundColor Cyan
$results |
    Select-Object VMName, ChangeNumber, Status, Details |
    Format-Table -AutoSize

Write-Host "`nSummary" -ForegroundColor Cyan
Write-Host "  Total    : $($serverList.Count)"
Write-Host "  Success  : $success" -ForegroundColor Green
Write-Host "  NotFound : $notFound" -ForegroundColor Yellow
Write-Host "  Failed   : $failed" -ForegroundColor Red

$results | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "`nResult CSV: $OutputCsv" -ForegroundColor Green
