# Path to CSV
$CSVPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Script that runs inside each VM
$Script = @'
# Check if VMware Tools is installed
$vmwareTools = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -match "VMware Tools" }

if ($vmwareTools) {
    Write-Output "===== VMware Tools Detected ====="
    Write-Output "Name: $($vmwareTools.Name)"
    Write-Output "Version: $($vmwareTools.Version)"
    Write-Output "Status: INSTALLED"
}
else {
    Write-Output "===== VMware Tools Not Installed ====="
    Write-Output "Status: NOT INSTALLED"
}
'@

# Import CSV
$VMList = Import-Csv -Path $CSVPath

# Run in parallel
$VMList | ForEach-Object -Parallel {

    # Ensure Az modules are available in each runspace
    Import-Module Az.Compute -Force

    $VMName = $_.VMName
    $RGName = $_.ResourceGroup

    Write-Host "Running VMware Tools check on VM '$VMName' in RG '$RGName'..." -ForegroundColor Yellow

    try {
        $Result = Invoke-AzVMRunCommand `
            -ResourceGroupName $RGName `
            -Name $VMName `
            -CommandId "RunPowerShellScript" `
            -ScriptString $using:Script `
            -ErrorAction Stop

        Write-Host "Output from $VMName" -ForegroundColor Cyan
        $Result.Value.Message | Write-Output

        Write-Host "Completed on $VMName" -ForegroundColor Green
    }
    catch {
        Write-Host "Failed on $VMName ($RGName): $($_.Exception.Message)" -ForegroundColor Red
    }

} -ThrottleLimit 15
