Write-Output "===== VMware Tools Pre-Check ====="

# Detect VMware Tools via registry + services
$vmwareReg = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" `
    -ErrorAction SilentlyContinue |
    Get-ItemProperty |
    Where-Object { $_.DisplayName -match "VMware Tools" }

$vmwareSvc = Get-Service -DisplayName "VMware*" -ErrorAction SilentlyContinue

if (-not $vmwareReg -and -not $vmwareSvc) {
    Write-Output "VMware Tools already NOT installed."
    Write-Output "STATUS=Already Not Installed"
    return
}

Write-Output "VMware Tools detected. Starting removal..."

# ---------- EXISTING REMOVAL LOGIC ----------
function Get-VMwareToolsInstallerID {
    foreach ($item in Get-ChildItem Registry::HKEY_CLASSES_ROOT\Installer\Products -ErrorAction SilentlyContinue) {
        if ($item.GetValue('ProductName') -eq 'VMware Tools') {
            return @{
                reg_id = $item.PSChildName
                msi_id = [Regex]::Match(
                    $item.GetValue('ProductIcon'),
                    '(?<={)(.*?)(?=})'
                ).Value
            }
        }
    }
}

$vmware_tools_ids = Get-VMwareToolsInstallerID

$reg_targets = @(
    "Registry::HKEY_CLASSES_ROOT\Installer\Features\",
    "Registry::HKEY_CLASSES_ROOT\Installer\Products\",
    "HKLM:\SOFTWARE\Classes\Installer\Features\",
    "HKLM:\SOFTWARE\Classes\Installer\Products\",
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\"
)

$targets = @()

if ($vmware_tools_ids) {
    foreach ($item in $reg_targets) {
        $targets += $item + $vmware_tools_ids.reg_id
    }
    $targets += "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{$($vmware_tools_ids.msi_id)}"
}

$targets += "HKLM:\SOFTWARE\VMware, Inc"
$targets += "C:\Program Files\VMware"
$targets += "C:\Program Files\Common Files\VMware"

# Stop & remove services
$services = Get-Service -DisplayName "VMware*" -ErrorAction SilentlyContinue
$services | Stop-Service -Force -ErrorAction SilentlyContinue

foreach ($s in $services) {
    sc.exe DELETE $($s.Name) | Out-Null
}

# Remove files and registry
foreach ($item in $targets) {
    if (Test-Path $item) {
        Remove-Item -Path $item -Recurse -Force -ErrorAction SilentlyContinue
    }
}

Write-Output "Removal completed. Starting post-check..."

# ---------- POST CHECK ----------
$postSvc = Get-Service -DisplayName "VMware*" -ErrorAction SilentlyContinue
$postFiles = @(
    "C:\Program Files\VMware",
    "C:\Program Files\Common Files\VMware"
) | Where-Object { Test-Path $_ }

$postReg = Test-Path "HKLM:\SOFTWARE\VMware, Inc"

if (-not $postSvc -and -not $postFiles -and -not $postReg) {
    Write-Output "Post-check passed. VMware Tools fully removed."
    Write-Output "STATUS=Uninstalled Successfully"
}
else {
    Write-Output "Post-check FAILED. Some remnants still exist."
    Write-Output "Remaining Services: $($postSvc.Count)"
    Write-Output "Remaining Paths: $($postFiles -join ', ')"
    Write-Output "Remaining Registry: $postReg"
    Write-Output "STATUS=Partial Removal"
}
