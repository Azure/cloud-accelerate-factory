# Simple VMware Tools Uninstaller WITH FULL ERROR REPORTING (FIXED)
$CSVPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\Servernames-mig.csv"

$SimpleScript = @'
#!/bin/bash
echo "=== Uninstalling VMware Tools on $HOSTNAME ==="

if command -v yum >/dev/null 2>&1; then
    echo "YUM: Removing open-vm-tools*"
    yum list installed open-vm-tools* 2>&1 || echo "No YUM packages found"
    yum remove -y open-vm-tools* 2>&1 || echo "YUM removal complete/no packages"
elif command -v dnf >/dev/null 2>&1; then
    echo "DNF: Removing open-vm-tools*"
    dnf remove -y open-vm-tools* 2>&1 || echo "DNF removal complete/no packages"
elif command -v apt >/dev/null 2>&1; then
    echo "APT: Removing open-vm-tools*"
    DEBIAN_FRONTEND=noninteractive apt-get purge -y open-vm-tools* 2>&1 || echo "APT removal complete/no packages"
else
    echo "No recognized package manager found"
fi

echo "=== COMPLETE ==="
'@

Import-Csv $CSVPath | ForEach-Object -Parallel {
    $VMName = $_.VMName
    $RGName = $_.ResourceGroup
    
    try {
        Write-Host "`n🔄 [$VMName/$RGName] Starting..." -ForegroundColor Yellow
        
        $result = Invoke-AzVMRunCommand -ResourceGroupName $RGName -VMName $VMName -CommandId 'RunShellScript' -ScriptString $using:SimpleScript -ErrorAction Stop
        
        if ($result.Status -eq 'Succeeded') {
            Write-Host "  ✅ SUCCESS" -ForegroundColor Green
            $output = $result.Value[0].Message -replace "`n", " | " -replace "`r", ""
            Write-Host "  OUTPUT: $output" -ForegroundColor Gray
        } else {
            Write-Host "  ❌ VM SCRIPT FAILED" -ForegroundColor Red
            Write-Host "  ERROR: $($result.Value.Message)" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "  ❌ AZURE ERROR: $($_.Exception.Message)" -ForegroundColor Magenta
    }
} -ThrottleLimit 10

Write-Host "`n🎯 All VMs processed!" -ForegroundColor Magenta
