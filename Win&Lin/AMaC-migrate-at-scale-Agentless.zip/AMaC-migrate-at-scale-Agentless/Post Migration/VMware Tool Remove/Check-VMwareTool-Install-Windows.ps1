﻿# Path to your CSV file
$CSVPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Script that will run inside each VM (single-quoted here-string!)
$Script = @'
# Check if VMware Tools is installed
$vmwareTools = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -match "VMware Tools" }

if ($vmwareTools) {
    Write-Output "===== VMware Tools Detected ====="
    Write-Output "Name: $($vmwareTools.Name)"
    Write-Output "Version: $($vmwareTools.Version)"
    Write-Output "Status: INSTALLED"
}
else {
    Write-Output "===== VMware Tools Not Installed ====="
    Write-Output "Status: NOT INSTALLED"
}
'@

# Import CSV
$VMList = Import-Csv -Path $CSVPath

foreach ($entry in $VMList) {

    $VMName = $entry.VMName
    $RGName = $entry.ResourceGroup

    Write-Host "Running VMware Tools check on VM '$VMName' in RG '$RGName'..." -ForegroundColor Yellow

    try {
        $Result = Invoke-AzVMRunCommand `
            -ResourceGroupName $RGName `
            -Name $VMName `
            -CommandId "RunPowerShellScript" `
            -ScriptString $Script `
            -ErrorAction Stop

        Write-Host "Output from $VMName" -ForegroundColor Cyan
        $Result.Value.Message | Write-Output

        Write-Host "Completed on $VMName" -ForegroundColor Green
    }
    catch {
        Write-Host "Failed on $VMName ($RGName): $($_.Exception.Message)" -ForegroundColor Red
    }
}
