﻿# Path to your CSV file with VM list
$CSVPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Path to output CSV for results
$OutputCSV = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\VMwareTool_Results.csv"

# Load the VMware Tools removal script (Azure compatible)
$VMwareScript = Get-Content -Raw -Path "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Scripts\VMware Tool Remove\VMwareTool-Uninstaller_v01.ps1"

# Import VM list
$VMList = Import-Csv -Path $CSVPath

# Initialize results array (thread-safe)
$ResultsBag = [System.Collections.Concurrent.ConcurrentBag[PSCustomObject]]::new()

Write-Host "Starting VMware Tools removal on $($VMList.Count) VM(s)..." -ForegroundColor Cyan

# Parallel execution
$VMList | ForEach-Object -Parallel {
    # Create a local reference to the ConcurrentBag
    $Results = $using:ResultsBag

    $VMName = $_.VMName
    $RGName = $_.ResourceGroup

    $status = ""
    $message = ""

    try {
        $Result = Invoke-AzVMRunCommand `
            -ResourceGroupName $RGName `
            -Name $VMName `
            -CommandId "RunPowerShellScript" `
            -ScriptString $using:VMwareScript `
            -ErrorAction Stop

        # Capture all stdout/stderr messages
        $msgList = $Result.Value | ForEach-Object { $_.Message } | Where-Object { $_ -ne "" }
        $message = ($msgList -join "`n").Trim()

        # Determine status
        if ($message -match "uninstalled successfully") {
            $status = "Uninstalled"
        }
        elseif ($message -match "Not Installed") {
            $status = "Not Installed"
        }
        else {
            $status = "Success"
        }

        Write-Host "[$VMName] Status: $status" -ForegroundColor Green

    } catch {
        $status = "RunCommand Failed"
        $message = $_.Exception.Message
        Write-Host "[$VMName] Failed: $message" -ForegroundColor Red
    }

    # Add result to shared ConcurrentBag via local reference
    $Results.Add([PSCustomObject]@{
        VMName = $VMName
        ResourceGroup = $RGName
        Status = $status
        Message = $message
        Timestamp = Get-Date
    })

} -ThrottleLimit 15  # Adjust parallelism as needed

# Export results
$ResultsBag #| Sort-Object VMName | Export-Csv -Path $OutputCSV -NoTypeInformation
Write-Host "All results exported to $OutputCSV" -ForegroundColor Cyan
