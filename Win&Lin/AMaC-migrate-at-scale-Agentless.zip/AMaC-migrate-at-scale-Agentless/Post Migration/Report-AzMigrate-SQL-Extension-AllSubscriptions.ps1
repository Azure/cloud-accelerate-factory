<#
.SYNOPSIS
Builds a report of Azure VMs with SQL extension enabled across all subscriptions.

.DESCRIPTION
Scans all accessible subscriptions and reports only VMs that have
Microsoft.SqlVirtualMachine/sqlVirtualMachines registration.
This script is read-only and does not perform create/update/delete actions.

Report columns include:
- SQL version and edition details (best-effort from SQL VM resource properties)
- Server host name and CPU core count
- VM creation date/time (best-effort)
- VM location and license type
- OS and data disk storage tiers (Standard/Premium/etc.)

.NOTES
Author: Deepak Tyagi
Requires: Az.Accounts, Az.Compute, Az.Resources
#>

# ==================== CONFIG ====================
$OutputFolder = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File"
$IncludeDisabledSubscriptions = $false
$RequiredTagName = "ProjectID"
$RequiredTagValue = "P5909.00"
$ReadOnlyReportMode = $true
# ================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not $ReadOnlyReportMode) {
    throw "Safety stop: This script is designed for read-only reporting. Keep `$ReadOnlyReportMode = `$true."
}

try {
    Disable-AzContextAutosave -Scope Process -ErrorAction SilentlyContinue | Out-Null
}
catch {
    # Context autosave is optional; ignore if unavailable.
}

Write-Host "Read-only report mode active. No production changes will be made." -ForegroundColor Green

function Get-FirstNotEmpty {
    param([object[]]$Values)

    foreach ($value in $Values) {
        if ($null -eq $value) { continue }
        $text = [string]$value
        if (-not [string]::IsNullOrWhiteSpace($text)) {
            return $text.Trim()
        }
    }

    return $null
}

function Get-VmCreationTimeText {
    param(
        [object]$Vm,
        [object]$VmResource
    )

    $candidates = @(
        $Vm.TimeCreated,
        $VmResource.TimeCreated,
        $VmResource.Properties.timeCreated,
        $VmResource.Properties.createdTime,
        $Vm.StorageProfile.OsDisk.TimeCreated
    )

    foreach ($candidate in $candidates) {
        if ($null -eq $candidate) { continue }
        try {
            return ([DateTimeOffset]$candidate).ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss zzz")
        }
        catch {
            $text = [string]$candidate
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                return $text
            }
        }
    }

    return "N/A"
}

function Get-TagValue {
    param(
        [hashtable]$Tags,
        [string]$TagName
    )

    if ($null -eq $Tags -or [string]::IsNullOrWhiteSpace($TagName)) {
        return $null
    }

    foreach ($key in $Tags.Keys) {
        if ([string]::Equals([string]$key, $TagName, [System.StringComparison]::OrdinalIgnoreCase)) {
            return [string]$Tags[$key]
        }
    }

    return $null
}

$vmSizeCacheByLocation = @{}

function Get-CpuCoreCount {
    param(
        [string]$Location,
        [string]$VmSize
    )

    if ([string]::IsNullOrWhiteSpace($Location) -or [string]::IsNullOrWhiteSpace($VmSize)) {
        return "N/A"
    }

    if (-not $vmSizeCacheByLocation.ContainsKey($Location)) {
        $lookup = @{}
        try {
            $sizes = Get-AzVMSize -Location $Location -ErrorAction Stop
            foreach ($size in $sizes) {
                $lookup[[string]$size.Name] = [string]$size.NumberOfCores
            }
        }
        catch {
            # Keep empty lookup when region query is blocked.
        }
        $vmSizeCacheByLocation[$Location] = $lookup
    }

    $locationLookup = $vmSizeCacheByLocation[$Location]
    if ($locationLookup.ContainsKey($VmSize)) {
        return $locationLookup[$VmSize]
    }

    return "N/A"
}

try {
    Import-Module Az.Accounts -ErrorAction Stop
    Import-Module Az.Compute -ErrorAction Stop
    Import-Module Az.Resources -ErrorAction Stop
}
catch {
    Write-Host "Failed to load required Az modules (Az.Accounts, Az.Compute, Az.Resources)." -ForegroundColor Red
    throw
}

if (-not (Get-AzContext)) {
    Write-Host "No Azure context found. Running Connect-AzAccount..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

$subscriptions = Get-AzSubscription
if (-not $IncludeDisabledSubscriptions) {
    $subscriptions = @($subscriptions | Where-Object { $_.State -eq "Enabled" })
}

if (-not $subscriptions -or $subscriptions.Count -eq 0) {
    throw "No subscriptions found for reporting."
}

$reportRows = @()

foreach ($subscription in $subscriptions) {
    Write-Host ("Processing subscription: {0}" -f $subscription.Name) -ForegroundColor Cyan

    try {
        Set-AzContext -SubscriptionId $subscription.Id -ErrorAction Stop | Out-Null

        $sqlVmResources = @(Get-AzResource -ResourceType "Microsoft.SqlVirtualMachine/sqlVirtualMachines" -ExpandProperties -ErrorAction Stop)
        if ($sqlVmResources.Count -eq 0) {
            Write-Host "  No SQL extension-enabled VMs found in this subscription." -ForegroundColor DarkGray
            continue
        }

        $sqlByVmId = @{}
        $sqlByVmName = @{}

        foreach ($sqlVmResource in $sqlVmResources) {
            $sqlProps = $sqlVmResource.Properties

            $vmResourceId = Get-FirstNotEmpty @(
                $sqlProps.virtualMachineResourceId,
                $sqlProps.VirtualMachineResourceId
            )

            if (-not [string]::IsNullOrWhiteSpace($vmResourceId)) {
                $sqlByVmId[$vmResourceId.ToLowerInvariant()] = $sqlVmResource
            }

            if (-not [string]::IsNullOrWhiteSpace([string]$sqlVmResource.Name)) {
                $sqlByVmName[[string]$sqlVmResource.Name.ToLowerInvariant()] = $sqlVmResource
            }
        }

        $vms = @(Get-AzVM -Status -ErrorAction Stop)

        foreach ($vm in $vms) {
            $vmTagValue = Get-TagValue -Tags $vm.Tags -TagName $RequiredTagName
            if ([string]::IsNullOrWhiteSpace($vmTagValue) -or -not [string]::Equals($vmTagValue.Trim(), $RequiredTagValue, [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }

            $sqlMatch = $null
            $vmIdKey = [string]$vm.Id
            $vmNameKey = [string]$vm.Name

            if (-not [string]::IsNullOrWhiteSpace($vmIdKey) -and $sqlByVmId.ContainsKey($vmIdKey.ToLowerInvariant())) {
                $sqlMatch = $sqlByVmId[$vmIdKey.ToLowerInvariant()]
            }
            elseif (-not [string]::IsNullOrWhiteSpace($vmNameKey) -and $sqlByVmName.ContainsKey($vmNameKey.ToLowerInvariant())) {
                $sqlMatch = $sqlByVmName[$vmNameKey.ToLowerInvariant()]
            }

            if ($null -eq $sqlMatch) {
                continue
            }

            $sqlProps = $sqlMatch.Properties
            $sqlVersion = Get-FirstNotEmpty @(
                $sqlProps.sqlImageSku,
                $sqlProps.SqlImageSku,
                $sqlProps.sqlVersion,
                $sqlProps.SqlVersion,
                $sqlProps.sku,
                $sqlProps.Sku,
                $sqlProps.offer,
                $sqlProps.Offer
            )

            $sqlEdition = Get-FirstNotEmpty @(
                $sqlProps.sqlEdition,
                $sqlProps.SqlEdition,
                $sqlProps.edition,
                $sqlProps.Edition
            )

            if ([string]::IsNullOrWhiteSpace($sqlVersion)) {
                $sqlVersion = "Unknown"
            }

            if ([string]::IsNullOrWhiteSpace($sqlEdition)) {
                $sqlEdition = "Unknown"
            }

            $vmResource = $null
            try {
                $vmResource = Get-AzResource -ResourceId $vm.Id -ExpandProperties -ErrorAction Stop
            }
            catch {
                # Continue with best-effort fields.
            }

            $hostName = Get-FirstNotEmpty @($vm.OSProfile.ComputerName, $vm.Name)
            if ([string]::IsNullOrWhiteSpace($hostName)) { $hostName = "N/A" }

            $vmSize = Get-FirstNotEmpty @($vm.HardwareProfile.VmSize)
            if ([string]::IsNullOrWhiteSpace($vmSize)) { $vmSize = "N/A" }

            $cpuCores = Get-CpuCoreCount -Location ([string]$vm.Location) -VmSize $vmSize
            $creationTime = Get-VmCreationTimeText -Vm $vm -VmResource $vmResource

            $vmLocation = Get-FirstNotEmpty @($vm.Location)
            if ([string]::IsNullOrWhiteSpace($vmLocation)) { $vmLocation = "N/A" }

            $licenseType = Get-FirstNotEmpty @(
                $vm.LicenseType,
                $sqlProps.sqlServerLicenseType,
                $sqlProps.SqlServerLicenseType,
                $sqlProps.licenseType,
                $sqlProps.LicenseType
            )
            if ([string]::IsNullOrWhiteSpace($licenseType)) { $licenseType = "N/A" }

            $osDiskTier = Get-FirstNotEmpty @($vm.StorageProfile.OsDisk.ManagedDisk.StorageAccountType)
            if ([string]::IsNullOrWhiteSpace($osDiskTier)) { $osDiskTier = "N/A" }

            $osDiskSizeGb = Get-FirstNotEmpty @($vm.StorageProfile.OsDisk.DiskSizeGB)
            if ([string]::IsNullOrWhiteSpace($osDiskSizeGb)) { $osDiskSizeGb = "N/A" }

            $dataDiskDetails = "None"
            if ($vm.StorageProfile.DataDisks -and $vm.StorageProfile.DataDisks.Count -gt 0) {
                $diskDetails = foreach ($disk in $vm.StorageProfile.DataDisks) {
                    $diskTier = Get-FirstNotEmpty @($disk.ManagedDisk.StorageAccountType)
                    if ([string]::IsNullOrWhiteSpace($diskTier)) { $diskTier = "N/A" }

                    $diskSize = Get-FirstNotEmpty @($disk.DiskSizeGB)
                    if ([string]::IsNullOrWhiteSpace($diskSize)) { $diskSize = "N/A" }

                    "{0}:{1}({2}GB)" -f $disk.Name, $diskTier, $diskSize
                }
                $dataDiskDetails = ($diskDetails -join "; ")
            }

            $reportRows += [PSCustomObject]@{
                SubscriptionName    = $subscription.Name
                SubscriptionId      = $subscription.Id
                ResourceGroupName   = $vm.ResourceGroupName
                VMName              = $vm.Name
                ServerHostname      = $hostName
                VMSize              = $vmSize
                CpuCores            = $cpuCores
                SQLVersion          = $sqlVersion
                SQLEdition          = $sqlEdition
                VMLocation          = $vmLocation
                LicenseType         = $licenseType
                VMCreationDateTime  = $creationTime
                OSDiskTier          = $osDiskTier
                OSDiskSizeGB        = $osDiskSizeGb
                DataDiskDetails     = $dataDiskDetails
            }
        }
    }
    catch {
        Write-Warning ("Failed subscription {0}: {1}" -f $subscription.Name, $_.Exception.Message)
        continue
    }
}

if ($reportRows.Count -eq 0) {
    Write-Host ("No SQL extension-enabled VMs found across scanned subscriptions for tag {0}={1}." -f $RequiredTagName, $RequiredTagValue) -ForegroundColor Yellow
    return
}

if (-not (Test-Path -Path $OutputFolder)) {
    New-Item -Path $OutputFolder -ItemType Directory -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$outputCsvPath = Join-Path -Path $OutputFolder -ChildPath ("AzureMigrate-SQLExtension-AllSubscriptions-{0}.csv" -f $timestamp)

$reportRows |
    Sort-Object SubscriptionName, ResourceGroupName, VMName |
    Export-Csv -Path $outputCsvPath -NoTypeInformation -Encoding UTF8

Write-Host ("Report generated successfully: {0}" -f $outputCsvPath) -ForegroundColor Green
Write-Host ("Total SQL extension-enabled VMs: {0}" -f $reportRows.Count) -ForegroundColor Green
