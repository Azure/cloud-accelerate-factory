﻿<#
.SYNOPSIS
   Checks whether Accelerated Networking is enabled on Azure VMs listed in a CSV file.

.DESCRIPTION
   This script reads a CSV with VM names, retrieves the primary NIC of each VM,
   and displays whether Accelerated Networking is enabled or disabled.

.INPUTS
   CSV file with column "VMName".

.NOTES
   Requires Az PowerShell module.
#>

# Path to your CSV file
$csvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# ===================== AUTHENTICATE =====================
Write-Host "Authenticating to Azure..." -ForegroundColor Cyan
#Connect-AzAccount -ErrorAction Stop | Out-Null

# ===================== DISCOVER ALL SUBSCRIPTIONS =====================
$allSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
$currentContext   = Get-AzContext
Write-Host "Connected tenant : $($currentContext.Tenant.Id)" -ForegroundColor Cyan
Write-Host "Subscriptions    : $($allSubscriptions.Count) enabled" -ForegroundColor Cyan

# ===================== HELPER — find VM across all subscriptions =====================
function Find-AzVMCrossSub {
    param(
        [Parameter(Mandatory)]
        [string]$VmName,
        [string]$ResourceGroup,
        [Parameter(Mandatory)]
        [array]$Subscriptions
    )

    foreach ($sub in $Subscriptions) {
        try { Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null } catch { continue }

        $found = if (-not [string]::IsNullOrWhiteSpace($ResourceGroup)) {
            Get-AzVM -Name $VmName -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
        } else {
            Get-AzVM -Name $VmName -ErrorAction SilentlyContinue
        }

        if ($found) {
            return [PSCustomObject]@{ VM = $found; SubscriptionId = $sub.Id; SubscriptionName = $sub.Name }
        }
    }
    return $null
}

# ===================== MAIN =====================
$servers = Import-Csv -Path $csvPath
Write-Host "Loaded $($servers.Count) VM(s) from CSV`n" -ForegroundColor Green

$results = foreach ($server in $servers) {
    $vmName = ([string]$server.VMName).Trim()
    $csvRg  = if ($null -ne $server.ResourceGroup) { ([string]$server.ResourceGroup).Trim() } else { '' }

    if ([string]::IsNullOrWhiteSpace($vmName)) { continue }

    try {
        $match = Find-AzVMCrossSub -VmName $vmName -ResourceGroup $csvRg -Subscriptions $allSubscriptions

        if (-not $match) {
            [PSCustomObject]@{ VMName = $vmName; ResourceGroup = $csvRg; SubscriptionName = ''; AcceleratedNetworking = 'NotFound'; Details = 'VM not found across all enabled subscriptions' }
            continue
        }

        $vm    = $match.VM
        $nicId = $vm.NetworkProfile.NetworkInterfaces[0].Id
        $nicName = $nicId.Split('/')[-1]
        $nic   = Get-AzNetworkInterface -Name $nicName -ResourceGroupName $vm.ResourceGroupName -ErrorAction Stop
        $anStatus = if ($nic.EnableAcceleratedNetworking) { 'Enabled' } else { 'Disabled' }

        [PSCustomObject]@{
            VMName               = $vm.Name
            ResourceGroup        = $vm.ResourceGroupName
            SubscriptionName     = $match.SubscriptionName
            AcceleratedNetworking = $anStatus
            Details              = ''
        }
    }
    catch {
        [PSCustomObject]@{ VMName = $vmName; ResourceGroup = $csvRg; SubscriptionName = ''; AcceleratedNetworking = 'Error'; Details = $_.Exception.Message }
    }
}

# ===================== OUTPUT =====================
$col = @{ VMName = 30; ResourceGroup = 35; SubscriptionName = 35; AcceleratedNetworking = 22 }

Write-Host (
    'VMName'.PadRight($col.VMName) +
    'ResourceGroup'.PadRight($col.ResourceGroup) +
    'SubscriptionName'.PadRight($col.SubscriptionName) +
    'AcceleratedNetworking'.PadRight($col.AcceleratedNetworking) +
    'Details'
) -ForegroundColor White
Write-Host ('-' * 145) -ForegroundColor DarkGray

foreach ($r in $results) {
    $anColor = switch ($r.AcceleratedNetworking) {
        'Enabled'   { 'Green' }
        'Disabled'  { 'Yellow' }
        'NotFound'  { 'DarkYellow' }
        'Error'     { 'Red' }
        default     { 'Gray' }
    }
    Write-Host $r.VMName.PadRight($col.VMName)                    -NoNewline -ForegroundColor Cyan
    Write-Host $r.ResourceGroup.PadRight($col.ResourceGroup)       -NoNewline -ForegroundColor Gray
    Write-Host $r.SubscriptionName.PadRight($col.SubscriptionName) -NoNewline -ForegroundColor Gray
    Write-Host $r.AcceleratedNetworking.PadRight($col.AcceleratedNetworking) -NoNewline -ForegroundColor $anColor
    Write-Host $r.Details                                          -ForegroundColor Gray
}
Write-Host ('-' * 145) -ForegroundColor DarkGray
