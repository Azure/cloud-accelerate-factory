<#
.SYNOPSIS
Calculates data transfer/replication time based on data size and transfer speed.

.DESCRIPTION
Converts data size and speed to common units and calculates the time required for replication.
Supports multiple input units:
  - Data: B, KB, MB, GB, TB
  - Speed: bps, Kbps, Mbps, Gbps, B/s, KB/s, MB/s, GB/s, Tbps

.PARAMETERS
-DataSize: Size of data to transfer (numeric value)
-DataUnit: Unit of data size (B, KB, MB, GB, TB). Default: GB
-Speed: Transfer speed (numeric value)
-SpeedUnit: Unit of speed (bps, Kbps, Mbps, Gbps, B/s, KB/s, MB/s, GB/s, Tbps). Default: Mbps

.EXAMPLE
# Calculate time to transfer 100 GB at 100 Mbps
.\Calculate-DataTransferTime.ps1 -DataSize 100 -DataUnit GB -Speed 100 -SpeedUnit Mbps

.EXAMPLE
# Calculate time to transfer 500 GB at 1 Gbps
.\Calculate-DataTransferTime.ps1 -DataSize 500 -DataUnit GB -Speed 1 -SpeedUnit Gbps

.EXAMPLE
# Interactive mode (no parameters)
.\Calculate-DataTransferTime.ps1

.NOTES
- Author: Deepak Tyagi
- Useful for Azure migration planning and replication time estimation.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [double]$DataSize,

    [Parameter(Mandatory = $false)]
    [ValidateSet("B", "KB", "MB", "GB", "TB", IgnoreCase = $true)]
    [string]$DataUnit = "GB",

    [Parameter(Mandatory = $false)]
    [double]$Speed,

    [Parameter(Mandatory = $false)]
    [ValidateSet("bps", "Kbps", "Mbps", "Gbps", "B/s", "KB/s", "MB/s", "GB/s", "Tbps", IgnoreCase = $true)]
    [string]$SpeedUnit = "Mbps"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Show-Header {
    Write-Host ""
    Write-Host ("=" * 80) -ForegroundColor Cyan
    Write-Host "Data Transfer Time Calculator" -ForegroundColor Cyan
    Write-Host ("=" * 80) -ForegroundColor Cyan
    Write-Host ""
}

function ConvertTo-Bytes {
    param(
        [double]$Value,
        [string]$Unit
    )

    $Unit = $Unit.ToUpper()

    switch ($Unit) {
        "B"  { return $Value }
        "KB" { return $Value * 1024 }
        "MB" { return $Value * 1024 * 1024 }
        "GB" { return $Value * 1024 * 1024 * 1024 }
        "TB" { return $Value * 1024 * 1024 * 1024 * 1024 }
        default { throw "Unknown data unit: $Unit" }
    }
}

function ConvertTo-BitsPerSecond {
    param(
        [double]$Value,
        [string]$Unit
    )

    $Unit = $Unit.ToLower()

    switch ($Unit) {
        "bps"  { return $Value }
        "kbps" { return $Value * 1000 }
        "mbps" { return $Value * 1000 * 1000 }
        "gbps" { return $Value * 1000 * 1000 * 1000 }
        "tbps" { return $Value * 1000 * 1000 * 1000 * 1000 }
        "b/s"  { return $Value * 8 }
        "kb/s" { return $Value * 1024 * 8 }
        "mb/s" { return $Value * 1024 * 1024 * 8 }
        "gb/s" { return $Value * 1024 * 1024 * 1024 * 8 }
        default { throw "Unknown speed unit: $Unit" }
    }
}

function Format-TimeSpan {
    param([TimeSpan]$Duration)

    $days = [Math]::Floor($Duration.TotalDays)
    $hours = $Duration.Hours
    $minutes = $Duration.Minutes
    $seconds = $Duration.Seconds

    $parts = @()
    if ($days -gt 0) { $parts += "$days day$(if ($days -ne 1) { 's' })" }
    if ($hours -gt 0) { $parts += "$hours hour$(if ($hours -ne 1) { 's' })" }
    if ($minutes -gt 0) { $parts += "$minutes minute$(if ($minutes -ne 1) { 's' })" }
    if ($seconds -gt 0) { $parts += "$seconds second$(if ($seconds -ne 1) { 's' })" }

    if ($parts.Count -eq 0) {
        return "< 1 second"
    }

    return ($parts -join ", ")
}

function Get-UserInput {
    param(
        [string]$Prompt,
        [string[]]$ValidOptions = $null
    )

    while ($true) {
        $input = Read-Host $Prompt

        if ($null -eq $ValidOptions -or $input -in $ValidOptions) {
            return $input
        }

        Write-Host "Invalid input. Please enter one of: $($ValidOptions -join ', ')" -ForegroundColor Yellow
    }
}

function Calculate-TransferTime {
    param(
        [double]$DataSize,
        [string]$DataUnit,
        [double]$Speed,
        [string]$SpeedUnit
    )

    try {
        $bytes = ConvertTo-Bytes -Value $DataSize -Unit $DataUnit
        $bitsPerSecond = ConvertTo-BitsPerSecond -Value $Speed -Unit $SpeedUnit
        $bytesPerSecond = $bitsPerSecond / 8

        if ($bytesPerSecond -le 0) {
            throw "Speed must be greater than 0"
        }

        $seconds = $bytes / $bytesPerSecond
        $duration = [TimeSpan]::FromSeconds($seconds)

        return @{
            Seconds      = $seconds
            Duration     = $duration
            FormattedTime= Format-TimeSpan -Duration $duration
            DataBytes    = $bytes
            BytesPerSec  = $bytesPerSecond
        }
    }
    catch {
        Write-Host "Error in calculation: $_" -ForegroundColor Red
        return $null
    }
}

function Show-Result {
    param([hashtable]$Result)

    Write-Host ""
    Write-Host "=" * 80 -ForegroundColor Green
    Write-Host "TRANSFER TIME CALCULATION RESULT" -ForegroundColor Green
    Write-Host "=" * 80 -ForegroundColor Green
    Write-Host ""

    Write-Host "Input:" -ForegroundColor Cyan
    Write-Host ("  Data Size       : {0:N2} {1}" -f $DataSize, $DataUnit)
    Write-Host ("  Transfer Speed  : {0:N2} {1}" -f $Speed, $SpeedUnit)
    Write-Host ""

    Write-Host "Converted Values:" -ForegroundColor Cyan
    Write-Host ("  Total Data      : {0:N0} bytes ({1:N2} GB)" -f $Result.DataBytes, ($Result.DataBytes / 1GB))
    Write-Host ("  Transfer Rate   : {0:N0} bytes/sec ({1:N2} MB/s)" -f $Result.BytesPerSec, ($Result.BytesPerSec / 1MB))
    Write-Host ""

    Write-Host "Time to Transfer:" -ForegroundColor Cyan
    Write-Host ("  {0:N0} seconds" -f $Result.Seconds) -ForegroundColor Yellow
    Write-Host ("  {0}" -f $Result.FormattedTime) -ForegroundColor Green
    Write-Host ""

    Write-Host "=" * 80 -ForegroundColor Green
    Write-Host ""
}

# Main execution
Show-Header

# If parameters not provided, use interactive mode
if (-not $PSBoundParameters.ContainsKey('DataSize') -or -not $PSBoundParameters.ContainsKey('Speed')) {
    Write-Host "Enter data transfer details (or press Ctrl+C to exit):" -ForegroundColor Cyan
    Write-Host ""

    # Get data size
    $DataSize = [double](Get-UserInput "Data size (numeric value)")
    Write-Host ""

    # Get data unit
    Write-Host "Select data unit:"
    Write-Host "  1. B  (Bytes)"
    Write-Host "  2. KB (Kilobytes)"
    Write-Host "  3. MB (Megabytes)"
    Write-Host "  4. GB (Gigabytes) [default]"
    Write-Host "  5. TB (Terabytes)"
    Write-Host ""
    $unitChoice = Get-UserInput "Enter choice (1-5, or press Enter for default)" "1", "2", "3", "4", "5", ""

    if ($unitChoice -eq "" -or $unitChoice -eq "4") {
        $DataUnit = "GB"
    }
    else {
        $unitChoice = [int]$unitChoice
        $units = @("", "B", "KB", "MB", "GB", "TB")
        $DataUnit = $units[$unitChoice]
    }

    Write-Host ""

    # Get speed
    $Speed = [double](Get-UserInput "Transfer speed (numeric value)")
    Write-Host ""

    # Get speed unit
    Write-Host "Select speed unit:"
    Write-Host "  1. bps   (bits per second)"
    Write-Host "  2. Kbps  (kilobits per second)"
    Write-Host "  3. Mbps  (megabits per second) [default]"
    Write-Host "  4. Gbps  (gigabits per second)"
    Write-Host "  5. Tbps  (terabits per second)"
    Write-Host "  6. B/s   (bytes per second)"
    Write-Host "  7. KB/s  (kilobytes per second)"
    Write-Host "  8. MB/s  (megabytes per second)"
    Write-Host "  9. GB/s  (gigabytes per second)"
    Write-Host ""
    $speedChoice = Get-UserInput "Enter choice (1-9, or press Enter for default)" "1", "2", "3", "4", "5", "6", "7", "8", "9", ""

    if ($speedChoice -eq "" -or $speedChoice -eq "3") {
        $SpeedUnit = "Mbps"
    }
    else {
        $speedChoice = [int]$speedChoice
        $speedUnits = @("", "bps", "Kbps", "Mbps", "Gbps", "Tbps", "B/s", "KB/s", "MB/s", "GB/s")
        $SpeedUnit = $speedUnits[$speedChoice]
    }

    Write-Host ""
}

# Calculate transfer time
$result = Calculate-TransferTime -DataSize $DataSize -DataUnit $DataUnit -Speed $Speed -SpeedUnit $SpeedUnit

if ($null -ne $result) {
    Show-Result -Result $result
}
