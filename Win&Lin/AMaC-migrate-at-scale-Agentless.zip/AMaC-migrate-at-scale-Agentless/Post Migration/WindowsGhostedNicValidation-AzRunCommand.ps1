<#
.SYNOPSIS
Read-only ghosted NIC detection across Azure VMs using Invoke-AzVMRunCommand.

.DESCRIPTION
Runs a detection script inside each Windows VM via Azure Run Command and returns:
- Ghosted NIC count
- Valid NIC count
- Per-NIC details (bus, service, state, description)

No cleanup/removal operations are performed.
No WMI/Win32_Product usage.

.NOTES
- Author: Deepak Tyagi
- Requires Az.Compute and Az.Accounts modules.
- Requires VM Agent + RunCommand availability on target VMs.

.EXAMPLE
.\WindowsGhostedNicValidation-AzRunCommand.ps1

.EXAMPLE
.\WindowsGhostedNicValidation-AzRunCommand.ps1 -CsvPath .\Script-Run-Data-File\ServerNames-Mig.csv
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$CsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv",

    [Parameter(Mandatory = $false)]
    [string]$VmNameColumn = "VMName",

    [Parameter(Mandatory = $false)]
    [string]$ResourceGroupColumn = "ResourceGroup",

    [Parameter(Mandatory = $false)]
    [int]$DelayBetweenVMsSeconds = 1,

    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = ".\GhostNIC-Reports"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not (Test-Path -Path $CsvPath)) {
    throw "CSV file not found: $CsvPath"
}

Import-Module Az.Accounts -ErrorAction Stop
Import-Module Az.Compute -ErrorAction Stop

if (-not (Get-AzContext)) {
    Connect-AzAccount | Out-Null
}

$vmList = Import-Csv -Path $CsvPath
if (-not ($vmList | Get-Member -Name $VmNameColumn -MemberType NoteProperty)) {
    throw "Column '$VmNameColumn' not found in CSV."
}
if (-not ($vmList | Get-Member -Name $ResourceGroupColumn -MemberType NoteProperty)) {
    throw "Column '$ResourceGroupColumn' not found in CSV."
}

$remoteScript = @'
$ErrorActionPreference = "Stop"

$activePnpIds = @(Get-NetAdapter -ErrorAction Stop | Select-Object -ExpandProperty PnpDeviceID)

function Scan-Bus {
    param([string]$BusName, [string[]]$ActivePnp)

    $records = @()
    $root = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\"
    $path = "HKLM:\SYSTEM\CurrentControlSet\Enum\$BusName"

    if (-not (Test-Path -Path $path)) {
        return $records
    }

    foreach ($rootChild in (Get-ChildItem -Path $path -Depth 0 -ErrorAction SilentlyContinue)) {
        $rootChildPath = $rootChild.Name.ToString().Replace("HKEY_LOCAL_MACHINE\", "HKLM:\")

        foreach ($entry in (Get-ChildItem -Path $rootChildPath -Depth 0 -ErrorAction SilentlyContinue)) {
            $entryPath = $entry.Name.ToString().Replace("HKEY_LOCAL_MACHINE\", "HKLM:\")
            $relative = $entry.Name.ToString().Replace($root, "")

            $service = (Get-ItemProperty -Path $entryPath -Name Service -ErrorAction SilentlyContinue).Service
            if ($service -notin @("netvsc", "mlx5", "mlx4_bus")) {
                continue
            }

            $descRaw = (Get-ItemProperty -Path $entryPath -Name DeviceDesc -ErrorAction SilentlyContinue).DeviceDesc
            $idx = (Get-ItemProperty -Path "$entryPath\Device Parameters" -Name InstanceIndex -ErrorAction SilentlyContinue).InstanceIndex

            $desc = "Unknown Device"
            if ($descRaw) {
                try {
                    $parts = $descRaw -split ";"
                    $desc = if ($parts.Count -gt 1) { $parts[1] } else { $descRaw }
                    if ($idx -and $idx -ne 1) { $desc += " #$idx" }
                }
                catch {
                    $desc = "Unknown Device"
                }
            }

            $state = if ($ActivePnp -contains $relative) { "Valid" } else { "Ghosted" }

            $records += [PSCustomObject]@{
                BusName           = $BusName
                DeviceDescription = $desc
                ServiceType       = $service
                RegistryRelativeId= $relative
                State             = $state
            }
        }
    }

    return $records
}

$all = @()
$all += Scan-Bus -BusName "PCI" -ActivePnp $activePnpIds
$all += Scan-Bus -BusName "VMBUS" -ActivePnp $activePnpIds

if ($all.Count -eq 0) {
    $all = @([PSCustomObject]@{
        BusName = "N/A"
        DeviceDescription = "No NIC records found"
        ServiceType = "N/A"
        RegistryRelativeId = "N/A"
        State = "None"
    })
}

$ghosted = @($all | Where-Object { $_.State -eq "Ghosted" }).Count
$valid = @($all | Where-Object { $_.State -eq "Valid" }).Count

[PSCustomObject]@{
    HostName = $env:COMPUTERNAME
    GhostedNICs = $ghosted
    ValidNICs = $valid
    Records = $all
} | ConvertTo-Json -Depth 6
'@

if (-not (Test-Path -Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$summaryCsv = Join-Path -Path $OutputFolder -ChildPath "GhostNIC-AzRunCommand-Summary-$timestamp.csv"
$detailCsv = Join-Path -Path $OutputFolder -ChildPath "GhostNIC-AzRunCommand-Details-$timestamp.csv"
$errorCsv = Join-Path -Path $OutputFolder -ChildPath "GhostNIC-AzRunCommand-Errors-$timestamp.csv"

$summary = @()
$details = @()
$errors = @()

foreach ($entry in $vmList) {
    $vmName = [string]$entry.$VmNameColumn
    $rgName = [string]$entry.$ResourceGroupColumn

    if ([string]::IsNullOrWhiteSpace($vmName) -or [string]::IsNullOrWhiteSpace($rgName)) {
        $errors += [PSCustomObject]@{
            VMName = $vmName
            ResourceGroup = $rgName
            Status = "Skipped"
            Error = "Missing VM or ResourceGroup value in CSV"
        }
        continue
    }

    Write-Host "Scanning VM '$vmName' in RG '$rgName'..." -ForegroundColor Yellow

    try {
        $result = Invoke-AzVMRunCommand `
            -ResourceGroupName $rgName `
            -Name $vmName `
            -CommandId "RunPowerShellScript" `
            -ScriptString $remoteScript `
            -ErrorAction Stop

        $message = ($result.Value | Select-Object -First 1).Message
        if ([string]::IsNullOrWhiteSpace($message)) {
            throw "RunCommand returned empty output."
        }

        $jsonStart = $message.IndexOf("{")
        if ($jsonStart -lt 0) {
            throw "Could not find JSON payload in RunCommand output."
        }

        $json = $message.Substring($jsonStart)
        $parsed = $json | ConvertFrom-Json -Depth 10

        $summary += [PSCustomObject]@{
            VMName = $vmName
            ResourceGroup = $rgName
            HostName = $parsed.HostName
            GhostedNICs = $parsed.GhostedNICs
            ValidNICs = $parsed.ValidNICs
            EstimatedCleanupGuidance = if ([int]$parsed.GhostedNICs -ge 1000) {
                ">60 minutes"
            }
            elseif ([int]$parsed.GhostedNICs -ge 600) {
                "~30 minutes"
            }
            else {
                "Typically <30 minutes"
            }
        }

        foreach ($r in @($parsed.Records)) {
            $details += [PSCustomObject]@{
                VMName = $vmName
                ResourceGroup = $rgName
                HostName = $parsed.HostName
                BusName = $r.BusName
                DeviceDescription = $r.DeviceDescription
                ServiceType = $r.ServiceType
                RegistryRelativeId = $r.RegistryRelativeId
                State = $r.State
            }
        }

        Write-Host "Completed: $vmName" -ForegroundColor Green
    }
    catch {
        $errors += [PSCustomObject]@{
            VMName = $vmName
            ResourceGroup = $rgName
            Status = "Failed"
            Error = $_.Exception.Message
        }
        Write-Host "Failed: $vmName ($rgName): $($_.Exception.Message)" -ForegroundColor Red
    }

    if ($DelayBetweenVMsSeconds -gt 0) {
        Start-Sleep -Seconds $DelayBetweenVMsSeconds
    }
}

if ($summary.Count -gt 0) {
    $summary | Export-Csv -Path $summaryCsv -NoTypeInformation -Encoding UTF8
}

if ($details.Count -gt 0) {
    $details | Export-Csv -Path $detailCsv -NoTypeInformation -Encoding UTF8
}

if ($errors.Count -gt 0) {
    $errors | Export-Csv -Path $errorCsv -NoTypeInformation -Encoding UTF8
}

Write-Host "" 
Write-Host "Scan complete (read-only, no cleanup)." -ForegroundColor Cyan
Write-Host "Summary rows: $($summary.Count) | Detail rows: $($details.Count) | Errors: $($errors.Count)" -ForegroundColor Yellow

if ($summary.Count -gt 0) { Write-Host "Summary CSV: $summaryCsv" -ForegroundColor Green }
if ($details.Count -gt 0) { Write-Host "Detail CSV: $detailCsv" -ForegroundColor Green }
if ($errors.Count -gt 0) { Write-Host "Error CSV: $errorCsv" -ForegroundColor Yellow }
