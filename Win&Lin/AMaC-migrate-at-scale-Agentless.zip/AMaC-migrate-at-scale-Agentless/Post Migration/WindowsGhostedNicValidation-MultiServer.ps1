<#
NOTE: This script is detection-only and does NOT remove or modify NICs.
It is designed for production-safe assessment across multiple servers.

.SYNOPSIS
Scans multiple Windows servers for ghosted and valid NICs.

.DESCRIPTION
Runs the ghosted NIC detection logic remotely via PowerShell remoting
(Invoke-Command) and produces centralized reports:
- Summary CSV (per server counts)
- Detailed CSV (per NIC record)

.NOTES
- Author: Deepak Tyagi
- Requires WinRM/PowerShell remoting to target servers.
- Requires local administrator rights on target servers.
- No cleanup/removal operations are performed.

.EXAMPLE
.\WindowsGhostedNicValidation-MultiServer.ps1 -ComputerName "srv01","srv02"

.EXAMPLE
.\WindowsGhostedNicValidation-MultiServer.ps1 -CsvPath .\Metadata-File\ServerNames-Mig.csv -ComputerNameColumn VMName
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string[]]$ComputerName,

    [Parameter(Mandatory = $false)]
    [string]$CsvPath,

    [Parameter(Mandatory = $false)]
    [string]$ComputerNameColumn = "VMName",

    [Parameter(Mandatory = $false)]
    [int]$ThrottleLimit = 10,

    [Parameter(Mandatory = $false)]
    [System.Management.Automation.PSCredential]$Credential,

    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = ".\GhostNIC-Reports",

    [Parameter(Mandatory = $false)]
    [switch]$SkipConnectivityCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not $ComputerName -and -not $CsvPath) {
    throw "Provide either -ComputerName or -CsvPath."
}

$targets = @()

if ($ComputerName) {
    $targets += $ComputerName
}

if ($CsvPath) {
    if (-not (Test-Path -Path $CsvPath)) {
        throw "CSV file not found: $CsvPath"
    }

    $csvData = Import-Csv -Path $CsvPath
    if (-not ($csvData | Get-Member -Name $ComputerNameColumn -MemberType NoteProperty)) {
        throw "Column '$ComputerNameColumn' not found in CSV."
    }

    $targets += ($csvData | ForEach-Object { $_.$ComputerNameColumn })
}

$targets = @(
    $targets |
    Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
    ForEach-Object { $_.Trim() } |
    Select-Object -Unique
)

if ($targets.Count -eq 0) {
    throw "No target servers found after processing inputs."
}

if ($ThrottleLimit -lt 1) {
    $ThrottleLimit = 1
}

Write-Host "Total target servers: $($targets.Count)" -ForegroundColor Cyan

$reachable = @()
$unreachable = @()

if ($SkipConnectivityCheck) {
    $reachable = $targets
}
else {
    Write-Host "Checking WinRM connectivity..." -ForegroundColor Cyan
    foreach ($server in $targets) {
        try {
            Test-WSMan -ComputerName $server -ErrorAction Stop | Out-Null
            $reachable += $server
        }
        catch {
            $unreachable += [PSCustomObject]@{
                ComputerName = $server
                Status       = "Unreachable"
                Error        = $_.Exception.Message
            }
        }
    }
}

Write-Host "Reachable: $($reachable.Count) | Unreachable: $($unreachable.Count)" -ForegroundColor Yellow

$scanScript = {
    Set-StrictMode -Version Latest
    $ErrorActionPreference = "Stop"

    if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Script must run with administrator privileges on target server."
    }

    $allAdaptersPnPIDs = @()
    try {
        $allAdaptersPnPIDs = @(Get-NetAdapter -ErrorAction Stop | Select-Object -ExpandProperty PnpDeviceID)
    }
    catch {
        throw "Failed to get active NIC adapters: $($_.Exception.Message)"
    }

    function Scan-RegistryBus {
        param(
            [Parameter(Mandatory = $true)]
            [string]$BusName,
            [Parameter(Mandatory = $true)]
            [string[]]$ActivePnPIds
        )

        $records = @()
        $rootPath = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\"
        $registryPath = "$($rootPath.Replace("HKEY_LOCAL_MACHINE\\", "HKLM:\\"))$BusName"

        if (-not (Test-Path -Path $registryPath)) {
            return $records
        }

        $topItems = Get-ChildItem -Path $registryPath -Depth 0 -ErrorAction SilentlyContinue
        foreach ($top in $topItems) {
            $topPath = $top.Name.ToString().Replace("HKEY_LOCAL_MACHINE\\", "HKLM:\\")
            $childItems = Get-ChildItem -Path $topPath -Depth 0 -ErrorAction SilentlyContinue

            foreach ($entry in $childItems) {
                $entryPath = $entry.Name.ToString().Replace("HKEY_LOCAL_MACHINE\\", "HKLM:\\")
                $entryRelative = $entry.Name.ToString().Replace($rootPath, "")

                $serviceType = (Get-ItemProperty -Path $entryPath -Name Service -ErrorAction SilentlyContinue).Service
                $deviceDescRaw = (Get-ItemProperty -Path $entryPath -Name DeviceDesc -ErrorAction SilentlyContinue).DeviceDesc
                $instanceIndex = (Get-ItemProperty -Path "$entryPath\Device Parameters" -Name InstanceIndex -ErrorAction SilentlyContinue).InstanceIndex

                if (-not ($serviceType -in @("netvsc", "mlx5", "mlx4_bus"))) {
                    continue
                }

                $deviceDescription = "Unknown Device"
                if ($deviceDescRaw) {
                    try {
                        $parts = $deviceDescRaw -split ";"
                        if ($parts.Count -gt 1) {
                            $deviceDescription = $parts[1]
                        }
                        else {
                            $deviceDescription = $deviceDescRaw
                        }
                        if ($instanceIndex -and $instanceIndex -ne 1) {
                            $deviceDescription += " #$instanceIndex"
                        }
                    }
                    catch {
                        $deviceDescription = "Unknown Device"
                    }
                }

                $isValid = $ActivePnPIds -contains $entryRelative
                $state = if ($isValid) { "Valid" } else { "Ghosted" }

                $records += [PSCustomObject]@{
                    BusName            = $BusName
                    DeviceDescription  = $deviceDescription
                    ServiceType        = $serviceType
                    RegistryRelativeId = $entryRelative
                    State              = $state
                }
            }
        }

        return $records
    }

    $allRecords = @()
    $allRecords += Scan-RegistryBus -BusName "PCI" -ActivePnPIds $allAdaptersPnPIDs
    $allRecords += Scan-RegistryBus -BusName "VMBUS" -ActivePnPIds $allAdaptersPnPIDs

    if ($allRecords.Count -eq 0) {
        $allRecords = @([PSCustomObject]@{
            BusName            = "N/A"
            DeviceDescription  = "No NIC records found"
            ServiceType        = "N/A"
            RegistryRelativeId = "N/A"
            State              = "None"
        })
    }

    return $allRecords
}

$detailed = @()
$scanErrors = @()

if ($reachable.Count -gt 0) {
    Write-Host "Starting remote NIC scan (read-only)..." -ForegroundColor Cyan

    try {
        $invokeParams = @{
            ComputerName = $reachable
            ScriptBlock  = $scanScript
            ThrottleLimit = $ThrottleLimit
            ErrorAction  = "SilentlyContinue"
            ErrorVariable = "InvokeErr"
        }

        if ($Credential) {
            $invokeParams.Credential = $Credential
        }

        $remoteOutput = Invoke-Command @invokeParams

        if ($remoteOutput) {
            $detailed = $remoteOutput | Select-Object \
                @{Name = "ComputerName"; Expression = { $_.PSComputerName }}, \
                BusName, DeviceDescription, ServiceType, RegistryRelativeId, State
        }

        if ($InvokeErr) {
            foreach ($err in $InvokeErr) {
                $target = if ($err.TargetObject) { [string]$err.TargetObject } else { "Unknown" }
                $scanErrors += [PSCustomObject]@{
                    ComputerName = $target
                    Status       = "ScanFailed"
                    Error        = $err.Exception.Message
                }
            }
        }
    }
    catch {
        throw "Remote scan execution failed: $($_.Exception.Message)"
    }
}

if (-not (Test-Path -Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$detailedCsv = Join-Path -Path $OutputFolder -ChildPath "GhostNIC-Detailed-$timestamp.csv"
$summaryCsv = Join-Path -Path $OutputFolder -ChildPath "GhostNIC-Summary-$timestamp.csv"
$errorCsv = Join-Path -Path $OutputFolder -ChildPath "GhostNIC-Errors-$timestamp.csv"

$summary = @()
if ($detailed.Count -gt 0) {
    $summary = $detailed |
        Group-Object ComputerName |
        ForEach-Object {
            $ghosted = @($_.Group | Where-Object { $_.State -eq "Ghosted" }).Count
            $valid = @($_.Group | Where-Object { $_.State -eq "Valid" }).Count

            [PSCustomObject]@{
                ComputerName = $_.Name
                GhostedNICs  = $ghosted
                ValidNICs    = $valid
                EstimatedCleanupGuidance = if ($ghosted -ge 1000) {
                    ">60 minutes"
                }
                elseif ($ghosted -ge 600) {
                    "~30 minutes"
                }
                else {
                    "Typically <30 minutes"
                }
            }
        } |
        Sort-Object ComputerName
}

if ($detailed.Count -gt 0) {
    $detailed | Export-Csv -Path $detailedCsv -NoTypeInformation -Encoding UTF8
}

if ($summary.Count -gt 0) {
    $summary | Export-Csv -Path $summaryCsv -NoTypeInformation -Encoding UTF8
}

$allErrors = @()
$allErrors += $unreachable
$allErrors += $scanErrors
if ($allErrors.Count -gt 0) {
    $allErrors | Export-Csv -Path $errorCsv -NoTypeInformation -Encoding UTF8
}

Write-Host "" 
Write-Host "Scan complete (read-only)." -ForegroundColor Green
Write-Host "Targets total: $($targets.Count) | Reachable: $($reachable.Count) | Unreachable: $($unreachable.Count)" -ForegroundColor Cyan

if ($summary.Count -gt 0) {
    Write-Host "\nSummary:" -ForegroundColor Cyan
    $summary | Format-Table -AutoSize
    Write-Host "Summary CSV: $summaryCsv" -ForegroundColor Green
}

if ($detailed.Count -gt 0) {
    Write-Host "Detailed CSV: $detailedCsv" -ForegroundColor Green
}

if ($allErrors.Count -gt 0) {
    Write-Warning "Some servers were unreachable or failed scan. See: $errorCsv"
}
