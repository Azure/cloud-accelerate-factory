﻿# Path to your CSV
$vmList = Import-Csv "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Discover subscriptions once and search VMs across tenant.
$allSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
Write-Host "Found $($allSubscriptions.Count) enabled subscription(s) in tenant." -ForegroundColor Cyan

$vmSearchCache = @{}

function Get-DiskTierLabel {
    param([string]$StorageAccountType)

    if ([string]::IsNullOrWhiteSpace($StorageAccountType)) {
        return 'N/A'
    }

    if ($StorageAccountType -match '^Premium') { return 'Premium' }
    if ($StorageAccountType -match '^Standard') { return 'Standard' }
    if ($StorageAccountType -match '^Ultra') { return 'Ultra' }
    return 'Other'
}

function Find-AzVMCrossSubscription {
    param(
        [Parameter(Mandatory)][string]$VMName,
        [string]$ResourceGroup,
        [Parameter(Mandatory)][array]$Subscriptions,
        [Parameter(Mandatory)][hashtable]$Cache
    )

    $cacheKey = if ([string]::IsNullOrWhiteSpace($ResourceGroup)) {
        $VMName.ToLowerInvariant()
    }
    else {
        "$($VMName.ToLowerInvariant())|$($ResourceGroup.ToLowerInvariant())"
    }

    if ($Cache.ContainsKey($cacheKey)) {
        return $Cache[$cacheKey]
    }

    foreach ($sub in $Subscriptions) {
        try {
            Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null

            $vm = if ([string]::IsNullOrWhiteSpace($ResourceGroup)) {
                Get-AzVM -Name $VMName -ErrorAction SilentlyContinue
            }
            else {
                Get-AzVM -Name $VMName -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
            }

            if ($vm) {
                $found = [PSCustomObject]@{
                    VM               = $vm
                    SubscriptionName = $sub.Name
                }
                $Cache[$cacheKey] = $found
                return $found
            }
        }
        catch {
            continue
        }
    }

    return $null
}

$result = foreach ($entry in $vmList) {
    $vmName = $entry.VMName
    $rgName = $entry.ResourceGroup

    # Find VM across all enabled subscriptions in tenant.
    $foundVm = Find-AzVMCrossSubscription -VMName $vmName -ResourceGroup $rgName -Subscriptions $allSubscriptions -Cache $vmSearchCache
    if (-not $foundVm) {
        Write-Warning "VM '$vmName' not found."
        continue
    }

    $vm = $foundVm.VM

    # Total Disk Count (OS + Data Disks)
    $totalDiskCount = 1 + $vm.StorageProfile.DataDisks.Count

    # Disk Types
    $osDiskType = $vm.StorageProfile.OsDisk.ManagedDisk.StorageAccountType
    $osDiskTier = Get-DiskTierLabel -StorageAccountType $osDiskType

    $dataDiskTypeValues = @($vm.StorageProfile.DataDisks | ForEach-Object { $_.ManagedDisk.StorageAccountType })
    $dataDiskTypes = if ($vm.StorageProfile.DataDisks.Count -gt 0) {
        $dataDiskTypeValues -join ', '
    }
    else {
        'N/A'
    }

    $dataDiskTiers = if ($vm.StorageProfile.DataDisks.Count -gt 0) {
        ($dataDiskTypeValues | ForEach-Object { Get-DiskTierLabel -StorageAccountType $_ } | Select-Object -Unique) -join ', '
    }
    else {
        'N/A'
    }

    # Get NICs
    $nics = $vm.NetworkProfile.NetworkInterfaces

    foreach ($nicRef in $nics) {
        $nic = Get-AzNetworkInterface -ResourceId $nicRef.Id

        foreach ($ipConfig in $nic.IpConfigurations) {

            # Private IP + Static/Dynamic
            $privateIp = $ipConfig.PrivateIpAddress
            $privateAllocation = $ipConfig.PrivateIpAllocationMethod

            # Public IP (if exists)
            $publicIp = $null
            if ($ipConfig.PublicIpAddress) {
                $publicIpObj = Get-AzPublicIpAddress -ResourceId $ipConfig.PublicIpAddress.Id
                $publicIp = $publicIpObj.IpAddress
            }

            # Output object
            [PSCustomObject]@{
                VMName               = $vm.Name
                ResourceGroup        = $vm.ResourceGroupName
                SubscriptionName     = $foundVm.SubscriptionName
                PrivateIP            = $privateIp
                PrivateIPAllocation  = $privateAllocation
                NICName              = $nic.Name
                PublicIP             = $publicIp
                TotalDiskCount       = $totalDiskCount
                OSDiskType           = $osDiskType
                OSDiskTier           = $osDiskTier
                DataDiskTypes        = $dataDiskTypes
                DataDiskTiers        = $dataDiskTiers
            }
        }
    }
}

# Display output
$result | Format-Table -AutoSize

# Optional: export to CSV
# $result | Export-Csv "C:\Path\vm-report.csv" -NoTypeInformation
