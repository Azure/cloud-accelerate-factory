<#
.SYNOPSIS
    Generates a detailed Azure Migrate VM report including NIC, VNet, and Subnet details.

.DESCRIPTION
    This script retrieves all replicating VMs from a specified Azure Migrate project
    and exports detailed information such as Machine Name, Migration State,
    Target VM Size, Target Region, Target Resource Group, Target VNet, Target Subnet,
    and NIC details including IP addresses.

.EXAMPLE
    .\AzureMigrate_VM_Report.ps1
    Generates the report for the configured project and outputs it to the specified CSV file.

.INPUTS
    None. The script uses the Azure context of the logged-in user.

.OUTPUTS
    CSV file containing the detailed VM, VNet, Subnet, and NIC report.

.NOTES
    Author: Deepak Tyagi
    Date: 21.11.2025
    Requires Azure PowerShell module: Az.Migrate

.COMPONENT
    Azure Migrate PowerShell automation

.ROLE
    Cloud Administrator / Migration Engineer

.FUNCTIONALITY
    Extracts detailed VM, VNet, Subnet, and NIC properties from Azure Migrate replication items
    for reporting and analysis purposes.
#>

############ CONFIG ############
$ProjectRG              = "RG-AM-CUS-Prod-AzureMigrateCUS"
$ProjectName            = "Azuremigrate-AM-CUS-VMwareEOL"
$OutputCsv              = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\AzureMigrateReport.csv"
################################

Import-Module Az.Accounts
Import-Module Az.Migrate
Import-Module Az.Resources  # Only for Get-AzSubscription

# Get all replicating VMs
$replicatingVMs = Get-AzMigrateServerReplication -ResourceGroupName $ProjectRG -ProjectName $ProjectName         

$allNicData = @()

foreach ($vm in $replicatingVMs) {
    $vmDetail = Get-AzMigrateServerReplication -TargetObjectID $vm.Id
    $ps = $vmDetail.ProviderSpecificDetail

    # Extract Target Resource Group
    $TargetResourceGroup = ""
    if ($ps.TargetResourceGroupId -and $ps.TargetResourceGroupId -match "/resourceGroups/([^/]+)") {
        $TargetResourceGroup = $Matches[1]
    }

    # Extract Target VNet
    $TargetVNet = ""
    if ($ps.TargetNetworkId -and $ps.TargetNetworkId -match "/virtualNetworks/([^/]+)") {
        $TargetVNet = $Matches[1]
    }

    # ========== TARGET SUBSCRIPTION ONLY ==========
    $TargetSubscriptionId = ""
    $TargetSubName = "Unknown"
    
    if ($ps.TargetResourceGroupId -and $ps.TargetResourceGroupId -match "/subscriptions/([^/]+)/resourceGroups/") {
        $TargetSubscriptionId = $Matches[1]
        try {
            $TargetSubDetails = Get-AzSubscription -SubscriptionId $TargetSubscriptionId -ErrorAction SilentlyContinue
            $TargetSubName = if ($TargetSubDetails) { $TargetSubDetails.Name } else { "Not Accessible" }
        }
        catch {
            $TargetSubName = "Access Denied"
        }
    }
    # ==============================================

    if ($ps.VMNic.Count -gt 0) {
        foreach ($nic in $ps.VMNic) {
            $TargetSubnet = if ($nic.PSObject.Properties.Match("TargetSubnetName") -and $nic.TargetSubnetName) { $nic.TargetSubnetName } else { "Not Configured" }
            $TestSubnet = if ($nic.TestSubnetName) { $nic.TestSubnetName } else { "Not Configured" }

            $allNicData += [PSCustomObject]@{
                MachineName        = $vm.MachineName
                TargetSubscription = $TargetSubName      
                TargetSubId        = $TargetSubscriptionId 
                MigrationState     = $vmDetail.MigrationState
                TargetRegion       = $ps.TargetLocation
                TargetResourceGroup= $TargetResourceGroup
                TargetVNet         = $TargetVNet
                TargetSubnet       = $TargetSubnet
                TargetVMSize       = $ps.TargetVMSize
                TargetIPAddress    = $nic.TargetIPAddress
                SourceIPAddress    = $nic.SourceIPAddress
                TargetIPType       = $nic.TargetIPAddressType
                TestSubnet         = $TestSubnet
                IsPrimaryNic       = $nic.IsPrimaryNic
                TFOState           = $vm.LastTestMigrationStatus
                TFOCleanUPStatus   = $vm.TestMigrateStateDescription
            }
        }
    } else {
        $allNicData += [PSCustomObject]@{
            MachineName        = $vm.MachineName
            TargetSubscription = $TargetSubName      # ✅ ADDED
            TargetSubId        = $TargetSubscriptionId  # ✅ ADDED
            MigrationState     = $vmDetail.MigrationState
            TargetRegion       = $ps.TargetLocation
            TargetResourceGroup= $TargetResourceGroup
            TargetVNet         = $TargetVNet
            TargetSubnet       = "No NIC"
            TargetVMSize       = $ps.TargetVMSize
            TargetIPAddress    = ""
            SourceIPAddress    = ""
            IsPrimaryNic       = "No NIC"
            TargetIPType       = ""
            TestSubnet         = $TestSubnet
            TFOState           = $vm.LastTestMigrationStatus
            TFOCleanUPStatus   = $vm.TestMigrateStateDescription
        }
    }
}

$allNicData | Export-Csv -Path $OutputCsv -NoTypeInformation
Write-Host "Export complete: $OutputCsv (with TargetSubscription column)" -ForegroundColor Green
