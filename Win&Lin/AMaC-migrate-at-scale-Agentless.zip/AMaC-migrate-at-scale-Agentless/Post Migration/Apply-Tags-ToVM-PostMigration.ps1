param(
    [string]$CsvPath = "c:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\VM-Tags.csv"
)
# Import CSV data
$vmData = Import-Csv $CsvPath
Write-Host "Total VM rows in CSV: $($vmData.Count)" -ForegroundColor Cyan

$vmIndex = 0
foreach ($row in $vmData) {
    $vmIndex++
    $vmName = $row.VMName
    $rgName = $row.ResourceGroupName
    if (-not $vmName -or -not $rgName) {
        Write-Host "Row $vmIndex - Skipped (blank VMName or ResourceGroupName)" -ForegroundColor Yellow
        continue
    }
    Write-Host "`n[$vmIndex/$($vmData.Count)] Processing: $vmName" -ForegroundColor Yellow

    # Build tags hashtable from all columns except VMName and ResourceGroupName
    $tags = @{}
    $skipColumns = @('VMName', 'ResourceGroupName')
    foreach ($prop in $row.PSObject.Properties) {
        if ($prop.Name -notin $skipColumns -and -not [string]::IsNullOrWhiteSpace($prop.Value)) {
            $tags[$prop.Name] = $prop.Value
        }
    }

    if ($tags.Count -eq 0) {
        Write-Host "No tags for $vmName" -ForegroundColor Yellow
        continue
    }

    try {
        $vm = Get-AzVM -Name $vmName -ResourceGroupName $rgName -ErrorAction Stop
        Write-Host "Processing $vmName in $rgName" -ForegroundColor Cyan

        # Collect all resource IDs to tag
        $resourceIds = @($vm.Id)

        # OS Disk
        if ($vm.StorageProfile.OsDisk.ManagedDisk.Id) {
            $resourceIds += $vm.StorageProfile.OsDisk.ManagedDisk.Id
        }

        # Data Disks
        foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
            if ($dataDisk.ManagedDisk.Id) {
                $resourceIds += $dataDisk.ManagedDisk.Id
            }
        }

        # NICs and associated Public IPs
        foreach ($nicRef in $vm.NetworkProfile.NetworkInterfaces) {
            $resourceIds += $nicRef.Id
            $nic = Get-AzNetworkInterface -ResourceId $nicRef.Id -ErrorAction SilentlyContinue
            if ($nic) {
                foreach ($ipConfig in $nic.IpConfigurations) {
                    if ($ipConfig.PublicIpAddress.Id) {
                        $resourceIds += $ipConfig.PublicIpAddress.Id
                    }
                }
            }
        }

        # Apply tags to all resources
        foreach ($resId in $resourceIds) {
            $resName = $resId.Split('/')[-1]
            try {
                Update-AzTag -ResourceId $resId -Tag $tags -Operation Merge -ErrorAction Stop
                Write-Host "  Tags applied to: $resName" -ForegroundColor Green
            }
            catch {
                Write-Host "  Failed to tag: $resName - $($_.Exception.Message)" -ForegroundColor Red
            }
        }
    }
    catch {
        Write-Host "Failed for $vmName`: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "Completed processing CSV file." -ForegroundColor Green
