﻿############ CONFIG ############
$ProjectRG   = "RG-AM-CUS-Prod-AzureMigrateCUS"
$ProjectName = "Azuremigrate-AM-CUS-VMwareEOL"

#$ProjectRG   = "RG-AM-EastUS-NonProd-AZMigrate2"
#$ProjectName = "AzmigVMEOLSAPxtra"

$OutputCsv   = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\AzureMigrateReport.csv"
$ServerCsv   = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"
################################

# Import server list
$ServerList = Import-Csv $ServerCsv

$allNicData = @()

foreach ($server in $ServerList) {

    Write-Host "Processing $($server.VMName)" -ForegroundColor Cyan

    # Get replication item for specific server
    $vm = Get-AzMigrateServerReplication `
        -ResourceGroupName $ProjectRG `
        -ProjectName $ProjectName `
        -MachineName $server.VMName`
        -ErrorAction SilentlyContinue

    if (-not $vm) {
        Write-Warning "Server not found in Azure Migrate: $($server.VMName)"
        continue
    }

    $vmDetail = Get-AzMigrateServerReplication -TargetObjectID $vm.Id
    $ps = $vmDetail.ProviderSpecificDetail

    # Extract Subscription 
    $TargetSubscriptionId = ""
    $TargetSubName = "Unknown"
    
    if ($ps.TargetResourceGroupId -and $ps.TargetResourceGroupId -match "/subscriptions/([^/]+)/resourceGroups/") {
        $TargetSubscriptionId = $Matches[1]
        try {
            $TargetSubDetails = Get-AzSubscription -SubscriptionId $TargetSubscriptionId -ErrorAction SilentlyContinue
            $TargetSubName = if ($TargetSubDetails) { $TargetSubDetails.Name } else { "Not Accessible" }
        }
        catch {
            $TargetSubName = "Access Denied"
        }
    }


    # Extract Target Resource Group
    $TargetResourceGroup = ""
    if ($ps.TargetResourceGroupId -match "/resourceGroups/([^/]+)") {
        $TargetResourceGroup = $Matches[1]
    }

    # Extract Target VNet
    $TargetVNet = ""
    if ($ps.TargetNetworkId -match "/virtualNetworks/([^/]+)") {
        $TargetVNet = $Matches[1]
    }

    if ($ps.VMNic.Count -gt 0) {
        foreach ($nic in $ps.VMNic) {

            $TargetSubnet = if ($nic.TargetSubnetName) { $nic.TargetSubnetName } else { "Not Configured" }
            $TestSubnet   = if ($nic.TestSubnetName)   { $nic.TestSubnetName }   else { "Not Configured" }

            $allNicData += [PSCustomObject]@{
                MachineName         = $vm.MachineName
                MigrationState      = $vmDetail.MigrationState
                TargetSubscription = $TargetSubName 
                TargetRegion        = $ps.TargetLocation
                TargetResourceGroup = $TargetResourceGroup
                TargetVNet          = $TargetVNet
                TargetSubnet        = $TargetSubnet
                TargetVMSize        = $ps.TargetVMSize
                TargetIPAddress     = $nic.TargetIPAddress
                SourceIPAddress     = $nic.SourceIPAddress
                TargetIPType        = $nic.TargetIPAddressType
                TestSubnet          = $TestSubnet
                IsPrimaryNic        = $nic.IsPrimaryNic
                TFOState            = $vm.LastTestMigrationStatus
                TFOCleanUPStatus    = $vm.TestMigrateStateDescription
            }
        }
    }
    else {
        $allNicData += [PSCustomObject]@{
            MachineName         = $vm.MachineName
            MigrationState      = $vmDetail.MigrationState
            TargetSubscription = $TargetSubName 
            TargetRegion        = $ps.TargetLocation
            TargetResourceGroup = $TargetResourceGroup
            TargetVNet          = $TargetVNet
            TargetSubnet        = "No NIC"
            TargetVMSize        = $ps.TargetVMSize
            TargetIPAddress     = ""
            SourceIPAddress     = ""
            TargetIPType        = ""
            TestSubnet          = "N/A"
            IsPrimaryNic        = "No NIC"
            TFOState            = $vm.LastTestMigrationStatus
            TFOCleanUPStatus    = $vm.TestMigrateStateDescription
        }
    }
}

# Export result
$allNicData | Export-Csv -Path $OutputCsv -NoTypeInformation
Write-Host "Export complete: $OutputCsv" -ForegroundColor Green
