<#
.SYNOPSIS
    Enables Accelerated Networking on Azure VM NICs in parallel using CSV input.
    Requires PowerShell 7.x and Az modules.

.DESCRIPTION
    Phase 1: Enables AccelNet on ALL NICs without stopping VMs (parallel, throttled)
    Phase 2: Safely reboots all successfully updated VMs (parallel, throttled)
    - Reports success/failure/skipped with failure reason

.NOTES
    CSV columns: VMName, ResourceGroup
#>

# ===================== USER CONFIG =====================
$CsvPath     = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"
$MaxParallel = 10

# ===================== VALIDATE CSV =====================
if (-not (Test-Path $CsvPath)) {
    Write-Host "CSV file not found: $CsvPath" -ForegroundColor Red
    exit
}

$servers = Import-Csv $CsvPath | Where-Object { -not [string]::IsNullOrWhiteSpace($_.VMName) }
Write-Host "Loaded $($servers.Count) VMs from CSV" -ForegroundColor Cyan

# ===================== TRACKING =====================
$jobs = @()
$results = [System.Collections.ArrayList]::new()

# ===================== STATUS DISPLAY =====================
function Show-Status {
    param($serverStatus)
    Write-Host "`n=== Accelerated Networking - Job Status ===" -ForegroundColor Yellow
    foreach ($key in $serverStatus.Keys | Sort-Object) {
        $entry = $serverStatus[$key]
        $color = switch ($entry.Status) {
            "Running"  { "Cyan" }
            "Success"  { "Green" }
            "Skipped"  { "Magenta" }
            "Failed"   { "Red" }
            default    { "Yellow" }
        }
        $line = "{0,-35} : {1}" -f $key, $entry.Status
        if ($entry.Reason) { $line += " - $($entry.Reason)" }
        Write-Host $line -ForegroundColor $color
    }
    Write-Host "============================================`n"
}

$serverStatus = @{}
foreach ($s in $servers) { $serverStatus[$s.VMName.Trim()] = @{ Status = "Pending"; Reason = "" } }

# ===================== PROCESS COMPLETED JOBS =====================
function Process-CompletedJobs {
    param([ref]$jobList, $serverStatus, $results)

    $finished = $jobList.Value | Where-Object { $_.State -ne 'Running' }
    foreach ($job in $finished) {
        $output = Receive-Job -Job $job -ErrorAction SilentlyContinue
        $result = $output | Where-Object { $_ -is [hashtable] -and $_.ContainsKey("Status") } | Select-Object -Last 1

        if ($result) {
            $serverStatus[$job.Name] = @{ Status = $result.Status; Reason = $result.Reason }
            $null = $results.Add([PSCustomObject]@{
                VMName        = $job.Name
                Status        = $result.Status
                Reason        = $result.Reason
                NICsProcessed = $result.NICsProcessed
            })
        }
        else {
            $serverStatus[$job.Name] = @{ Status = "Failed"; Reason = "No output from job" }
            $null = $results.Add([PSCustomObject]@{
                VMName        = $job.Name
                Status        = "Failed"
                Reason        = "No output from job"
                NICsProcessed = 0
            })
        }

        Remove-Job -Job $job
        $jobList.Value = $jobList.Value | Where-Object { $_.Id -ne $job.Id }
    }
}

# ===================== MAIN LOOP =====================
foreach ($server in $servers) {
    $vmName = $server.VMName.Trim()
    $rgName = $server.ResourceGroup.Trim()

    # Throttle: wait if max parallel reached
    while (($jobs | Where-Object { $_.State -eq 'Running' }).Count -ge $MaxParallel) {
        Start-Sleep -Seconds 2
        Process-CompletedJobs -jobList ([ref]$jobs) -serverStatus $serverStatus -results $results
        foreach ($j in $jobs | Where-Object { $_.State -eq 'Running' }) {
            $serverStatus[$j.Name] = @{ Status = "Running"; Reason = "" }
        }
        Show-Status $serverStatus
    }

    # Start parallel job
    $serverStatus[$vmName] = @{ Status = "Running"; Reason = "" }
    Show-Status $serverStatus

    $jobs += Start-Job -Name $vmName -ScriptBlock {
        param($vmName, $rgName)

        try {
            # Get VM
            $vm = Get-AzVM -Name $vmName -ResourceGroupName $rgName -ErrorAction Stop

            # Get all NICs
            $nicRefs = $vm.NetworkProfile.NetworkInterfaces
            if (-not $nicRefs -or $nicRefs.Count -eq 0) {
                return @{ Status = "Failed"; Reason = "No NICs found on VM"; NICsProcessed = 0 }
            }

            # Check if all NICs already have AccelNet enabled
            $nicsToUpdate = @()
            foreach ($nicRef in $nicRefs) {
                $nicName = $nicRef.Id.Split("/")[-1]
                $nic = Get-AzNetworkInterface -Name $nicName -ResourceGroupName $rgName -ErrorAction Stop
                if ($nic.EnableAcceleratedNetworking -ne $true) {
                    $nicsToUpdate += $nic
                }
            }

            if ($nicsToUpdate.Count -eq 0) {
                return @{ Status = "Skipped"; Reason = "Already enabled on all $($nicRefs.Count) NIC(s)"; NICsProcessed = 0 }
            }

            # Check VM size supports Accelerated Networking
            $vmSize = $vm.HardwareProfile.VmSize
            $sizeInfo = Get-AzVMSize -ResourceGroupName $rgName -VMName $vmName | Where-Object { $_.Name -eq $vmSize }
            if ($sizeInfo -and $sizeInfo.NumberOfCores -lt 2) {
                return @{ Status = "Failed"; Reason = "VM size '$vmSize' (< 2 cores) may not support AccelNet"; NICsProcessed = 0 }
            }

            # Enable AccelNet on each NIC
            $updatedCount = 0
            foreach ($nic in $nicsToUpdate) {
                $nic.EnableAcceleratedNetworking = $true
                Set-AzNetworkInterface -NetworkInterface $nic -ErrorAction Stop | Out-Null
                $updatedCount++
            }

            return @{ Status = "Success"; Reason = "Enabled on $updatedCount NIC(s)"; NICsProcessed = $updatedCount }
        }
        catch {
            return @{ Status = "Failed"; Reason = $_.Exception.Message; NICsProcessed = 0 }
        }
    } -ArgumentList $vmName, $rgName
}

# ===================== WAIT FOR REMAINING JOBS =====================
while ($jobs.Count -gt 0) {
    Start-Sleep -Seconds 2
    Process-CompletedJobs -jobList ([ref]$jobs) -serverStatus $serverStatus -results $results
    foreach ($j in $jobs | Where-Object { $_.State -eq 'Running' }) {
        $serverStatus[$j.Name] = @{ Status = "Running"; Reason = "" }
    }
    Show-Status $serverStatus
}

# ===================== PHASE 1 SUMMARY =====================
Write-Host "`n=============== PHASE 1 SUMMARY - AccelNet Enable ===============" -ForegroundColor Yellow
$results | Sort-Object VMName | Format-Table VMName, Status, NICsProcessed, Reason -AutoSize

$success = ($results | Where-Object { $_.Status -eq "Success" }).Count
$skipped = ($results | Where-Object { $_.Status -eq "Skipped" }).Count
$failed  = ($results | Where-Object { $_.Status -eq "Failed" }).Count

Write-Host "Total: $($results.Count) | Success: $success | Skipped: $skipped | Failed: $failed" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Yellow

# ===================== PHASE 2: SAFE VM REBOOT =====================
$vmsToReboot = $results | Where-Object { $_.Status -eq "Success" }

if ($vmsToReboot.Count -eq 0) {
    Write-Host "`nNo VMs need to be rebooted. All were either skipped or failed." -ForegroundColor Yellow
}
else {
    Write-Host "`n=============== PHASE 2 - Rebooting $($vmsToReboot.Count) VM(s) Safely ===============" -ForegroundColor Cyan

    $startJobs = @()
    $startResults = [System.Collections.ArrayList]::new()
    $startStatus = @{}
    foreach ($v in $vmsToReboot) { $startStatus[$v.VMName] = @{ Status = "Pending"; Reason = "" } }

    foreach ($vm in $vmsToReboot) {
        $vmName = $vm.VMName
        $rgName = ($servers | Where-Object { $_.VMName.Trim() -eq $vmName }).ResourceGroup.Trim()

        # Throttle
        while (($startJobs | Where-Object { $_.State -eq 'Running' }).Count -ge $MaxParallel) {
            Start-Sleep -Seconds 2
            $finished = $startJobs | Where-Object { $_.State -ne 'Running' }
            foreach ($job in $finished) {
                $output = Receive-Job -Job $job -ErrorAction SilentlyContinue
                $res = $output | Where-Object { $_ -is [hashtable] -and $_.ContainsKey("Status") } | Select-Object -Last 1
                if ($res) {
                    $startStatus[$job.Name] = @{ Status = $res.Status; Reason = $res.Reason }
                    $null = $startResults.Add([PSCustomObject]@{ VMName = $job.Name; Status = $res.Status; Reason = $res.Reason })
                } else {
                    $startStatus[$job.Name] = @{ Status = "Failed"; Reason = "No output from start job" }
                    $null = $startResults.Add([PSCustomObject]@{ VMName = $job.Name; Status = "Failed"; Reason = "No output from start job" })
                }
                Remove-Job -Job $job
                $startJobs = $startJobs | Where-Object { $_.Id -ne $job.Id }
            }
        }

        $startStatus[$vmName] = @{ Status = "Rebooting"; Reason = "" }
        Write-Host "  Rebooting VM: $vmName ..." -ForegroundColor Cyan

        $startJobs += Start-Job -Name $vmName -ScriptBlock {
            param($vmName, $rgName)
            try {
                Restart-AzVM -Name $vmName -ResourceGroupName $rgName -ErrorAction Stop | Out-Null
                return @{ Status = "Rebooted"; Reason = "VM rebooted successfully" }
            }
            catch {
                return @{ Status = "Failed"; Reason = $_.Exception.Message }
            }
        } -ArgumentList $vmName, $rgName
    }

    # Wait for remaining start jobs
    while ($startJobs.Count -gt 0) {
        Start-Sleep -Seconds 2
        $finished = $startJobs | Where-Object { $_.State -ne 'Running' }
        foreach ($job in $finished) {
            $output = Receive-Job -Job $job -ErrorAction SilentlyContinue
            $res = $output | Where-Object { $_ -is [hashtable] -and $_.ContainsKey("Status") } | Select-Object -Last 1
            if ($res) {
                $startStatus[$job.Name] = @{ Status = $res.Status; Reason = $res.Reason }
                $null = $startResults.Add([PSCustomObject]@{ VMName = $job.Name; Status = $res.Status; Reason = $res.Reason })
            } else {
                $startStatus[$job.Name] = @{ Status = "Failed"; Reason = "No output from start job" }
                $null = $startResults.Add([PSCustomObject]@{ VMName = $job.Name; Status = "Failed"; Reason = "No output from start job" })
            }
            Remove-Job -Job $job
            $startJobs = $startJobs | Where-Object { $_.Id -ne $job.Id }
        }
    }

    # Phase 2 Summary
    Write-Host "`n=============== PHASE 2 SUMMARY - VM Reboot ===============" -ForegroundColor Yellow
    $startResults | Sort-Object VMName | Format-Table VMName, Status, Reason -AutoSize

    $rebooted = ($startResults | Where-Object { $_.Status -eq "Rebooted" }).Count
    $rebootFailed = ($startResults | Where-Object { $_.Status -eq "Failed" }).Count
    Write-Host "Total: $($startResults.Count) | Rebooted: $rebooted | Failed: $rebootFailed" -ForegroundColor Cyan
    Write-Host "=============================================================" -ForegroundColor Yellow
}

# ===================== FINAL SUMMARY =====================
Write-Host "`n=============== FINAL OVERALL SUMMARY ===============" -ForegroundColor Yellow
Write-Host "Phase 1 (AccelNet Enable): Success=$success | Skipped=$skipped | Failed=$failed" -ForegroundColor Cyan
if ($vmsToReboot.Count -gt 0) {
    Write-Host "Phase 2 (VM Reboot):       Rebooted=$rebooted | Failed=$rebootFailed" -ForegroundColor Cyan
}
Write-Host "=====================================================" -ForegroundColor Yellow
