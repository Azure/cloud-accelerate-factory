﻿<#
.SYNOPSIS
    Retrieves the Azure VM Agent (waagent) status for multiple VMs listed in a CSV.

.DESCRIPTION
    This script reads VM names from a CSV file, dynamically determines their Resource Group,
    and fetches the Azure VM Agent version, status, and message for each VM.
    Useful for auditing VM agent health across multiple VMs in a subscription.

.EXAMPLE
    .\Get-AzVMAgentStatus.ps1 -CsvPath "C:\Temp\vm-list.csv"
    Retrieves the agent status for all VMs listed in the CSV and displays results in the console.

.EXAMPLE
    .\Get-AzVMAgentStatus.ps1 -CsvPath "C:\Temp\vm-list.csv" | Export-Csv "C:\Temp\AgentStatusReport.csv" -NoTypeInformation
    Retrieves agent status and exports the results to a CSV file for further reporting.

.INPUTS
    CSV file containing VM names (mandatory column: VMName).

.OUTPUTS
    Table or CSV of VMName, ResourceGroup, AgentVersion, Status, and Message.

.NOTES
    - Requires Az module installed and logged in to Azure.
    - If a VM does not exist or the agent is missing, the output will indicate an error.
    - The script dynamically discovers the Resource Group for each VM based on its name.

.COMPONENT
    Azure Virtual Machines / Azure VM Agent Health Monitoring

.ROLE
    Cloud Administrator / Azure Operations / IT Operations

.FUNCTIONALITY
    VM Health Audit, Azure VM Agent Monitoring, Compliance Reporting

.AUTHOR
    Name : Deepak
    Version : v.01
#>




# Path to your CSV with VM names only
$csvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# ===================== AUTHENTICATE =====================
Write-Host "Authenticating to Azure..." -ForegroundColor Cyan
#Connect-AzAccount -ErrorAction Stop | Out-Null

# ===================== DISCOVER ALL SUBSCRIPTIONS =====================
$allSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
$currentContext   = Get-AzContext
Write-Host "Connected tenant : $($currentContext.Tenant.Id)" -ForegroundColor Cyan
Write-Host "Subscriptions    : $($allSubscriptions.Count) enabled" -ForegroundColor Cyan

# ===================== HELPER — find VM across all subscriptions =====================
function Find-AzVMCrossSub {
    param(
        [Parameter(Mandatory)]
        [string]$VmName,
        [string]$ResourceGroup,
        [Parameter(Mandatory)]
        [array]$Subscriptions
    )

    foreach ($sub in $Subscriptions) {
        try {
            Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null
        }
        catch { continue }

        if (-not [string]::IsNullOrWhiteSpace($ResourceGroup)) {
            $found = Get-AzVM -Name $VmName -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
        }
        else {
            $found = Get-AzVM -Name $VmName -ErrorAction SilentlyContinue
        }

        if ($found) {
            return [PSCustomObject]@{ VM = $found; SubscriptionId = $sub.Id; SubscriptionName = $sub.Name }
        }
    }

    return $null
}

# ===================== MAIN =====================
$vmList = Import-Csv -Path $csvPath
Write-Host "Loaded $($vmList.Count) VM(s) from CSV`n" -ForegroundColor Green

$results = foreach ($vm in $vmList) {
    $vmName = ([string]$vm.VMName).Trim()
    $csvRg  = if ($null -ne $vm.ResourceGroup) { ([string]$vm.ResourceGroup).Trim() } else { '' }

    if ([string]::IsNullOrWhiteSpace($vmName)) { continue }

    try {
        $match = Find-AzVMCrossSub -VmName $vmName -ResourceGroup $csvRg -Subscriptions $allSubscriptions

        if (-not $match) {
            [PSCustomObject]@{
                VMName           = $vmName
                ResourceGroup    = $csvRg
                SubscriptionName = ''
                AgentVersion     = 'N/A'
                Status           = 'NotFound'
                Message          = 'VM not found across all enabled subscriptions'
            }
            continue
        }

        # Get full status object (requires explicit RG + Name)
        $vmObj      = Get-AzVM -ResourceGroupName $match.VM.ResourceGroupName -Name $vmName -Status -ErrorAction Stop
        $agentStatus = $vmObj.VMAgent.Statuses

        [PSCustomObject]@{
            VMName           = $vmObj.Name
            ResourceGroup    = $match.VM.ResourceGroupName
            SubscriptionName = $match.SubscriptionName
            AgentVersion     = $vmObj.VMAgent.VmAgentVersion
            Status           = ($agentStatus | Select-Object -ExpandProperty DisplayStatus) -join '; '
            Message          = ($agentStatus | Select-Object -ExpandProperty Message) -join '; '
        }
    }
    catch {
        [PSCustomObject]@{
            VMName           = $vmName
            ResourceGroup    = $csvRg
            SubscriptionName = ''
            AgentVersion     = 'N/A'
            Status           = 'Error'
            Message          = $_.Exception.Message
        }
    }
}

# ===================== OUTPUT =====================
$col = @{ VMName = 30; ResourceGroup = 35; SubscriptionName = 35; AgentVersion = 18; Status = 20 }

Write-Host (
    'VMName'.PadRight($col.VMName) +
    'ResourceGroup'.PadRight($col.ResourceGroup) +
    'SubscriptionName'.PadRight($col.SubscriptionName) +
    'AgentVersion'.PadRight($col.AgentVersion) +
    'Status'
) -ForegroundColor White
Write-Host ('-' * 145) -ForegroundColor DarkGray

foreach ($r in $results) {
    $statusColor = switch -Wildcard ($r.Status) {
        'Ready*'    { 'Green' }
        'NotReady*' { 'Red' }
        'NotFound'  { 'DarkYellow' }
        'Error'     { 'Red' }
        default     { 'Yellow' }
    }
    Write-Host $r.VMName.PadRight($col.VMName)           -NoNewline -ForegroundColor Cyan
    Write-Host $r.ResourceGroup.PadRight($col.ResourceGroup) -NoNewline -ForegroundColor Gray
    Write-Host $r.SubscriptionName.PadRight($col.SubscriptionName) -NoNewline -ForegroundColor Gray
    Write-Host $r.AgentVersion.PadRight($col.AgentVersion) -NoNewline -ForegroundColor Gray
    Write-Host $r.Status                                  -ForegroundColor $statusColor
}
Write-Host ('-' * 145) -ForegroundColor DarkGray

# Optional: export to CSV
# $results | Export-Csv "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\VMAgentStatusReport.csv" -NoTypeInformation
