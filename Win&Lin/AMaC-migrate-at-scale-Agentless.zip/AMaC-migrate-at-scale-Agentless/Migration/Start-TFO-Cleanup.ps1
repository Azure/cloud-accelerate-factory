# TFO Cleanup Script - Run after test migration
#$ProjectName    = "Azuremigrate-AM-CUS-VMwareEOL"
#$ProjectRG      = "RG-AM-CUS-Prod-AzureMigrateCUS"
#$CleanupCsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\TFO-FIle.csv"


#$ProjectName    = "AzmigEUUKSVMEOL"
#$ProjectRG      = "rg-eu-uks-nonprod-azuremigrateuks"
#$CleanupCsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\TFO-FIle.csv"

#$ProjectName    = "AzmigEUUKSVMPub"
#$ProjectRG      = "rg-eu-uks-nonprod-azmigrateukspub"
#$CleanupCsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\TFO-FIle.csv"


$ProjectName    = "AzmigAPSEAVMEOL"
$ProjectRG      = "rg-ap-sea-nonprod-azuremigratesea"
$CleanupCsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\TFO-FIle.csv"

#$ProjectName    = "AzmigEUUKSVMEOL"
#$ProjectRG      = "rg-eu-uks-nonprod-azuremigrateuks" 

# CSV columns: MachineName
$CleanupVMs = Import-Csv $CleanupCsvPath

# Store all jobs so we can monitor them together
$CleanupJobs = @()

# 1) Start cleanup for all VMs
foreach ($VM in $CleanupVMs) {
    if ([string]::IsNullOrWhiteSpace($VM.MachineName)) { continue }

    Write-Output "`n=== Starting TFO cleanup for $($VM.MachineName) ==="

    try {
        $ReplicatingServer = Get-AzMigrateServerReplication `
            -ProjectName $ProjectName `
            -ResourceGroupName $ProjectRG `
            -MachineName $VM.MachineName `
            -ErrorAction Stop

        $job = Start-AzMigrateTestMigrationCleanup -InputObject $ReplicatingServer -ErrorAction Stop

        $CleanupJobs += [PSCustomObject]@{
            MachineName = $VM.MachineName
            Job         = $job
        }

        Write-Output "  Cleanup started. JobId = $($job.Id)"
    }
    catch {
        Write-Error ("Failed to start cleanup for {0}: {1}" -f $VM.MachineName, $_.Exception.Message)
    }
}

# 2) Monitor all cleanup jobs together until all complete
if ($CleanupJobs.Count -eq 0) {
    Write-Output "`nNo cleanup jobs were started. Check CSV or VM names."
    return
}

Write-Output "`n=== Monitoring all TFO cleanup jobs ==="

$allDone = $false
while (-not $allDone) {
    $allDone = $true

    foreach ($item in $CleanupJobs) {
        $job = Get-AzMigrateJob -InputObject $item.Job
        $item.Job = $job  # update reference

        Write-Output ("{0} cleanup status: {1}" -f $item.MachineName, $job.State)

        if ($job.State -in @('InProgress','NotStarted')) {
            $allDone = $false
        }
    }

    if (-not $allDone) {
        Start-Sleep -Seconds 10
        Write-Output "---- polling again ----"
    }
}

Write-Output "`nAll TFO cleanup jobs finished. Ready for production migration."
