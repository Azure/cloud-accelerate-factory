# ===================== USER CONFIG =====================
#$ProjectSubscriptionId = "3d9f4c5d-536d-4252-b653-1928e7d0ccb0"
#$ProjectName           = "Azuremigrate-AM-CUS-VMwareEOL"
#$ProjectRG             = "RG-AM-CUS-Prod-AzureMigrateCUS"
#$CsvPath               = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\TFO-FIle.csv"

$ProjectSubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612"
$ProjectName           = "AzmigAPSEAVMEOL"
$ProjectRG             = "rg-ap-sea-nonprod-azuremigratesea"
$CsvPath               = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\TFO-FIle.csv"

# ===================== MODULES =====================
Import-Module Az.Accounts, Az.Migrate, Az.Network

# ===================== CSV FORMAT =====================
# Required columns:
#   MachineName,VNetName,SubnetName
# Optional columns (override default project settings per row):
#   ProjectSubscriptionId,ProjectName,ProjectRG

# ===================== VALIDATE PROJECT =====================
Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null

try {
    $null = Get-AzMigrateProject -Name $ProjectName -ResourceGroupName $ProjectRG -ErrorAction Stop
    Write-Output "Project validated: $ProjectName"
}
catch {
    Write-Error "Azure Migrate project not found. $($_.Exception.Message)"
    return
}

# ===================== LOAD CSV =====================
if (-not (Test-Path -Path $CsvPath)) {
    Write-Error "CSV not found: $CsvPath"
    return
}

$Csv = Import-Csv $CsvPath
if (-not $Csv -or $Csv.Count -eq 0) {
    Write-Error "CSV is empty: $CsvPath"
    return
}

$requiredColumns = @('MachineName', 'VNetName', 'SubnetName')
foreach ($col in $requiredColumns) {
    if ($Csv[0].PSObject.Properties.Name -notcontains $col) {
        Write-Error "CSV missing required column: $col"
        return
    }
}

Write-Output "Loaded $($Csv.Count) VM row(s) from CSV"

# ===================== DISCOVER SUBSCRIPTIONS =====================
$AllSubscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }
Write-Output "Found $($AllSubscriptions.Count) enabled subscription(s) for VNet lookup"

# Cache VNet/Subnet lookups to avoid repeated cross-sub searches.
$NetworkCache = @{}
$ProjectCache = @{}

function Resolve-TestNetworkId {
    param(
        [Parameter(Mandatory)][string]$VNetName,
        [Parameter(Mandatory)][string]$SubnetName,
        [Parameter(Mandatory)][array]$Subscriptions,
        [Parameter(Mandatory)][hashtable]$Cache
    )

    $cacheKey = "$($VNetName.ToLowerInvariant())|$($SubnetName.ToLowerInvariant())"
    if ($Cache.ContainsKey($cacheKey)) {
        return $Cache[$cacheKey]
    }

    foreach ($sub in $Subscriptions) {
        try {
            Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null
            $vnets = Get-AzVirtualNetwork -Name $VNetName -ErrorAction SilentlyContinue
            if (-not $vnets) { continue }

            foreach ($vnet in @($vnets)) {
                $subnet = $vnet.Subnets | Where-Object { $_.Name -eq $SubnetName }
                if ($subnet) {
                    $resolved = [PSCustomObject]@{
                        TestNetworkId    = $vnet.Id
                        SubscriptionId   = $sub.Id
                        SubscriptionName = $sub.Name
                        ResourceGroup    = $vnet.ResourceGroupName
                        VNetName         = $vnet.Name
                        SubnetName       = $subnet.Name
                    }
                    $Cache[$cacheKey] = $resolved
                    return $resolved
                }
            }
        }
        catch {
            continue
        }
    }

    return $null
}

# ===================== START TFO =====================
$Jobs = @()
$Results = @()

foreach ($VM in $Csv) {
    $MachineName = [string]$VM.MachineName
    $VNetName    = [string]$VM.VNetName
    $SubnetName  = [string]$VM.SubnetName

    $RowProjectSubscriptionId = if ([string]::IsNullOrWhiteSpace([string]$VM.ProjectSubscriptionId)) { $ProjectSubscriptionId } else { ([string]$VM.ProjectSubscriptionId).Trim() }
    $RowProjectName           = if ([string]::IsNullOrWhiteSpace([string]$VM.ProjectName)) { $ProjectName } else { ([string]$VM.ProjectName).Trim() }
    $RowProjectRG             = if ([string]::IsNullOrWhiteSpace([string]$VM.ProjectRG)) { $ProjectRG } else { ([string]$VM.ProjectRG).Trim() }

    if ([string]::IsNullOrWhiteSpace($MachineName) -or [string]::IsNullOrWhiteSpace($VNetName) -or [string]::IsNullOrWhiteSpace($SubnetName)) {
        Write-Output "Skipping row with blank MachineName/VNetName/SubnetName"
        $Results += [PSCustomObject]@{
            MachineName       = $MachineName
            VNetName          = $VNetName
            SubnetName        = $SubnetName
            Status            = 'Skipped'
            Reason            = 'Blank required value'
            JobId             = ''
            TestVNetSubId     = ''
            TestVNetSubName   = ''
        }
        continue
    }

    Write-Output "`n=== Processing TFO $MachineName ==="

    try {
        if ([string]::IsNullOrWhiteSpace($RowProjectSubscriptionId) -or [string]::IsNullOrWhiteSpace($RowProjectName) -or [string]::IsNullOrWhiteSpace($RowProjectRG)) {
            throw "ProjectSubscriptionId/ProjectName/ProjectRG are blank after fallback resolution"
        }

        $projectKey = "$($RowProjectSubscriptionId.ToLowerInvariant())|$($RowProjectName.ToLowerInvariant())|$($RowProjectRG.ToLowerInvariant())"
        if (-not $ProjectCache.ContainsKey($projectKey)) {
            Set-AzContext -SubscriptionId $RowProjectSubscriptionId | Out-Null
            $null = Get-AzMigrateProject -Name $RowProjectName -ResourceGroupName $RowProjectRG -ErrorAction Stop
            $ProjectCache[$projectKey] = $true
        }

        $Network = Resolve-TestNetworkId -VNetName $VNetName -SubnetName $SubnetName -Subscriptions $AllSubscriptions -Cache $NetworkCache
        if (-not $Network) {
            throw "VNet/Subnet not found in enabled subscriptions: $VNetName / $SubnetName"
        }

        Write-Output "Using Test VNet: $($Network.VNetName) ($($Network.ResourceGroup)) in $($Network.SubscriptionName)"

        Set-AzContext -SubscriptionId $RowProjectSubscriptionId | Out-Null
        $ReplicatingServer = Get-AzMigrateServerReplication -ProjectName $RowProjectName -ResourceGroupName $RowProjectRG -MachineName $MachineName -ErrorAction Stop

        $Job = Start-AzMigrateTestMigration -InputObject $ReplicatingServer -TestNetworkID $Network.TestNetworkId -ErrorAction Stop
        $Jobs += [PSCustomObject]@{ VMName = $MachineName; JobId = $Job.Id; Job = $Job }

        $Results += [PSCustomObject]@{
            MachineName       = $MachineName
            VNetName          = $VNetName
            SubnetName        = $SubnetName
            Status            = 'Started'
            Reason            = 'Test migration started'
            JobId             = $Job.Id
            TestVNetSubId     = $Network.SubscriptionId
            TestVNetSubName   = $Network.SubscriptionName
        }

        Write-Output "Started: $($Job.Id)"
    }
    catch {
        Write-Output "Failed for ${MachineName}: $($_.Exception.Message)"
        $Results += [PSCustomObject]@{
            MachineName       = $MachineName
            VNetName          = $VNetName
            SubnetName        = $SubnetName
            Status            = 'Failed'
            Reason            = $_.Exception.Message
            JobId             = ''
            TestVNetSubId     = ''
            TestVNetSubName   = ''
        }
    }
}

# ===================== MONITOR JOBS =====================
if ($Jobs.Count -gt 0) {
    Write-Output "`n=== TFO Monitoring Jobs ==="
    $allComplete = $false
    while (-not $allComplete) {
        $allComplete = $true
        foreach ($jobInfo in $Jobs) {
            $jobInfo.Job = Get-AzMigrateJob -InputObject $jobInfo.Job
            Write-Output "$($jobInfo.VMName): $($jobInfo.Job.State) $($jobInfo.Job.PercentageComplete)"
            if ($jobInfo.Job.State -in @('InProgress', 'NotStarted')) { $allComplete = $false }
        }
        if (-not $allComplete) { Start-Sleep 30 }
    }
    Write-Output "All test migration jobs completed."
}
else {
    Write-Output "No jobs were started."
}

# ===================== SUMMARY =====================
$Started = ($Results | Where-Object { $_.Status -eq 'Started' }).Count
$Failed  = ($Results | Where-Object { $_.Status -eq 'Failed' }).Count
$Skipped = ($Results | Where-Object { $_.Status -eq 'Skipped' }).Count

Write-Output "`n=== SUMMARY ==="
Write-Output "Total   : $($Results.Count)"
Write-Output "Started : $Started"
Write-Output "Failed  : $Failed"
Write-Output "Skipped : $Skipped"

$Results | Format-Table MachineName, VNetName, SubnetName, Status, JobId, Reason -AutoSize