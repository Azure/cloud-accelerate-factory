# Connect to Azure
#Connect-AzAccount

# Variables
#$resourceGroupName = "rg-eu-uks-nonprod-azuremigrateuks"
#$projectName       = "AzmigEUUKSVMEOL"

#$resourceGroupName = "rg-eu-uks-nonprod-azmigrateukspub"
#$projectName       = "AzmigEUUKSVMPub"

$resourceGroupName = "rg-ap-sea-nonprod-azuremigratesea"
$projectName       = "AzmigAPSEAVMEOL"

#$resourceGroupName = "RG-AM-CUS-Prod-AzureMigrateCUS"
#$projectName       = "Azuremigrate-AM-CUS-VMwareEOL"

$csvPath           = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

# Confirmation prompt before starting migrations
$totalVMs = (Import-Csv $csvPath).Count
$caption = "Confirm Azure Migrate Cutover"
$message = "This will start CUTOVER MIGRATION (final, non-test) for $($totalVMs) VMs from CSV.`n`nThis action WILL shut down source servers and migrate to Azure.`n`nDo you want to continue?"
$yes = New-Object System.Management.Automation.Host.ChoiceDescription("&Yes", "Start migrations.")
$no = New-Object System.Management.Automation.Host.ChoiceDescription("&No", "Cancel.")
$choices = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
$response = $host.ui.PromptForChoice($caption, $message, $choices, 1)  # 1 = default No

if ($response -eq 1) {
    Write-Host "Migration cancelled by user." -ForegroundColor Yellow
    exit
}

Write-Host "Starting migrations for $($totalVMs) VMs..." -ForegroundColor Green

# Import VM names from CSV
$vmList = Import-Csv $csvPath

foreach ($item in $vmList) {
    $vm = $item.VMName
    Write-Host "Starting migration for: $vm" -ForegroundColor Cyan

    # Get replicating server
    $replicatingServer = Get-AzMigrateServerReplication `
        -ProjectName $projectName `
        -ResourceGroupName $resourceGroupName `
        -MachineName $vm

    if (-not $replicatingServer) {
        Write-Host "!! VM not found or not replicating: $vm" -ForegroundColor Red
        continue
    }

    # Start migration
    $migrateJob = Start-AzMigrateServerMigration `
        -InputObject $replicatingServer `
        -TurnOffSourceServer

    Write-Host " Migration started for $vm. Job ID: $($migrateJob.Name)" -ForegroundColor Green
}
