<#
.SYNOPSIS
Azure Migrate monitoring script (full view).

.DESCRIPTION
Shows running Azure Migrate jobs and replication/sync status for VMs.
Supports full inventory, active-only view, or MigrationInProgress-only view.

.NOTES
- Author: Deepak Tyagi
- Use this script when you need detailed monitoring and richer output columns.
- Job Operation may appear as N/A if Azure API does not return operation fields.
- DataSyncPercent depends on which progress fields are exposed by Az.Migrate objects.

.EXAMPLE
.\Monitor-AzMigrateSyncProgress.ps1

.EXAMPLE
.\Monitor-AzMigrateSyncProgress.ps1 -OnlyMigrationInProgress

.EXAMPLE
.\Monitor-AzMigrateSyncProgress.ps1 -ShowAllVMs -RefreshSeconds 10
#>

param(
    [Parameter(Mandatory = $false)]
    #[string]$SubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3",
    [string]$SubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612",
    

    [Parameter(Mandatory = $false)]
    #[string]$ResourceGroupName = "rg-eu-uks-nonprod-azuremigrateuks",
    [string]$ResourceGroupName = "rg-ap-sea-nonprod-azuremigratesea",

    [Parameter(Mandatory = $false)]
    #[string]$ProjectName = "AzmigEUUKSVMEOL",
    [string]$ProjectName = "AzmigAPSEAVMEOL",

    [Parameter(Mandatory = $false)]
    [int]$RefreshSeconds = 20,

    [Parameter(Mandatory = $false)]
    [switch]$ShowAllVMs,

    [Parameter(Mandatory = $false)]
    [switch]$OnlyMigrationInProgress
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-FirstValue {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string[]]$PropertyNames
    )

    if ($null -eq $InputObject) {
        return $null
    }

    foreach ($propertyName in $PropertyNames) {
        if ($InputObject.PSObject.Properties.Name -contains $propertyName) {
            $value = $InputObject.$propertyName
            if ($null -ne $value -and "${value}".Trim() -ne "") {
                return $value
            }
        }
    }

    return $null
}

function Get-SyncPercent {
    param(
        [Parameter(Mandatory = $true)]
        [object]$ReplicationDetail,

        [Parameter(Mandatory = $false)]
        [object]$ProviderSpecificDetail
    )

    $providerFields = @(
        "MigrationProgressPercentage",
        "InitialReplicationProgressPercentage",
        "ResyncProgressPercentage",
        "DataSyncProgressPercentage",
        "GatewayOperationDetailProgressPercentage",
        "ProgressPercentage",
        "ReplicationProgressPercentage"
    )

    $rootFields = @(
        "ProgressPercentage",
        "PercentComplete"
    )

    $value = Get-FirstValue -InputObject $ProviderSpecificDetail -PropertyNames $providerFields
    if ($null -ne $value) {
        return $value
    }

    $value = Get-FirstValue -InputObject $ReplicationDetail -PropertyNames $rootFields
    return $value
}

function Format-Bytes {
    param([Nullable[double]]$Bytes)

    if ($null -eq $Bytes -or $Bytes -lt 0) { return "N/A" }

    $units = @("B", "KB", "MB", "GB", "TB", "PB")
    $size = [double]$Bytes
    $idx = 0
    while ($size -ge 1024 -and $idx -lt ($units.Count - 1)) {
        $size = $size / 1024
        $idx++
    }

    return ("{0:N2} {1}" -f $size, $units[$idx])
}

function Format-DurationFromMilliseconds {
    param([Nullable[double]]$Milliseconds)

    if ($null -eq $Milliseconds -or $Milliseconds -lt 0) { return "N/A" }

    try {
        $ts = [TimeSpan]::FromMilliseconds([double]$Milliseconds)
        if ($ts.TotalHours -ge 24) {
            return ("{0}d {1:00}h {2:00}m" -f [Math]::Floor($ts.TotalDays), $ts.Hours, $ts.Minutes)
        }
        return ("{0:00}h {1:00}m" -f [Math]::Floor($ts.TotalHours), $ts.Minutes)
    }
    catch {
        return "N/A"
    }
}

function Get-DiskTotalBytes {
    param([object]$ProviderSpecificDetail)

    $protectedDisks = Get-FirstValue -InputObject $ProviderSpecificDetail -PropertyNames @("ProtectedDisk")
    if ($null -eq $protectedDisks) { return $null }

    $total = 0.0
    $found = $false
    foreach ($disk in @($protectedDisks)) {
        $diskBytes = Get-FirstValue -InputObject $disk -PropertyNames @(
            "SourceDiskSizeInBytes",
            "DiskSizeInBytes",
            "CapacityInBytes",
            "SizeInBytes",
            "TargetDiskSizeInBytes"
        )

        if ($diskBytes) {
            try {
                $value = [double]$diskBytes
                if ($value -gt 0) {
                    $total += $value
                    $found = $true
                }
            }
            catch {
                # Ignore malformed disk size values.
            }
        }
    }

    if ($found) { return $total }
    return $null
}

try {
    Import-Module Az.Accounts -ErrorAction Stop
    Import-Module Az.Migrate -ErrorAction Stop
}
catch {
    Write-Host "Failed to load Az modules. Install or update Az.Accounts and Az.Migrate." -ForegroundColor Red
    throw
}

if (-not (Get-AzContext)) {
    Write-Host "No Azure context found. Running Connect-AzAccount..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

if (-not [string]::IsNullOrWhiteSpace($SubscriptionId)) {
    try {
        $currentContext = Get-AzContext
        if (-not $currentContext -or $currentContext.Subscription.Id -ne $SubscriptionId) {
            Write-Host "Switching context to subscription $SubscriptionId" -ForegroundColor Yellow
            Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
        }
    }
    catch {
        Write-Host "Failed to set subscription context to '$SubscriptionId'." -ForegroundColor Red
        throw
    }
}

if ($RefreshSeconds -lt 5) {
    Write-Host "RefreshSeconds too low; using 5 seconds minimum." -ForegroundColor Yellow
    $RefreshSeconds = 5
}

# Validate project once so failures are explicit before entering monitor loop.
try {
    $null = Get-AzMigrateProject -ResourceGroupName $ResourceGroupName -Name $ProjectName -ErrorAction Stop
}
catch {
    Write-Host "Could not find Azure Migrate project '$ProjectName' in resource group '$ResourceGroupName'." -ForegroundColor Red
    Write-Host "Check subscription context and project/resource group names." -ForegroundColor Yellow
    throw
}

Write-Host "Monitoring Azure Migrate project $ProjectName in resource group $ResourceGroupName" -ForegroundColor Cyan
Write-Host "Subscription: $((Get-AzContext).Subscription.Id)" -ForegroundColor DarkCyan
Write-Host "Press Ctrl+C to stop." -ForegroundColor Cyan

while ($true) {
    try {
        Clear-Host
        Write-Host ("Azure Migrate Monitor | " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")) -ForegroundColor Cyan
        Write-Host "Resource Group: $ResourceGroupName | Project: $ProjectName" -ForegroundColor DarkCyan

        $runningJobs = @()
        $jobQueryWarning = $null
        try {
            $jobs = Get-AzMigrateJob -ResourceGroupName $ResourceGroupName -ProjectName $ProjectName -ErrorAction Stop
            $runningJobs = @($jobs | Where-Object { $_.State -in @("InProgress", "NotStarted") })
        }
        catch {
            # Some Azure Migrate solutions do not support listing jobs at project scope.
            $jobQueryWarning = $_.Exception.Message
        }

        Write-Host ""
        Write-Host "Running Jobs" -ForegroundColor Yellow
        if ($runningJobs.Count -gt 0) {
            $runningJobs |
                ForEach-Object {
                    $operationName = Get-FirstValue -InputObject $_ -PropertyNames @(
                        "OperationName",
                        "DisplayName",
                        "JobType",
                        "FriendlyName",
                        "ScenarioName"
                    )

                    $vmName = Get-FirstValue -InputObject $_ -PropertyNames @(
                        "TargetObjectName"
                    )

                    $startTimeLocal = "N/A"
                    $startTimeUtc = "N/A"
                    $elapsedMinutes = "N/A"
                    $elapsedHHMM = "N/A"

                    $startTimeRaw = Get-FirstValue -InputObject $_ -PropertyNames @("StartTime")
                    if ($startTimeRaw) {
                        try {
                            $startTimeOffset = [DateTimeOffset]$startTimeRaw
                            $startTimeLocal = $startTimeOffset.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss zzz")
                            $startTimeUtc = $startTimeOffset.ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss 'UTC'")
                            $elapsed = ([DateTimeOffset]::UtcNow - $startTimeOffset.ToUniversalTime()).TotalMinutes
                            if ($elapsed -ge 0) {
                                $elapsedMinutes = [Math]::Round($elapsed, 2)
                                $elapsedSpan = [TimeSpan]::FromMinutes($elapsed)
                                $elapsedHHMM = ("{0:00}:{1:00}" -f [Math]::Floor($elapsedSpan.TotalHours), $elapsedSpan.Minutes)
                            }
                        }
                        catch {
                            # Keep N/A if time conversion fails.
                        }
                    }

                    [PSCustomObject]@{
                        Name       = $_.Name
                        State      = $_.State
                        VMName     = if ($vmName) { $vmName } else { "N/A" }
                        Operation  = if ($operationName) { $operationName } else { "N/A" }
                        StartLocal = $startTimeLocal
                        StartUTC   = $startTimeUtc
                        ElapsedHHMM= $elapsedHHMM
                        ElapsedMin = $elapsedMinutes
                        EndTime    = $_.EndTime
                    }
                } |
                Sort-Object StartUTC -Descending |
                Format-Table -AutoSize
        }
        else {
            Write-Host "No running jobs found." -ForegroundColor DarkGray
            if ($jobQueryWarning) {
                Write-Host "Job listing not available for this solution context: $jobQueryWarning" -ForegroundColor Yellow
            }
        }

        $replicationItems = Get-AzMigrateServerReplication -ResourceGroupName $ResourceGroupName -ProjectName $ProjectName
        $rows = @()

        foreach ($item in $replicationItems) {
            $detail = Get-AzMigrateServerReplication -TargetObjectID $item.Id
            $providerDetail = $detail.ProviderSpecificDetail
            $syncPercent = Get-SyncPercent -ReplicationDetail $detail -ProviderSpecificDetail $providerDetail

            $uploadSpeedBpsRaw = Get-FirstValue -InputObject $providerDetail -PropertyNames @(
                "GatewayOperationDetailUploadSpeed",
                "GatewayOperationDetailVmwareReadThroughput"
            )
            $timeRemainingMsRaw = Get-FirstValue -InputObject $providerDetail -PropertyNames @("GatewayOperationDetailTimeRemaining")
            $timeElapsedMsRaw = Get-FirstValue -InputObject $providerDetail -PropertyNames @("GatewayOperationDetailTimeElapsed")

            $uploadSpeedBps = $null
            $timeRemainingMs = $null
            $timeElapsedMs = $null

            try { if ($uploadSpeedBpsRaw) { $uploadSpeedBps = [double]$uploadSpeedBpsRaw } } catch {}
            try { if ($timeRemainingMsRaw) { $timeRemainingMs = [double]$timeRemainingMsRaw } } catch {}
            try { if ($timeElapsedMsRaw) { $timeElapsedMs = [double]$timeElapsedMsRaw } } catch {}

            $remainingBytesEstimate = $null
            $totalBytesEstimate = Get-DiskTotalBytes -ProviderSpecificDetail $providerDetail

            if ($null -ne $uploadSpeedBps -and $null -ne $timeRemainingMs -and $uploadSpeedBps -gt 0 -and $timeRemainingMs -ge 0) {
                $remainingBytesEstimate = $uploadSpeedBps * ($timeRemainingMs / 1000.0)
            }

            if ($null -eq $totalBytesEstimate -and $null -ne $uploadSpeedBps -and $null -ne $timeElapsedMs -and $null -ne $remainingBytesEstimate -and $uploadSpeedBps -gt 0) {
                $transferredBytesEstimate = $uploadSpeedBps * ($timeElapsedMs / 1000.0)
                $totalBytesEstimate = $transferredBytesEstimate + $remainingBytesEstimate
            }

            $rows += [PSCustomObject]@{
                VMName          = $item.MachineName
                MigrationState  = $detail.MigrationState
                DataSyncPercent = if ($null -ne $syncPercent) { [string]$syncPercent } else { "N/A" }
                SyncSpeed       = if ($null -ne $uploadSpeedBps -and $uploadSpeedBps -gt 0) { ("{0}/s" -f (Format-Bytes -Bytes $uploadSpeedBps)) } else { "N/A" }
                ETA             = Format-DurationFromMilliseconds -Milliseconds $timeRemainingMs
                DataToSync      = Format-Bytes -Bytes $totalBytesEstimate
                DataRemaining   = Format-Bytes -Bytes $remainingBytesEstimate
                RemainingBytes  = $remainingBytesEstimate
            }
        }

        if ($OnlyMigrationInProgress) {
            $rows = @($rows | Where-Object { $_.MigrationState -eq "MigrationInProgress" })
        }
        elseif (-not $ShowAllVMs) {
            $rows = @($rows | Where-Object {
                $_.MigrationState -in @(
                    "EnableProtectionInProgress",
                    "InitialReplicationInProgress",
                    "DeltaSyncInProgress",
                    "FinalSyncInProgress",
                    "PreparingForMigration",
                    "MigrationInProgress",
                    "TestMigrationInProgress"
                ) -or $_.DataSyncPercent -ne "N/A"
            })
        }

        Write-Host ""
        Write-Host "Replication / Data Sync" -ForegroundColor Yellow
        if ($rows.Count -gt 0) {
            $displayRows = @()
            $serialNumber = 1
            foreach ($row in ($rows | Sort-Object VMName)) {
                $displayRows += [PSCustomObject]@{
                    SrNo            = $serialNumber
                    VMName          = $row.VMName
                    MigrationState  = $row.MigrationState
                    DataSyncPercent = $row.DataSyncPercent
                    SyncSpeed       = $row.SyncSpeed
                    ETA             = $row.ETA
                    DataToSync      = $row.DataToSync
                    DataRemaining   = $row.DataRemaining
                    RemainingBytes  = $row.RemainingBytes
                }
                $serialNumber++
            }

            $totalRemainingBytes = ($displayRows | Where-Object { $null -ne $_.RemainingBytes -and $_.RemainingBytes -ge 0 } | Measure-Object -Property RemainingBytes -Sum).Sum
            Write-Host ("Total Count: {0}" -f $displayRows.Count) -ForegroundColor Green
            Write-Host ("Total Remaining Data: {0}" -f (Format-Bytes -Bytes $totalRemainingBytes)) -ForegroundColor Green
            $displayRows |
                Select-Object SrNo, VMName, MigrationState, DataSyncPercent, SyncSpeed, ETA, DataToSync, DataRemaining |
                Format-Table -AutoSize

            $numeric = @($rows | Where-Object { $_.DataSyncPercent -match '^[0-9]+(\.[0-9]+)?$' } | ForEach-Object { [double]$_.DataSyncPercent })

            $activeStates = @(
                "MigrationInProgress",
                "FinalSyncInProgress",
                "PreparingForMigration",
                "DeltaSyncInProgress",
                "InitialReplicationInProgress",
                "EnableProtectionInProgress",
                "TestMigrationInProgress"
            )

            $activeRows = @($rows | Where-Object { $_.MigrationState -in $activeStates })
            $activeNumeric = @($activeRows | Where-Object { $_.DataSyncPercent -match '^[0-9]+(\.[0-9]+)?$' } | ForEach-Object { [double]$_.DataSyncPercent })

            if ($numeric.Count -gt 0 -or $activeRows.Count -gt 0) {
                Write-Host ""
                if ($numeric.Count -gt 0) {
                    $overallAvg = [Math]::Round((($numeric | Measure-Object -Average).Average), 2)
                    Write-Host "Overall average reported sync percent: $overallAvg" -ForegroundColor Green
                }
                else {
                    Write-Host "Overall average reported sync percent: N/A" -ForegroundColor DarkGray
                }

                if ($activeNumeric.Count -gt 0) {
                    $activeAvg = [Math]::Round((($activeNumeric | Measure-Object -Average).Average), 2)
                    $activeMin = [Math]::Round((($activeNumeric | Measure-Object -Minimum).Minimum), 2)
                    $activeMax = [Math]::Round((($activeNumeric | Measure-Object -Maximum).Maximum), 2)
                    Write-Host "Active migration average percent: $activeAvg" -ForegroundColor Cyan
                    Write-Host "Active migration summary: Count=$($activeRows.Count) Min=$activeMin Max=$activeMax" -ForegroundColor Cyan
                }
                elseif ($activeRows.Count -gt 0) {
                    Write-Host "Active migration average percent: N/A (no numeric percent exposed)" -ForegroundColor DarkGray
                    Write-Host "Active migration summary: Count=$($activeRows.Count)" -ForegroundColor Cyan
                }
                else {
                    Write-Host "Active migration average percent: N/A (no active migration rows)" -ForegroundColor DarkGray
                    Write-Host "Active migration summary: Count=0" -ForegroundColor Cyan
                }
            }
            else {
                Write-Host ""
                Write-Host "No numeric sync percent exposed by current objects for these items." -ForegroundColor DarkGray
            }
        }
        else {
            Write-Host "No active replication/sync items to display." -ForegroundColor DarkGray
        }
    }
    catch {
        Write-Host "Monitor iteration error: $($_.Exception.Message)" -ForegroundColor Red
    }

    Start-Sleep -Seconds $RefreshSeconds
}
