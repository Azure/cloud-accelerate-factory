<#
.SYNOPSIS
Azure Migrate monitoring script (lite view).

.DESCRIPTION
Lightweight monitor that shows running jobs and only VMs in MigrationInProgress state.

.NOTES
- Author: Deepak Tyagi
- Use this script for day-to-day cutover tracking with minimal output.
- Designed to stay small and easy to maintain.

.EXAMPLE
.\Monitor-AzMigrateSyncProgress-Lite.ps1

.EXAMPLE
.\Monitor-AzMigrateSyncProgress-Lite.ps1 -RefreshSeconds 10
#>

param(
    <#[string]$SubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3",
    [string]$ResourceGroupName = "rg-eu-uks-nonprod-azuremigrateuks",
    [string]$ProjectName = "AzmigEUUKSVMEOL",
    [int]$RefreshSeconds = 20
    #>
    <#[string]$SubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612",
    [string]$ResourceGroupName = "rg-ap-sea-nonprod-azuremigratesea",
    [string]$ProjectName = "AzmigAPSEAVMEOL",
    [int]$RefreshSeconds = 20
    #>

    [string]$SubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612",
    [string]$ResourceGroupName = "rg-ap-sea-nonprod-azuremigratesea",
    [string]$ProjectName = "AzmigAPSEAVMEOL",
    [int]$RefreshSeconds = 20
)

$ErrorActionPreference = "Stop"

function Get-FirstValue {
    param([object]$Object, [string[]]$Names)
    if (-not $Object) { return $null }
    foreach ($n in $Names) {
        if ($Object.PSObject.Properties.Name -contains $n) {
            $v = $Object.$n
            if ($null -ne $v -and "$v".Trim() -ne "") { return $v }
        }
    }
    return $null
}

function Get-SyncPercent {
    param([object]$Detail)
    $ps = $Detail.ProviderSpecificDetail
    $v = Get-FirstValue -Object $ps -Names @(
        "MigrationProgressPercentage",
        "DataSyncProgressPercentage",
        "GatewayOperationDetailProgressPercentage",
        "ProgressPercentage"
    )
    if ($v) { return $v }
    return (Get-FirstValue -Object $Detail -Names @("ProgressPercentage","PercentComplete"))
}

function Format-Bytes {
    param([Nullable[double]]$Bytes)

    if ($null -eq $Bytes -or $Bytes -lt 0) { return "N/A" }

    $units = @("B", "KB", "MB", "GB", "TB", "PB")
    $size = [double]$Bytes
    $idx = 0
    while ($size -ge 1024 -and $idx -lt ($units.Count - 1)) {
        $size = $size / 1024
        $idx++
    }
    return ("{0:N2} {1}" -f $size, $units[$idx])
}

function Format-DurationFromMilliseconds {
    param([Nullable[double]]$Milliseconds)

    if ($null -eq $Milliseconds -or $Milliseconds -lt 0) { return "N/A" }

    try {
        $ts = [TimeSpan]::FromMilliseconds([double]$Milliseconds)
        if ($ts.TotalHours -ge 24) {
            return ("{0}d {1:00}h {2:00}m" -f [Math]::Floor($ts.TotalDays), $ts.Hours, $ts.Minutes)
        }
        return ("{0:00}h {1:00}m" -f [Math]::Floor($ts.TotalHours), $ts.Minutes)
    }
    catch {
        return "N/A"
    }
}

function Get-DiskTotalBytes {
    param([object]$ProviderDetail)

    $protectedDisks = Get-FirstValue -Object $ProviderDetail -Names @("ProtectedDisk")
    if ($null -eq $protectedDisks) { return $null }

    $total = 0.0
    $found = $false
    foreach ($disk in @($protectedDisks)) {
        $diskBytes = Get-FirstValue -Object $disk -Names @(
            "SourceDiskSizeInBytes",
            "DiskSizeInBytes",
            "CapacityInBytes",
            "SizeInBytes",
            "TargetDiskSizeInBytes"
        )

        if ($diskBytes) {
            try {
                $value = [double]$diskBytes
                if ($value -gt 0) {
                    $total += $value
                    $found = $true
                }
            }
            catch {}
        }
    }

    if ($found) { return $total }
    return $null
}

Import-Module Az.Accounts -ErrorAction Stop
Import-Module Az.Migrate -ErrorAction Stop

if (-not (Get-AzContext)) { Connect-AzAccount | Out-Null }
Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null

$null = Get-AzMigrateProject -ResourceGroupName $ResourceGroupName -Name $ProjectName -ErrorAction Stop

while ($true) {
    Clear-Host
    Write-Host ("Azure Migrate Lite Monitor | " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")) -ForegroundColor Cyan
    Write-Host "RG: $ResourceGroupName | Project: $ProjectName | Sub: $SubscriptionId" -ForegroundColor DarkCyan

    # Running jobs (simple view)
    Write-Host ""
    Write-Host "Running Jobs" -ForegroundColor Yellow
    try {
        $jobs = Get-AzMigrateJob -ResourceGroupName $ResourceGroupName -ProjectName $ProjectName |
            Where-Object { $_.State -in @("InProgress","NotStarted") } |
            Select-Object Name, State, TargetObjectName, FriendlyName, StartTime

        if ($jobs) {
            $jobs | Format-Table -AutoSize
        } else {
            Write-Host "No running jobs" -ForegroundColor DarkGray
        }
    }
    catch {
        Write-Host "Job list not available in this solution context" -ForegroundColor DarkGray
    }

    # Only MigrationInProgress VMs
    Write-Host ""
    Write-Host "MigrationInProgress VMs" -ForegroundColor Yellow
    $reps = Get-AzMigrateServerReplication -ResourceGroupName $ResourceGroupName -ProjectName $ProjectName
    $rows = foreach ($r in $reps) {
        $d = Get-AzMigrateServerReplication -TargetObjectID $r.Id
        if ($d.MigrationState -eq "MigrationInProgress") {
            $ps = $d.ProviderSpecificDetail

            $uploadSpeedBpsRaw = Get-FirstValue -Object $ps -Names @(
                "GatewayOperationDetailUploadSpeed",
                "GatewayOperationDetailVmwareReadThroughput"
            )
            $timeRemainingMsRaw = Get-FirstValue -Object $ps -Names @("GatewayOperationDetailTimeRemaining")
            $timeElapsedMsRaw = Get-FirstValue -Object $ps -Names @("GatewayOperationDetailTimeElapsed")

            $uploadSpeedBps = $null
            $timeRemainingMs = $null
            $timeElapsedMs = $null

            try { if ($uploadSpeedBpsRaw) { $uploadSpeedBps = [double]$uploadSpeedBpsRaw } } catch {}
            try { if ($timeRemainingMsRaw) { $timeRemainingMs = [double]$timeRemainingMsRaw } } catch {}
            try { if ($timeElapsedMsRaw) { $timeElapsedMs = [double]$timeElapsedMsRaw } } catch {}

            $remainingBytesEstimate = $null
            $totalBytesEstimate = Get-DiskTotalBytes -ProviderDetail $ps

            if ($null -ne $uploadSpeedBps -and $null -ne $timeRemainingMs -and $uploadSpeedBps -gt 0 -and $timeRemainingMs -ge 0) {
                $remainingBytesEstimate = $uploadSpeedBps * ($timeRemainingMs / 1000.0)
            }

            if ($null -eq $totalBytesEstimate -and $null -ne $uploadSpeedBps -and $null -ne $timeElapsedMs -and $null -ne $remainingBytesEstimate -and $uploadSpeedBps -gt 0) {
                $transferredBytesEstimate = $uploadSpeedBps * ($timeElapsedMs / 1000.0)
                $totalBytesEstimate = $transferredBytesEstimate + $remainingBytesEstimate
            }

            [PSCustomObject]@{
                VMName          = $r.MachineName
                MigrationState  = $d.MigrationState
                DataSyncPercent = (Get-SyncPercent -Detail $d)
                SyncSpeed       = if ($null -ne $uploadSpeedBps -and $uploadSpeedBps -gt 0) { ("{0}/s" -f (Format-Bytes -Bytes $uploadSpeedBps)) } else { "N/A" }
                ETA             = Format-DurationFromMilliseconds -Milliseconds $timeRemainingMs
                DataToSync      = Format-Bytes -Bytes $totalBytesEstimate
                DataRemaining   = Format-Bytes -Bytes $remainingBytesEstimate
                RemainingBytes  = $remainingBytesEstimate
            }
        }
    }

    if ($rows) {
        $displayRows = @()
        $serialNumber = 1
        foreach ($row in ($rows | Sort-Object VMName)) {
            $displayRows += [PSCustomObject]@{
                SrNo            = $serialNumber
                VMName          = $row.VMName
                MigrationState  = $row.MigrationState
                DataSyncPercent = $row.DataSyncPercent
                SyncSpeed       = $row.SyncSpeed
                ETA             = $row.ETA
                DataToSync      = $row.DataToSync
                DataRemaining   = $row.DataRemaining
                RemainingBytes  = $row.RemainingBytes
            }
            $serialNumber++
        }

        $totalRemainingBytes = ($displayRows | Where-Object { $null -ne $_.RemainingBytes -and $_.RemainingBytes -ge 0 } | Measure-Object -Property RemainingBytes -Sum).Sum
        Write-Host ("Total Count: {0}" -f $displayRows.Count) -ForegroundColor Green
        Write-Host ("Total Remaining Data: {0}" -f (Format-Bytes -Bytes $totalRemainingBytes)) -ForegroundColor Green
        $displayRows |
            Select-Object SrNo, VMName, MigrationState, DataSyncPercent, SyncSpeed, ETA, DataToSync, DataRemaining |
            Format-Table -AutoSize
    }
    else {
        Write-Host "No VMs currently in MigrationInProgress" -ForegroundColor DarkGray
    }

    Start-Sleep -Seconds ([Math]::Max(5, $RefreshSeconds))
}
