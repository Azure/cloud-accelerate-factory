<#
.SYNOPSIS
    Updates all managed disks (OS + Data) of Azure VMs to Premium SSD (Premium_LRS).

.DESCRIPTION
    Reads VM names and Resource Groups from a CSV file, then converts all attached
    managed disks to Premium SSD for each VM.
    The VM must be deallocated before disk SKU changes can be applied.

.NOTES
    Required CSV columns:
        VMName,ResourceGroup

    Example CSV:
        VMName,ResourceGroup
        APP-SRV-01,RG-Production
        DB-SRV-01,RG-Production

    Author: Deepak Tyagi
    Date:   May 2026
#>

# ===================== USER CONFIG =====================
$CsvPath       = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\VMDisk-PremiumSSD.csv"
$TargetDiskSku = "Premium_LRS"
#$TargetDiskSku = "StandardSSD_LRS"

# ===================== MODULES =====================
Import-Module Az.Accounts, Az.Compute

# ===================== TENANT-WIDE SUBSCRIPTION DISCOVERY =====================
Write-Host "Fetching all subscriptions in tenant..." -ForegroundColor Cyan
$AllSubscriptions = Get-AzSubscription -ErrorAction Stop
Write-Host "Found $($AllSubscriptions.Count) subscription(s) in tenant." -ForegroundColor Green

# Build a lookup: VMName+RG -> SubscriptionId  (lazy, filled as VMs are found)
$SubCache = @{}

# ===================== VALIDATE CSV =====================
if (-not (Test-Path -Path $CsvPath)) {
    Write-Error "CSV not found: $CsvPath"
    return
}

$Rows = Import-Csv $CsvPath
if (-not $Rows -or $Rows.Count -eq 0) {
    Write-Error "CSV is empty: $CsvPath"
    return
}

$requiredColumns = @('VMName', 'ResourceGroup')
foreach ($col in $requiredColumns) {
    if ($Rows[0].PSObject.Properties.Name -notcontains $col) {
        Write-Error "CSV missing required column: $col"
        return
    }
}

Write-Host "Loaded $($Rows.Count) VM row(s) from CSV" -ForegroundColor Green

# ===================== RESULTS TRACKING =====================
$Results      = @()
$SuccessCount = 0
$FailCount    = 0
$SkipCount    = 0

# ===================== MAIN LOOP =====================
$vmIndex = 0
foreach ($row in $Rows) {
    $vmIndex++
    $VMName = $row.VMName.Trim()
    $RGName = $row.ResourceGroup.Trim()

    if ([string]::IsNullOrWhiteSpace($VMName) -or [string]::IsNullOrWhiteSpace($RGName)) {
        Write-Host "[$vmIndex/$($Rows.Count)] Skipped - blank VMName or ResourceGroup" -ForegroundColor Yellow
        $SkipCount++
        $Results += [PSCustomObject]@{
            VMName         = $VMName
            ResourceGroup  = $RGName
            SubscriptionId = "N/A"
            Status         = "Skipped"
            Reason         = "Blank VMName or ResourceGroup"
        }
        continue
    }

    Write-Host "`n[$vmIndex/$($Rows.Count)] Processing: $VMName  RG: $RGName" -ForegroundColor Yellow

    try {
        # --- Tenant-wide search: find which subscription owns this VM ---
        $vm          = $null
        $FoundSubId  = $null

        foreach ($sub in $AllSubscriptions) {
            Set-AzContext -SubscriptionId $sub.Id | Out-Null
            $vm = Get-AzVM -Name $VMName -ResourceGroupName $RGName -ErrorAction SilentlyContinue
            if ($vm) {
                $FoundSubId = $sub.Id
                Write-Host "  Found in subscription: $($sub.Name) ($($sub.Id))" -ForegroundColor Green
                break
            }
        }

        if (-not $vm) {
            Write-Host "  VM '$VMName' not found in any subscription." -ForegroundColor Red
            $FailCount++
            $Results += [PSCustomObject]@{
                VMName        = $VMName
                ResourceGroup = $RGName
                SubscriptionId = "Not Found"
                Status        = "Failed"
                Reason        = "VM not found in any tenant subscription"
            }
            continue
        }

        # Check VM power state
        $vmStatus    = Get-AzVM -Name $VMName -ResourceGroupName $RGName -Status -ErrorAction Stop
        $powerState  = ($vmStatus.Statuses | Where-Object { $_.Code -like "PowerState/*" }).DisplayStatus

        if ($powerState -ne "VM deallocated") {
            Write-Host "  Deallocating VM: $VMName ..." -ForegroundColor Cyan
            Stop-AzVM -Name $VMName -ResourceGroupName $RGName -Force -ErrorAction Stop | Out-Null
            Write-Host "  VM deallocated." -ForegroundColor Green
        }
        else {
            Write-Host "  VM is already deallocated." -ForegroundColor Green
        }

        # Collect all disk IDs
        $diskUpdates = @()

        # OS Disk
        if ($vm.StorageProfile.OsDisk.ManagedDisk.Id) {
            $diskUpdates += [PSCustomObject]@{
                DiskName = $vm.StorageProfile.OsDisk.Name
                DiskId   = $vm.StorageProfile.OsDisk.ManagedDisk.Id
                Type     = "OsDisk"
            }
        }

        # Data Disks
        foreach ($dataDisk in $vm.StorageProfile.DataDisks) {
            if ($dataDisk.ManagedDisk.Id) {
                $diskUpdates += [PSCustomObject]@{
                    DiskName = $dataDisk.Name
                    DiskId   = $dataDisk.ManagedDisk.Id
                    Type     = "DataDisk"
                }
            }
        }

        if ($diskUpdates.Count -eq 0) {
            Write-Host "  No managed disks found on $VMName" -ForegroundColor Yellow

            $SkipCount++
            $Results += [PSCustomObject]@{
                VMName         = $VMName
                ResourceGroup  = $RGName
                SubscriptionId = $FoundSubId
                Status         = "Skipped"
                Reason         = "No managed disks found"
            }
            continue
        }

        # Update each disk SKU
        $allDisksUpdated = $true
        foreach ($disk in $diskUpdates) {
            Write-Host "  Updating [$($disk.Type)] $($disk.DiskName) -> $TargetDiskSku ..." -ForegroundColor Cyan
            try {
                $diskObj      = Get-AzDisk -ResourceGroupName $RGName -DiskName $disk.DiskName -ErrorAction Stop
                $currentSku   = $diskObj.Sku.Name

                if ($currentSku -eq $TargetDiskSku) {
                    Write-Host "    Already $TargetDiskSku - no change needed." -ForegroundColor Green
                    continue
                }

                $diskObj.Sku = [Microsoft.Azure.Management.Compute.Models.DiskSku]::new($TargetDiskSku)
                Update-AzDisk -ResourceGroupName $RGName -DiskName $disk.DiskName -Disk $diskObj -ErrorAction Stop | Out-Null
                Write-Host "    Updated from $currentSku to $TargetDiskSku." -ForegroundColor Green
            }
            catch {
                Write-Host "    Failed to update disk $($disk.DiskName): $($_.Exception.Message)" -ForegroundColor Red
                $allDisksUpdated = $false
            }
        }

        if ($allDisksUpdated) {
            $SuccessCount++
            $Results += [PSCustomObject]@{
                VMName         = $VMName
                ResourceGroup  = $RGName
                SubscriptionId = $FoundSubId
                Status         = "Success"
                Reason         = "All disks updated to $TargetDiskSku"
            }
        }
        else {
            $FailCount++
            $Results += [PSCustomObject]@{
                VMName         = $VMName
                ResourceGroup  = $RGName
                SubscriptionId = $FoundSubId
                Status         = "PartialFail"
                Reason         = "One or more disks failed to update"
            }
        }
    }
    catch {
        Write-Host "  ERROR processing $VMName : $($_.Exception.Message)" -ForegroundColor Red
        $FailCount++
        $Results += [PSCustomObject]@{
            VMName         = $VMName
            ResourceGroup  = $RGName
            SubscriptionId = if ($FoundSubId) { $FoundSubId } else { "Unknown" }
            Status         = "Failed"
            Reason         = $_.Exception.Message
        }
    }
}

# ===================== SUMMARY =====================
Write-Host "`n=============================" -ForegroundColor Cyan
Write-Host " SUMMARY" -ForegroundColor Cyan
Write-Host "=============================" -ForegroundColor Cyan
Write-Host " Total    : $($Rows.Count)" -ForegroundColor White
Write-Host " Success  : $SuccessCount"  -ForegroundColor Green
Write-Host " Failed   : $FailCount"     -ForegroundColor Red
Write-Host " Skipped  : $SkipCount"     -ForegroundColor Yellow
Write-Host "=============================" -ForegroundColor Cyan

$Results | Format-Table VMName, ResourceGroup, SubscriptionId, Status, Reason -AutoSize
$Results | Out-GridView -Title "VM Disk Update to Premium SSD - Results"
