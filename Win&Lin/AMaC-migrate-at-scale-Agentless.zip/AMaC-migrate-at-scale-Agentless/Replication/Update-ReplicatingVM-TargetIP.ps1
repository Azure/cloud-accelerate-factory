<#
.SYNOPSIS
    Updates the Target IP Address on Azure Migrate replicating VMs from CSV input.
    Requires PowerShell 7.x and Az.Migrate module.

.DESCRIPTION
    This script reads a CSV file containing VM names and their desired Target IP addresses,
    retrieves each replicating server from the Azure Migrate project, builds an updated
    NIC mapping with the new static IP values, and applies it using Set-AzMigrateServerReplication.

    It updates the primary NIC's Target IP Address so that when the VM is migrated (cutover),
    it will receive the specified static IP in the target Azure subnet.

    Secondary NIC IPs are optional. If provided in the CSV, they are applied to non-primary
    NICs in order. If omitted, existing secondary NIC target IPs are preserved.

.NOTES
    CSV columns:
        VMName | TargetIP | SecondaryTargetIP | SecondaryIP1 | SecondaryIP2 ...

    Notes:
        - VMName is required.
        - TargetIP updates the primary NIC.
        - SecondaryTargetIP is an alias for SecondaryIP1.
        - SecondaryIP1, SecondaryIP2, ... map to non-primary NICs in order.
        - If any optional secondary IP column is blank, that NIC is left unchanged.

    Example CSV:
        VMName,TargetIP,SecondaryIP1
        US-THT-EDITST02,10.247.16.134,
        US-THT-MISCDB01,10.247.16.4,10.247.16.5

    Author: Deepak Tyagi
    Date:   April 2026
#>

# ===================== USER CONFIG =====================
$CsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\Update-TargetIP.csv"

# Azure Migrate project
#$ProjectSubscriptionId = "3d9f4c5d-536d-4252-b653-1928e7d0ccb0"
#$ProjectName           = "Azuremigrate-AM-CUS-VMwareEOL"
#$ProjectRG             = "RG-AM-CUS-Prod-AzureMigrateCUS"

$ProjectSubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3"
$ProjectName           = "AzmigEUUKSVMEOL"
$ProjectRG             = "rg-eu-uks-nonprod-azuremigrateuks"

#$ProjectSubscriptionId = "3d9f4c5d-536d-4252-b653-1928e7d0ccb0"
#$ProjectName           = "Azuremigrate-AM-CUS-VMwareEOL"
#$ProjectRG             = "RG-AM-CUS-Prod-AzureMigrateCUS"

#$ProjectSubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3"
#$ProjectName           = "AzmigEUUKSVMPub"
#$ProjectRG             = "rg-eu-uks-nonprod-azmigrateukspub"

#$ProjectSubscriptionId = "3c33b258-6a1b-498c-9dd7-2e4b52ff16dc"
#$ProjectName           = "AzmigVMEOLSAPxtra"
#$ProjectRG             = "RG-AM-EastUS-NonProd-AZMigrate2"

#$ProjectSubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612"
#$ProjectName           = "AzmigAPSEAVMEOL"
#$ProjectRG             = "rg-ap-sea-nonprod-azuremigratesea"

#$ProjectSubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612"
#$ProjectName           = "AzmigAPSEAVMPUB"
#$ProjectRG             = "rg-ap-sea-nonprod-azuremigratesea"


# ===================== MODULES =====================
Import-Module Az.Accounts, Az.Migrate

# Resolve NIC IP parameter name across Az.Migrate module versions.
$nicMappingIpParam = if ((Get-Command New-AzMigrateNicMapping).Parameters.ContainsKey('TargetNicIP')) { 'TargetNicIP' } else { 'TargetStaticIPAddress' }

# ===================== VALIDATE PROJECT =====================
Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null
Write-Host "`n🔄 Project subscription: $ProjectSubscriptionId" -ForegroundColor Cyan

try {
    $Project = Get-AzMigrateProject -Name $ProjectName -ResourceGroupName $ProjectRG -ErrorAction Stop
    Write-Host "✅ Project: $($Project.Name) in RG $ProjectRG" -ForegroundColor Green
}
catch {
    Write-Error "Azure Migrate project not found. $_"
    return
}

# ===================== LOAD CSV =====================
if (-not (Test-Path -Path $CsvPath)) {
    Write-Error "CSV not found: $CsvPath"
    return
}

$VMs = Import-Csv $CsvPath
Write-Host "📋 Loaded $($VMs.Count) VM(s) from CSV`n" -ForegroundColor Green

# ===================== RESULTS TRACKING =====================
$Results = @()
$SuccessCount = 0
$FailCount    = 0
$SkipCount    = 0

function Get-SecondaryTargetIPs {
    param(
        [Parameter(Mandatory)]
        [pscustomobject]$Row
    )

    $secondaryIPs = @()

    if ($Row.PSObject.Properties.Name -contains 'SecondaryTargetIP') {
        $aliasValue = [string]$Row.SecondaryTargetIP
        if (-not [string]::IsNullOrWhiteSpace($aliasValue)) {
            $secondaryIPs += $aliasValue.Trim()
        }
    }

    $indexedSecondaryColumns = $Row.PSObject.Properties.Name |
        Where-Object { $_ -match '^SecondaryIP(\d+)$' } |
        Sort-Object { [int]([regex]::Match($_, '\d+').Value) }

    foreach ($columnName in $indexedSecondaryColumns) {
        $columnValue = [string]$Row.$columnName
        if (-not [string]::IsNullOrWhiteSpace($columnValue)) {
            $secondaryIPs += $columnValue.Trim()
        }
    }

    return ,$secondaryIPs
}

# ===================== MAIN LOOP =====================
foreach ($VM in $VMs) {
    $vmName  = $VM.VMName.Trim()
    $targetIP = if ($null -ne $VM.TargetIP) { ([string]$VM.TargetIP).Trim() } else { '' }
    $secondaryTargetIPs = Get-SecondaryTargetIPs -Row $VM

    if ([string]::IsNullOrWhiteSpace($vmName)) {
        Write-Host "⚠️  Skipping row: VMName is empty" -ForegroundColor Yellow
        $SkipCount++
        continue
    }

    if ([string]::IsNullOrWhiteSpace($targetIP) -and $secondaryTargetIPs.Count -eq 0) {
        Write-Host "⚠️  Skipping $vmName : no primary or secondary Target IP provided" -ForegroundColor Yellow
        $SkipCount++
        $Results += [PSCustomObject]@{ VMName = $vmName; TargetIP = ""; Status = "Skipped - No IP"; Details = "No TargetIP or SecondaryIP values provided" }
        continue
    }

    Write-Host "=== $vmName ===" -ForegroundColor Yellow

    try {
        # ---------- STEP 1: GET REPLICATING SERVER ----------
        $replicatingServer = Get-AzMigrateServerReplication `
            -ProjectName       $ProjectName `
            -ResourceGroupName $ProjectRG `
            -MachineName       $vmName

        if (-not $replicatingServer) {
            throw "VM '$vmName' not found in Azure Migrate replicating servers."
        }

        # Get full object with provider-specific details
        $replicatingServer = Get-AzMigrateServerReplication -TargetObjectID $replicatingServer.Id
        $ps = $replicatingServer.ProviderSpecificDetail

        Write-Host "  ✅ Found replicating VM: $($replicatingServer.MachineName) | State: $($replicatingServer.MigrationState)" -ForegroundColor Green

        # ---------- STEP 2: BUILD NIC MAPPING WITH NEW IP ----------
        if (-not $ps.VMNic -or $ps.VMNic.Count -eq 0) {
            throw "No NICs found on replicating server '$vmName'."
        }

        $NicMappings = @()
        $primaryUpdated = $false
        $secondaryNicIndex = 0

        foreach ($nic in $ps.VMNic) {
            $nicParams = @{
                NicID = $nic.NicId
            }

            if ($nic.IsPrimaryNic -eq "true" -or $nic.IsPrimaryNic -eq $true) {
                if (-not [string]::IsNullOrWhiteSpace($targetIP)) {
                    # Update primary NIC with the new Target IP
                    $nicParams[$nicMappingIpParam] = $targetIP
                    $primaryUpdated = $true
                    Write-Host "  🌐 Primary NIC: $($nic.NicId) | Current IP: $($nic.TargetIPAddress) → New IP: $targetIP" -ForegroundColor Cyan
                }
                else {
                    if (-not [string]::IsNullOrWhiteSpace($nic.TargetIPAddress)) {
                        $nicParams[$nicMappingIpParam] = $nic.TargetIPAddress
                    }
                    Write-Host "  ℹ️  Primary NIC: $($nic.NicId) | IP unchanged: $($nic.TargetIPAddress)" -ForegroundColor Gray
                }
            }
            else {
                $newSecondaryIP = if ($secondaryNicIndex -lt $secondaryTargetIPs.Count) { $secondaryTargetIPs[$secondaryNicIndex] } else { $null }
                if (-not [string]::IsNullOrWhiteSpace($newSecondaryIP)) {
                    $nicParams[$nicMappingIpParam] = $newSecondaryIP
                    Write-Host "  🌐 Secondary NIC $($secondaryNicIndex + 1): $($nic.NicId) | Current IP: $($nic.TargetIPAddress) → New IP: $newSecondaryIP" -ForegroundColor Cyan
                }
                else {
                    # Keep existing IP for non-primary NICs when no override is supplied.
                    if (-not [string]::IsNullOrWhiteSpace($nic.TargetIPAddress)) {
                        $nicParams[$nicMappingIpParam] = $nic.TargetIPAddress
                    }
                    Write-Host "  ℹ️  Secondary NIC $($secondaryNicIndex + 1): $($nic.NicId) | IP unchanged: $($nic.TargetIPAddress)" -ForegroundColor Gray
                }
                $secondaryNicIndex++
            }

            $NicMappings += New-AzMigrateNicMapping @nicParams
        }

        if (-not $primaryUpdated -and -not [string]::IsNullOrWhiteSpace($targetIP)) {
            Write-Host "  ⚠️  No primary NIC detected — updating first NIC as fallback" -ForegroundColor Yellow
            # Rebuild first NIC mapping with the target IP
            $firstNic = $ps.VMNic[0]
            $fallbackNicParams = @{ NicID = $firstNic.NicId }
            $fallbackNicParams[$nicMappingIpParam] = $targetIP
            $NicMappings[0] = New-AzMigrateNicMapping @fallbackNicParams
        }

        if ($secondaryTargetIPs.Count -gt $secondaryNicIndex) {
            Write-Host "  ⚠️  $($secondaryTargetIPs.Count - $secondaryNicIndex) secondary IP value(s) were provided but no matching NIC was found" -ForegroundColor Yellow
        }

        # ---------- STEP 3: APPLY UPDATE ----------
        Write-Host "  🚀 Updating Target IP..." -ForegroundColor Cyan

        $updateJob = Set-AzMigrateServerReplication `
            -InputObject $replicatingServer `
            -NicToUpdate $NicMappings

        # ---- SAFE NORMALIZATION ----
        if ($updateJob -is [array]) {
            $updateJob = $updateJob | Select-Object -First 1
        }

        if ($updateJob -is [bool] -or $null -eq $updateJob) {
            Write-Host "  ✅ $vmName → Target IP updated to $targetIP (no job returned)" -ForegroundColor Green
            $SuccessCount++
            $Results += [PSCustomObject]@{ VMName = $vmName; TargetIP = $targetIP; Status = "Success"; Details = "No job returned - assumed success" }
            continue
        }

        # ---------- STEP 4: MONITOR JOB ----------
        Write-Host "  ⏳ Job: $($updateJob.Id.Split('/')[-1])" -ForegroundColor Magenta
        do {
            Start-Sleep -Seconds 5
            $updateJob = Get-AzMigrateJob -InputObject $updateJob

            if ($updateJob -is [array]) {
                $updateJob = $updateJob | Select-Object -First 1
            }
        } while ($updateJob.State -in @('InProgress', 'NotStarted'))

        if ($updateJob.State -eq 'Succeeded') {
            Write-Host "  ✅ $vmName → Target IP updated to $targetIP" -ForegroundColor Green
            $SuccessCount++
            $Results += [PSCustomObject]@{ VMName = $vmName; TargetIP = $targetIP; Status = "Success"; Details = "Job completed successfully" }
        }
        else {
            Write-Host "  ❌ $vmName → Update FAILED (State: $($updateJob.State))" -ForegroundColor Red
            $FailCount++
            $Results += [PSCustomObject]@{ VMName = $vmName; TargetIP = $targetIP; Status = "Failed"; Details = "Job state: $($updateJob.State)" }
        }
    }
    catch {
        Write-Host "  ❌ $vmName : $($_.Exception.Message)" -ForegroundColor Red
        $FailCount++
        $Results += [PSCustomObject]@{ VMName = $vmName; TargetIP = $targetIP; Status = "Error"; Details = $_.Exception.Message }
    }

    Start-Sleep -Seconds 3
}

# ===================== SUMMARY =====================
Write-Host "`n╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║        TARGET IP UPDATE SUMMARY          ║" -ForegroundColor Cyan
Write-Host "╠══════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host "║  Total VMs   : $($VMs.Count)".PadRight(43) + "║" -ForegroundColor Cyan
Write-Host "║  ✅ Success  : $SuccessCount".PadRight(43) + "║" -ForegroundColor Green
Write-Host "║  ❌ Failed   : $FailCount".PadRight(43) + "║" -ForegroundColor Red
Write-Host "║  ⚠️  Skipped  : $SkipCount".PadRight(43) + "║" -ForegroundColor Yellow
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan

# ===================== EXPORT RESULTS =====================
$OutputCsv = $CsvPath -replace '\.csv$', '-Results.csv'
$Results | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "`n📄 Results exported to: $OutputCsv" -ForegroundColor Green

Write-Host "`n✅ Batch complete — verify Target IPs in Azure Migrate portal." -ForegroundColor Green
