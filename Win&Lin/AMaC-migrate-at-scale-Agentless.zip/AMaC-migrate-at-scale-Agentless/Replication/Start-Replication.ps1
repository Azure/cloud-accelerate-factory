<#
.SYNOPSIS
    Starts Azure Migrate agentless replication for VMware VMs using CSV input.
    Need PowerShell version 7.5.X

.DESCRIPTION
    This script enables agentless replication for on-premises VMware VMs discovered
    by an Azure Migrate project. It:
      - Validates the Azure Migrate project in the specified project subscription.
      - Reads VM configuration from a CSV file (one row per VM).
      - For each VM, retrieves the discovered server object from the Azure Migrate project.
      - Automatically identifies the OS disk from the discovered server (first disk).
      - Switches to the target subscription to resolve target Resource Group, VNet and subnets.
      - Starts replication using New-AzMigrateServerReplication, pointing to the target
        resource IDs (cross-subscription supported within the same tenant).
      - Monitors each replication job until it completes (Succeeded / Failed).

    The script assumes:
      - The Azure Migrate project is created and configured for agentless VMware.
      - The appliance has discovered the VMs listed in the CSV.
      - The project and target subscriptions are in the same Azure AD tenant.
      - The first disk in the discovered server object represents the OS disk.

.EXAMPLE
    # Configure variables at the top of the script:
    #   - $CsvPath
    #   - $ProjectSubscriptionId
    #   - $ProjectName
    #   - $ProjectRG
    #   - $DefaultTargetSubscriptionId
    # Then run: PS C:\> .\Start-Replication.ps1

.EXAMPLE
    # Run from a different working directory:
    PS C:\> cd 'C:\Scripts'
    PS C:\Scripts> .\Start-Replication.ps1
.OUTPUTS
    None (no objects are emitted to the pipeline).
    The script writes human-readable status messages to the host, including:
      - Project validation status.
      - Per-VM discovery status.
      - Target subscription, RG, VNet and subnet resolution.
      - Replication job state transitions until completion.

.NOTES
    CSV required columns (in this exact order):
        VMName
        TargetVMName
        ApplianceName
        TargetSubscriptionId   # optional; if empty, $DefaultTargetSubscriptionId is used
        TargetRG
        TargetVNet
        TargetSubnet
        TestVNet
        TestSubnet
        TargetVMSize
        TargetDiskType         # e.g., Premium_LRS (Premium SSD), StandardSSD_LRS (Standard SSD), Standard_LRS (Standard HDD)
        LicType                # e.g., WindowsServer or NoLicenseType
        Tags                   #TagName1,TagValue1,TagName2,TagValue2

#>
#Get-Command New-AzMigrateServerReplication | Select-Object -ExpandProperty Parameters
# ===================== USER CONFIG =====================

$CsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\Start-Replication.csv"

# Azure Migrate project (in PROD subscription)
$ProjectSubscriptionId = "3d9f4c5d-536d-4252-b653-1928e7d0ccb0"                  # e.g. the ELC-AM-CUS-PROD subscription ID
$ProjectName           = "Azuremigrate-AM-CUS-VMwareEOL"
$ProjectRG             = "RG-AM-CUS-Prod-AzureMigrateCUS"    # exact RG name from Get-AzResourceGroup

# Target subscription (Prod/NONPROD); per-VM TargetSubscriptionId in CSV overrides this if populated.
$DefaultTargetSubscriptionId = "xxxxxxx"

# ===================== MODULES =====================

Import-Module Az.Accounts
Import-Module Az.Migrate
Import-Module Az.Network
Import-Module Az.Resources

# ===================== VALIDATE PROJECT =====================

Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null
Write-Host "🔄 Project subscription: $ProjectSubscriptionId" -ForegroundColor Cyan

try {
    $Project = Get-AzMigrateProject -Name $ProjectName -ResourceGroupName $ProjectRG -ErrorAction Stop
    Write-Host "✅ Project: $($Project.Name) in RG $ProjectRG" -ForegroundColor Green
}
catch {
    Write-Error "Azure Migrate project not found. $_"
    return
}

# ===================== LOAD CSV =====================

if (-not (Test-Path -Path $CsvPath)) {
    Write-Error "CSV not found: $CsvPath"
    return
}

$VMs = Import-Csv $CsvPath
Write-Host "📋 Loaded $($VMs.Count) VM rows from CSV" -ForegroundColor Green

# ===================== MAIN LOOP =====================

foreach ($VM in $VMs) {

    if ([string]::IsNullOrWhiteSpace($VM.VMName)) { continue }

    Write-Host "`n=== $($VM.VMName) ===" -ForegroundColor Yellow

    try {
        # ---------- STEP 1: PROJECT SUB (DISCOVERY) ----------

        Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null

        $DiscoveredServer = Get-AzMigrateDiscoveredServer `
            -ProjectName       $ProjectName `
            -ResourceGroupName $ProjectRG `
            -ApplianceName     $VM.ApplianceName `
            -DisplayName       $VM.VMName `
            -ErrorAction       Stop

        Write-Host "✅ Discovered: $($DiscoveredServer.DisplayName)" -ForegroundColor Green

        if (-not $DiscoveredServer.Disk -or $DiscoveredServer.Disk.Count -eq 0) {
            throw "No disks found on discovered server."
        }

        # ---------- STEP 2: TARGET SUB (RESOLVE RG / VNets) ----------

        $ThisTargetSub = if ([string]::IsNullOrWhiteSpace($VM.TargetSubscriptionId)) {
            $DefaultTargetSubscriptionId
        } else { $VM.TargetSubscriptionId }

        Set-AzContext -SubscriptionId $ThisTargetSub | Out-Null
        Write-Host "🌐 Target subscription: $ThisTargetSub" -ForegroundColor Cyan

        $TargetRG = Get-AzResourceGroup -Name $VM.TargetRG -ErrorAction Stop
        Write-Host "✅ Target RG: $($TargetRG.ResourceGroupName)" -ForegroundColor Green

        $TargetVNet   = Get-AzVirtualNetwork -Name $VM.TargetVNet -ErrorAction Stop
        $TargetSubnet = $TargetVNet.Subnets | Where-Object { $_.Name -eq $VM.TargetSubnet }
        if (-not $TargetSubnet) { throw "Target subnet not found." }

        $TestVNet   = Get-AzVirtualNetwork -Name $VM.TestVNet -ErrorAction Stop
        $TestSubnet = $TestVNet.Subnets | Where-Object { $_.Name -eq $VM.TestSubnet }
        if (-not $TestSubnet) { throw "Test subnet not found." }

        Write-Host "✅ Target VNet/Subnet: $($TargetVNet.Name)/$($TargetSubnet.Name)" -ForegroundColor Green
        Write-Host "✅ Test VNet/Subnet:   $($TestVNet.Name)/$($TestSubnet.Name)" -ForegroundColor Green

        $TargetRgId   = $TargetRG.ResourceId
        $TargetVnetId = $TargetVNet.Id
        $TestVnetId   = $TestVNet.Id

        # ---------- STEP 3: PREPARE VM TAGS (for replicating VM) ----------

        $VMTags = @{}
        # TAG 1
        if (-not [string]::IsNullOrWhiteSpace($VM.TagName1) -and -not [string]::IsNullOrWhiteSpace($VM.TagValue1)) {
            $VMTags[$VM.TagName1] = $VM.TagValue1
            Write-Host "🏷️  VM Tag1: $($VM.TagName1)=$($VM.TagValue1)" -ForegroundColor Cyan
        }

        # TAG 2
        if (-not [string]::IsNullOrWhiteSpace($VM.TagName2) -and -not [string]::IsNullOrWhiteSpace($VM.TagValue2)) {
            $VMTags[$VM.TagName2] = $VM.TagValue2
            Write-Host "🏷️  VM Tag2: $($VM.TagName2)=$($VM.TagValue2)" -ForegroundColor Cyan
        }

        

        # ---------- STEP 4: AUTOMATIC DISK MAPPING ----------

        $DisksToInclude = @()
        foreach ($disk in $DiscoveredServer.Disk) {

            $isOsDisk = $false
            # Detect OS disk automatically
            if ($disk.IsOSDisk -eq $true) {
                $isOsDisk = $true
            } elseif (-not ($DisksToInclude | Where-Object { $_.IsOSDisk })) {
                # fallback: first disk is OS if none marked
                $isOsDisk = $true
            }

            $DiskMapping = New-AzMigrateDiskMapping -DiskID $disk.Uuid `
                                        -DiskType $VM.TargetDiskType `
                                        -IsOSDisk $isOsDisk
            $DisksToInclude += $DiskMapping
        }

        # ---------- STEP 5: START REPLICATION ----------

        Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null
        Write-Host "🚀 Starting replication..." -ForegroundColor Cyan

        $RepJob = New-AzMigrateServerReplication -InputObject $DiscoveredServer `
            -TargetResourceGroupId $TargetRgId `
            -TargetNetworkId       $TargetVnetId `
            -TargetSubnetName      $TargetSubnet.Name `
            -TargetVMName          $VM.TargetVMName `
            -TargetVMSize          $VM.TargetVMSize `
            -LicenseType           $VM.LicType `
            -TestNetworkId         $TestVnetId `
            -TestSubnetName        $TestSubnet.Name `
            -DiskToInclude         $DisksToInclude `
            -Tag                   $VMTags  # 

            Write-Host "✅ VM tags applied during replication: $($VMTags.Keys -join ', ')" -ForegroundColor Green

        # ---------- STEP 6: MONITOR JOB ----------

        Write-Host "⏳ Job: $($RepJob.Id.Split('/')[-1])" -ForegroundColor Magenta
        do {
            Start-Sleep -Seconds 10
            $RepJob = Get-AzMigrateJob -InputObject $RepJob
            $color = switch ($RepJob.State) {
                'Succeeded' { 'Green' }
                'Failed'    { 'Red' }
                default     { 'Yellow' }
            }
            Write-Host "Status: $($RepJob.State)" -ForegroundColor $color
        } while ($RepJob.State -in @('InProgress','NotStarted'))

        if ($RepJob.State -eq 'Succeeded') {
            Write-Host "✅ $($VM.VMName) replication enabled" -ForegroundColor Green
        } else {
            Write-Host "$($VM.VMName) replication job ended with state: $($RepJob.State)" -ForegroundColor Red
        }

    } catch {
        Write-Host "$($VM.VMName): $($_.Exception.Message)" -ForegroundColor Red
    }

    Start-Sleep -Seconds 5
}

Write-Host "`nBatch complete – verify replication and tags in Azure Migrate portal." -ForegroundColor Green