<#
.SYNOPSIS
    Starts Azure Migrate agentless replication for VMware VMs using CSV input.
    Need PowerShell version 7.5.X

.DESCRIPTION
    This script enables agentless replication for on-premises VMware VMs discovered
    by an Azure Migrate project. It handles:
      - Blank TargetVMSize → Auto-suggested SKU by Azure Migrate
      - Blank TestVNet/TestSubnet → Skips test network params
      - Automatic OS disk detection (first explicit IsOSDisk or first disk)
      - **VM TAGS applied during replication** (TagName1/TagValue1, TagName2/TagValue2)

.NOTES
    CSV columns (exact order):
        VMName | TargetVMName | ApplianceName | TargetSubscriptionId | TargetRG | TargetVNet | TargetSubnet | TestVNet | TestSubnet | TargetVMSize | TargetDiskType | LicType | TagName1 | TagValue1 | TagName2 | TagValue2
    Optional: TargetSubscriptionId, TestVNet/TestSubnet, TargetVMSize (blank=auto), Tags (blank=skip)
        TargetDiskType         # e.g., Premium_LRS (Premium SSD), StandardSSD_LRS (Standard SSD), Standard_LRS (Standard HDD)
        LicType                # e.g., WindowsServer or NoLicenseType
        Tags                   #TagName1,TagValue1,TagName2,TagValue2
#>

# ===================== USER CONFIG =====================
$CsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\Start-Replication-ch.csv"

# Azure Migrate project
#$ProjectSubscriptionId = "3d9f4c5d-536d-4252-b653-1928e7d0ccb0"                  
#$ProjectName           = "Azuremigrate-AM-CUS-VMwareEOL"
#$ProjectRG             = "RG-AM-CUS-Prod-AzureMigrateCUS"   

$ProjectSubscriptionId = "93be8cec-1449-48fd-8b0d-64a650f2f826"                  
$ProjectName           = "Azuremigrate-CN3-NONPROD-VMwareEOL"
$ProjectRG             = "rg-cn-cn3-nonprod-azuremigrate"  

# Target subscription default (CSV overrides per VM)
$DefaultTargetSubscriptionId = "xxxxxxx"

# ===================== MODULES =====================
Import-Module Az.Accounts, Az.Migrate, Az.Network, Az.Resources

# ===================== VALIDATE PROJECT =====================
Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null
Write-Host "🔄 Project subscription: $ProjectSubscriptionId" -ForegroundColor Cyan

try {
    $Project = Get-AzMigrateProject -Name $ProjectName -ResourceGroupName $ProjectRG -ErrorAction Stop
    Write-Host "✅ Project: $($Project.Name) in RG $ProjectRG" -ForegroundColor Green
}
catch {
    Write-Error "Azure Migrate project not found. $_"
    return
}

# ===================== LOAD CSV =====================
if (-not (Test-Path -Path $CsvPath)) {
    Write-Error "CSV not found: $CsvPath"
    return
}

$VMs = Import-Csv $CsvPath
Write-Host "📋 Loaded $($VMs.Count) VM rows from CSV" -ForegroundColor Green

# ===================== MAIN LOOP =====================
foreach ($VM in $VMs) {
    if ([string]::IsNullOrWhiteSpace($VM.VMName)) { continue }

    Write-Host "`n=== $($VM.VMName) ===" -ForegroundColor Yellow

    try {
        # ---------- STEP 1: PROJECT SUB (DISCOVERY) ----------
        Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null

        $DiscoveredServer = Get-AzMigrateDiscoveredServer `
            -ProjectName       $ProjectName `
            -ResourceGroupName $ProjectRG `
            -ApplianceName     $VM.ApplianceName `
            -DisplayName       $VM.VMName `
            -ErrorAction       Stop

        Write-Host "✅ Discovered: $($DiscoveredServer.DisplayName)" -ForegroundColor Green

        if (-not $DiscoveredServer.Disk -or $DiscoveredServer.Disk.Count -eq 0) {
            throw "No disks found on discovered server."
        }

        # ---------- STEP 2: TARGET SUB (RESOLVE RG / VNets) ----------
        $ThisTargetSub = if ([string]::IsNullOrWhiteSpace($VM.TargetSubscriptionId)) {
            $DefaultTargetSubscriptionId
        } else { $VM.TargetSubscriptionId }

        Set-AzContext -SubscriptionId $ThisTargetSub | Out-Null
        Write-Host "🌐 Target subscription: $ThisTargetSub" -ForegroundColor Cyan

        $TargetRG = Get-AzResourceGroup -Name $VM.TargetRG -ErrorAction Stop
        Write-Host "✅ Target RG: $($TargetRG.ResourceGroupName)" -ForegroundColor Green

        $TargetVNet   = Get-AzVirtualNetwork -Name $VM.TargetVNet -ErrorAction Stop
        $TargetSubnet = $TargetVNet.Subnets | Where-Object { $_.Name -eq $VM.TargetSubnet }
        if (-not $TargetSubnet) { throw "Target subnet not found." }

        $TargetRgId   = $TargetRG.ResourceId
        $TargetVnetId = $TargetVNet.Id

        # ---------- TEST NETWORK: CONDITIONAL ----------
        $useTestNetwork = -not ([string]::IsNullOrWhiteSpace($VM.TestVNet) -and [string]::IsNullOrWhiteSpace($VM.TestSubnet))
        if ($useTestNetwork) {
            $TestVNet   = Get-AzVirtualNetwork -Name $VM.TestVNet -ErrorAction Stop
            $TestSubnet = $TestVNet.Subnets | Where-Object { $_.Name -eq $VM.TestSubnet }
            if (-not $TestSubnet) { throw "Test subnet '$($VM.TestSubnet)' not found." }
            $TestVnetId = $TestVNet.Id
            Write-Host "✅ Test VNet/Subnet: $($TestVNet.Name)/$($TestSubnet.Name)" -ForegroundColor Green
        } else {
            Write-Host "⚠️  TestVNet/TestSubnet blank → Skipping test network" -ForegroundColor Yellow
            $TestVnetId = $null
        }

        Write-Host "✅ Target VNet/Subnet: $($TargetVNet.Name)/$($TargetSubnet.Name)" -ForegroundColor Green

        # ---------- STEP 3: AUTOMATIC DISK MAPPING ----------
        $DisksToInclude = @()
        foreach ($disk in $DiscoveredServer.Disk) {
            $isOsDisk = $false
            # Detect OS disk automatically
            if ($disk.IsOSDisk -eq $true) {
                $isOsDisk = $true
            } elseif (-not ($DisksToInclude | Where-Object { $_.IsOSDisk })) {
                # fallback: first disk is OS if none marked
                $isOsDisk = $true
            }

            $DiskMapping = New-AzMigrateDiskMapping -DiskID $disk.Uuid `
                                        -DiskType $VM.TargetDiskType `
                                        -IsOSDisk $isOsDisk
            $DisksToInclude += $DiskMapping
        }

        # ---------- STEP 4: PREPARE VM TAGS (NEW - APPLIES TO REPLICATED VM) ----------
        $VMTags = @{}
        
        # Tag 1 
        if (-not [string]::IsNullOrWhiteSpace($VM.TagName1) -and -not [string]::IsNullOrWhiteSpace($VM.TagValue1)) {
            $VMTags[$VM.TagName1] = $VM.TagValue1
            Write-Host "🏷️  VM Tag1: $($VM.TagName1)=$($VM.TagValue1)" -ForegroundColor Cyan
        }
        
        # Tag 2  
        if (-not [string]::IsNullOrWhiteSpace($VM.TagName2) -and -not [string]::IsNullOrWhiteSpace($VM.TagValue2)) {
            $VMTags[$VM.TagName2] = $VM.TagValue2
            Write-Host "🏷️  VM Tag2: $($VM.TagName2)=$($VM.TagValue2)" -ForegroundColor Cyan
        }

        if ($VMTags.Count -gt 0) {
            Write-Host "✅ VM tags prepared: $($VMTags.Keys -join ', ')" -ForegroundColor Green
        } else {
            Write-Host "ℹ️  No VM tags specified" -ForegroundColor Gray
        }

        # ---------- STEP 5: START REPLICATION WITH VM TAGS ----------
        Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null
        Write-Host "🚀 Starting replication WITH VM TAGS..." -ForegroundColor Cyan

        # Dynamic splat for optional params
        $repParams = @{
            InputObject            = $DiscoveredServer
            TargetResourceGroupId  = $TargetRgId
            TargetNetworkId        = $TargetVnetId
            TargetSubnetName       = $TargetSubnet.Name
            TargetVMName           = $VM.TargetVMName
            LicenseType            = $VM.LicType
            DiskToInclude          = $DisksToInclude
        }

        # VM TAGS - NEW!
        if ($VMTags.Count -gt 0) {
            $repParams.Tag = $VMTags
        }

        # TargetVMSize: optional (blank = auto-suggest)
        if (-not [string]::IsNullOrWhiteSpace($VM.TargetVMSize)) {
            $repParams.TargetVMSize = $VM.TargetVMSize
            Write-Host "✅ TargetVMSize: $($VM.TargetVMSize)" -ForegroundColor Green
        } else {
            Write-Host "ℹ️  TargetVMSize blank → Using auto-suggested SKU" -ForegroundColor Cyan
        }

        # Test network: conditional
        if ($useTestNetwork) {
            $repParams.TestNetworkId  = $TestVnetId
            $repParams.TestSubnetName = $TestSubnet.Name
        }

        $RepJob = New-AzMigrateServerReplication @repParams

        # ---------- STEP 6: MONITOR JOB ----------
        Write-Host "⏳ Job: $($RepJob.Id.Split('/')[-1])" -ForegroundColor Magenta
        do {
            Start-Sleep -Seconds 10
            $RepJob = Get-AzMigrateJob -InputObject $RepJob
            $color = switch ($RepJob.State) {
                'Succeeded' { 'Green' }
                'Failed'    { 'Red' }
                default     { 'Yellow' }
            }
            Write-Host "Status: $($RepJob.State)" -ForegroundColor $color
        } while ($RepJob.State -in @('InProgress','NotStarted'))

        if ($RepJob.State -eq 'Succeeded') {
            Write-Host "✅ $($VM.VMName) replication enabled WITH TAGS" -ForegroundColor Green
        } else {
            Write-Host "$($VM.VMName) replication job ended with state: $($RepJob.State)" -ForegroundColor Red
        }

    } catch {
        Write-Host "$($VM.VMName): $($_.Exception.Message)" -ForegroundColor Red
    }

    Start-Sleep -Seconds 5
}

Write-Host "`nBatch complete – verify replication AND VM TAGS in Azure Migrate portal." -ForegroundColor Green
