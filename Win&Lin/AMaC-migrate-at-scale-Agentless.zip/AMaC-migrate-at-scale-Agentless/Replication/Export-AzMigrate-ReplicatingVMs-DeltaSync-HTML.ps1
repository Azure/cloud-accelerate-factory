<#
.SYNOPSIS
Exports Azure Migrate replicating VM delta-sync status to an HTML report.

.DESCRIPTION
Creates a point-in-time HTML report for replicating VMs with:
1) VM Name
2) Delta Sync status
3) Last Delta Sync time
4) Sync age in hours

Color rules:
- Green: age < 2.5 hours
- Yellow: age 4 to 6 hours
- Red: age > 6 hours

Anything between 2.5 and 4 hours is shown in neutral style.

.NOTES
- Author: Deepak Tyagi
- Requires Az.Accounts and Az.Migrate modules.

.EXAMPLE
.\Export-AzMigrate-ReplicatingVMs-DeltaSync-HTML.ps1

.EXAMPLE
Edit CONFIG values in script, then run:
.\Export-AzMigrate-ReplicatingVMs-DeltaSync-HTML.ps1
#>

# ==================== CONFIG ====================
<#
$SubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3"
$ResourceGroupName = "rg-eu-uks-nonprod-azuremigrateuks"
$ProjectName = "AzmigEUUKSVMEOL"
#>

$SubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612"
$ResourceGroupName = "rg-ap-sea-nonprod-azuremigratesea"
$ProjectName = "AzmigAPSEAVMEOL"


$ServerCsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\ServerNames-Mig.csv"

$OutputPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File"
# ================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Convert-ToHtmlText {
    param([object]$Value)

    if ($null -eq $Value) { return "" }

    $text = [string]$Value
    $text = $text.Replace("&", "&amp;")
    $text = $text.Replace("<", "&lt;")
    $text = $text.Replace(">", "&gt;")
    $text = $text.Replace('"', "&quot;")
    return $text
}

function Get-FirstValue {
    param(
        [object]$InputObject,
        [string[]]$PropertyNames
    )

    if ($null -eq $InputObject) { return $null }

    foreach ($propertyName in $PropertyNames) {
        if ($InputObject.PSObject.Properties.Name -contains $propertyName) {
            $value = $InputObject.$propertyName
            if ($null -ne $value -and "${value}".Trim() -ne "") {
                return $value
            }
        }
    }

    return $null
}

function Get-ServerNameFromCsvRow {
  param([object]$Row)

  return Get-FirstValue -InputObject $Row -PropertyNames @(
    "VMName",
    "MachineName",
    "ServerName",
    "ComputerName",
    "Name"
  )
}

try {
    Import-Module Az.Accounts -ErrorAction Stop
    Import-Module Az.Migrate -ErrorAction Stop
}
catch {
    Write-Host "Failed to load Az modules. Install/update Az.Accounts and Az.Migrate." -ForegroundColor Red
    throw
}

if (-not (Get-AzContext)) {
    Write-Host "No Azure context found. Running Connect-AzAccount..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

if (-not [string]::IsNullOrWhiteSpace($SubscriptionId)) {
  try {
    Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
  }
  catch {
    Write-Host "Current session cannot access subscription $SubscriptionId. Trying interactive login..." -ForegroundColor Yellow
    Connect-AzAccount -Subscription $SubscriptionId -ErrorAction Stop | Out-Null
    Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
  }
}

$null = Get-AzMigrateProject -ResourceGroupName $ResourceGroupName -Name $ProjectName -ErrorAction Stop

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = Join-Path -Path (Get-Location) -ChildPath ("AzureMigrate-ReplicatingVMs-DeltaSync-{0}.html" -f $timestamp)
}
elseif ((Test-Path -Path $OutputPath -PathType Container) -or ([System.IO.Path]::GetExtension($OutputPath) -eq "")) {
  if (-not (Test-Path -Path $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
  }
  $OutputPath = Join-Path -Path $OutputPath -ChildPath ("AzureMigrate-ReplicatingVMs-DeltaSync-{0}.html" -f $timestamp)
}

$reportTime = Get-Date

$serverOrderLookup = $null
if (-not [string]::IsNullOrWhiteSpace($ServerCsvPath)) {
  if (-not (Test-Path -Path $ServerCsvPath -PathType Leaf)) {
    throw "Server CSV not found: $ServerCsvPath"
  }

  $serverOrderLookup = [System.Collections.Generic.Dictionary[string, int]]::new([System.StringComparer]::OrdinalIgnoreCase)
  $serverCsvRows = Import-Csv -Path $ServerCsvPath
  $serverIndex = 0

  foreach ($serverRow in $serverCsvRows) {
    $serverName = Get-ServerNameFromCsvRow -Row $serverRow
    if (-not [string]::IsNullOrWhiteSpace($serverName)) {
      $serverName = $serverName.Trim()
      if (-not $serverOrderLookup.ContainsKey($serverName)) {
        $serverOrderLookup[$serverName] = $serverIndex
        $serverIndex++
      }
    }
  }

  if ($serverOrderLookup.Count -eq 0) {
    throw "Server CSV does not contain any usable server names. Expected a column like VMName, MachineName, ServerName, ComputerName, or Name."
  }
}

$replicationItems = Get-AzMigrateServerReplication -ResourceGroupName $ResourceGroupName -ProjectName $ProjectName
$rows = @()

foreach ($item in $replicationItems) {
  if ($null -ne $serverOrderLookup -and -not $serverOrderLookup.ContainsKey([string]$item.MachineName)) {
    continue
  }

    $detail = Get-AzMigrateServerReplication -TargetObjectID $item.Id
    $providerDetail = $detail.ProviderSpecificDetail

    $migrationState = [string](Get-FirstValue -InputObject $detail -PropertyNames @("MigrationState"))
    $replicationStatus = [string](Get-FirstValue -InputObject $detail -PropertyNames @("ReplicationStatus"))
    $gatewayState = [string](Get-FirstValue -InputObject $providerDetail -PropertyNames @("GatewayOperationDetailState"))

    # Keep only replicating VMs with delta-sync or initial replication relevant rows.
    if (
        $migrationState -ne "Replicating" -and
      $replicationStatus -notmatch "Delta|Replicat|Initial" -and
      $gatewayState -notmatch "Delta|Initial"
    ) {
        continue
    }

    $lastDeltaSyncRaw = Get-FirstValue -InputObject $providerDetail -PropertyNames @("LastRecoveryPointReceived")
    $lastDeltaSyncLocal = "N/A"
    $ageHours = $null

    if ($lastDeltaSyncRaw) {
        try {
            $dto = [DateTimeOffset]$lastDeltaSyncRaw
            $lastDeltaSyncLocal = $dto.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss zzz")
            $ageHours = [Math]::Round((([DateTimeOffset]::UtcNow - $dto.ToUniversalTime()).TotalHours), 2)
            if ($ageHours -lt 0) { $ageHours = $null }
        }
        catch {
            $lastDeltaSyncLocal = [string]$lastDeltaSyncRaw
            $ageHours = $null
        }
    }

      $initialReplicationPercentRaw = Get-FirstValue -InputObject $providerDetail -PropertyNames @(
        "InitialReplicationProgressPercentage",
        "InitialSeedingProgressPercentage",
        "ResyncProgressPercentage",
        "ResynchronizationProgressPercentage",
        "ProgressPercentage"
      )

      $initialReplicationPercent = "N/A"
      if ($null -ne $initialReplicationPercentRaw -and "${initialReplicationPercentRaw}".Trim() -ne "") {
        $percentNumber = $null

        if ($initialReplicationPercentRaw -is [ValueType]) {
          $percentNumber = [double]$initialReplicationPercentRaw
        }
        else {
          $rawText = [string]$initialReplicationPercentRaw
          $cleanText = $rawText -replace "[^0-9\.]", ""
          if ($cleanText -match "^\d+(\.\d+)?$") {
            $percentNumber = [double]$cleanText
          }
        }

        if ($null -ne $percentNumber) {
          if ($percentNumber -gt 100) { $percentNumber = 100 }
          if ($percentNumber -lt 0) { $percentNumber = 0 }
          $initialReplicationPercent = ("{0:N1}%" -f $percentNumber)
        }
      }

    $deltaSyncLabel = if ($replicationStatus) { $replicationStatus } elseif ($gatewayState) { $gatewayState } else { "N/A" }

    $rows += [PSCustomObject]@{
        VMName            = $item.MachineName
      CsvOrder          = if ($null -ne $serverOrderLookup) { $serverOrderLookup[[string]$item.MachineName] } else { [int]::MaxValue }
        InitialReplicationPercent = $initialReplicationPercent
        DeltaSync         = $deltaSyncLabel
        LastDeltaSyncTime = $lastDeltaSyncLocal
        SyncAgeHours      = if ($null -ne $ageHours) { $ageHours } else { "N/A" }
    }
}

$greenCount = @($rows | Where-Object { $_.SyncAgeHours -is [double] -and $_.SyncAgeHours -lt 2.5 }).Count
$yellowCount = @($rows | Where-Object { $_.SyncAgeHours -is [double] -and $_.SyncAgeHours -ge 4 -and $_.SyncAgeHours -le 6 }).Count
$redCount = @($rows | Where-Object { $_.SyncAgeHours -is [double] -and $_.SyncAgeHours -gt 6 }).Count
$neutralCount = @($rows | Where-Object {
  ($_.SyncAgeHours -eq "N/A") -or
  ($_.SyncAgeHours -is [double] -and $_.SyncAgeHours -ge 2.5 -and $_.SyncAgeHours -lt 4)
}).Count

$tableRowsHtml = ""
if ($rows.Count -gt 0) {
  $displayRows = if ($null -ne $serverOrderLookup) {
    $rows | Sort-Object CsvOrder, VMName
  }
  else {
    $rows | Sort-Object @{ Expression = 'SyncAgeHours'; Descending = $true }, VMName
  }

  foreach ($row in $displayRows) {
        $ageClass = "age-neutral"

        if ($row.SyncAgeHours -is [double]) {
            if ($row.SyncAgeHours -gt 6) {
                $ageClass = "age-red"
            }
            elseif ($row.SyncAgeHours -ge 4 -and $row.SyncAgeHours -le 6) {
                $ageClass = "age-yellow"
            }
            elseif ($row.SyncAgeHours -lt 2.5) {
                $ageClass = "age-green"
            }
        }

        $tableRowsHtml += "<tr>"
        $tableRowsHtml += "<td>" + (Convert-ToHtmlText $row.VMName) + "</td>"
        $tableRowsHtml += "<td>" + (Convert-ToHtmlText $row.InitialReplicationPercent) + "</td>"
        $tableRowsHtml += "<td>" + (Convert-ToHtmlText $row.DeltaSync) + "</td>"
        $tableRowsHtml += "<td class='" + $ageClass + "'>" + (Convert-ToHtmlText $row.LastDeltaSyncTime) + "</td>"
        $tableRowsHtml += "<td class='" + $ageClass + "'>" + (Convert-ToHtmlText $row.SyncAgeHours) + "</td>"
        $tableRowsHtml += "</tr>"
    }
}
else {
        $tableRowsHtml = "<tr><td colspan='5' class='muted'>No replicating VM rows found.</td></tr>"
}

$html = @"
<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Azure Migrate Replicating VMs - Delta Sync Report</title>
<style>
:root {
  --bg1: #0d1a2d;
  --bg2: #1f3557;
  --card: #ffffff;
  --text: #1b2b4b;
  --muted: #5e6b86;
  --line: #e5e9f2;
  --good-bg: #cff3dc;
  --good-text: #0a4f2b;
  --warn-bg: #ffe3a7;
  --warn-text: #6b3f00;
  --bad-bg: #ffc7c7;
  --bad-text: #6d1111;
  --neutral-bg: #e8edf8;
  --neutral-text: #35415c;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: "Segoe UI", "Trebuchet MS", sans-serif;
  color: var(--text);
  background: radial-gradient(1200px 500px at 10% -10%, #2b4f89 0%, transparent 60%),
              radial-gradient(900px 380px at 100% 0%, #127191 0%, transparent 55%),
              linear-gradient(135deg, var(--bg1), var(--bg2));
}
.container {
  max-width: 1200px;
  margin: 24px auto;
  padding: 0 16px 30px;
}
.header {
  background: rgba(255,255,255,0.95);
  border: 1px solid rgba(255,255,255,0.8);
  border-radius: 14px;
  padding: 18px;
}
h1 {
  margin: 0;
  font-size: 26px;
}
.sub {
  margin-top: 8px;
  font-size: 13px;
  color: var(--muted);
}
.grid {
  margin-top: 14px;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 10px;
}
.card {
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 12px;
}
.k {
  font-size: 12px;
  color: var(--muted);
  text-transform: uppercase;
}
.v {
  margin-top: 5px;
  font-size: 28px;
  font-weight: 700;
}
.section {
  margin-top: 14px;
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 12px;
  overflow: hidden;
}
.section h2 {
  margin: 0;
  padding: 12px 14px;
  border-bottom: 1px solid var(--line);
  font-size: 18px;
}
.table-wrap {
  overflow-x: auto;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  border-bottom: 1px solid var(--line);
  text-align: left;
  padding: 10px 12px;
  font-size: 13px;
}
th {
  background: #f6f8fc;
  font-size: 12px;
  text-transform: uppercase;
}
.age-green {
  background: linear-gradient(90deg, #b4ebc8 0%, var(--good-bg) 100%);
  color: var(--good-text);
  font-weight: 800;
  box-shadow: inset 0 0 0 1px #6fc492;
}
.age-yellow {
  background: linear-gradient(90deg, #ffd16a 0%, var(--warn-bg) 100%);
  color: var(--warn-text);
  font-weight: 800;
  box-shadow: inset 0 0 0 1px #df9f2a;
}
.age-red {
  background: linear-gradient(90deg, #ff8f8f 0%, var(--bad-bg) 100%);
  color: var(--bad-text);
  font-weight: 800;
  box-shadow: inset 0 0 0 1px #d44f4f;
}
.age-neutral {
  background: linear-gradient(90deg, #d8e2f4 0%, var(--neutral-bg) 100%);
  color: var(--neutral-text);
  box-shadow: inset 0 0 0 1px #aab8d7;
}
.muted { color: var(--muted); font-style: italic; }
.legend {
  margin-top: 10px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 12px;
}
.pill {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid transparent;
}
.pill-green { background: var(--good-bg); color: var(--good-text); border-color: #6fc492; font-weight: 700; }
.pill-yellow { background: var(--warn-bg); color: var(--warn-text); border-color: #df9f2a; font-weight: 700; }
.pill-red { background: var(--bad-bg); color: var(--bad-text); border-color: #d44f4f; font-weight: 700; }
.pill-neutral { background: var(--neutral-bg); color: var(--neutral-text); border-color: #aab8d7; font-weight: 700; }
.footer {
  margin-top: 10px;
  color: #e3ebff;
  font-size: 12px;
}
</style>
</head>
<body>
  <div class='container'>
    <div class='header'>
      <h1>Azure Migrate Replicating VMs - Delta Sync Report</h1>
      <div class='sub'>
        Generated: $(Convert-ToHtmlText ($reportTime.ToString("yyyy-MM-dd HH:mm:ss zzz"))) |
        Subscription: $(Convert-ToHtmlText $SubscriptionId) |
        Resource Group: $(Convert-ToHtmlText $ResourceGroupName) |
        Project: $(Convert-ToHtmlText $ProjectName)
      </div>
      <div class='grid'>
        <div class='card'><div class='k'>Replicating VMs</div><div class='v'>$(Convert-ToHtmlText $rows.Count)</div></div>
        <div class='card'><div class='k'>Green (&lt;2.5h)</div><div class='v'>$(Convert-ToHtmlText $greenCount)</div></div>
        <div class='card'><div class='k'>Yellow (4-6h)</div><div class='v'>$(Convert-ToHtmlText $yellowCount)</div></div>
        <div class='card'><div class='k'>Red (&gt;6h)</div><div class='v'>$(Convert-ToHtmlText $redCount)</div></div>
        <div class='card'><div class='k'>Neutral (2.5-4h / N/A)</div><div class='v'>$(Convert-ToHtmlText $neutralCount)</div></div>
      </div>
      <div class='legend'>
        <span class='pill pill-green'>Green: Age &lt; 2.5h</span>
        <span class='pill pill-yellow'>Yellow: Age 4h to 6h</span>
        <span class='pill pill-red'>Red: Age &gt; 6h</span>
        <span class='pill pill-neutral'>Neutral: Age 2.5h to &lt;4h or N/A</span>
      </div>
    </div>

    <div class='section'>
      <h2>Replicating VM Details</h2>
      <div class='table-wrap'>
        <table>
          <thead>
            <tr>
              <th>VM Name</th>
              <th>Initial Replication (%)</th>
              <th>Delta Sync</th>
              <th>Last Delta Sync Time (Local)</th>
              <th>Sync Age (Hours)</th>
            </tr>
          </thead>
          <tbody>
            $tableRowsHtml
          </tbody>
        </table>
      </div>
    </div>

    <div class='footer'>
      Report source: Azure Migrate replication item details (LastRecoveryPointReceived).
    </div>
  </div>
</body>
</html>
"@

Set-Content -Path $OutputPath -Value $html -Encoding UTF8
Write-Host ("HTML report exported: " + $OutputPath) -ForegroundColor Green
