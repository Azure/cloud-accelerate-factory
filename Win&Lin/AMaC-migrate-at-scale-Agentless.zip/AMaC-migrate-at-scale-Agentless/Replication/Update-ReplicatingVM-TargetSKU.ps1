<#
.SYNOPSIS
    Updates Azure Migrate replicating VM target SKU (TargetVMSize) using CSV input.

.DESCRIPTION
    This script reads VM names and desired target SKU sizes from a CSV file and updates
    each replicating server in an Azure Migrate project using Set-AzMigrateServerReplication.

.NOTES
    Required CSV columns:
        VMName,TargetVMSize

    Example CSV:
        VMName,TargetVMSize
        APP-SRV-01,Standard_D4s_v5
        DB-SRV-01,Standard_E8s_v5

    Author: Deepak Tyagi
    Date:   April 2026
#>

# ===================== USER CONFIG =====================
$CsvPath = "C:\Users\v-deepak6\OneDrive - Microsoft\Desktop\Project\ELC\Script-Run-Data-File\Update-TargetSKU.csv"

# Azure Migrate project
$ProjectSubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3"
$ProjectName           = "AzmigEUUKSVMEOL"
$ProjectRG             = "rg-eu-uks-nonprod-azuremigrateuks"

#$ProjectSubscriptionId = "3d9f4c5d-536d-4252-b653-1928e7d0ccb0"
#$ProjectName           = "Azuremigrate-AM-CUS-VMwareEOL"
#$ProjectRG             = "RG-AM-CUS-Prod-AzureMigrateCUS"

#$ProjectSubscriptionId = "e6696cb1-8604-4f1b-b022-633ecfb8f8a3"
#$ProjectName           = "AzmigEUUKSVMPub"
#$ProjectRG             = "rg-eu-uks-nonprod-azmigrateukspub"

#$ProjectSubscriptionId = "3c33b258-6a1b-498c-9dd7-2e4b52ff16dc"
#$ProjectName           = "AzmigVMEOLSAPxtra"
#$ProjectRG             = "RG-AM-EastUS-NonProd-AZMigrate2"

#$ProjectSubscriptionId = "c98ba209-886d-4fe2-8acf-3c4f39296612"
#$ProjectName           =  "AzmigAPSEAVMPUB" #"AzmigAPSEAVMEOL"
#$ProjectRG             = "rg-ap-sea-nonprod-azuremigratesea"

# ===================== MODULES =====================
Import-Module Az.Accounts, Az.Migrate

# ===================== VALIDATE PROJECT =====================
Set-AzContext -SubscriptionId $ProjectSubscriptionId | Out-Null
Write-Host "Project subscription: $ProjectSubscriptionId" -ForegroundColor Cyan

try {
    $Project = Get-AzMigrateProject -Name $ProjectName -ResourceGroupName $ProjectRG -ErrorAction Stop
    Write-Host "Project: $($Project.Name) in RG $ProjectRG" -ForegroundColor Green
}
catch {
    Write-Error "Azure Migrate project not found. $($_.Exception.Message)"
    return
}

# ===================== LOAD CSV =====================
if (-not (Test-Path -Path $CsvPath)) {
    Write-Error "CSV not found: $CsvPath"
    return
}

$Rows = Import-Csv $CsvPath
if (-not $Rows -or $Rows.Count -eq 0) {
    Write-Error "CSV is empty: $CsvPath"
    return
}

$requiredColumns = @('VMName', 'TargetVMSize')
foreach ($col in $requiredColumns) {
    if ($Rows[0].PSObject.Properties.Name -notcontains $col) {
        Write-Error "CSV missing required column: $col"
        return
    }
}

Write-Host "Loaded $($Rows.Count) VM row(s) from CSV" -ForegroundColor Green

# ===================== RESULTS TRACKING =====================
$Results = @()
$SuccessCount = 0
$FailCount    = 0
$SkipCount    = 0

# ===================== MAIN LOOP =====================
foreach ($row in $Rows) {
    $vmName = if ($null -ne $row.VMName) { ([string]$row.VMName).Trim() } else { '' }
    $targetVmSize = if ($null -ne $row.TargetVMSize) { ([string]$row.TargetVMSize).Trim() } else { '' }

    if ([string]::IsNullOrWhiteSpace($vmName)) {
        Write-Host "Skipping row: VMName is empty" -ForegroundColor Yellow
        $SkipCount++
        continue
    }

    if ([string]::IsNullOrWhiteSpace($targetVmSize)) {
        Write-Host ("Skipping {0}: TargetVMSize is empty" -f $vmName) -ForegroundColor Yellow
        $SkipCount++
        $Results += [PSCustomObject]@{
            VMName       = $vmName
            TargetVMSize = ''
            Status       = 'Skipped'
            Details      = 'TargetVMSize is empty'
        }
        continue
    }

    Write-Host "=== $vmName ===" -ForegroundColor Yellow

    try {
        $replicatingServer = Get-AzMigrateServerReplication `
            -ProjectName       $ProjectName `
            -ResourceGroupName $ProjectRG `
            -MachineName       $vmName

        if (-not $replicatingServer) {
            throw "Replicating server not found for VM '$vmName'."
        }

        # Get full object with provider-specific details.
        $replicatingServer = Get-AzMigrateServerReplication -TargetObjectID $replicatingServer.Id
        $currentSize = $replicatingServer.ProviderSpecificDetail.TargetVMSize

        if (-not [string]::IsNullOrWhiteSpace($currentSize) -and $currentSize -eq $targetVmSize) {
            Write-Host "No change for $vmName (already $targetVmSize)" -ForegroundColor Gray
            $SkipCount++
            $Results += [PSCustomObject]@{
                VMName       = $vmName
                TargetVMSize = $targetVmSize
                Status       = 'Skipped'
                Details      = 'Already set to requested size'
            }
            continue
        }

        Write-Host "Updating SKU: $currentSize -> $targetVmSize" -ForegroundColor Cyan

        $updateJob = Set-AzMigrateServerReplication `
            -InputObject $replicatingServer `
            -TargetVMSize $targetVmSize

        if ($updateJob -is [array]) {
            $updateJob = $updateJob | Select-Object -First 1
        }

        if ($updateJob -is [bool] -or $null -eq $updateJob) {
            Write-Host "Updated $vmName to $targetVmSize (no job returned)" -ForegroundColor Green
            $SuccessCount++
            $Results += [PSCustomObject]@{
                VMName       = $vmName
                TargetVMSize = $targetVmSize
                Status       = 'Success'
                Details      = 'No job returned, assumed successful'
            }
            continue
        }

        Write-Host "Job: $($updateJob.Id.Split('/')[-1])" -ForegroundColor Magenta
        do {
            Start-Sleep -Seconds 5
            $updateJob = Get-AzMigrateJob -InputObject $updateJob
            if ($updateJob -is [array]) {
                $updateJob = $updateJob | Select-Object -First 1
            }
        } while ($updateJob.State -in @('InProgress', 'NotStarted'))

        if ($updateJob.State -eq 'Succeeded') {
            Write-Host "Updated $vmName to $targetVmSize" -ForegroundColor Green
            $SuccessCount++
            $Results += [PSCustomObject]@{
                VMName       = $vmName
                TargetVMSize = $targetVmSize
                Status       = 'Success'
                Details      = 'Job completed successfully'
            }
        }
        else {
            Write-Host "Update failed for $vmName (State: $($updateJob.State))" -ForegroundColor Red
            $FailCount++
            $Results += [PSCustomObject]@{
                VMName       = $vmName
                TargetVMSize = $targetVmSize
                Status       = 'Failed'
                Details      = "Job state: $($updateJob.State)"
            }
        }
    }
    catch {
        Write-Host ("Error for {0}: {1}" -f $vmName, $_.Exception.Message) -ForegroundColor Red
        $FailCount++
        $Results += [PSCustomObject]@{
            VMName       = $vmName
            TargetVMSize = $targetVmSize
            Status       = 'Error'
            Details      = $_.Exception.Message
        }
    }

    Start-Sleep -Seconds 2
}

# ===================== SUMMARY =====================
Write-Host ""
Write-Host "==================== SKU UPDATE SUMMARY ====================" -ForegroundColor Cyan
Write-Host "Total VMs : $($Rows.Count)" -ForegroundColor Cyan
Write-Host "Success   : $SuccessCount" -ForegroundColor Green
Write-Host "Failed    : $FailCount" -ForegroundColor Red
Write-Host "Skipped   : $SkipCount" -ForegroundColor Yellow

# ===================== EXPORT RESULTS =====================
$OutputCsv = $CsvPath -replace '\.csv$', '-Results.csv'
$Results | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "Results exported to: $OutputCsv" -ForegroundColor Green

Write-Host "Batch complete. Verify TargetVMSize in Azure Migrate portal." -ForegroundColor Green
