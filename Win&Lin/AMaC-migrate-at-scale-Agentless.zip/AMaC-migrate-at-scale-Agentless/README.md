# AMAC -AGENTLESS AUTOMATION SCRIPTS
It covers migration, replication, post-migration validation/remediation, and VMware Tools cleanup scripts.

## Global prerequisites

- PowerShell 7+ (recommended for scripts using `ForEach-Object -Parallel`)
- Azure login: `Connect-AzAccount`
- Common Azure modules used across scripts:
  - `Az.Accounts`
  - `Az.Migrate`
  - `Az.Network`
  - `Az.Resources`
  - `Az.Compute`
- CSV inventory files with expected columns (varies by script)

## Folder overview

| Folder | Purpose |
|---|---|
| `Migration` | Start test migration (TFO), cleanup test migration, and start production cutover migration. |
| `Replication` | Start replication, monitor sync progress, export replication reports, and update replication target settings. |
| `Post Migration` | Post-cutover checks/remediation/reporting: tagging, diagnostics, networking, VM agent status, and ghost NIC validation. |
| `Post Migration\VMware Tool Remove` | VMware Tools detection and cleanup scripts for Windows/Linux VMs. |

## Migration scripts

| Script | What it does | Typical input | Output |
|---|---|---|---|
| `Migration\Start-Migration.ps1` | Starts TFO cleanup jobs (`Start-AzMigrateTestMigrationCleanup`) for listed VMs and monitors all jobs. | CSV with `MachineName` | Console status per VM/job |
| `Migration\Start-TFO.ps1` | Starts test migration (TFO) with VNet/subnet mapping from CSV and monitors job completion. | CSV with `MachineName`, `VNetName`, `SubnetName` | Console + summary table |
| `Migration\Start-TFO-Cleanup.ps1` | Starts production cutover migration (`Start-AzMigrateServerMigration -TurnOffSourceServer`) with confirmation prompt. | CSV with `VMName` | Console start status |

## Replication scripts

| Script | What it does | Typical input | Output |
|---|---|---|---|
| `Replication\Start-Replication.ps1` | Starts VMware agentless replication from CSV, resolves target/test networks, maps disks, applies tags, monitors jobs. | Replication CSV (VM, appliance, target/test network, disk/license/tag fields) | Console per-VM state |
| `Replication\Start-Replication-DynamicParams-v0.1.ps1` | Flexible replication starter with optional test network and optional target VM size handling. | Replication CSV with same core mapping fields | Console per-VM state |
| `Replication\Monitor-AzMigrateSyncProgress.ps1` | Full monitoring view for running jobs and replication progress with filtering switches. | Subscription/project parameters | Refreshing console dashboard |
| `Replication\Monitor-AzMigrateSyncProgress-Lite.ps1` | Lightweight monitor focused on running jobs and `MigrationInProgress` VMs. | Subscription/project parameters | Refreshing console dashboard |
| `Replication\Export-AzMigrate-ReplicatingVMs-DeltaSync-HTML.ps1` | Exports HTML report of delta sync state, last sync time, and sync age color bands. | Project config + optional server CSV filter/order | HTML report |
| `Replication\Update-ReplicatingVM-TargetIP.ps1` | Updates target NIC IPs for replicating VMs (primary + optional secondary mappings). | CSV with `VMName`, `TargetIP`, optional `SecondaryIP*` | Console + result summary |
| `Replication\Update-ReplicatingVM-TargetSKU.ps1` | Updates target VM size (`TargetVMSize`) for replicating VMs and exports results. | CSV with `VMName`, `TargetVMSize` | Console + `*-Results.csv` |
| `Replication\Update-VMDisk-ToPremiumSSD-ToStandardSSD.ps1` | Updates managed disk SKU (OS/data) for Azure VMs found across tenant subscriptions. | CSV with `VMName`, `ResourceGroup` | Console + table/grid summary |

## Post Migration scripts

| Script | What it does | Typical input | Output |
|---|---|---|---|
| `Post Migration\Apply-Tags-ToVM-PostMigration.ps1` | Applies tags via Azure Migrate replication object update (VM/disks/NICs). | Tag CSV (`VMName` + tag columns) | Console/job status |
| `Post Migration\Apply-Tags-v.01.ps1` | Applies tags directly to Azure VM resources (VM, disks, NICs, public IPs). | CSV with `VMName`, `ResourceGroupName`, tag columns | Console status |
| `Post Migration\Calculate-DataTransferTime.ps1` | Calculates transfer/replication duration from data size + speed units. | Parameters or interactive input | Duration output |
| `Post Migration\Check-HybridBenefitStatus.ps1` | Checks license/AHB status across enabled subscriptions for CSV VM list. | VM CSV | Console table |
| `Post Migration\Check-RDPStatus.ps1` | Runs in-guest RDP checks (service, 3389 listening, loopback TCP test) via Run Command. | VM CSV | Console output per VM |
| `Post Migration\Enable-AcceleratedNetworking-Parallel.ps1` | Enables accelerated networking on NICs in parallel and reboots successful VMs. | VM CSV | Phase summaries |
| `Post Migration\Enable-BootDiagnostics.v01.ps1` | Enables managed Boot Diagnostics in parallel (clears custom storage URI if set). | VM CSV | Console status |
| `Post Migration\Enable-SerialConsole.ps1` | Runs in-guest EMS/serial console boot settings across VM list. | VM CSV | Console status |
| `Post Migration\Get-AcceleratedNetworkingStatus.ps1` | Reports accelerated networking status per VM. | VM CSV | Console table |
| `Post Migration\Get-AzVMAgentStatus.v01.ps1` | Reports VM agent version/status/messages for listed VMs. | VM CSV | Console table |
| `Post Migration\Get-BootDiagnostics.ps1` | Reports boot diagnostics mode (managed/custom/disabled) for listed VMs. | VM CSV | Console table |
| `Post Migration\Get-ChangeNumber.ps1` | Reads VM `ChangeNumber` tag values for listed servers. | Server CSV | Console/tag report |
| `Post Migration\Get-PostMigrataion-IP_And_DiskCount.ps1` | Reports NIC/IP and disk count/type/tier information post migration. | VM CSV | Console table |
| `Post Migration\Report-AzMigrate-SQL-Extension-AllSubscriptions.ps1` | Read-only report of SQL extension-enabled VMs across subscriptions (tag-filter capable). | Azure context + tag filter config | Console/report rows |
| `Post Migration\Report-AzureMigrateVM_v01.ps1` | Exports detailed Azure Migrate replication report for all VMs in project. | Project config | CSV export |
| `Post Migration\Report-AzureMigrateVM-BY-CSV-Input.v01.ps1` | Exports Azure Migrate report filtered to VMs in CSV. | Project config + VM CSV | CSV export |
| `Post Migration\Run-GhostedNIC-Script-AzVMs-Parallel.ps1` | Parallel Run Command runner for embedded ghost NIC scan/cleanup script. | VM CSV | Console output |
| `Post Migration\WindowsGhostedNicValidation-AzRunCommand.ps1` | Read-only ghost NIC validation via Run Command. | VM CSV | Summary/detail/error CSVs |
| `Post Migration\WindowsGhostedNicValidation-MultiServer.ps1` | Read-only ghost NIC validation via PowerShell remoting (WinRM). | `-ComputerName` or CSV | Summary/detail/error CSVs |

## VMware Tool Remove scripts

| Script | What it does | Typical input | Output |
|---|---|---|---|
| `Post Migration\VMware Tool Remove\Check-VMwareTool-Install-Windows.ps1` | Sequential VMware Tools presence check on Windows VMs. | VM CSV | Console output |
| `Post Migration\VMware Tool Remove\Check-VMwareTool-Install-Windows-Parallel.ps1` | Parallel VMware Tools presence check on Windows VMs. | VM CSV | Console output |
| `Post Migration\VMware Tool Remove\Run-Remove-Vmwaretools-WindowsVMs.ps1` | Executes Windows VMware Tools removal script via Run Command in parallel. | VM CSV + uninstaller script path | Console + result bag |
| `Post Migration\VMware Tool Remove\VMwareTool-Uninstaller_v01.ps1` | In-guest VMware Tools uninstaller for Windows with post-check markers. | Executed inside VM | Status lines (`STATUS=...`) |
| `Post Migration\VMware Tool Remove\Run-Remove-Vmwaretools-LinuxVMs-v01.ps1` | Linux VMware Tools package removal (`yum/dnf/apt`) via RunShellScript. | Linux VM CSV | Console status |
| `Post Migration\VMware Tool Remove\Run-Remove-Vmwaretools-LinuxVMs-v02.ps1` | Enhanced Linux removal output formatting/coloring. | Linux VM CSV | Console status |

## Recommended execution flow

1. **Replication phase**: `Start-Replication*` -> `Monitor-*` -> `Export-*`.
2. **Test migration phase**: `Start-TFO.ps1` -> validate -> `Start-Migration.ps1` (cleanup test migration resources).
3. **Cutover phase**: `Start-TFO-Cleanup.ps1` (final migration with source shutdown).
4. **Post migration phase**: run reporting/validation scripts, then apply remediations (`Enable-*`, tagging, IP/SKU/disk updates as needed).
5. **Optional cleanup**: VMware Tools scripts and ghost NIC cleanup/validation.

## Important cautions

- Some scripts are read-only reports/validation; others actively modify infrastructure.
- Scripts using `Invoke-AzVMRunCommand` depend on VM Agent health and RBAC permissions.
- Validate production-impacting scripts in a test batch first.
