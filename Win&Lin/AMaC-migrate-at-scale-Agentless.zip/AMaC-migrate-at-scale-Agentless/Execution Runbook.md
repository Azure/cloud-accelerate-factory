# Azure Migration Scripts — Detailed Operations Handbook

> **Scope:** Pre and Post Migration PowerShell Scripts  
> **Created:** 2026-05-07  
> **Project:** Cloud Accelerate Factory

---

## Table of Contents

1. [Purpose](#1-purpose)
2. [Audience](#2-audience)
3. [End-to-End Process](#3-end-to-end-process)
4. [Prerequisites](#4-prerequisites)
5. [Standard Runbook Steps](#5-standard-runbook-steps)
6. [Script Reference](#6-script-reference)
   - [Phase 1 — Replication Setup](#phase-1--replication-setup)
   - [Phase 2 — Validation & Reporting](#phase-2--validation--reporting)
   - [Phase 3 — Test Failover](#phase-3--test-failover)
   - [Phase 4 — Pre-Migration](#phase-4--pre-migration)
   - [Phase 5 — Cutover Migration](#phase-5--cutover-migration)
   - [Phase 6 — Post-Migration Configuration](#phase-6--post-migration-configuration)
   - [Phase 6 — VMware Tools Removal](#phase-6--vmware-tools-removal)
7. [Handover Checklist](#7-handover-checklist)
8. [Enhancement Recommendations](#8-enhancement-recommendations)

---

## 1. Purpose

This handbook explains what each script does, when to use it, input requirements, execution process, expected output, and operational advantages. It is designed so another engineer can run the full migration lifecycle by following the steps in sequence.

---

## 2. Audience

- Migration Engineers
- Cloud Operations / Platform Teams
- Change Managers and Service Owners
- Support Teams handling pre and post-migration checks

---

## 3. End-to-End Process

Execute steps in the following order:

1. Prepare CSV files in Metadata folders.
2. Validate Azure login, subscriptions, and permissions.
3. Run replication scripts (`Start-Replication*.ps1`).
4. Run migration reporting scripts to verify replication readiness.
5. Execute test failover (`Start-TFO.ps1`), then cleanup (`Start-TFO-Cleanup.ps1`).
6. Execute cutover migration (`Start-Migration.ps1`) during approved change window.
7. Run post-migration configuration scripts (tags, diagnostics, networking, disk/SKU/IP updates).
8. Run health verification scripts (RDP, AHB, agent, boot diagnostics, accelerated networking).
9. Run VMware tools validation/removal scripts where applicable.
10. Export and archive outputs for audit and handover.

---

## 4. Prerequisites

| Requirement | Details |
|---|---|
| PowerShell Version | 7.x recommended (required for parallel processing scripts) |
| Az Modules | `Az.Accounts`, `Az.Migrate`, `Az.Compute`, `Az.Network`, `Az.Resources` |
| Azure Access | Azure Migrate project and target subscriptions/resource groups |
| CSV Input | Validated CSV with correct header names and no trailing spaces |
| Change Approval | Required for disruptive steps (test failover, cutover, stop/start actions) |

---

## 5. Standard Runbook Steps

Follow these steps for **every** script before execution:

1. Open the script and update **User Config** values (subscription IDs, project name, RG, CSV path).
2. Validate CSV format and sample rows before full run.
3. Start with **1–2 pilot VMs** before full batch execution.
4. Run the script and monitor status messages for success/failure/skip counts.
5. Capture output artifacts (console logs, CSV exports, Out-GridView screenshots).
6. If failures occur, fix data/config and rerun only failed rows.

---

## 6. Script Reference

### Quick Reference Table

| Script | Phase | Sub-phase | Input CSV | OS |
|---|---|---|---|---|
| `Start-Replication.ps1` | Phase 1 | Replication Setup | `Replication.csv` | Win / Linux |
| `Start-Replication-DynamicParams-v0.1.ps1` | Phase 1 | Replication Setup | `Replication.csv` | Win / Linux |
| `Report-AzureMigrateVM_v01.ps1` | Phase 2 | Migration Reporting | N/A (all VMs) | Win / Linux |
| `Report-AzureMigrateVM-BY-CSV-Input.v01.ps1` | Phase 2 | Migration Reporting | `ServerNames-Mig.csv` | Win / Linux |
| `Start-TFO.ps1` | Phase 3 | TFO Execution | `TFO-FIle.csv` | Win / Linux |
| `Start-TFO-Cleanup.ps1` | Phase 3 | TFO Cleanup | N/A | Win / Linux |
| `Apply-Tags-v.01.ps1` | Phase 4 | Resource Tagging | `Tags.csv` | Win / Linux |
| `Start-Migration.ps1` | Phase 5 | Cutover Migration | `ServerNames-Mig.csv` | Win / Linux |
| `Apply-Tags-ToVM-PostMigration.ps1` | Phase 6 | Resource Tagging | `VM-Tags.csv` | Win / Linux |
| `Check-HybridBenefitStatus.ps1` | Phase 6 | VM Health Verification | `ServerNames-Mig.csv` | Win / Linux |
| `Check-RDPStatus.ps1` | Phase 6 | VM Health Verification | `ServerNames-Mig.csv` | Windows |
| `Enable-AcceleratedNetworking-Parallel.ps1` | Phase 6 | Network Configuration | `ServerNames-Mig.csv` | Win / Linux |
| `Enable-BootDiagnostics.v01.ps1` | Phase 6 | Diagnostics | `ServerNames-Mig.csv` | Win / Linux |
| `Enable-SerialConsole.ps1` | Phase 6 | Diagnostics | `ServerNames-Mig.csv` | Windows |
| `Get-AcceleratedNetworkingStatus.ps1` | Phase 6 | Network Configuration | `ServerNames-Mig.csv` | Win / Linux |
| `Get-AzVMAgentStatus.v01.ps1` | Phase 6 | VM Health Verification | `ServerNames-Mig.csv` | Win / Linux |
| `Get-BootDiagnostics.ps1` | Phase 6 | Diagnostics | `ServerNames-Mig.csv` | Win / Linux |
| `Get-ChangeNumber.ps1` | Phase 6 | Config & Validation | N/A | Win / Linux |
| `Get-PostMigrataion-IP_And_DiskCount.ps1` | Phase 6 | VM Health Verification | `ServerNames-Mig.csv` | Win / Linux |
| `Update-ReplicatingVM-TargetIP.ps1` | Phase 6 | Config & Validation | N/A | Win / Linux |
| `Update-ReplicatingVM-TargetSKU.ps1` | Phase 6 | Config & Validation | N/A | Win / Linux |
| `Update-VMDisk-ToPremiumSSD-ToStandardSSD.ps1` | Phase 6 | Config & Validation | N/A | Win / Linux |
| `Check-VMwareTool-Install-Windows-Parallel.ps1` | Phase 6 | VMware Tools Removal | `ServerNames-Mig.csv` | Windows |
| `Check-VMwareTool-Install-Windows.ps1` | Phase 6 | VMware Tools Removal | N/A | Win / Linux |
| `Run-Remove-Vmwaretools-LinuxVMs-v01.ps1` | Phase 6 | VMware Tools Removal | `ServerNames-Mig.csv` | Linux |
| `Run-Remove-Vmwaretools-WindowsVMs.ps1` | Phase 6 | VMware Tools Removal | `ServerNames-Mig.csv` | Windows |
| `VMwareTool-Uninstaller_v01.ps1` | Phase 6 | VMware Tools Removal | N/A (called by other scripts) | Windows |

---

### Phase 1 — Replication Setup

---

#### `Start-Replication.ps1`

**What it does:** Base replication script — reads VM config from CSV, validates the Azure Migrate project, resolves target resources, and starts replication jobs with job monitoring until completion.

**Run:**
```powershell
.\Start-Replication.ps1
```

**Input CSV:** `Replication.csv`

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Read input CSV or query Azure Migrate resources.
3. Process VMs one-by-one or in parallel.
4. Apply action (replication/configuration/validation/reporting).
5. Print summary and export/visualize results.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.
- CSV export or grid view output where implemented.

**Key Notes:** Job monitoring until completion.

</details>

---

#### `Start-Replication-DynamicParams-v0.1.ps1`

**What it does:** Enhanced replication script with dynamic parameters — supports tag application during replication, auto VM sizing, and auto OS disk detection.

**Run:**
```powershell
.\Start-Replication-DynamicParams-v0.1.ps1
```

**Input CSV:** `Replication.csv`

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Read input CSV or query Azure Migrate resources.
3. Process VMs one-by-one or in parallel.
4. Apply action (replication/configuration/validation/reporting).
5. Print summary and export/visualize results.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.
- CSV export or grid view output where implemented.

**Key Notes:** Auto OS disk detection; Tag support (`TagName1`–`TagName5`); Leave VM size blank for Azure auto-suggestion.

</details>

---

### Phase 2 — Validation & Reporting

---

#### `Report-AzureMigrateVM_v01.ps1`

**What it does:** Full report — subscription, region, RG, VNet, subnet, NIC, and IP details for all replicating VMs. Exports detailed CSV report.

**Run:**
```powershell
.\Report-AzureMigrateVM_v01.ps1
```

**Input CSV:** N/A (queries all replicating VMs)

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Query Azure Migrate resources.
3. Process VMs one-by-one or in parallel.
4. Print summary and export/visualize results.

**Expected Output:**
- Console execution log with success/failure details.
- Detailed CSV report export.

</details>

---

#### `Report-AzureMigrateVM-BY-CSV-Input.v01.ps1`

**What it does:** Targeted report for specific VMs listed in CSV input. Input-driven reporting for the CUS project.

**Run:**
```powershell
.\Report-AzureMigrateVM-BY-CSV-Input.v01.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Read input CSV.
3. Process listed VMs and generate report.
4. Print summary and export/visualize results.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.
- CSV export or grid view output where implemented.

**Key Notes:** Input-driven reporting; CUS project.

</details>

---

### Phase 3 — Test Failover

---

#### `Start-TFO.ps1`

**What it does:** Initiates test failover — reads VM list from CSV, starts test migration to specified VNet, and monitors job progress.

**Run:**
```powershell
.\Start-TFO.ps1
```

**Input CSV:** `TFO-FIle.csv`

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Read input CSV.
3. Start test migration jobs per VM.
4. Monitor job progress.
5. Print summary.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.

**Key Notes:** Job progress monitoring included.

</details>

---

#### `Start-TFO-Cleanup.ps1`

**What it does:** Cleans up test failover resources after validation is complete.

**Run:**
```powershell
.\Start-TFO-Cleanup.ps1
```

**Input CSV:** N/A

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Query Azure Migrate resources.
3. Process VMs one-by-one or in parallel.
4. Apply cleanup action.
5. Print summary.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.

</details>

---

### Phase 4 — Pre-Migration

---

#### `Apply-Tags-v.01.ps1`

**What it does:** Applies tags to replicating VMs during the Azure Migrate replication phase.

**Run:**
```powershell
.\Apply-Tags-v.01.ps1
```

**Input CSV:** `Tags.csv`

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Read input CSV.
3. Process VMs one-by-one or in parallel.
4. Apply tags.
5. Print summary and export/visualize results.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.
- CSV export or grid view output where implemented.

**Key Notes:** Project Name (EXM): `Azuremigrate-AM-CUS-VMwareEOL`.

</details>

---

### Phase 5 — Cutover Migration

---

#### `Start-Migration.ps1`

> ⚠️ **Disruptive** — requires change approval. Turns off source servers.

**What it does:** Reads VM list from CSV, retrieves replicating servers, prompts for user confirmation, executes cutover migration, and turns off source servers.

**Run:**
```powershell
.\Start-Migration.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

<details>
<summary>Steps, Output & Notes</summary>

**Process Steps:**
1. Load modules and validate context.
2. Read input CSV.
3. Retrieve replicating server objects.
4. Prompt for interactive confirmation.
5. Execute cutover migration.
6. Shut down source servers.
7. Print summary.

**Expected Output:**
- Console execution log with success/failure details.
- Counts for completed/skipped/failed VM rows.

**Key Notes:** Interactive confirmation required before execution; source server shutdown is automatic post-cutover.

</details>

---

### Phase 6 — Post-Migration Configuration

---

#### `Apply-Tags-ToVM-PostMigration.ps1`

**What it does:** Applies tags to VM, OS disk, data disks, NICs, and public IPs from CSV input.

**Run:**
```powershell
.\Apply-Tags-ToVM-PostMigration.ps1
```

**Input CSV:** `VM-Tags.csv`

**Key Notes:** Tags all associated resources — VM + Disks + NICs + PIPs.

---

#### `Check-HybridBenefitStatus.ps1`

**What it does:** Validates Azure Hybrid Benefit (AHB) license type on migrated VMs by checking the `LicenseType` property.

**Run:**
```powershell
.\Check-HybridBenefitStatus.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** Read-only validation; checks `LicenseType` property.

---

#### `Check-RDPStatus.ps1`

**What it does:** Validates RDP service, port 3389, and connectivity via `Invoke-AzVMRunCommand`.

**Run:**
```powershell
.\Check-RDPStatus.ps1
```

**Input CSV:** `ServerNames-Mig.csv`  
**Target OS:** Windows only

**Key Notes:** Checks RDP service + port + responsiveness.

---

#### `Enable-AcceleratedNetworking-Parallel.ps1`

**What it does:** Enables Accelerated Networking in two phases — NIC update, then controlled parallel reboot.

**Run:**
```powershell
.\Enable-AcceleratedNetworking-Parallel.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** `ThrottleLimit: 10`; Phase 1 = NIC update / Phase 2 = Reboot.

---

#### `Enable-BootDiagnostics.v01.ps1`

**What it does:** Enables boot diagnostics with managed storage account on migrated VMs.

**Run:**
```powershell
.\Enable-BootDiagnostics.v01.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** `ThrottleLimit: 20`; Managed storage account recommended.

---

#### `Enable-SerialConsole.ps1`

**What it does:** Enables serial console via `bcdedit` EMS commands for troubleshooting.

**Run:**
```powershell
.\Enable-SerialConsole.ps1
```

**Input CSV:** `ServerNames-Mig.csv`  
**Target OS:** Windows only

**Key Notes:** `ThrottleLimit: 15`; Uses `Invoke-AzVMRunCommand`.

---

#### `Get-AcceleratedNetworkingStatus.ps1`

**What it does:** Read-only verification of Accelerated Networking status on the primary NIC.

**Run:**
```powershell
.\Get-AcceleratedNetworkingStatus.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** Read-only verification.

---

#### `Get-AzVMAgentStatus.v01.ps1`

**What it does:** Checks Azure VM Agent version, status, and health messages. Auto-detects resource group and exports results to CSV.

**Run:**
```powershell
.\Get-AzVMAgentStatus.v01.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** Auto resource group detection; exports to CSV.

---

#### `Get-BootDiagnostics.ps1`

**What it does:** Read-only verification of boot diagnostics configuration (managed vs. custom storage).

**Run:**
```powershell
.\Get-BootDiagnostics.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** Read-only verification.

---

#### `Get-ChangeNumber.ps1`

**What it does:** Pulls the Azure VM tag `ChangeNumber` for VMs listed in `ServerNames-Mig.csv`.

**Run:**
```powershell
.\Get-ChangeNumber.ps1
```

**Input CSV:** N/A (reads `ServerNames-Mig.csv` internally)

---

#### `Get-PostMigrataion-IP_And_DiskCount.ps1`

**What it does:** Retrieves private/public IP, allocation method, and total disk count for migrated VMs.

**Run:**
```powershell
.\Get-PostMigrataion-IP_And_DiskCount.ps1
```

**Input CSV:** `ServerNames-Mig.csv`

**Key Notes:** Reports static vs. dynamic IP allocation.

---

#### `Update-ReplicatingVM-TargetIP.ps1`

**What it does:** Updates the Target IP Address on Azure Migrate replicating VMs from CSV input. Requires PowerShell 7.x and the `Az.Migrate` module.

**Run:**
```powershell
.\Update-ReplicatingVM-TargetIP.ps1
```

**Input CSV:** N/A (see script USER CONFIG section)

---

#### `Update-ReplicatingVM-TargetSKU.ps1`

**What it does:** Updates the Azure Migrate replicating VM target SKU (`TargetVMSize`) using CSV input.

**Run:**
```powershell
.\Update-ReplicatingVM-TargetSKU.ps1
```

**Input CSV:** N/A (see script USER CONFIG section)

---

#### `Update-VMDisk-ToPremiumSSD-ToStandardSSD.ps1`

**What it does:** Updates all managed disks (OS + Data) of Azure VMs to Premium SSD (`Premium_LRS`).

**Run:**
```powershell
.\Update-VMDisk-ToPremiumSSD.ps1
```

**Input CSV:** N/A (see script USER CONFIG section)

---

### Phase 6 — VMware Tools Removal

---

#### `Check-VMwareTool-Install-Windows-Parallel.ps1`

**Path:** `VMware Tool Remove\Check-VMwareTool-Install-Windows-Parallel.ps1`

**What it does:** Parallel variant for large-scale VMware Tools detection on Windows VMs.

**Run:**
```powershell
.\Check-VMwareTool-Install-Windows-Parallel.ps1
```

**Input CSV:** `ServerNames-Mig.csv`  
**Target OS:** Windows only

**Key Notes:** `ThrottleLimit: 15`; read-only detection.

---

#### `Check-VMwareTool-Install-Windows.ps1`

**Path:** `VMware Tool Remove\Check-VMwareTool-Install-Windows.ps1`

**What it does:** Detects VMware Tools installation on Windows VMs.

**Run:**
```powershell
.\Check-VMwareTool-Install-Windows.ps1
```

**Input CSV:** N/A (see script USER CONFIG section)

---

#### `Run-Remove-Vmwaretools-LinuxVMs-v01.ps1`

**Path:** `VMware Tool Remove\Run-Remove-Vmwaretools-LinuxVMs-v01.ps1`

**What it does:** Removes `open-vm-tools` packages via auto-detected package manager (`yum`/`dnf`/`apt`) with parallel execution.

**Run:**
```powershell
.\Run-Remove-Vmwaretools-LinuxVMs-v01.ps1
```

**Input CSV:** `ServerNames-Mig.csv`  
**Target OS:** Linux only

**Key Notes:** `ThrottleLimit: 10`; auto package manager detection.

---

#### `Run-Remove-Vmwaretools-WindowsVMs.ps1`

**Path:** `VMware Tool Remove\Run-Remove-Vmwaretools-WindowsVMs.ps1`

**What it does:** Removes VMware Tools from Windows VMs in parallel, using `VMwareTool-Uninstaller_v01.ps1` as the core uninstall engine.

**Run:**
```powershell
.\Run-Remove-Vmwaretools-WindowsVMs.ps1
```

**Input CSV:** `ServerNames-Mig.csv`  
**Target OS:** Windows only

**Key Notes:** `ThrottleLimit: 15`; exports results to CSV.

---

#### `VMwareTool-Uninstaller_v01.ps1`

**Path:** `VMware Tool Remove\VMwareTool-Uninstaller_v01.ps1`

**What it does:** Core uninstaller — handles registry keys, services, MSI uninstall, and post-removal validation. Can be run standalone or called by `Run-Remove-Vmwaretools-WindowsVMs.ps1`.

**Run:**
```powershell
.\VMwareTool-Uninstaller_v01.ps1
```

**Input CSV:** N/A (called by other scripts)  
**Target OS:** Windows only

---

## 7. Handover Checklist

- [ ] All script configs updated and validated for target environment.
- [ ] Input CSV files reviewed and approved.
- [ ] Pilot execution completed successfully.
- [ ] Production batch completed with evidence captured.
- [ ] Known issues and rerun procedures handed over to Factory Team.

---

## 8. Enhancement Recommendations

- Avoid hardcoded values across multiple scripts — centralize into a shared config file.
- Add a shared logging module for consistent CSV and log output format.
- Add a `--dry-run` mode for scripts that make disruptive changes.
- Integrate pre-check and post-check scripts into a single orchestrator wrapper.
- Version and archive run artifacts per migration wave for compliance.
