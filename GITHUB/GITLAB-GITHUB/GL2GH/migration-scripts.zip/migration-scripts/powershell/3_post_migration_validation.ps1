# ============================================================
# GL2GH Post-Migration Validation
# - Reads repos_with_status.csv
# - Validates MigrationStatus=Success repositories only
# - Uses GitLab API for source validation
# - Uses GitHub API for target validation
# - Generates CSV and Markdown summaries
# ============================================================

$ErrorActionPreference = "Stop"

$BaseScriptLoc = Split-Path -Parent $MyInvocation.MyCommand.Path

$LogDir = Join-Path $BaseScriptLoc "logs"
$PostValidationLogDir = Join-Path $LogDir "3_post_migration_validation"
$ArtifactsDir = Join-Path $BaseScriptLoc "output_files"

$ReposStatusFile = if ($env:REPOS_STATUS_FILE) {
    $env:REPOS_STATUS_FILE
} else {
    Join-Path $ArtifactsDir "repos_with_status.csv"
}

$ValidationLogPrefix = if ($env:POST_MIGRATION_VALIDATION_LOG) {
    $env:POST_MIGRATION_VALIDATION_LOG
} else {
    Join-Path $PostValidationLogDir "post-migration-validation"
}

$BranchValidationThreshold = if ($env:BRANCH_VALIDATION_THRESHOLD) {
    [int]$env:BRANCH_VALIDATION_THRESHOLD
} else {
    10
}

$CommitCheck = if ($env:COMMIT_CHECK) {
    $env:COMMIT_CHECK
} else {
    "true"
}

$RunTs = Get-Date -Format "yyyyMMdd_HHmmss"

$OutputDir = Join-Path $ArtifactsDir "post-migration-validation"
$LogFile = "$ValidationLogPrefix-$RunTs.log"
$SummaryCsv = Join-Path $OutputDir "validation-summary_$RunTs.csv"
$SummaryMd = Join-Path $OutputDir "validation-summary_$RunTs.md"

New-Item -ItemType Directory -Force -Path $LogDir,$PostValidationLogDir,$OutputDir | Out-Null

function Write-Log {
    param([string]$Message)
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line
}

function Invoke-GitLabApi {
    param([string]$Endpoint)

    Invoke-RestMethod `
        -Uri "$($env:GITLAB_SERVER_URL.TrimEnd('/'))/api/v4$Endpoint" `
        -Headers @{
            "PRIVATE-TOKEN" = $env:GITLAB_PAT
        }
}

function Get-GitLabProjectId {
    param(
        [string]$Group,
        [string]$Project
    )

    $encoded = [uri]::EscapeDataString("$Group/$Project")
    return $encoded
}

function Get-GitLabBranches {
    param(
        [string]$Group,
        [string]$Project
    )

    $id = Get-GitLabProjectId $Group $Project
    $page = 1
    $result = @()

    while ($true) {
        $response = @(Invoke-GitLabApi "/projects/$id/repository/branches?per_page=100&page=$page")

        $result += $response.name

        if ($response.Count -lt 100) {
            break
        }

        $page++
    }

    return $result
}

function Get-GitLabDefaultBranch {
    param(
        [string]$Group,
        [string]$Project
    )

    $id = Get-GitLabProjectId $Group $Project
    return (Invoke-GitLabApi "/projects/$id").default_branch
}

function Get-GitHubBranches {
    param(
        [string]$Org,
        [string]$Repo
    )

    $json = gh api "/repos/$Org/$Repo/branches?per_page=100" --paginate |
        ConvertFrom-Json

    return $json.name
}

function Get-GitHubDefaultBranch {
    param(
        [string]$Org,
        [string]$Repo
    )

    return gh api "/repos/$Org/$Repo" --jq ".default_branch"
}


function Get-GitHubCommitCount {
    param([string]$Org,[string]$Repo,[string]$Branch)

    $encodedBranch = [uri]::EscapeDataString($Branch)
    $total = 0
    $page = 1

    while ($true) {
        $commits = gh api "/repos/$Org/$Repo/commits?sha=$encodedBranch&per_page=100&page=$page" | ConvertFrom-Json
        $count = @($commits).Count
        $total += $count

        Write-Log "[INFO] GitHub commit count progress: $Org/$Repo branch '$Branch' page=$page, total_so_far=$total"

        if ($count -lt 100) { break }
        $page++
    }

    return $total
}

function Get-GitLabCommitCount {
    param([string]$Group,[string]$Project,[string]$Branch)

    $id = Get-GitLabProjectId $Group $Project
    $encodedBranch = [uri]::EscapeDataString($Branch)
    $total = 0
    $page = 1

    while ($true) {
        $commits = Invoke-GitLabApi "/projects/$id/repository/commits?ref_name=$encodedBranch&per_page=100&page=$page"
        $count = @($commits).Count
        $total += $count

        Write-Log "[INFO] GitLab commit count progress: $Group/$Project branch '$Branch' page=$page, total_so_far=$total"

        if ($count -lt 100) { break }
        $page++
    }

    return $total
}

function Get-GitHubSHA {
    param([string]$Org,[string]$Repo,[string]$Branch)
    $encodedBranch = [uri]::EscapeDataString($Branch)
    return (gh api "/repos/$Org/$Repo/commits/$encodedBranch" --jq ".sha")
}

function Get-GitLabSHA {
    param([string]$Group,[string]$Project,[string]$Branch)

    $id = Get-GitLabProjectId $Group $Project
    $encodedBranch = [uri]::EscapeDataString($Branch)
    return (Invoke-GitLabApi "/projects/$id/repository/commits/$encodedBranch").id
}

Write-Log "[INFO] Starting GitLab -> GitHub post migration validation"
Write-Log "[INFO] Status file: $ReposStatusFile"

if (!(Test-Path $ReposStatusFile)) {
    throw "Migration status file not found: $ReposStatusFile"
}


$results = @()

$Total = 0
$Success = 0
$Failed = 0
$Skipped = 0


foreach ($repo in Import-Csv $ReposStatusFile) {

    if ($repo.MigrationStatus -ne "Success") {
        Write-Log "Skipping $($repo.github_org)/$($repo.github_repo) because MigrationStatus=$($repo.MigrationStatus)"
        $Skipped++
        continue
    }

    $Total++

    Write-Log "============================================================"
    Write-Log "REPO VALIDATION STARTED"
    Write-Log "Source     : GitLab $($repo.gitlab_group)/$($repo.gitlab_project)"
    Write-Log "Repository : GitHub $($repo.github_org)/$($repo.github_repo)"
    Write-Log "============================================================"

    try {

        $ghBranches = @(Get-GitHubBranches $repo.github_org $repo.github_repo)
        $glBranches = @(Get-GitLabBranches $repo.gitlab_group $repo.gitlab_project)

        $ghDefault = Get-GitHubDefaultBranch $repo.github_org $repo.github_repo
        $glDefault = Get-GitLabDefaultBranch $repo.gitlab_group $repo.gitlab_project

        $branchMatch = ($ghBranches.Count -eq $glBranches.Count)
        $defaultMatch = ($ghDefault -eq $glDefault)

        Write-Log "Branch Count: GitLab=$($glBranches.Count) | GitHub=$($ghBranches.Count) | $(if($branchMatch){'✅'}else{'❌'})"
        Write-Log "Default Branch: GitLab=$glDefault | GitHub=$ghDefault | $(if($defaultMatch){'✅'}else{'❌'})"

        if ($glBranches.Count -le $BranchValidationThreshold) {
            Write-Log "Branch count is $BranchValidationThreshold or below. Validating all branches."
            $branchesToValidate = @($glBranches)
        }
        else {
            Write-Log "Branch count exceeds threshold. Validating first $BranchValidationThreshold branches."
            $branchesToValidate = @($glBranches[0..($BranchValidationThreshold - 1)])
        }

        Write-Log "Branches to validate: $($branchesToValidate -join ', ')"

        $commitMatch = $true
        $shaMatch = $true

        foreach ($branch in $branchesToValidate) {

            if ($ghBranches -contains $branch) {

                $ghCount = Get-GitHubCommitCount `
                    -Org $repo.github_org `
                    -Repo $repo.github_repo `
                    -Branch $branch

                $glCount = Get-GitLabCommitCount `
                    -Group $repo.gitlab_group `
                    -Project $repo.gitlab_project `
                    -Branch $branch

                $cm = ($ghCount -eq $glCount)

                if (-not $cm) {
                    $commitMatch = $false
                }

                Write-Log "Branch '$branch': Commits=$(if($cm){'✅'}else{'❌'}) | GitLab=$glCount | GitHub=$ghCount"


                $ghSha = Get-GitHubSHA `
                    -Org $repo.github_org `
                    -Repo $repo.github_repo `
                    -Branch $branch

                $glSha = Get-GitLabSHA `
                    -Group $repo.gitlab_group `
                    -Project $repo.gitlab_project `
                    -Branch $branch


                $sm = ($ghSha -eq $glSha)

                if (-not $sm) {
                    $shaMatch = $false
                }

                Write-Log "Branch '$branch': SHA=$(if($sm){'✅'}else{'❌'}) | GitLab=$glSha | GitHub=$ghSha"

            }
            else {
                Write-Log "Branch '$branch' missing in GitHub ❌"
                $commitMatch = $false
                $shaMatch = $false
            }
        }


        $overall = (
            $branchMatch -and
            $defaultMatch -and
            $commitMatch -and
            $shaMatch
        )


        if ($overall) {
            $result = "Matching"
            $Success++
        }
        else {
            $result = "Mismatch"
            $Failed++
        }


        Write-Log "============================================================"
        Write-Log "VALIDATION COMPLETE"
        Write-Log "Repository: $($repo.github_org)/$($repo.github_repo)"
        Write-Log "Result: $result"
        Write-Log "============================================================"


        $results += [PSCustomObject]@{
            GitHubRepo = "$($repo.github_org)/$($repo.github_repo)"
            GitLabProject = "$($repo.gitlab_group)/$($repo.gitlab_project)"
            Exists = "✅"
            Branches = "$($glBranches.Count)/$($ghBranches.Count)"
            DefaultMatch = if($defaultMatch){"✅"}else{"❌"}
            CommitMatch = if($commitMatch){"✅"}else{"❌"}
            SHAMatch = if($shaMatch){"✅"}else{"❌"}
            Result = $result
        }

    }
    catch {

        Write-Log "[ERROR] $($_.Exception.Message)"
        $Failed++
    }
}


$results | Export-Csv -Path $SummaryCsv -NoTypeInformation

$results | ConvertTo-Html | Out-File $SummaryMd

Write-Log "[INFO] Validation completed"
Write-Log "[INFO] CSV: $SummaryCsv"
Write-Log "[INFO] MD: $SummaryMd"

Write-Host ""
Write-Host "Summary:"
Write-Host "  Total   : $Total"
Write-Host "  Skipped : $Skipped"
Write-Host "  Success : $Success"
Write-Host "  Failed  : $Failed"

Write-Host ""
Write-Host "===================== FINAL SUMMARY ====================="

$results | Format-Table GitHubRepo,GitLabProject,Exists,Branches,DefaultMatch,CommitMatch,SHAMatch -AutoSize

Write-Host "========================================================="
