param(
    [Parameter(Mandatory = $false)]
    [string]$CsvPath
)

$ErrorActionPreference = "Stop"

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host "[SUCCESS] $Message" -ForegroundColor Green
}

function Write-WarningMsg {
    param([string]$Message)
    Write-Host "[WARNING] $Message" -ForegroundColor Yellow
}

function Write-ErrorMsg {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Write-Header {
    param([string]$Message)
    Write-Host ""
    Write-Host $Message -ForegroundColor Magenta
    Write-Host ("=" * $Message.Length) -ForegroundColor Magenta
}

$TranscriptStarted = $false
$BaseScriptLoc = Split-Path -Parent $MyInvocation.MyCommand.Path

if ([string]::IsNullOrWhiteSpace($BaseScriptLoc)) {
    $BaseScriptLoc = (Get-Location).Path
}

$LogDir = Join-Path $BaseScriptLoc "logs"
$ReadinessLogDir = Join-Path $LogDir "1_migration_readiness_check"
$RequiredColumns = @("group-path", "project", "url")

$ActivePipelineStatuses = @(
    "created",
    "waiting_for_resource",
    "preparing",
    "waiting_for_callback",
    "pending",
    "running",
    "scheduled",
    "canceling"
)

if ([string]::IsNullOrWhiteSpace($CsvPath)) {
    $CsvPath = "projects.csv"
}

Write-Info "Using Inventory File: $CsvPath"

if ([string]::IsNullOrWhiteSpace($env:GITLAB_SERVER_URL)) {
    Write-WarningMsg "GITLAB_SERVER_URL environment variable is not set. Using default: gitlab.com"
    $env:GITLAB_SERVER_URL = "https://gitlab.com"
}

if ([string]::IsNullOrWhiteSpace($env:GITLAB_PAT)) {
    Write-ErrorMsg "GITLAB_PAT environment variable is not set."
    Write-Host "Set it using:" -ForegroundColor Yellow
    Write-Host "`$env:GITLAB_PAT = 'your-pat-token-here'" -ForegroundColor Yellow
    exit 1
}

$GitLabServerUrl = $env:GITLAB_SERVER_URL.Trim().TrimEnd("/")
$GitLabApiEndpoint = "$GitLabServerUrl/api/v4"
$GitLabHeaders = @{
    "PRIVATE-TOKEN" = $env:GITLAB_PAT
    "Accept"        = "application/json"
}

Write-Info "GitLab API Endpoint: $GitLabApiEndpoint"

try {
    foreach ($dir in @($LogDir, $ReadinessLogDir)) {
        if (-not (Test-Path -LiteralPath $dir)) {
           New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
        }
    }
    $RunTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $LogFile = Join-Path $ReadinessLogDir "migration_readiness_$RunTimestamp.log"
    Start-Transcript -Path $LogFile -Append -ErrorAction Stop | Out-Null
    $TranscriptStarted = $true
    Write-Info "Log File: $LogFile"
}
catch {
    Write-WarningMsg "Unable to start transcript logging."
    Write-WarningMsg "Reason: $($_.Exception.Message)"
}

function Stop-ScriptTranscript {
    if ($script:TranscriptStarted) {
        try {
            Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
        }
        catch {
            # Do not override the readiness result because logging failed.
        }
        $script:TranscriptStarted = $false
    }
}

function Get-HttpStatusCode {
    param(
        [Parameter(Mandatory = $true)]
        $ErrorRecord
    )

    $StatusCode = $null

    try {
        if ($ErrorRecord.Exception.Response -and $ErrorRecord.Exception.Response.StatusCode) {
            $StatusCode = [int]$ErrorRecord.Exception.Response.StatusCode
        }
    }
    catch {
        $StatusCode = $null
    }

    if (-not $StatusCode -and $ErrorRecord.Exception.Message -match "\b(\d{3})\b") {
        $StatusCode = [int]$Matches[1]
    }

    return $StatusCode
}

function Encode-Url {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Value
    )
    return [System.Uri]::EscapeDataString($Value)
}

function Invoke-GitLabGet {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url
    )

    try {
        $InvokeParameters = @{
            Method      = "GET"
            Uri         = $Url
            Headers     = $script:GitLabHeaders
            ErrorAction = "Stop"
        }

        if ($env:GITLAB_SKIP_CERTIFICATE_CHECK -eq "true") {
            $InvokeParameters["SkipCertificateCheck"] = $true
        }

        $Response = Invoke-WebRequest @InvokeParameters
        $Body = $null

        if (-not [string]::IsNullOrWhiteSpace($Response.Content)) {
            $Body = $Response.Content | ConvertFrom-Json
        }

        return [PSCustomObject]@{
            Success    = $true
            StatusCode = [int]$Response.StatusCode
            Data       = $Body
            Headers    = $Response.Headers
            Error      = $null
        }
    }
    catch {
        $StatusCode = Get-HttpStatusCode -ErrorRecord $_

        return [PSCustomObject]@{
            Success    = $false
            StatusCode = $StatusCode
            Data       = $null
            Headers    = $null
            Error      = $_.Exception.Message
        }
    }
}

function Get-GitLabPaginatedData {
    param(
        [Parameter(Mandatory = $true)]
        [string]$BaseUrl
    )

    $Page = 1
    $PerPage = 100
    $CombinedResults = @()

    while ($true) {
        $Separator = "?"
        if ($BaseUrl.Contains("?")) {
            $Separator = "&"
        }

        $PageUrl = "${BaseUrl}${Separator}per_page=$PerPage&page=$Page"
        $Response = Invoke-GitLabGet -Url $PageUrl

        if (-not $Response.Success) {
            return [PSCustomObject]@{
                Success    = $false
                StatusCode = $Response.StatusCode
                Data       = @()
                Error      = $Response.Error
            }
        }

        $CurrentPageData = @()
        if ($null -ne $Response.Data) {
            $CurrentPageData = @($Response.Data)
            $CombinedResults += $CurrentPageData
        }

        $NextPage = $null
        if ($Response.Headers) {
            try {
                $NextPage = $Response.Headers["X-Next-Page"]
            }
            catch {
                $NextPage = $null
            }
        }

        if (-not [string]::IsNullOrWhiteSpace([string]$NextPage)) {
            $Page = [int]$NextPage
            continue
        }

        if ($CurrentPageData.Count -lt $PerPage) {
            break
        }

        $Page++
    }

    return [PSCustomObject]@{
        Success    = $true
        StatusCode = 200
        Data       = $CombinedResults
        Error      = $null
    }
}

if (-not (Test-Path -LiteralPath $CsvPath -PathType Leaf)) {
    Write-ErrorMsg "CSV file '$CsvPath' was not found."
    Stop-ScriptTranscript
    exit 1
}

Write-Info "Reading input from file: '$CsvPath'"

try {
    $HeaderLine = Get-Content -LiteralPath $CsvPath -TotalCount 1 -ErrorAction Stop
}
catch {
    Write-ErrorMsg "Unable to read CSV file '$CsvPath'."
    Write-ErrorMsg "Reason: $($_.Exception.Message)"
    Stop-ScriptTranscript
    exit 1
}

if ([string]::IsNullOrWhiteSpace($HeaderLine)) {
    Write-ErrorMsg "CSV header validation failed. File does not contain a valid header row."
    Write-Host "Expected columns: group-path, project, url" -ForegroundColor Yellow
    Stop-ScriptTranscript
    exit 1
}

$CsvColumns = @(
    $HeaderLine.Split(",") | ForEach-Object {
        $_.Trim().Trim('"').Trim([char]0xFEFF)
    }
)

$MissingColumns = @(
    $RequiredColumns | Where-Object { $_ -notin $CsvColumns }
)

if ($MissingColumns.Count -gt 0) {
    Write-ErrorMsg "CSV header validation failed. Missing required column(s): $($MissingColumns -join ', ')"
    Write-Host "Expected columns: group-path, project, url" -ForegroundColor Yellow
    Stop-ScriptTranscript
    exit 1
}

try {
    $Inventory = @(Import-Csv -LiteralPath $CsvPath -ErrorAction Stop)
}
catch {
    Write-ErrorMsg "CSV import failed."
    Write-ErrorMsg "Reason: $($_.Exception.Message)"
    Stop-ScriptTranscript
    exit 1
}

if ($Inventory.Count -eq 0) {
    Write-ErrorMsg "CSV file contains valid headers but no project entries."
    Stop-ScriptTranscript
    exit 1
}

$ImportedColumns = @(
    $Inventory[0].PSObject.Properties.Name | ForEach-Object {
        $_.Trim().Trim([char]0xFEFF)
    }
)

$MissingImportedColumns = @(
    $RequiredColumns | Where-Object { $_ -notin $ImportedColumns }
)

if ($MissingImportedColumns.Count -gt 0) {
    Write-ErrorMsg "CSV header validation failed. Missing required column(s): $($MissingImportedColumns -join ', ')"
    Write-Host "Expected columns: group-path, project, url" -ForegroundColor Yellow
    Stop-ScriptTranscript
    exit 1
}

Write-Info "Validating GITLAB_PAT against GitLab server..."
$PatValidationResponse = Invoke-GitLabGet -Url "$GitLabApiEndpoint/user"

if (-not $PatValidationResponse.Success -or $PatValidationResponse.StatusCode -ne 200) {
    $StatusMessage = ""
    if ($PatValidationResponse.StatusCode) {
        $StatusMessage = " HTTP $($PatValidationResponse.StatusCode)."
    }

    Write-ErrorMsg "GITLAB_PAT validation failed against '$GitLabServerUrl'.$StatusMessage"
    Write-Host "Verify GITLAB_SERVER_URL and ensure GITLAB_PAT has API access." -ForegroundColor Yellow

    if ($PatValidationResponse.Error) {
        Write-ErrorMsg "Reason: $($PatValidationResponse.Error)"
    }

    Stop-ScriptTranscript
    exit 1
}

$AuthenticatedUser = $PatValidationResponse.Data.username
if (-not [string]::IsNullOrWhiteSpace([string]$AuthenticatedUser)) {
    Write-Success "GITLAB_PAT validation successful. Authenticated as '$AuthenticatedUser'."
}
else {
    Write-Success "GITLAB_PAT validation successful."
}

$ActiveMrSummary = @()
$ActivePipelineSummary = @()
$MrCheckFailed = $false
$PipelineCheckFailed = $false
$ProjectCheckFailed = $false
$TotalRows = 0
$ProcessedProjects = 0
$SkippedRows = 0

Write-Host ""
Write-Info "Scanning GitLab projects for open merge requests and active pipelines..."
Write-Host ""

foreach ($Row in $Inventory) {
    $TotalRows++
    $GroupPath = ""
    $ProjectName = ""
    $ProjectUrl = ""

    if ($null -ne $Row.'group-path') {
        $GroupPath = ([string]$Row.'group-path').Trim()
    }

    if ($null -ne $Row.project) {
        $ProjectName = ([string]$Row.project).Trim()
    }

    if ($null -ne $Row.url) {
        $ProjectUrl = ([string]$Row.url).Trim()
    }

    if ([string]::IsNullOrWhiteSpace($GroupPath) -or [string]::IsNullOrWhiteSpace($ProjectName) -or [string]::IsNullOrWhiteSpace($ProjectUrl)) {
        $SkippedRows++
        Write-WarningMsg "Skipping CSV row $TotalRows because group-path, project, or url is empty."
        continue
    }

    # Extract project path from URL (e.g., "pauljaison-group/ecommerce-store" from "https://gitlab.com/pauljaison-group/ecommerce-store")
    $ProjectPath = $ProjectUrl -replace '^https?://[^/]+/(.*)$', '$1'
    if ($ProjectPath -eq $ProjectUrl) {
        $SkippedRows++
        Write-WarningMsg "Skipping CSV row $TotalRows because URL format is invalid: '$ProjectUrl'"
        continue
    }

    $EncodedProjectPath = Encode-Url -Value $ProjectPath
    Write-Info "Checking project '$ProjectPath' (URL: $ProjectUrl)"

    $ProjectResponse = Invoke-GitLabGet -Url "$GitLabApiEndpoint/projects/$EncodedProjectPath"

    if (-not $ProjectResponse.Success) {
        $ProjectCheckFailed = $true
        $MrCheckFailed = $true
        $PipelineCheckFailed = $true
        $StatusMessage = ""

        if ($ProjectResponse.StatusCode) {
            $StatusMessage = " HTTP $($ProjectResponse.StatusCode)."
        }

        Write-ErrorMsg "Failed to resolve project '$ProjectPath'.$StatusMessage"
        if ($ProjectResponse.Error) {
            Write-ErrorMsg "Reason: $($ProjectResponse.Error)"
        }

        Write-WarningMsg "Skipping merge request and pipeline checks for '$ProjectPath'."
        continue
    }

    $ProjectId = $ProjectResponse.Data.id
    $DisplayName = [string]$ProjectResponse.Data.path_with_namespace

    if ([string]::IsNullOrWhiteSpace($DisplayName)) {
        $DisplayName = $ProjectPath
    }

    if ($null -eq $ProjectId) {
        $ProjectCheckFailed = $true
        $MrCheckFailed = $true
        $PipelineCheckFailed = $true
        Write-ErrorMsg "GitLab returned no project ID for '$ProjectPath'."
        Write-WarningMsg "Skipping merge request and pipeline checks for '$ProjectPath'."
        continue
    }

    $ProcessedProjects++

    $MergeRequestUrl = "$GitLabApiEndpoint/projects/$ProjectId/merge_requests?state=opened"
    $MergeRequestResult = Get-GitLabPaginatedData -BaseUrl $MergeRequestUrl

    if (-not $MergeRequestResult.Success) {
        $MrCheckFailed = $true
        $StatusMessage = ""

        if ($MergeRequestResult.StatusCode) {
            $StatusMessage = " HTTP $($MergeRequestResult.StatusCode)."
        }

        Write-ErrorMsg "Failed to retrieve merge requests for '$DisplayName'.$StatusMessage"
        if ($MergeRequestResult.Error) {
            Write-ErrorMsg "Reason: $($MergeRequestResult.Error)"
        }
    }
    else {
        foreach ($MergeRequest in @($MergeRequestResult.Data)) {
            $ActiveMrSummary += [PSCustomObject]@{
                Project = $DisplayName
                Iid     = $MergeRequest.iid
                Title   = $MergeRequest.title
                Status  = $MergeRequest.state
                Url     = $MergeRequest.web_url
            }
        }
    }

    $PipelineUrl = "$GitLabApiEndpoint/projects/$ProjectId/pipelines"
    $PipelineResult = Get-GitLabPaginatedData -BaseUrl $PipelineUrl

    if (-not $PipelineResult.Success) {
        $PipelineCheckFailed = $true
        $StatusMessage = ""

        if ($PipelineResult.StatusCode) {
            $StatusMessage = " HTTP $($PipelineResult.StatusCode)."
        }

        Write-ErrorMsg "Failed to retrieve pipelines for '$DisplayName'.$StatusMessage"
        if ($PipelineResult.Error) {
            Write-ErrorMsg "Reason: $($PipelineResult.Error)"
        }
    }
    else {
        $ActivePipelines = @(
            $PipelineResult.Data | Where-Object {
                $_.status -in $ActivePipelineStatuses
            }
        )

        foreach ($Pipeline in $ActivePipelines) {
            $ActivePipelineSummary += [PSCustomObject]@{
                Project    = $DisplayName
                PipelineId = $Pipeline.id
                Ref        = $Pipeline.ref
                Status     = $Pipeline.status
                Url        = $Pipeline.web_url
            }
        }
    }
}

Write-Header "Pre-Migration Validation Summary (GitLab)"
Write-Host "Total CSV rows       : $TotalRows"
Write-Host "Projects processed   : $ProcessedProjects"
Write-Host "Rows skipped         : $SkippedRows"
Write-Host ""

if ($MrCheckFailed) {
    Write-ErrorMsg "One or more merge request checks could not be completed."
}

if ($ActiveMrSummary.Count -gt 0) {
    Write-WarningMsg "Detected Open Merge Request(s):"

    foreach ($Entry in $ActiveMrSummary) {
        Write-Host ""
        Write-Host "Project : $($Entry.Project)"
        Write-Host "MR      : !$($Entry.Iid)"
        Write-Host "Title   : $($Entry.Title)"
        Write-Host "Status  : $($Entry.Status)"
        Write-Host "MR URL  : $($Entry.Url)"
    }
}
elseif (-not $MrCheckFailed) {
    Write-Success "Merge Request Summary --> No Open Merge Requests"
}

Write-Host ""

if ($PipelineCheckFailed) {
    Write-ErrorMsg "One or more pipeline checks could not be completed."
}

if ($ActivePipelineSummary.Count -gt 0) {
    Write-WarningMsg "Detected Active Pipeline(s):"

    foreach ($Entry in $ActivePipelineSummary) {
        Write-Host ""
        Write-Host "Project     : $($Entry.Project)"
        Write-Host "Pipeline ID : $($Entry.PipelineId)"
        Write-Host "Ref         : $($Entry.Ref)"
        Write-Host "Status      : $($Entry.Status)"
        Write-Host "Run URL     : $($Entry.Url)"
    }
}
elseif (-not $PipelineCheckFailed) {
    Write-Success "Pipeline Summary --> No Active Pipelines"
}

Write-Host ""

$HasActiveItems = (
    $ActiveMrSummary.Count -gt 0 -or
    $ActivePipelineSummary.Count -gt 0
)

$HasFailures = (
    $ProjectCheckFailed -or
    $MrCheckFailed -or
    $PipelineCheckFailed
)

if ($HasFailures -and -not $HasActiveItems) {
    Write-ErrorMsg "Validation checks could not be completed due to API failures."
    Write-Host "Review the errors before proceeding with migration." -ForegroundColor Red
    Stop-ScriptTranscript
    exit 1
}
elseif ($HasFailures -and $HasActiveItems) {
    Write-WarningMsg "Active items were detected, and some validation checks failed."
    Write-Host "Review all warnings and errors before proceeding with migration." -ForegroundColor Yellow
    Stop-ScriptTranscript
    exit 1
}
elseif (-not $HasFailures -and $HasActiveItems) {
    Write-WarningMsg "Open merge requests or active pipelines were found."
    Write-Host "Continue with migration only after reviewing the active items." -ForegroundColor Yellow
    Stop-ScriptTranscript
    exit 0
}
else {
    Write-Success "No open merge requests or active pipelines were detected."
    Write-Success "You can proceed with migration."
    Stop-ScriptTranscript
    exit 0
}
