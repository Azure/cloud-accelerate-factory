$ErrorActionPreference = "Stop"

# ============================================================
# - Generates migration status CSV
# - Generates repos_with_status.csv for downstream stages
# ============================================================

# CLI arguments
$MaxConcurrent = 10
$CsvPath = if ($env:INVENTORY_FILE) { $env:INVENTORY_FILE } else { "projects.csv" }
$OutputPath = ""

for ($i = 0; $i -lt $args.Count; $i++) {
    switch ($args[$i]) {
        "--max-concurrent" {
            $i++
            $MaxConcurrent = [int]$args[$i]
        }
        "--csv" {
            $i++
            $CsvPath = $args[$i]
        }
        "--output" {
            $i++
            $OutputPath = $args[$i]
        }
        default {
            throw "Unknown option: $($args[$i])"
        }
    }
}

############################################
# Defaults
############################################
$timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")

$RootDir = if ($env:CI_PROJECT_DIR) { $env:CI_PROJECT_DIR } else { (Get-Location).Path }
$LogDir = Join-Path $RootDir "logs"
$MigrationLogDir = Join-Path $LogDir "2_migration"
$RepoMigrationLogDir = Join-Path $MigrationLogDir "repository-migration-logs"
$OutputDir = Join-Path $RootDir "output_files"

New-Item -ItemType Directory -Force -Path $LogDir, $MigrationLogDir, $RepoMigrationLogDir, $OutputDir | Out-Null

$RunLog = Join-Path $MigrationLogDir "gl2gh-migrate-repos-$timestamp.log"
$ReposWithStatusCsv = Join-Path $OutputDir "repos_with_status.csv"

############################################
# Logging
############################################
function Write-Log {
    param([string]$Message)

    $msg = "[{0}] {1}" -f (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"), $Message
    Write-Host $msg
    Add-Content -Path $RunLog -Value $msg
}

function Fail {
    param([string]$Message)
    Write-Log "[ERROR] $Message"
    exit 1
}

############################################
# Helpers
############################################
function Trim-Value {
    param([AllowNull()][string]$Value)
    if ($null -eq $Value) { return "" }
    return $Value.Replace("`r", "").Trim()
}

function Normalize-Url {
    param([AllowNull()][string]$Url)

    $u = Trim-Value $Url
    if ([string]::IsNullOrWhiteSpace($u)) { return "" }

    if ($u -notmatch '^https?://') {
        $u = "https://$u"
    }

    return $u.TrimEnd('/')
}

function Require-Command {
    param([string]$Name)

    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        Fail "Required command not found: $Name"
    }
}

function Require-Env {
    param([string]$Name)

    $value = [Environment]::GetEnvironmentVariable($Name)
    if ([string]::IsNullOrWhiteSpace($value)) {
        Fail "$Name is required"
    }
}

function Get-MigrationId {
    param([string]$File)

    if (-not (Test-Path $File)) { return "" }

    $content = Get-Content -Path $File -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($content)) { return "" }

    $patterns = @(
        '(?im)Migration\s+ID[:\s]*([A-Za-z0-9_-]+)',
        '(?im)Migration\s+in\s+progress\s+\(ID:\s*([A-Za-z0-9_-]+)\)',
        '(?im)migrationId[=:\s]*([A-Za-z0-9_-]+)'
    )

    foreach ($pattern in $patterns) {
        $matches = [regex]::Matches($content, $pattern)
        if ($matches.Count -gt 0) {
            return $matches[$matches.Count - 1].Groups[1].Value
        }
    }

    return ""
}

function Normalize-HeaderName {
    param([string]$Name)

    return (Trim-Value $Name).ToLowerInvariant().Replace("-", "_").Replace(" ", "_")
}

function Quote-Csv {
    param([AllowNull()][object]$Value)

    $s = if ($null -eq $Value) { "" } else { [string]$Value }
    return '"' + $s.Replace('"', '""') + '"'
}

############################################
# Validate inputs
############################################
Require-Command "gh"

Require-Env "GITLAB_SERVER_URL"
Require-Env "GITLAB_PAT"
Require-Env "GH_PAT"

$SourceGlServerUrl = Normalize-Url $env:GITLAB_SERVER_URL
$GitHubApiUrl = Normalize-Url $(if ($env:GITHUB_API_URL) { $env:GITHUB_API_URL } else { "https://api.github.com" })

if ($GitHubApiUrl -match '^https://api\.github\.com/?$') {
    Write-Log "[INFO] Migration destination : GitHub Enterprise Cloud"
}
elseif ($GitHubApiUrl -match '^https://api\.[a-zA-Z0-9.-]+\.ghe\.com/?$') {
    Write-Log "[INFO] Migration destination : GitHub Enterprise Cloud Data Residency"
}
else {
    Fail "Invalid GITHUB_API_URL: $GitHubApiUrl"
}

if ($MaxConcurrent -lt 1) {
    Fail "--max-concurrent must be at least 1"
}

if (-not (Test-Path -Path $CsvPath -PathType Leaf)) {
    Fail "CSV file not found: $CsvPath"
}

if ((Get-Item $CsvPath).Length -eq 0) {
    Fail "CSV file is empty: $CsvPath"
}

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputCsvPath = Join-Path $OutputDir "gl2gh_migration_output-$timestamp.csv"
}
else {
    $OutputCsvPath = $OutputPath
}

$env:GH_PAT = $env:GH_PAT
$env:GH_TOKEN = $env:GH_PAT
$env:GL_PAT = $env:GITLAB_PAT
if (-not $env:GEI_SKIP_VERSION_CHECK) { $env:GEI_SKIP_VERSION_CHECK = "true" }
if (-not $env:GEI_SKIP_STATUS_CHECK) { $env:GEI_SKIP_STATUS_CHECK = "true" }

############################################
# Load CSV + header validation
############################################
try {
    $Rows = @(Import-Csv -Path $CsvPath)
}
catch {
    Fail "Failed to read CSV: $($_.Exception.Message)"
}

if ($Rows.Count -eq 0) {
    Fail "CSV contains no repository rows: $CsvPath"
}

$Headers = @($Rows[0].PSObject.Properties.Name)
$NormalizedHeaders = @{}
foreach ($h in $Headers) {
    $NormalizedHeaders[(Normalize-HeaderName $h)] = $h
}

$RequiredColumns = @(
    "group_path",
    "project",
    "url",
    "github_org",
    "github_repo",
    "gh_repo_visibility"
)

$Missing = @()
foreach ($col in $RequiredColumns) {
    if (-not $NormalizedHeaders.ContainsKey($col)) {
        $Missing += $col
    }
}

if ($Missing.Count -gt 0) {
    Fail "CSV missing required columns: $($Missing -join ' ')"
}

############################################
# Status CSV helpers
############################################
$StatusLock = [System.Object]::new()
$StatusRows = [System.Collections.Generic.List[object]]::new()

function Save-StatusCsv {
    [System.Threading.Monitor]::Enter($StatusLock)
    try {
        $StatusRows |
            Select-Object gitlab_group,gitlab_project,github_org,github_repo,gh_repo_visibility,Migration_Status,Log_File |
            Export-Csv -Path $OutputCsvPath -NoTypeInformation -Encoding utf8
    }
    finally {
        [System.Threading.Monitor]::Exit($StatusLock)
    }
}

function Update-RepoStatus {
    param(
        [string]$TargetOrg,
        [string]$TargetRepo,
        [string]$NewStatus,
        [string]$LogFile
    )

    [System.Threading.Monitor]::Enter($StatusLock)
    try {
        foreach ($row in $StatusRows) {
            if ($row.github_org -eq $TargetOrg -and $row.github_repo -eq $TargetRepo) {
                $row.Migration_Status = $NewStatus
                $row.Log_File = $LogFile
                break
            }
        }

        $StatusRows |
            Select-Object gitlab_group,gitlab_project,github_org,github_repo,gh_repo_visibility,Migration_Status,Log_File |
            Export-Csv -Path $OutputCsvPath -NoTypeInformation -Encoding utf8
    }
    finally {
        [System.Threading.Monitor]::Exit($StatusLock)
    }
}

############################################
# Build common GL2GH args
############################################
$CommonArgs = [System.Collections.Generic.List[string]]::new()

$CommonArgs.Add("--gitlab-server-url")
$CommonArgs.Add($SourceGlServerUrl)
$CommonArgs.Add("--github-pat")
$CommonArgs.Add($env:GH_PAT)
$CommonArgs.Add("--gitlab-pat")
$CommonArgs.Add($env:GITLAB_PAT)
$CommonArgs.Add("--target-api-url")
$CommonArgs.Add($GitHubApiUrl)

$TargetUploadUrl = Normalize-Url $env:TARGET_UPLOAD_URL
if (-not [string]::IsNullOrWhiteSpace($TargetUploadUrl)) {
    $CommonArgs.Add("--target-uploads-url")
    $CommonArgs.Add($TargetUploadUrl)
}

$StorageType = if ($env:STORAGE_TYPE) { $env:STORAGE_TYPE.ToUpperInvariant() } else { "GITHUB" }

switch ($StorageType) {
    "GITHUB" {
        $CommonArgs.Add("--use-github-storage")
    }
    "AZURE" {
        Require-Env "AZURE_STORAGE_CONNECTION_STRING"
        $CommonArgs.Add("--azure-storage-connection-string")
        $CommonArgs.Add($env:AZURE_STORAGE_CONNECTION_STRING)
    }
    "AWS" {
        Require-Env "AWS_BUCKET_NAME"
        Require-Env "AWS_REGION"
        Require-Env "AWS_ACCESS_KEY_ID"
        Require-Env "AWS_SECRET_ACCESS_KEY"

        $CommonArgs.Add("--aws-bucket-name")
        $CommonArgs.Add($env:AWS_BUCKET_NAME)
        $CommonArgs.Add("--aws-region")
        $CommonArgs.Add($env:AWS_REGION)
        $CommonArgs.Add("--aws-access-key")
        $CommonArgs.Add($env:AWS_ACCESS_KEY_ID)
        $CommonArgs.Add("--aws-secret-key")
        $CommonArgs.Add($env:AWS_SECRET_ACCESS_KEY)

        if ($env:AWS_SESSION_TOKEN) {
            $CommonArgs.Add("--aws-session-token")
            $CommonArgs.Add($env:AWS_SESSION_TOKEN)
        }
    }
    default {
        Fail "Invalid STORAGE_TYPE: $StorageType. Valid values: GITHUB, AZURE, AWS"
    }
}

$SkipSslVerify = if ($env:SKIP_SSL_VERIFY) { $env:SKIP_SSL_VERIFY.ToUpperInvariant() } else { "N" }
if ($SkipSslVerify -in @("Y", "YES")) {
    $CommonArgs.Add("--no-ssl-verify")
}

if ($env:GITLAB_DEBUG -eq "true") {
    $CommonArgs.Add("--gitlab-debug")
    $CommonArgs.Add("--verbose")
}

############################################
# Build migration queue
############################################
$Queue = [System.Collections.Generic.Queue[object]]::new()
$Migrated = [System.Collections.Generic.List[object]]::new()
$Failed = [System.Collections.Generic.List[object]]::new()
$Skipped = 0

$lineNum = 1

foreach ($row in $Rows) {
    $lineNum++

    $gitlabGroup = Trim-Value $row.($NormalizedHeaders["group_path"])
    $gitlabProject = Trim-Value $row.($NormalizedHeaders["project"])
    $fullUrl = Trim-Value $row.($NormalizedHeaders["url"])
    $githubOrg = Trim-Value $row.($NormalizedHeaders["github_org"])
    $githubRepo = Trim-Value $row.($NormalizedHeaders["github_repo"])
    $visibility = Trim-Value $row.($NormalizedHeaders["gh_repo_visibility"])

    if (-not [string]::IsNullOrWhiteSpace($fullUrl)) {
        try {
            $cleanUrl = ($fullUrl -split '\?')[0]
            if ($cleanUrl.EndsWith(".git")) {
                $cleanUrl = $cleanUrl.Substring(0, $cleanUrl.Length - 4)
            }

            $uri = [Uri]$cleanUrl
            $pathPart = $uri.AbsolutePath.Trim('/')

            if (-not [string]::IsNullOrWhiteSpace($pathPart)) {
                $segments = $pathPart.Split('/', [System.StringSplitOptions]::RemoveEmptyEntries)

                if ($segments.Count -ge 2) {
                    $gitlabProject = $segments[-1]
                    $gitlabGroup = ($segments[0..($segments.Count - 2)] -join '/')
                }
            }
        }
        catch {
            Write-Host "[WARNING] Could not resolve GitLab path from URL on line $lineNum. Using CSV group/project values."
        }
    }

    if (
        [string]::IsNullOrWhiteSpace($gitlabGroup) -or
        [string]::IsNullOrWhiteSpace($gitlabProject) -or
        [string]::IsNullOrWhiteSpace($githubOrg) -or
        [string]::IsNullOrWhiteSpace($githubRepo) -or
        [string]::IsNullOrWhiteSpace($visibility)
    ) {
        Write-Host "[WARNING] Skipping malformed line ${lineNum}: missing required values"
        $Skipped++
        continue
    }

    $repoItem = [pscustomobject]@{
        gitlab_group       = $gitlabGroup
        gitlab_project     = $gitlabProject
        github_org         = $githubOrg
        github_repo        = $githubRepo
        gh_repo_visibility = $visibility
    }

    $Queue.Enqueue($repoItem)

    $StatusRows.Add([pscustomobject]@{
        gitlab_group       = $gitlabGroup
        gitlab_project     = $gitlabProject
        github_org         = $githubOrg
        github_repo        = $githubRepo
        gh_repo_visibility = $visibility
        Migration_Status   = "Pending"
        Log_File           = ""
    })
}

Save-StatusCsv

Write-Log "============================================================"
Write-Log "GitLab to GitHub migration using gh gl2gh migrate-repo"
Write-Log "============================================================"
Write-Log "[INFO] CSV_PATH              : $CsvPath"
Write-Log "[INFO] GITLAB_SERVER_URL  : $SourceGlServerUrl"
Write-Log "[INFO] GITHUB_API_URL        : $GitHubApiUrl"
Write-Log "[INFO] MAX_CONCURRENT        : $MaxConcurrent"
Write-Log "[INFO] STORAGE_TYPE          : $StorageType"
Write-Log "[INFO] Output CSV            : $OutputCsvPath"

Write-Host "[INFO] Starting migration with $MaxConcurrent concurrent jobs..."
Write-Host "[INFO] Processing $($Queue.Count) repositories from: $CsvPath"
Write-Host "[INFO] Initialized migration status output: $OutputCsvPath"

############################################
# Status bar
############################################
function Show-StatusBar {
    param(
        [int]$QueueCount,
        [int]$InProgress,
        [int]$MigratedCount,
        [int]$FailedCount
    )

    $status = "QUEUE: $QueueCount | IN PROGRESS: $InProgress | MIGRATED: $MigratedCount | MIGRATION FAILED: $FailedCount"
    Write-Host -NoNewline "`r$($PSStyle.Foreground.Cyan)$status$($PSStyle.Reset)"
}

############################################
# Migration worker
############################################
$Worker = {
    param(
        $Repo,
        [string[]]$CommonArgs,
        [string]$LogFile,
        [string]$MigrationLogDir
    )

    $ErrorActionPreference = "Stop"

    function Get-WorkerMigrationId {
        param([string]$File)

        if (-not (Test-Path $File)) { return "" }

        $content = Get-Content -Path $File -Raw -ErrorAction SilentlyContinue
        if ([string]::IsNullOrWhiteSpace($content)) { return "" }

        $patterns = @(
            '(?im)Migration\s+ID[:\s]*([A-Za-z0-9_-]+)',
            '(?im)Migration\s+in\s+progress\s+\(ID:\s*([A-Za-z0-9_-]+)\)',
            '(?im)migrationId[=:\s]*([A-Za-z0-9_-]+)'
        )

        foreach ($pattern in $patterns) {
            $matches = [regex]::Matches($content, $pattern)
            if ($matches.Count -gt 0) {
                return $matches[$matches.Count - 1].Groups[1].Value
            }
        }

        return ""
    }

    $startLine = "[{0}] [START] Migration: {1}/{2} -> {3}/{4} (gh_repo_visibility: {5})" -f `
        (Get-Date), $Repo.gitlab_group, $Repo.gitlab_project, $Repo.github_org, $Repo.github_repo, $Repo.gh_repo_visibility
    Add-Content -Path $LogFile -Value $startLine

    Add-Content -Path $LogFile -Value ("[{0}] [INFO] Submitting migration request for {1}/{2}" -f (Get-Date), $Repo.github_org, $Repo.github_repo)

    $argsList = [System.Collections.Generic.List[string]]::new()
    foreach ($a in $CommonArgs) { $argsList.Add($a) }

    $argsList.Add("--gitlab-group")
    $argsList.Add($Repo.gitlab_group)
    $argsList.Add("--gitlab-project")
    $argsList.Add($Repo.gitlab_project)
    $argsList.Add("--github-org")
    $argsList.Add($Repo.github_org)
    $argsList.Add("--github-repo")
    $argsList.Add($Repo.github_repo)
    $argsList.Add("--target-repo-visibility")
    $argsList.Add($Repo.gh_repo_visibility)

    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = "gh"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.WorkingDirectory = $MigrationLogDir

    # GitHub CLI extension command
    # Equivalent to: gh gl2gh migrate-repo
    [void]$psi.ArgumentList.Add("gl2gh")
    [void]$psi.ArgumentList.Add("migrate-repo")

    foreach ($arg in $argsList) {
        [void]$psi.ArgumentList.Add($arg)
    }

    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $psi

    [void]$process.Start()

    # Stream stdout/stderr continuously to the repository log file.
    # The parent monitoring loop will read the growing log file and display
    # live migration output without changing migration behavior.

    $logWriter = [System.IO.StreamWriter]::new($LogFile, $true)
    $logWriter.AutoFlush = $true

    try {
        while (-not $process.HasExited) {

            while (-not $process.StandardOutput.EndOfStream) {
                $line = $process.StandardOutput.ReadLine()
                if ($line) {
                    $logWriter.WriteLine($line)
                }
            }

            while (-not $process.StandardError.EndOfStream) {
                $line = $process.StandardError.ReadLine()
                if ($line) {
                    $logWriter.WriteLine($line)
                }
            }

            Start-Sleep -Milliseconds 500
        }

        while (-not $process.StandardOutput.EndOfStream) {
            $line = $process.StandardOutput.ReadLine()
            if ($line) {
                $logWriter.WriteLine($line)
            }
        }

        while (-not $process.StandardError.EndOfStream) {
            $line = $process.StandardError.ReadLine()
            if ($line) {
                $logWriter.WriteLine($line)
            }
        }
    }
    finally {
        $logWriter.Dispose()
    }

    $migrationId = Get-WorkerMigrationId $LogFile

    if ($migrationId) {
        Add-Content -Path $LogFile -Value ("[{0}] [INFO] Migration ID: {1}" -f (Get-Date), $migrationId)
    }

    $migrationLogContent = Get-Content -Path $LogFile -Raw -ErrorAction SilentlyContinue
    if (($process.ExitCode -eq 0) -and ($migrationLogContent -match "State:\s*SUCCEEDED")) {
        Add-Content -Path $LogFile -Value ("[{0}] [SUCCESS] Migration: {1}/{2} -> {3}/{4}" -f `
            (Get-Date), $Repo.gitlab_group, $Repo.gitlab_project, $Repo.github_org, $Repo.github_repo)

        return [pscustomobject]@{
            Result = "SUCCESS"
            Repo = $Repo
            LogFile = $LogFile
            MigrationId = $migrationId
            ExitCode = 0
        }
    }

    Add-Content -Path $LogFile -Value ("[{0}] [FAILED] Migration failed for {1}/{2}. See log file for details." -f `
        (Get-Date), $Repo.github_org, $Repo.github_repo)

    return [pscustomobject]@{
        Result = "FAILED"
        Repo = $Repo
        LogFile = $LogFile
        MigrationId = $migrationId
        ExitCode = $process.ExitCode
    }
}

############################################
# Main loop
############################################
$Jobs = [System.Collections.Generic.List[object]]::new()

while ($Queue.Count -gt 0 -or $Jobs.Count -gt 0) {

    while ($Jobs.Count -lt $MaxConcurrent -and $Queue.Count -gt 0) {
        $repo = $Queue.Dequeue()

        $safeName = ("{0}_{1}" -f $repo.github_org, $repo.github_repo) -replace '[/:\s]', '_'
        $safeName = $safeName -replace '[^A-Za-z0-9._-]', ''
        $logFile = Join-Path $RepoMigrationLogDir "gl2gh-$safeName-$timestamp.log"

        Update-RepoStatus -TargetOrg $repo.github_org -TargetRepo $repo.github_repo -NewStatus "In Progress" -LogFile $logFile

        $ps = [PowerShell]::Create()

        [void]$ps.AddScript($Worker.ToString())
        [void]$ps.AddArgument($repo)
        [void]$ps.AddArgument([string[]]$CommonArgs.ToArray())
        [void]$ps.AddArgument($logFile)
        [void]$ps.AddArgument($MigrationLogDir)

        $async = $ps.BeginInvoke()

        $Jobs.Add([pscustomobject]@{
            PowerShell = $ps
            AsyncResult = $async
            Repo = $repo
            LogFile = $logFile
            LastLength = 0L
        })

        Show-StatusBar -QueueCount $Queue.Count -InProgress $Jobs.Count -MigratedCount $Migrated.Count -FailedCount $Failed.Count
    }

    foreach ($job in @($Jobs)) {
        if (Test-Path $job.LogFile) {
            $length = (Get-Item $job.LogFile).Length

            if ($length -gt $job.LastLength) {
                $stream = [System.IO.File]::Open($job.LogFile, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
                try {
                    [void]$stream.Seek($job.LastLength, [System.IO.SeekOrigin]::Begin)
                    $reader = [System.IO.StreamReader]::new($stream)
                    $delta = $reader.ReadToEnd()
                    if ($delta) {
                        Write-Host ""
                        foreach ($line in ($delta -split "`r?`n")) {
                            if (-not [string]::IsNullOrWhiteSpace($line)) {
                                Write-Host $line
                            }
                        }
                    }
                    $job.LastLength = $length
                }
                finally {
                    if ($reader) { $reader.Dispose() }
                    $stream.Dispose()
                }

                Show-StatusBar -QueueCount $Queue.Count -InProgress $Jobs.Count -MigratedCount $Migrated.Count -FailedCount $Failed.Count
            }
        }
    }

    foreach ($job in @($Jobs)) {
        if ($job.AsyncResult.IsCompleted) {
            try {
                $result = $job.PowerShell.EndInvoke($job.AsyncResult) | Select-Object -Last 1
            }
            catch {
                $result = [pscustomobject]@{
                    Result = "FAILED"
                    Repo = $job.Repo
                    LogFile = $job.LogFile
                    MigrationId = ""
                    ExitCode = 1
                }
            }
            finally {
                $job.PowerShell.Dispose()
            }

            if ($result.Result -eq "SUCCESS") {
                $Migrated.Add($job.Repo)
                Update-RepoStatus -TargetOrg $job.Repo.github_org -TargetRepo $job.Repo.github_repo -NewStatus "Success" -LogFile $job.LogFile
            }
            else {
                $Failed.Add($job.Repo)
                Update-RepoStatus -TargetOrg $job.Repo.github_org -TargetRepo $job.Repo.github_repo -NewStatus "Failure" -LogFile $job.LogFile
            }

            [void]$Jobs.Remove($job)

            Show-StatusBar -QueueCount $Queue.Count -InProgress $Jobs.Count -MigratedCount $Migrated.Count -FailedCount $Failed.Count
        }
    }

    Start-Sleep -Seconds 2
}

Write-Host ""
Write-Host "[INFO] All migrations completed."

$totalRepos = $Migrated.Count + $Failed.Count + $Skipped

Write-Host "[SUMMARY] Total: $totalRepos | Migrated: $($Migrated.Count) | Failed: $($Failed.Count) | Skipped: $Skipped"
Write-Host "[INFO] Wrote migration results with Migration_Status column: $OutputCsvPath"

############################################
# Generate repos_with_status.csv
############################################
Write-Host "[INFO] Generating repos_with_status.csv for downstream stages..."

$DownstreamRows = [System.Collections.Generic.List[object]]::new()

foreach ($item in $Migrated) {
    $DownstreamRows.Add([pscustomobject]@{
        gitlab_group       = $item.gitlab_group
        gitlab_project     = $item.gitlab_project
        github_org         = $item.github_org
        github_repo        = $item.github_repo
        gh_repo_visibility = $item.gh_repo_visibility
        MigrationStatus    = "Success"
    })
}

foreach ($item in $Failed) {
    $DownstreamRows.Add([pscustomobject]@{
        gitlab_group       = $item.gitlab_group
        gitlab_project     = $item.gitlab_project
        github_org         = $item.github_org
        github_repo        = $item.github_repo
        gh_repo_visibility = $item.gh_repo_visibility
        MigrationStatus    = "Failed"
    })
}

$DownstreamRows |
    Select-Object gitlab_group,gitlab_project,github_org,github_repo,gh_repo_visibility,MigrationStatus |
    Export-Csv -Path $ReposWithStatusCsv -NoTypeInformation -Encoding utf8

Write-Host "[INFO] Generated $ReposWithStatusCsv"

if ($Failed.Count -gt 0) {
    Write-Host "[WARNING] Migration completed with $($Failed.Count) failures" -ForegroundColor Yellow
}
