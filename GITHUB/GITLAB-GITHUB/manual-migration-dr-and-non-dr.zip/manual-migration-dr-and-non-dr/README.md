# Factory Runbook – GitLab Server to GitHub Migration

## 1. Executive Summary – Objective
This document provides detailed procedures to migrate source code repositories from **GitLab Server** to **GitHub**.

## 2. Pre-Requisites
### 2.1 Operating System Requirements
- Ubuntu OS

### 2.2 Software Requirements
- Docker (latest preferred)
- Node.js v20+
- npm v10+
- npm packages:
  - `@octokit/rest`
  - `@octokit/graphql`

### 2.3 Required Token Scopes
#### GitLab API Token
- Must be generated using an **admin user**
- Required permissions: **full API access**
- Used by `gl-exporter` during archive generation

#### GitHub Personal Access Token (PAT)
Required scopes:
- `repo`
- `admin:org`
- `workflow`
- `user`

### 2.4 Intermediate Storage for Archive Files
- GitHub Storage (up to 30 GB)
- Azure / AWS Storage (up to 40 GB)
- **GitHub Cloud with Data Residency requires Azure or AWS storage**

### 2.5 Enable GitHub Object Storage Feature Flag
- GitHub object storage feature flag must be enabled both for GitHub handle and GitHub organizations. Raise a request with GitHub Support to enable this feature.

### 2.6 Install GH CLI
- Install GitHub CLI by following the link below
```
https://github.com/cli/cli#installation
```

### 2.7 Authenticate GitHub
- For GitHub Enterprise Cloud without Data Residency:
```
gh auth login --hostname github.com
```
- For GitHub Enterprise Cloud with Data Residency:
```
gh auth login --hostname SUBDOMAIN.ghe.com
```

### 2.8 Install GH CLI extensions
- Install gh-gitlab-stats CLI extension by running below command. This extension is required for generating inventory reports.
```
gh extension install https://github.com/mona-actions/gh-gitlab-stats
```
- Install gh-migration-monitor CLI extension by running below command. This extension is required to monitor the status of migrations.
```
gh extension install https://github.com/mona-actions/gh-migration-monitor
```
- Install the gh-ado2gh CLI extension. This extension is required to generate mannequins (user identity mapping) CSV files, reclaim mannequins, and wait for/check the migration status.
```
gh extension install https://github.com/github/gh-ado2gh
```

### 2.9 Install GH CLI extensions
- The customer is required to configure the allow IP lists according to their implementation. The following documentation will assist with configuration if it has not yet been completed.
```
https://docs.github.com/en/enterprise-cloud@latest/migrations/ado/managing-access-for-a-migration-from-azure-devops#configuring-ip-allow-lists-for-migrations
```

## 3. Pre-Migration

### 3.1 Build gl-exporter Docker Image
- Copy gl_exporter folder to the server where the migration commands will be executed.
- Build the `gl-exporter` Docker image using running `docker build` command
```bash
cd gl_exporter
sudo docker build --no-cache=true -t gl-exporter .
```
- Verify the image creation using the `docker images` command.

**Example output:**

```bash
root@GLMigration:/opt/migration2ghscripts_new# docker images
REPOSITORY    TAG       IMAGE ID       CREATED        SIZE
gl-exporter   latest    5e168437a7a1   12 hours ago   1.51GB
ruby          3.2.1     3440a912810a   2 years ago    893MB
```

### 3.2 Setting Up Path for Scripts
The following custom-made scripts are required to execute the migration.  
Copy these scripts from bash_scripts folder to the server where the migration commands will be executed.

- `config.sh`  
  Contains shared variables used by multiple scripts.

- `runner.sh`  
  GitHub migration using JavaScript (used by the repository migration script).

- `gl-migration-readiness-check.sh`  
  Checks active merge requestes and active pipelines for the projects that are present in inventory report.

- `generate-gl-migration-archive.sh`  
  Generates GitLab migration archives (exports) for repositories defined in the inventory.

- `upload-gl-migration-archive.sh`  
  Uploads the generated archives to GitHub storage (used by migration jobs).

- `start-gl2gh-repo-migration.sh`  
  Triggers repository migrations in GitHub.

- `gl-post-migration-validation.sh`  
  Compares branch and commit counts between GitLab and GitHub to validate migration.

Create a directory named **`migration_scripts`** in the same path and copy the JavaScript files and libraries from java_scripts folder into it.

**Directory structure:**

```text
.
├── config.sh
├── runner.sh
├── gl-migration-readiness-check.sh
├── generate-gl-migration-archive.sh
├── upload-gl-migration-archive.sh
├── start-gl2gh-repo-migration.sh
├── gl-post-migration-validation.sh
└── migration_scripts/
    ├── batch.js
    ├── create-env-vars.js
    ├── create-migration-source.js
    ├── gh-api.js
    ├── index.js
    ├── issue.js
    ├── migration.js
    ├── package.json
    ├── repository.js
    ├── start-repo-migration.js
    ├── state.js
    ├── team.js
    ├── upload-to-github-blob.sh
    ├── upload-to-azure-blob.sh
    ├── upload-to-aws-blob.sh
    ├── user.js
    └── workflow.js
```

## 4. Inventory File (Repository Mapping)
The inventory file defines the scope of GitLab repositories to be migrated and their target mappings in GitHub.

### 4.1 Generate inventory CSV
Before triggering the pipeline, generate an inventory file using the GitHub CLI extension `gitlab-stats`:

```bash
gh gitlab-stats --hostname "GITLAB_URL" --token "GITLAB_API_PRIVATE_TOKEN" --namespace <GITLAB_GROUP>
```

This produces a CSV inventory of repositories.

### 4.2 Edit inventory CSV
After generation, edit the CSV and add two columns:
- `github_org`
- `github_repo`

Fill in the target GitHub organization and repository name for each row.

## 5. Migration
### 5.1 Validate NPM Packages Before Starting Migration

- Ensure the required npm packages are installed by running the following commands:

```bash
npm list @octokit/rest
npm list @octokit/graphql
```

### 5.2 Setting environmental variables
#### To Migrate Repositories to GitHub Enterprise Cloud

- Export the following environment variables:

```bash
export SOURCE_GL_SERVER_URL="https://mygitlab.com"
export GITLAB_USERNAME="gitlab_user"
export GITLAB_API_PRIVATE_TOKEN="glpat-token"
export GH_ORG="myghorg"
export GH_PAT="ghp_token"
export INVENTORY_FILE="gitlab-stats-<timestamp>.csv"
export GITHUB_TYPE=GitHub
```

#### To Migrate Repositories to GitHub Enterprise Cloud with Data Residency

- Export the following environment variables:

```bash
export SOURCE_GL_SERVER_URL="https://mygitlab.com"
export GITLAB_USERNAME="gitlab_user"
export GITLAB_API_PRIVATE_TOKEN="glpat-token"
export GH_ORG="myghorg"
export GH_PAT="ghp_token"
export GH_SERVER_URL="https://SUBDOMAIN.ghe.com"
export GH_API_URL="https://api.SUBDOMAIN.ghe.com"
export INVENTORY_FILE="gitlab-stats-<timestamp>.csv"
export GITHUB_TYPE=GitHubDR
```

- For migrating repositories to GitHub Cloud with Data Residency, export the following storage environmental details
```
export STORAGE_TYPE="AZURE"
(or)
export STORAGE_TYPE="AWS"

# If storage type is Azure, export the following env
export AZ_CONTAINER="container-name"
export AZURE_STORAGE_CONNECTION_STRING="connection-string"

# If storage type is AWS, export the following env
export AWS_ACCESS_KEY_ID="access-key-id"
export AWS_SECRET_ACCESS_KEY="access-key"
export AWS_REGION="aws-region"
export AWS_BUCKET_NAME="bucket-name"
```

### 5.3 Migration readiness check
- The script validates whether a project in GitLab is ready for migration. It checks Active Merge Requests and active Pipelines in the selected projects
```
./gl-migration-readiness-check.sh
```

### 5.4 Create migration archive (*.tar.gz)
- Execute the script ‘generate-gl-migration-archive.sh’
```
./generate-gl-migration-archive.sh
```
- This script calls gl-exporter command via Docker container and generate migration archives (.tar.gz) for each GitLab projects present in `gitlab-stats-<timestamp>.csv file`
- Migration archives (.tar.gz) will be created under the directory, `gitlab_migration_archives`
- After script is executed, run the export command to set env variable before running next script: export ARCHIVE_LIST=path-to-generated-csv
- For example:
```
export ARCHIVE_LIST=/path/artifacts/archive-lists_20250101_103000.csv
```

### 5.5 Upload the migration archive (.tar.gz) to Blob Storage
- Execute the script ‘upload-gl-migration-archive.sh’
```
./upload-gl-migration-archive.sh
```
- After script is executed, run the export command to set env variable before running next script: export UPLOADED_ARCHIVES=path-to-presigned-url-csv
- For example:
```
export UPLOADED_ARCHIVES=/path/artifacts/presigned-urls_20250101_110200.csv
```

### 5.6 Migration of repositories to Github
- Execute the script ‘start-gl2gh-repo-migration.sh’
```
./start-gl2gh-repo-migration.sh
```
- This script will start the migration process and give migration IDs for each repository.

### 5.7 Monitor the status of migration
- After executing migrations, it’s critical to monitor the progress and validate completion for each repository. This section outlines how to check migration status using the GitHub CLI and how to install and run a monitoring tool for real-time visibility.

#### Check Migration Status by Migration ID
- For GitHub Enterprise Cloud without Data Residency:
```
gh ado2gh wait-for-migration --migration-id <migration-id>
```

- GitHub Enterprise Cloud with Data Residency:
```
gh ado2gh wait-for-migration --migration-id <migration-id> --target-api-url "$GH_API_URL"
```

#### Monitor migrations with GitHub Extension (gh-migration-monitor)
- For GitHub Enterprise Cloud without Data Residency:
```
gh migration-monitor --organization $GH_ORG --github-token $GH_PAT
```

- GitHub Enterprise Cloud with Data Residency:
```
Migration-monitor extension is not supported in GitHub Cloud with Data Residency.
```

## 6. Post Migration Validation
- Execute the script ‘gl-post-migration-validation.sh’
```
./gl-post-migration-validation.sh
```
- The post migration validation script reads the branch, commit counts etc from the GitLab inventory file and compares those values against the corresponding data retrieved from the migrated GitHub repositories using the GitHub API.

## 7. User Identity Mapping (Mannequins)
#### For GitHub Enterprise Cloud without Data Residency:
- Generate Mannequin CSV for Organization:
```
gh ado2gh generate-mannequin-csv --github-org "{github-org}"
```

 - Reclaim mannequins by mapping them to the correct GitHub users. (Update the Mannequin CSV with Target User)
```
gh ado2gh reclaim-mannequin --github-org "{github-org}" --csv $CSV_FILE --skip-invitation
```

#### For GitHub Enterprise Cloud with Data Residency:
- Generate Mannequin CSV for Organization:
```
gh ado2gh generate-mannequin-csv --github-org "{github-org}" --target-api-url https://api.SUBDOMAIN.ghe.com
```

- Reclaim mannequins by mapping them to the correct GitHub users. (Update the Mannequin CSV with Target User)
```
gh ado2gh reclaim-mannequin --github-org "{github-org}" --csv $CSV_FILE --skip-invitation --target-api-url https://api.SUBDOMAIN.ghe.com
```
