#!/usr/bin/env bash
# Azure Boards Integration via ADO REST API
# Works with GitHub App connections (bypasses gh-ado2gh integrate-boards limitation)
# Uses ADO REST API: https://learn.microsoft.com/en-us/rest/api/azure/devops/wit/github-connections
#
# Requires: ADO_PAT, repos_with_status.csv, jq, curl
# Exit codes: 0=success, 1=failure

set -euo pipefail

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Counters for summary
TOTAL_REPOS=0
SUCCESSFUL_INTEGRATIONS=0
FAILED_INTEGRATIONS=0
SKIPPED_ALREADY_CONNECTED=0

# Log file
LOG_FILE="azure-boards-integration-$(date +%Y%m%d-%H%M%S).log"

# ADO REST API version for GitHub connections
ADO_API_VERSION="7.2-preview.1"

# Global map: GitHub org name → ADO GitHub connection ID
declare -A ORG_CONNECTION_MAP

################################################################################
# Logging Functions
################################################################################

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" >> "$LOG_FILE"
    echo -e "${BLUE}[INFO]${NC} $1" >&2
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" >> "$LOG_FILE"
    echo -e "${GREEN}[SUCCESS]${NC} $1" >&2
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" >> "$LOG_FILE"
    echo -e "${YELLOW}[WARNING]${NC} $1" >&2
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" >> "$LOG_FILE"
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

log_section() {
    echo "" >> "$LOG_FILE"
    echo "" >&2
    echo "==========================================================================" >> "$LOG_FILE"
    echo "==========================================================================" >&2
    echo -e "${BLUE}$1${NC}" >> "$LOG_FILE"
    echo -e "${BLUE}$1${NC}" >&2
    echo "==========================================================================" >> "$LOG_FILE"
    echo "==========================================================================" >&2
}

################################################################################
# Validation Functions
################################################################################

validate_prerequisites() {
    log_section "VALIDATING PREREQUISITES"

    # Check if repos_with_status.csv exists
    if [ ! -f "repos_with_status.csv" ]; then
        log_error "repos_with_status.csv not found"
        log_error "Make sure Stage 3 (Migration) completed successfully and published repos_with_status.csv"
        echo "##[error]repos_with_status.csv not found - Stage 3 migration may have failed"
        exit 1
    fi
    log_success "repos_with_status.csv found"

    # Check if any repos succeeded migration
    local success_count
    success_count=$(tail -n +2 "repos_with_status.csv" | grep -c ",Success$" || true)
    if [ "$success_count" -eq 0 ]; then
        log_warning "No successfully migrated repositories found"
        log_warning "All repositories failed migration. Skipping boards integration."
        echo "##[warning]No successfully migrated repositories - skipping boards integration"
        echo "Skipping Azure Boards integration as all repositories failed migration"
        exit 0
    fi
    log_success "Found $success_count successfully migrated repositories"

    # Check for required environment variables
    if [ -z "${ADO_PAT:-}" ]; then
        log_error "ADO_PAT environment variable is not set"
        echo "##[error]ADO_PAT environment variable is not set"
        exit 1
    fi
    log_success "ADO_PAT is set"

    # Check if jq is installed (required for JSON parsing)
    if ! command -v jq &> /dev/null; then
        log_error "jq is not installed (required for JSON parsing)"
        exit 1
    fi
    log_success "jq is installed: $(jq --version)"

    # Check if curl is installed
    if ! command -v curl &> /dev/null; then
        log_error "curl is not installed"
        exit 1
    fi
    log_success "curl is installed"

    # Verify ADO PAT authentication works
    log_info "Verifying ADO PAT authentication..."
    local auth_header
    auth_header=$(get_auth_header)

    #Get first ADO org dynalically from repos_with_status.csv
    local first_ado_org
    first_ado_org=$(tail -n +2 repos_with_status.csv | head -1 | cut -d',' -f1)

    local verify_code
    verify_code=$(curl -s -o /dev/null -w "%{http_code}" \
        -H "Authorization: Basic ${auth_header}" \
        -H "Content-Type: application/json" \
        "https://dev.azure.com/${first_ado_org}/_apis/projects?api-version=7.1&\$top=1")
    if [ "$verify_code" -eq 200 ]; then
        log_success "ADO PAT authentication verified (HTTP ${verify_code})"
    else
        log_error "ADO PAT authentication failed (HTTP ${verify_code})"
        log_error "Ensure ADO_PAT has correct scopes and is not expired"
        exit 1
    fi
}

################################################################################
# ADO REST API Functions
################################################################################

# Constructs the Base64-encoded authorization header value from ADO_PAT
get_auth_header() {
    # Use printf to avoid trailing newline issues across shells
    printf ':%s' "${ADO_PAT}" | base64 -w 0
}

# Retrieves all GitHub connections for a given ADO org and project.
# Returns the JSON response containing connection IDs and metadata.
get_github_connections() {
    local ado_org="$1"
    local ado_project="$2"

    local auth_header
    auth_header=$(get_auth_header)

    local url="https://dev.azure.com/${ado_org}/${ado_project}/_apis/githubconnections?api-version=${ADO_API_VERSION}"

    log_info "Fetching GitHub connections from: ${url}"

    local body_file
    body_file=$(mktemp)
    local http_code
    http_code=$(curl -s -o "$body_file" -w "%{http_code}" \
        -H "Authorization: Basic ${auth_header}" \
        -H "Content-Type: application/json" \
        "${url}")

    local body
    body=$(cat "$body_file")
    rm -f "$body_file"

    if [ "$http_code" -ne 200 ]; then
        log_error "Failed to get GitHub connections (HTTP ${http_code})"
        log_error "Response: ${body}"
        echo ""
        return 1
    fi

    # Validate that the response is valid JSON
    if ! echo "$body" | jq empty 2>/dev/null; then
        log_error "GitHub connections response is not valid JSON"
        log_error "Response body (first 500 chars): ${body:0:500}"
        echo ""
        return 1
    fi

    echo "$body"
}

# Builds a mapping of GitHub org name → connection ID for a given ADO org/project.
# Each GitHub App connection serves repos from a single GitHub org.
# We detect the org by sampling the first repo URL from each connection.
# Populates the ORG_CONNECTION_MAP associative array.
build_org_connection_map() {
    local ado_org="$1"
    local ado_project="$2"

    local connections_json
    connections_json=$(get_github_connections "$ado_org" "$ado_project") || true

    if [ -z "$connections_json" ]; then
        log_error "Failed to retrieve GitHub connections for ${ado_org}/${ado_project}"
        return 1
    fi

    log_info "Connections response length: ${#connections_json} chars"

    local count
    count=$(echo "$connections_json" | jq '.count // 0' 2>/dev/null) || true

    if [ -z "$count" ] || [ "$count" -eq 0 ] 2>/dev/null; then
        log_error "No GitHub connections found or failed to parse response for ${ado_org}/${ado_project}"
        log_error "Set up a GitHub connection at: https://dev.azure.com/${ado_org}/${ado_project}/_settings/boards-external-integration"
        return 1
    fi

    log_info "Found ${count} GitHub connection(s), building org-to-connection map..."

    local auth_header
    auth_header=$(get_auth_header)

    for i in $(seq 0 $((count - 1))); do
        local conn_id conn_name conn_valid
        conn_id=$(echo "$connections_json" | jq -r ".value[$i].id")
        conn_name=$(echo "$connections_json" | jq -r ".value[$i].name")
        conn_valid=$(echo "$connections_json" | jq -r ".value[$i].isConnectionValid")

        if [ "$conn_valid" != "true" ]; then
            log_warning "  Skipping invalid connection: ${conn_id} (${conn_name})"
            continue
        fi

        # Get repos for this connection to determine its GitHub org
        local repos_url="https://dev.azure.com/${ado_org}/${ado_project}/_apis/githubconnections/${conn_id}/repos?api-version=${ADO_API_VERSION}"
        local repos_body_file
        repos_body_file=$(mktemp)
        local repos_http_code
        repos_http_code=$(curl -s -o "$repos_body_file" -w "%{http_code}" \
            -H "Authorization: Basic ${auth_header}" \
            -H "Content-Type: application/json" \
            "${repos_url}")

        local repos_body
        repos_body=$(cat "$repos_body_file")
        rm -f "$repos_body_file"

        if [ "$repos_http_code" -ne 200 ]; then
            log_warning "  Failed to get repos for connection ${conn_id} (HTTP ${repos_http_code})"
            continue
        fi

        # Extract the GitHub org from the first repo URL (https://github.com/{org}/{repo})
        local first_repo_url
        first_repo_url=$(echo "$repos_body" | jq -r '.value[0].gitHubRepositoryUrl // empty')

        if [ -z "$first_repo_url" ]; then
            log_warning "  Connection ${conn_id} has no repos, skipping org detection"
            continue
        fi

        # Parse org from URL: https://github.com/{org}/{repo} → {org}
        local github_org_name
        github_org_name=$(echo "$first_repo_url" | sed 's|https://github.com/||' | cut -d'/' -f1)

        local repo_count
        repo_count=$(echo "$repos_body" | jq '.count // 0')

        log_info "  Connection ${conn_id} → org=${github_org_name} (${repo_count} repos)"
        ORG_CONNECTION_MAP["$github_org_name"]="$conn_id"
    done

    log_success "Org-to-connection map built with ${#ORG_CONNECTION_MAP[@]} org(s)"
    for org_key in "${!ORG_CONNECTION_MAP[@]}"; do
        log_info "  ${org_key} → ${ORG_CONNECTION_MAP[$org_key]}"
    done
}

# Finds the connection ID for a specific GitHub org.
# Uses the cached ORG_CONNECTION_MAP (must call build_org_connection_map first).
find_connection_for_org() {
    local github_org="$1"

    # Temporarily disable nounset to safely check associative array keys
    set +u
    local conn_id="${ORG_CONNECTION_MAP[$github_org]}"
    set -u

    if [ -n "$conn_id" ]; then
        echo "$conn_id"
        return 0
    fi

    set +u
    log_error "No GitHub connection found for org: ${github_org}"
    log_error "Available orgs: ${!ORG_CONNECTION_MAP[*]}"
    set -u
    return 1
}

# Adds a GitHub repository to an existing ADO GitHub connection via the REST API.
# Uses the reposBatch endpoint to add the repo URL.
add_repo_to_connection() {
    local ado_org="$1"
    local ado_project="$2"
    local connection_id="$3"
    local github_org="$4"
    local github_repo="$5"

    local auth_header
    auth_header=$(get_auth_header)

    local repo_url="https://github.com/${github_org}/${github_repo}"
    local url="https://dev.azure.com/${ado_org}/${ado_project}/_apis/githubconnections/${connection_id}/reposBatch?api-version=${ADO_API_VERSION}"

    local payload
    payload=$(jq -n \
        --arg repo_url "$repo_url" \
        '{
            gitHubRepositoryUrls: [{ gitHubRepositoryUrl: $repo_url }],
            operationType: "add"
        }')

    log_info "Adding ${repo_url} to connection ${connection_id}"
    log_info "POST ${url}"

    local body_file
    body_file=$(mktemp)
    local http_code
    http_code=$(curl -s -o "$body_file" -w "%{http_code}" \
        -X POST \
        -H "Authorization: Basic ${auth_header}" \
        -H "Content-Type: application/json" \
        -d "$payload" \
        "${url}")

    local body
    body=$(cat "$body_file")
    rm -f "$body_file"

    log_info "Response (HTTP ${http_code}): ${body}"

    if [ "$http_code" -ne 200 ]; then
        log_error "Failed to add repo to connection (HTTP ${http_code})"
        log_error "Response: ${body}"
        return 1
    fi

    # Check if the API actually processed the repo
    local result_count
    result_count=$(echo "$body" | jq '.count // 0')

    if [ "$result_count" -eq 0 ]; then
        log_error "API returned empty result (count=0) for ${repo_url}"
        log_error "This usually means the repo doesn't exist on GitHub or the GitHub App doesn't have access to it"
        log_error "Verify: 1) https://github.com/${github_org}/${github_repo} exists  2) The GitHub App installed on ${github_org} has access to the repo"
        return 1
    fi

    # Check for per-repo errors in the response
    local error_msg
    error_msg=$(echo "$body" | jq -r '.value[0].errorMessage // empty')

    if [ -n "$error_msg" ]; then
        # "Repository is already connected" is not a failure
        if echo "$error_msg" | grep -qi "already connected\|already exists"; then
            log_info "Repository already connected: ${repo_url}"
            return 2  # Special return code for already connected
        else
            log_error "API returned error for ${repo_url}: ${error_msg}"
            return 1
        fi
    fi

    log_success "Successfully added ${repo_url} to Azure Boards connection"
    return 0
}

################################################################################
# Main Processing Logic
################################################################################

process_repositories() {
    log_section "PROCESSING REPOSITORIES FROM repos_with_status.csv"

    # Build org→connection map once per ADO org/project
    # Cache tracks which org/project combos we've already mapped
    declare -A map_built_cache

    local line_number=0

    while IFS=',' read -r ado_org ado_team_project ado_repo github_org github_repo gh_repo_visibility migration_status; do
        : $((line_number++))

        # Skip header row
        if [ $line_number -eq 1 ]; then
            continue
        fi

        # Skip empty lines or lines with missing required fields
        if [ -z "$ado_org" ] || [ -z "$ado_team_project" ] || [ -z "$github_org" ] || [ -z "$github_repo" ]; then
            continue
        fi

        # Skip repositories that failed migration
        if [ "$migration_status" != "Success" ]; then
            log_warning "Skipping $ado_repo (Migration Status: $migration_status)"
            continue
        fi

        TOTAL_REPOS=$((TOTAL_REPOS + 1))

        log_section "Repository $TOTAL_REPOS: ${github_org}/${github_repo}"
        log_info "ADO Org: ${ado_org}"
        log_info "ADO Project: ${ado_team_project}"
        log_info "GitHub Org: ${github_org}"
        log_info "GitHub Repo: ${github_repo}"

        # Build org→connection map if not already done for this ADO org/project
        local map_key="${ado_org}|${ado_team_project}"
        if [ -z "${map_built_cache[$map_key]+x}" ]; then
            if ! build_org_connection_map "$ado_org" "$ado_team_project"; then
                log_error "Failed to build org-connection map for ${ado_org}/${ado_team_project}, skipping all repos in this org/project"
                FAILED_INTEGRATIONS=$((FAILED_INTEGRATIONS + 1))
                map_built_cache[$map_key]="failed"
                continue
            fi
            map_built_cache[$map_key]="1"
        elif [ "${map_built_cache[$map_key]}" = "failed" ]; then
            log_warning "Skipping ${github_repo} - org-connection map failed for ${ado_org}/${ado_team_project}"
            FAILED_INTEGRATIONS=$((FAILED_INTEGRATIONS + 1))
            continue
        fi

        # Find the connection for this repo's GitHub org
        local connection_id=""
        connection_id=$(find_connection_for_org "$github_org") || true

        if [ -z "$connection_id" ]; then
            log_error "No GitHub connection found for org ${github_org} in ${ado_org}/${ado_team_project}"
            log_error "Set up a GitHub connection at: https://dev.azure.com/${ado_org}/${ado_team_project}/_settings/boards-external-integration"
            FAILED_INTEGRATIONS=$((FAILED_INTEGRATIONS + 1))
            continue
        fi

        log_info "Using connection ${connection_id} for org ${github_org}"

        # Add the repo to the connection
        local result=0
        add_repo_to_connection "$ado_org" "$ado_team_project" "$connection_id" "$github_org" "$github_repo" || result=$?

        case $result in
            0)
                SUCCESSFUL_INTEGRATIONS=$((SUCCESSFUL_INTEGRATIONS + 1))
                ;;
            2)
                SKIPPED_ALREADY_CONNECTED=$((SKIPPED_ALREADY_CONNECTED + 1))
                SUCCESSFUL_INTEGRATIONS=$((SUCCESSFUL_INTEGRATIONS + 1))
                ;;
            *)
                FAILED_INTEGRATIONS=$((FAILED_INTEGRATIONS + 1))
                ;;
        esac

        echo "" | tee -a "$LOG_FILE"

    done < repos_with_status.csv
}

################################################################################
# Summary Report
################################################################################

print_summary() {
    log_section "AZURE BOARDS INTEGRATION SUMMARY (REST API)"

    echo "" | tee -a "$LOG_FILE"
    echo "Total Repositories Processed:    ${TOTAL_REPOS}" | tee -a "$LOG_FILE"
    echo "Successful Integrations:         ${SUCCESSFUL_INTEGRATIONS}" | tee -a "$LOG_FILE"
    echo "  (Already Connected):           ${SKIPPED_ALREADY_CONNECTED}" | tee -a "$LOG_FILE"
    echo "Failed Integrations:             ${FAILED_INTEGRATIONS}" | tee -a "$LOG_FILE"
    echo "" | tee -a "$LOG_FILE"
    echo "Log file: ${LOG_FILE}" | tee -a "$LOG_FILE"
    echo "==========================================================================" | tee -a "$LOG_FILE"

    # Handle integration results
    if [ $TOTAL_REPOS -eq 0 ]; then
        log_error "No repositories were processed"
        echo "##[error]Azure Boards integration: No repositories found to process - all migrations may have failed"
        exit 1
    elif [ $SUCCESSFUL_INTEGRATIONS -eq 0 ]; then
        log_error "All $FAILED_INTEGRATIONS repositories failed boards integration"
        echo "##[error]All repositories failed Azure Boards integration"
        exit 1
    elif [ $FAILED_INTEGRATIONS -gt 0 ]; then
        log_warning "Azure Boards integration completed with issues"
        echo "##[warning]Boards integration completed with PARTIAL SUCCESS: $SUCCESSFUL_INTEGRATIONS succeeded, $FAILED_INTEGRATIONS failed"
        echo "##vso[task.logissue type=warning]Partial success: $SUCCESSFUL_INTEGRATIONS succeeded, $FAILED_INTEGRATIONS failed"

        # Set task result to SucceededWithIssues and exit successfully
        echo "##vso[task.complete result=SucceededWithIssues]Boards integration completed with partial success"
        exit 0
    else
        log_success "Azure Boards integration completed successfully!"
        echo "##[section]All $SUCCESSFUL_INTEGRATIONS repositories integrated successfully with Azure Boards"
        exit 0
    fi
}

################################################################################
# Main Execution
################################################################################

main() {
    log_section "AZURE BOARDS INTEGRATION VIA REST API - ADO TO GHE"
    log_info "Script started at: $(date)"
    log_info "Log file: ${LOG_FILE}"
    log_info "Using ADO REST API (GitHub App compatible)"

    validate_prerequisites
    process_repositories
    print_summary

    log_info "Script completed at: $(date)"
}

# Execute main function
main
