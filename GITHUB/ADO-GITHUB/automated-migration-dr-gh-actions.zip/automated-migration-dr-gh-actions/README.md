# 🚀 Azure DevOps to GitHub Data Residency Migration — GitHub Actions Workflow

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Pipeline](https://img.shields.io/badge/Pipeline-GitHub%20Actions-2088FF.svg)](https://docs.github.com/actions)
[![Migration Tool](https://img.shields.io/badge/Tool-gh--ado2gh-181717.svg)](https://github.com/github/gh-ado2gh)

> The GitHub Actions equivalent of the Azure DevOps `ghdr-migration.yml` pipeline. A job-based workflow for migrating repositories from Azure DevOps into a **GitHub Data Residency** (`ghe.com`) tenant at scale. Supports batch migrations, parallel migration, automated validation, and pipeline rewiring.
>
> **Workflow file:** [`ghdr-migration.yml`](./ghdr-migration.yml)

---

## 🎯 Why a GitHub Actions version?

This workflow is a faithful translation of the Azure DevOps Data Residency pipeline so teams can run the same staged, self-service migration from GitHub. The five-stage flow, the manual approval gate, the partial-success model, parallel migration, and Data Residency host authentication are all preserved — only the orchestration layer changes (Azure DevOps `stages` → GitHub Actions `jobs`).

---

## 📋 Table of Contents

- [Workflow Execution Model](#-workflow-execution-model)
- [Mapping from the Azure DevOps Pipeline](#-mapping-from-the-azure-devops-pipeline)
- [Limitations](#️-limitations)
- [Prerequisites](#️-prerequisites)
- [Quick Start](#-quick-start-your-first-migration)
- [FAQ](#-frequently-asked-questions)
- [License](#-license)

---

## 📋 Workflow Execution Model

> ℹ️ **Informational Only**
> This section is for conceptual understanding. Actual behavior is governed by [`ghdr-migration.yml`](./ghdr-migration.yml).

This workflow orchestrates a **five-stage sequential migration** from Azure DevOps to a GitHub Data Residency tenant. Each stage is a separate GitHub Actions **job**. Jobs run on **GitHub-hosted `ubuntu-latest`** by default, or on your own runners by selecting `self-hosted` for the `runner_label` input.

### Key Features

- **Data Residency Authentication:** Every job that talks to GitHub authenticates against your Data Residency host (`gh auth login --hostname "$GH_HOSTNAME" --with-token`) rather than `github.com`. The host and API URL come from repository **variables** `GH_HOSTNAME` and `GITHUB_API_URL`.

- **Parallel Migration:** **Stage 3** runs `2_migration_for_GitHub_DR.sh` with `--max-concurrent`, configurable (1–10) via the `maxConcurrent` input.

- **Partial Success:** **Stage 3** uploads `repos_with_status.csv` (`migration-results`). Stages 4–5 download it and run only against successfully migrated repositories.

- **Manual Approval Gate:** The **Migration** job is bound to the `migration-approval` GitHub **Environment**. Add required reviewers there to pause before migration begins — the equivalent of the Azure DevOps `ManualValidation` step.

> **Note:** GitHub-hosted runners do not persist state between jobs, so the workflow uses `upload-artifact` / `download-artifact` for cross-stage continuity.

```mermaid
---
config:
  theme: neo
  layout: dagre
  look: handDrawn
---
flowchart TB
    Start["<b>Run workflow (workflow_dispatch)</b>"] --> Stage1["<b>Stage 1: Prereq validation</b><br>Verify repos.csv & columns"]
    Stage1 --> Stage2["<b>Stage 2: Pre-migration check</b><br>Check for active PRs and pipelines"]
    Stage2 --> Gate1["<b>Environment approval</b><br>migration-approval reviewers"]
    Gate1 -- Approved --> Stage3["<b>Stage 3: Repository Migration</b><br>Parallel migrate (maxConcurrent)"]
    Gate1 -- Rejected --> End1["<b>Run Cancelled</b>"]
    Stage3 --> Stage4["<b>Stage 4: Migration Validation</b><br>Compare branch, commit, and SHA counts"]
    Stage4 --> Stage5["<b>Stage 5: Pipeline Rewiring</b><br>Rewire ADO pipelines to GitHub repos"]
    Stage5 --> Success(["<b>Migration Complete ✓</b>"])

    style Stage1 fill:#e1f5ff
    style Stage2 fill:#e1f5ff
    style Gate1 fill:#FFF9C4
    style Stage3 fill:#e1f5ff
    style End1 fill:#ffcccc
    style Stage4 fill:#e1f5ff
    style Stage5 fill:#e1f5ff
    style Success fill:#e1ffe1
```

### Stage Execution Details

| Stage (Job) | Script | Notes |
|-------------|--------|-------|
| **1️⃣ Prerequisite Validation** (`prerequisite-validation`) | — | Verifies `bash/repos.csv` exists, is non-empty, and has the required columns. `pipelines.csv` is used in Stage 5. |
| **2️⃣ Pre-Migration Check** (`readiness-check`) | `1_pr_pipeline_check.sh` | Detects active builds, release pipelines, and pull requests. |
| **3️⃣ Repository Migration** (`migration`) | `2_migration_for_GitHub_DR.sh --csv bash/repos.csv --max-concurrent <n>` | Parallel migration to the Data Residency host. Produces `repos_with_status.csv`. **Gated by the `migration-approval` environment.** |
| **4️⃣ Migration Validation** (`post-migration-validation`) | `3_post_migration_validation.sh` | Compares branch counts, commit counts, and latest SHAs. Successful repos only. |
| **5️⃣ Pipeline Rewiring** (`pipeline-rewiring`) | `4_rewire_pipeline.sh` | Rewires ADO pipelines to GitHub via service connection. Skipped when `runDemoRepoMigration = true`. |

---

## 🔄 Mapping from the Azure DevOps Pipeline

| Azure DevOps concept | GitHub Actions equivalent |
|----------------------|---------------------------|
| `stages` | `jobs` chained via `needs:` |
| `ManualValidation@0` approval | `environment: migration-approval` on the Migration job (add required reviewers) |
| Variable group `core-entauto-github-dr-migration-secrets` (secrets) | Repository **secrets** `GH_PAT`, `ADO_PAT` |
| Variable group (config values) | Repository **variables** `GH_HOSTNAME`, `GITHUB_API_URL` |
| `maxConcurrent`, `runDemoRepoMigration` | `workflow_dispatch` inputs (same names) |
| `PublishBuildArtifacts` / `DownloadBuildArtifacts` | `actions/upload-artifact` / `actions/download-artifact` |

---

## ⚠️ Limitations

#### 1️⃣ What Gets Migrated
- Git repository content (all files), complete commit history, all branches and tags, and commit metadata.
- **NOT migrated:** pull requests, work items, build/release history, repository settings, wikis.

**Recommendation:** Complete or abandon all active pull requests before migrating.

#### 2️⃣ Runner Timeout
- **GitHub-hosted runners** have a hard **6-hour (360-minute)** maximum per job; `migrate_timeout_minutes` is capped accordingly. Use **self-hosted** runners for longer migrations.
- The migration runs on GitHub's backend services; the runner only polls status. If it times out, migration continues server-side.

#### 3️⃣ Pipeline Rewiring
- Only YAML-based pipelines are supported. Classic (UI-defined) pipelines must be rewired manually.

#### 4️⃣ Repository Size Limits
The [GitHub Enterprise Importer](https://github.com/github/gh-ado2gh) limits:

| Item | Maximum Size |
|------|--------------|
| Repository archive | ~40 GiB |
| Single file (during migration) | 400 MiB |
| Single file (after migration) | 100 MiB (larger files must use Git LFS) |
| Single commit | 2 GiB |

---

## ⚙️ Prerequisites

#### 1️⃣ 🗂️ CSV Configuration Files

**`bash/repos.csv`** — repositories to migrate

| Column | Description |
|--------|-------------|
| `org` | Azure DevOps organization name |
| `teamproject` | Azure DevOps project name |
| `repo` | Azure DevOps repository name |
| `github_org` | Target GitHub organization |
| `github_repo` | Target GitHub repository name |
| `gh_repo_visibility` | `private`, `public`, or `internal` |

**`bash/pipelines.csv`** — pipelines to rewire (Stage 5)

| Column | Description |
|--------|-------------|
| `org` | Azure DevOps organization name |
| `teamproject` | Azure DevOps project name |
| `repo` | Azure DevOps repository name (cross-references `repos.csv`) |
| `pipeline` | Pipeline name/path (e.g., `\my-pipeline-ci`) |
| `url` | Pipeline URL (for reference) |
| `serviceConnection` | GitHub service connection ID (see Prerequisite #3) |
| `github_org` | Target GitHub organization |
| `github_repo` | Target GitHub repository name |

#### 2️⃣ 🔐 Authentication Tokens

**GitHub PAT — Migration (all stages):** scoped on the **Data Residency host**
- ✅ `repo`, `workflow`, `admin:org`, `read:user`

**Azure DevOps PAT:** `Full access` (simplest) or minimum scopes:

<details>
<summary>📋 Minimum Required ADO PAT Scopes</summary>

`Analytics` (Read) · `Build` (Read) · `Code` (Read, Full, Status) · `GitHub Connections` (Read & manage) · `Graph` (Read) · `Identity` (Read) · `Pipeline Resources` (Use) · `User Profile` (Read) · `Project and Team` (Read) · `Release` (Read) · `Security` (Manage) · `Service Connections` (Read & query) · `Work Items` (Read)
</details>

#### 3️⃣ 🧩 GitHub Service Connection (Azure DevOps side)
Required for Stage 5 (pipeline rewiring): create a **GitHub** service connection in Azure DevOps (**Project Settings → Service connections**), grant **Contributor** on the target org/repos, and put its ID in the `serviceConnection` column of `bash/pipelines.csv`.

#### 4️⃣ 🔐 Secrets and Variables

Under **Settings → Secrets and variables → Actions**:

**Secrets**

| Secret | Value | Used In |
|--------|-------|---------|
| `GH_PAT` | GitHub PAT (migration scopes on the DR host) | All stages |
| `ADO_PAT` | Azure DevOps PAT | All stages |

**Variables** (non-secret configuration)

| Variable | Value | Used In |
|----------|-------|---------|
| `GH_HOSTNAME` | Data Residency hostname (e.g. `<tenant>.ghe.com`) | All stages |
| `GITHUB_API_URL` | Data Residency API URL (e.g. `https://api.<tenant>.ghe.com`) | All stages |

> **Note:** If you prefer to keep `GH_HOSTNAME` / `GITHUB_API_URL` as secrets, change `vars.` to `secrets.` in `ghdr-migration.yml`.

#### 5️⃣ 🔒 Approval Environment
Create an environment named **`migration-approval`** (**Settings → Environments**) and add required reviewers. Without reviewers the gate is a no-op and migration proceeds automatically.

#### 6️⃣ 🧪 Demo Mode
Set the `runDemoRepoMigration` input to `true` to migrate without post-migration stages.

**Behavior:**
- ✅ Runs Stages 1–3 (Prerequisites, Pre-migration Check, Migration)
- ❌ Skips Stages 4–5 (Validation, Rewiring)

> **⚠️ Demo Mode still migrates repositories** — it is not a dry run. Rollback requires manually deleting the migrated GitHub repositories. Use test repositories only.

---

## 🚀 Quick Start: Your First Migration

**Before you begin**, confirm the [Prerequisites](#️-prerequisites):
- ✅ 2 PAT tokens (1 ADO, 1 GitHub) stored as secrets
- ✅ `GH_HOSTNAME` and `GITHUB_API_URL` variables set
- ✅ `migration-approval` environment configured with reviewers
- ✅ GitHub service connection set up in Azure DevOps
- ✅ `bash/repos.csv` and `bash/pipelines.csv` prepared

> **💡 First-time tip:** run Demo Mode with 1–2 test repositories and `maxConcurrent = 1`.

### Step-by-Step

1. **Place this folder's contents at the root of a GitHub repository** so the workflow resolves to `.github/workflows/ghdr-migration.yml` and the scripts to `bash/`.

2. **Edit and commit your CSVs:**
   ```bash
   git add bash/repos.csv bash/pipelines.csv
   git commit -m "Configure migration batch"
   git push
   ```

3. **Run the workflow:** **Actions** tab → **ghdr-migration** → **Run workflow**, then set inputs:
   - `runDemoRepoMigration` — `true` to skip Stages 4–5
   - `maxConcurrent` — `1`–`5` parallel migrations
   - `runner_label` — `ubuntu-latest` or `self-hosted`
   - `migrate_timeout_minutes` — migration job timeout

4. **Approve the gate** in the run's environment prompt when the Migration job is queued for review.

5. **Monitor & download artifacts:**

   | Job | Artifact | Expected outcome |
   |-----|----------|------------------|
   | Prerequisite Validation | — | ✅ "X repositories found" |
   | Pre-migration Check | `validation-logs-*` | ✅ No active PRs / pipelines |
   | Migration | `migration-results`, `migration-logs-*` | ✅ `repos_with_status.csv` produced |
   | Migration Validation | `validation-logs-*` | ✅ Branch/commit/SHA match |
   | Pipeline Rewiring | `rewiring-logs-*` | ✅ Pipelines point to GitHub |

6. **Verify** by cloning a migrated repo from your DR host: `git clone https://<tenant>.ghe.com/<github_org>/<github_repo>.git`.

---

## ❓ Frequently Asked Questions

### Q1: Can multiple teams run this workflow simultaneously?
**A:** Yes, if migrating **different** repositories. Use separate CSVs with zero overlap; otherwise run sequentially.

### Q2: What happens to the ADO repository after migration?
**A:** It remains intact — migration is a copy, not a move. Disable it afterward to prevent accidental commits.

### Q3: Can I migrate from multiple ADO organizations?
**A:** One ADO org per run. Use a separate ADO PAT and a separate run per org.

### Q4: Can I skip Stage 5 if I have no pipelines?
**A:** Provide an empty `pipelines.csv` with just the header row, or set `runDemoRepoMigration = true`.

### Q5: Does this migrate pull requests?
**A:** No. Stage 2 warns if active PRs exist; complete, merge, or abandon them before migrating.

### Q6: What happens if migration fails halfway?
**A:** The workflow continues for repos that migrated successfully — `repos_with_status.csv` drives Stages 4–5, which skip failed repos.

### Q7: How is the approval gate enforced?
**A:** Through the `migration-approval` environment. Required reviewers there pause the Migration job until approved.

---

## 📄 License

MIT License — Copyright (c) 2025 Vamsi Cherukuri (<vamsicherukuri@hotmail.com>). See the repository root for the full text.

---

**Made with ❤️ for the DevOps community**
