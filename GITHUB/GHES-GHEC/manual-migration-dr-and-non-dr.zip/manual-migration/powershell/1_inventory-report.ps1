# inventory-report.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ------------------------------
# Config
# ------------------------------
$ORG = (Read-Host "Enter the ORG name").Trim().Trim('"')

if (-not $env:GH_SOURCE_PAT) {
    throw "Environment variable GH_SOURCE_PAT is not set"
}

if (-not $env:GHES_API_URL) {
    throw "Environment variable GHES_API_URL is not set"
}

$GH_SOURCE_PAT = $env:GH_SOURCE_PAT
$API_BASE = $env:GHES_API_URL.TrimEnd("/")
$OUT_FILE = "repos.csv"

# ------------------------------
# Logging helpers
# ------------------------------
function Log-Info([string]$Message) {
    Write-Host "[INFO]    $Message"
}

function Log-Warn([string]$Message) {
    Write-Host "[WARN]    $Message" -ForegroundColor Yellow
}

function Log-ErrorMsg([string]$Message) {
    Write-Host "[ERROR]   $Message" -ForegroundColor Red
}

function Log-Success([string]$Message) {
    Write-Host "[SUCCESS] $Message" -ForegroundColor Green
}

# ------------------------------
# Extract next page URL from Link header
# ------------------------------
function Get-NextLink {
    param(
        [AllowNull()]
        [AllowEmptyString()]
        [string]$LinkHeader
    )

    if ([string]::IsNullOrWhiteSpace($LinkHeader)) {
        return $null
    }

    $parts = $LinkHeader -split ","
    foreach ($part in $parts) {
        if ($part -match '<([^>]+)>;\s*rel="next"') {
            return $matches[1]
        }
    }

    return $null
}

# ------------------------------
# Read response body from exception (PS 5 + PS 7 compatible)
# ------------------------------
function Get-ExceptionResponseBody {
    param($Exception)

    try {
        if ($null -eq $Exception.Response) {
            return $null
        }

        $stream = $Exception.Response.GetResponseStream()
        if ($null -eq $stream) {
            return $null
        }

        $reader = New-Object System.IO.StreamReader($stream)
        try {
            return $reader.ReadToEnd()
        }
        finally {
            $reader.Dispose()
            $stream.Dispose()
        }
    }
    catch {
        return $null
    }
}

# ------------------------------
# Make API call (PS 5.1 + PS 7+ compatible)
# ------------------------------
function Call-Api {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url
    )

    $headers = @{
        "Accept"        = "application/vnd.github+json"
        "Authorization" = "Bearer $GH_SOURCE_PAT"
    }

    $invokeParams = @{
        Uri         = $Url
        Method      = "Get"
        Headers     = $headers
        ErrorAction = "Stop"
    }

    if ($PSVersionTable.PSVersion.Major -lt 6) {
        $invokeParams["UseBasicParsing"] = $true
    }

    try {
        $response = Invoke-WebRequest @invokeParams

        $body = $null
        if (-not [string]::IsNullOrWhiteSpace($response.Content)) {
            try {
                $body = $response.Content | ConvertFrom-Json
            }
            catch {
                $body = $response.Content
            }
        }

        $linkHeader = $null
        if ($response.Headers) {
            try {
                $linkHeader = $response.Headers["Link"]
            }
            catch {
                $linkHeader = $null
            }
        }

        return [PSCustomObject]@{
            StatusCode = [int]$response.StatusCode
            Body       = $body
            LinkHeader = $linkHeader
            ErrorText  = $null
        }
    }
    catch {
        $status = $null
        $message = $_.Exception.Message
        $bodyText = Get-ExceptionResponseBody -Exception $_.Exception

        try {
            if ($null -ne $_.Exception.Response -and $null -ne $_.Exception.Response.StatusCode) {
                $status = [int]$_.Exception.Response.StatusCode
            }
        }
        catch {
            $status = $null
        }

        return [PSCustomObject]@{
            StatusCode = $status
            Body       = $bodyText
            LinkHeader = $null
            ErrorText  = $message
        }
    }
}

# ------------------------------
# Validate org
# ------------------------------
function Validate-Org {
    $url = "$API_BASE/orgs/$ORG/repos?per_page=1&type=all"
    $result = Call-Api -Url $url

    if ($result.StatusCode -eq 404) {
        Log-ErrorMsg "Org not found: $ORG"
        exit 1
    }

    if ($result.StatusCode -eq 401 -or $result.StatusCode -eq 403) {
        Log-ErrorMsg "Authentication failed or access denied for org: $ORG"
        exit 1
    }

    if ($result.StatusCode -ne 200) {
        $msg = if ($result.ErrorText) { $result.ErrorText } else { "Failed to validate org: $ORG" }
        Log-ErrorMsg "$msg (HTTP $($result.StatusCode))"
        exit 1
    }
}

# ------------------------------
# Main
# ------------------------------
Log-Info "Validating organization '$ORG'..."
Validate-Org

# Keep old header exactly same
"ghes_org,ghes_repo,repo_url,repo_size_MB" | Set-Content -LiteralPath $OUT_FILE

$url = "$API_BASE/orgs/$ORG/repos?per_page=100&type=all"
$repoCount = 0

while (-not [string]::IsNullOrWhiteSpace($url)) {
    $result = Call-Api -Url $url

    if ($result.StatusCode -eq 404) {
        Log-ErrorMsg "Org not found: $ORG"
        exit 1
    }

    if ($result.StatusCode -ne 200) {
        $msg = if ($result.ErrorText) { $result.ErrorText } else { "Failed while retrieving repositories for org: $ORG" }
        Log-ErrorMsg "$msg (HTTP $($result.StatusCode))"
        exit 1
    }

    if ($null -ne $result.Body) {
        foreach ($repo in $result.Body) {
            $owner   = [string]$repo.owner.login
            $name    = [string]$repo.name
            $htmlUrl = if ($repo.html_url) { [string]$repo.html_url } else { "" }
            $sizeMB  = [math]::Round(([double]$repo.size / 1024), 2)

            "$owner,$name,$htmlUrl,$sizeMB" | Add-Content -LiteralPath $OUT_FILE
            $repoCount++
        }
    }

    $url = Get-NextLink -LinkHeader $result.LinkHeader
}

if ($repoCount -eq 0) {
    Log-Warn "Organization '$ORG' is valid, but no repositories were found."
}
else {
    Log-Success "Inventory report generated successfully. Repositories found: $repoCount"
}

Log-Info "Output file: $OUT_FILE"