# ============================================================
# GHES -> GHEC Rulesets Migration
# Organization + Repository Rulesets
# ============================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"


# ------------------------------------------------------------
# Environment Inputs
# ------------------------------------------------------------

$CSV_FILE = if ($env:CSV_FILE) {
    $env:CSV_FILE
}
else {
    "repos.csv"
}


$GH_PAT = $env:GH_PAT
if (-not $GH_PAT) {
    throw "Set GH_PAT"
}


$GH_SOURCE_PAT = $env:GH_SOURCE_PAT
if (-not $GH_SOURCE_PAT) {
    throw "Set GH_SOURCE_PAT"
}


$GHES_API_URL = $env:GHES_API_URL
if (-not $GHES_API_URL) {
    throw "Set GHES_API_URL"
}


# Normal GHEC:
# github.com
#
# GHES DR:
# custom hostname

$TARGET_HOST = if ($env:GH_TARGET_HOST) {
    $env:GH_TARGET_HOST
}
else {
    "github.com"
}

$TARGET_API_URL =
if (-not [string]::IsNullOrWhiteSpace($env:TARGET_API_URL)) {
    $env:TARGET_API_URL
}
elseif (-not [string]::IsNullOrWhiteSpace($env:GH_TARGET_HOST)) {
    "https://api.$($env:GH_TARGET_HOST)"
}
else {
    "https://api.github.com"
}


# ------------------------------------------------------------
# Source Host Resolution
# ------------------------------------------------------------

$SOURCE_HOST =
(
    $GHES_API_URL -replace "^https?://",""
) -replace "/api/v3.*$"



# ------------------------------------------------------------
# Logging
# ------------------------------------------------------------

$LOG_DIR = ".\logs"

if (!(Test-Path $LOG_DIR)) {
    New-Item -ItemType Directory -Path $LOG_DIR | Out-Null
}


$LOG_FILE = Join-Path $LOG_DIR (
    "rulesets-migration_{0}.log" -f
    (Get-Date -Format "yyyyMMdd_HHmmss")
)



function Write-Log {

    param(
        [string]$Level,
        [string]$Message
    )


    $Line =
    "[{0}] [{1}] {2}" -f `
    (Get-Date -Format "yyyy-MM-dd HH:mm:ss"),
    $Level,
    $Message


    Write-Host $Line

    Add-Content `
        -Path $LOG_FILE `
        -Value $Line

}



Write-Log INFO "Ruleset Migration Started"
Write-Log INFO "Source Host : $SOURCE_HOST"
Write-Log INFO "Target Host : $TARGET_HOST"

Write-Host ""
Write-Log INFO  "[INFO] Organization rulesets migration is skipped. This solution supports repository-level rulesets migration only."




# ------------------------------------------------------------
# Counters
# ------------------------------------------------------------

$RepoProcessed = 0

$RulesetsReturned = 0

$OrganizationRulesetsCreated = 0
$OrganizationRulesetsSkipped = 0

$RepositoryRulesetsCreated = 0
$RepositoryRulesetsSkipped = 0

$RulesetsFailed = 0


$CreatedOrganizationRulesets = @()
$SkippedOrganizationRulesets = @()

$CreatedRepositoryRulesets = @()
$SkippedRepositoryRulesets = @()
$AllRepoSummaries = @()



# ------------------------------------------------------------
# GitHub API Wrapper
# ------------------------------------------------------------

function Invoke-GitHubApi {

    param(
        [string]$HostName,
        [string]$Token,
        [string]$Method,
        [string]$Endpoint,
        [object]$Body = $null
    )

    if ($HostName -eq $TARGET_HOST) {

        $Uri = "$TARGET_API_URL$Endpoint"

    }
    else {

        $Uri = "https://$SOURCE_HOST/api/v3$Endpoint"

    }

    Write-Log INFO "$Method $Uri"

    $Headers = @{
        Authorization = "Bearer $Token"
        Accept = "application/vnd.github+json"
        "X-GitHub-Api-Version" = "2022-11-28"
    }

    $MaxRetries = 5
    $RetryCount = 0

    while ($true) {

        try {

            if ($Body) {

                $JsonBody =
                $Body |
                ConvertTo-Json -Depth 100

                return Invoke-RestMethod `
                    -Uri $Uri `
                    -Method $Method `
                    -Headers $Headers `
                    -Body $JsonBody `
                    -ContentType "application/json"

            }
            else {

                return Invoke-RestMethod `
                    -Uri $Uri `
                    -Method $Method `
                    -Headers $Headers

            }

        }
        catch {

            $StatusCode = $null
            $RetryAfter = $null

            if ($_.Exception.Response) {

                $StatusCode = [int]$_.Exception.Response.StatusCode

                if ($_.Exception.Response.Headers["Retry-After"]) {

                    $RetryAfter = [int]$_.Exception.Response.Headers["Retry-After"]

                }

            }

            if (
                ($StatusCode -eq 429) -or
                ($StatusCode -eq 403) -or
                ($StatusCode -eq 502) -or
                ($StatusCode -eq 503) -or
                ($StatusCode -eq 504)
            ) {

                if ($RetryCount -lt $MaxRetries) {

                    $RetryCount++

                    if ($RetryAfter) {

                        $WaitTime = $RetryAfter

                    }
                    else {

                        $WaitTime = [math]::Pow(2,$RetryCount) * 5

                    }

                    Write-Log WARN "GitHub API temporary failure detected (HTTP $StatusCode). Retry attempt $RetryCount/$MaxRetries after $WaitTime seconds."

                    Start-Sleep -Seconds $WaitTime

                    continue

                }

            }

            Write-Log ERROR "API Failed"
            Write-Log ERROR $_.Exception.Message

            if ($_.ErrorDetails.Message) {

                Write-Log ERROR "GitHub API Response Body:"
                Write-Log ERROR $_.ErrorDetails.Message

            }

            throw

        }

    }

}

function Get-CleanRulesetPayload {

    param(
        [object]$Ruleset,
        [string]$RulesetType
    )

    $Payload =
    $Ruleset |
    ConvertTo-Json -Depth 100 |
    ConvertFrom-Json


    $RemoveFields = @(
        "id",
        "node_id",
        "_links",
        "created_at",
        "updated_at",
        "source",
        "source_type",
        "ruleset_source",
        "current_user_can_bypass",
        "bypass_actors"
    )

    # Log bypass actors before removing
    if ($Payload.PSObject.Properties.Name -contains "bypass_actors") {

        Write-Log WARN "Bypass actors skipped for ruleset $($Payload.name) - Identity based configurations are out of scope."

    }

    foreach ($Field in $RemoveFields) {

        if ($Payload.PSObject.Properties.Name -contains $Field) {
            $Payload.PSObject.Properties.Remove($Field)
        }

    }


    # Remove unsupported rules before migration
    # GHES rulesets may contain rules not supported by target GHEC API.
    if ($Payload.PSObject.Properties.Name -contains "rules") {

        $FilteredRules = @()

        foreach ($Rule in @($Payload.rules)) {

            if ($Rule.type -eq "merge_queue") {

                Write-Log WARN "Merge queue rule skipped for ruleset $($Payload.name) - Target GHEC Ruleset API does not support migration of this rule configuration."
                continue

            }

            $FilteredRules += $Rule

        }

        $Payload.rules = $FilteredRules

    }


    # Normalize conditions only when present
    if ($Payload.PSObject.Properties.Name -contains "conditions") {

        if ($null -eq $Payload.conditions) {

            $Payload.PSObject.Properties.Remove("conditions")

        }
        elseif ($Payload.conditions.ref_name) {

            $IncludeRefs = @()

            foreach ($ref in @($Payload.conditions.ref_name.include)) {

                $IncludeRefs += $ref.ToString().Replace('"','')

            }

            $Payload.conditions.ref_name.include = $IncludeRefs


            $ExcludeRefs = @()

            foreach ($ref in @($Payload.conditions.ref_name.exclude)) {

                $ExcludeRefs += $ref.ToString().Replace('"','')

            }

            $Payload.conditions.ref_name.exclude = $ExcludeRefs

        }

    }


    # Organization ruleset cleanup
    # GHEC API does not accept repository ref conditions
    # for organization ruleset creation
    if ($RulesetType -eq "Organization") {

        if ($Payload.PSObject.Properties.Name -contains "conditions") {

            if ($Payload.conditions.ref_name) {

                $Payload.conditions.ref_name.include = @("~ALL")
                $Payload.conditions.ref_name.exclude = @()

            }

        }

    }


    # Push rulesets do not use branch/tag conditions
    if ($Payload.target -eq "push") {

        if ($Payload.PSObject.Properties.Name -contains "conditions") {

            $Payload.PSObject.Properties.Remove("conditions")

        }

    }


    return $Payload

}

# ------------------------------------------------------------
# Validate CSV
# ------------------------------------------------------------

if (!(Test-Path $CSV_FILE)) {
    throw "CSV file not found: $CSV_FILE"
}


$Repositories = Import-Csv $CSV_FILE



# ------------------------------------------------------------
# Ruleset Migration
# ------------------------------------------------------------

foreach ($Repo in $Repositories) {


    $RepoProcessed++


    $SourceOrg  = $Repo.ghes_org
    $SourceRepo = $Repo.ghes_repo

    $TargetOrg  = $Repo.github_org
    $TargetRepo = $Repo.github_repo

    $RepoSummary = @{
        Source = "$SourceOrg/$SourceRepo"
        Target = "$TargetOrg/$TargetRepo"
        OrganizationSkipped = @()
        RepositoryMigrated = @()
        RepositorySkipped = @()
    }


    Write-Host ""
    Write-Host "================================================" -ForegroundColor Cyan
    Write-Host "Source : $SourceOrg/$SourceRepo" -ForegroundColor Cyan
    Write-Host "Target : $TargetOrg/$TargetRepo" -ForegroundColor Cyan
    Write-Host "================================================" -ForegroundColor Cyan

    Write-Log INFO "Processing Repository"
    Write-Log INFO "Source Repository : $SourceOrg/$SourceRepo"
    Write-Log INFO "Target Repository : $TargetOrg/$TargetRepo"



    try {


        # ----------------------------------------------------
        # Get source repository rulesets
        # ----------------------------------------------------

        $SourceRulesets =
        Invoke-GitHubApi `
            -HostName $SOURCE_HOST `
            -Token $GH_SOURCE_PAT `
            -Method GET `
            -Endpoint "/repos/$SourceOrg/$SourceRepo/rulesets?per_page=100"



        if (!$SourceRulesets) {

            Write-Log INFO "No rulesets found"

            continue
        }


        $RulesetsReturned += $SourceRulesets.Count



        foreach ($Ruleset in $SourceRulesets) {


            Write-Host ""
            Write-Host "Checking ruleset: $($Ruleset.name)" -ForegroundColor Cyan


            # ------------------------------------------------
            # Get complete ruleset details
            # ------------------------------------------------

            $Details =
            Invoke-GitHubApi `
                -HostName $SOURCE_HOST `
                -Token $GH_SOURCE_PAT `
                -Method GET `
                -Endpoint "/repos/$SourceOrg/$SourceRepo/rulesets/$($Ruleset.id)"



            # =================================================
            # Organization Ruleset Handling
            # =================================================

            if ($Details.source_type -eq "Organization") {


                Write-Host `
                "[ORGANIZATION RULESET] $($Ruleset.name)" `
                -ForegroundColor Yellow

                Write-Host `
                "[SKIPPED] Organization ruleset migration skipped. Only repository rulesets are supported." `
                -ForegroundColor Yellow

                Write-Log INFO `
                "Organization ruleset skipped. Only repository-level ruleset migration is supported."


                # Get target organization rulesets

                $TargetOrgRulesets =
                Invoke-GitHubApi `
                    -HostName $TARGET_HOST `
                    -Token $GH_PAT `
                    -Method GET `
                    -Endpoint "/orgs/$TargetOrg/rulesets?per_page=100"



                $ExistingOrgRuleset =
                $TargetOrgRulesets |
                Where-Object {
                    $_.name -eq $Ruleset.name
                }



                if ($ExistingOrgRuleset) {


                    Write-Host `
                    "[SKIPPED] Organization ruleset already exists: $($Ruleset.name)" `
                    -ForegroundColor Yellow



                    Write-Log INFO `
                    "Organization ruleset skipped (already exists): $($Ruleset.name)"



                    $OrganizationRulesetsSkipped++

                    $null = $null


                    continue

                }
                continue

            }



            # =================================================
            # Repository Ruleset Handling
            # =================================================

            if ($Details.source_type -eq "Repository") {


                Write-Host `
                "[REPOSITORY RULESET] $($Ruleset.name)" `
                -ForegroundColor Cyan



                # Get target repository rulesets

                $TargetRepoRulesets =
                Invoke-GitHubApi `
                    -HostName $TARGET_HOST `
                    -Token $GH_PAT `
                    -Method GET `
                    -Endpoint "/repos/$TargetOrg/$TargetRepo/rulesets?per_page=100"



                $ExistingRepoRuleset =
                $TargetRepoRulesets |
                Where-Object {
                    $_.name -eq $Ruleset.name
                }



                if ($ExistingRepoRuleset) {


                    Write-Host `
                    "[SKIPPED] Repository ruleset already exists: $($Ruleset.name)" `
                    -ForegroundColor Yellow



                    Write-Log INFO `
                    "Repository ruleset skipped (already exists): $($Ruleset.name)"



                    $RepositoryRulesetsSkipped++

                    $RepoSummary.RepositorySkipped += $Ruleset.name


                    continue

                }



                Write-Host `
                "[CREATING] Repository ruleset: $($Ruleset.name)" `
                -ForegroundColor Cyan



                $Payload =
                $RulesetType = "Repository"

                $Payload =
                Get-CleanRulesetPayload $Details $RulesetType



                Invoke-GitHubApi `
                    -HostName $TARGET_HOST `
                    -Token $GH_PAT `
                    -Method POST `
                    -Endpoint "/repos/$TargetOrg/$TargetRepo/rulesets" `
                    -Body $Payload |
                    Out-Null



                Write-Host `
                "[SUCCESS] Repository ruleset migrated: $($Ruleset.name)" `
                -ForegroundColor Green



                Write-Log INFO `
                "Repository ruleset migrated: $($Ruleset.name)"



                $RepositoryRulesetsCreated++

                $RepoSummary.RepositoryMigrated += $Ruleset.name


            }

        }


    }

    catch {

        Write-Host `
        "[FAILED] Ruleset migration failed for $SourceRepo" `
        -ForegroundColor Red


        Write-Log ERROR $_.Exception.Message


        $RulesetsFailed++

    }

    $AllRepoSummaries += $RepoSummary

}



# ------------------------------------------------------------
# Final Summary
# ------------------------------------------------------------

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "Ruleset Migration Summary" -ForegroundColor Cyan
Write-Host ""

Write-Host "================================================" -ForegroundColor Cyan

foreach ($RepoSummary in $AllRepoSummaries) {

    Write-Host ""
    Write-Host "Source Repository : $($RepoSummary.Source)" -ForegroundColor Cyan
    Write-Host "Target Repository : $($RepoSummary.Target)" -ForegroundColor Cyan

    Write-Host ""
    Write-Host "Repository Rulesets" -ForegroundColor Cyan
    Write-Host "--------------------------------"

    Write-Host "Migrated : $($RepoSummary.RepositoryMigrated.Count)"

    foreach ($Rule in $RepoSummary.RepositoryMigrated) {
        Write-Host "$Rule -> Migrated" -ForegroundColor Green
    }

    foreach ($Rule in $RepoSummary.RepositorySkipped) {
        Write-Host "$Rule -> Skipped (Already Exists)" -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "================================================" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Repositories Processed : $RepoProcessed"
Write-Host "Failed : $RulesetsFailed"
Write-Host "Log File : $LOG_FILE"
Write-Host "================================================" -ForegroundColor Cyan
