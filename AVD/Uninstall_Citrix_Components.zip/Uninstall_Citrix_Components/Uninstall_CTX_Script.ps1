#Copyright (c) Microsoft Corporation.
#MIT License
#Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
#The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
#THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# Prompt the user before execution
$UserResponse = Read-Host "Do you want to proceed with this script? (Y/N)"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
# # Please update the below path as per your folder structure
$LogDir = "C:\ScriptLogs"
if (!(Test-Path $LogDir)) {
    New-Item -Path $LogDir -ItemType Directory | Out-Null
}
$LogFile = "$LogDir\CitrixUninstallLog_$Timestamp.txt"

# Function to log messages
Function Write-Log {
    param([string]$Message)
    $FormattedTimestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$FormattedTimestamp - $Message" | Out-File -Append -FilePath $LogFile
    Write-Host $Message
}
if ($UserResponse -match "^[Yy]$") {
	Write-Log "Proceeding with script execution..."
	#Before Execution ,You need to verify the Citrix Components and VDACleanupUtility exe file is available
	$AppName = "Citrix Virtual Apps"  
	$CitrixVersion = (Get-Package -Name "*Citrix Virtual Apps and Desktops*").Version
	# Define registry paths to search for installed applications
$UninstallKeys = @(
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
)
$UninstallString = $null
# Search for the uninstall string in both registry locations
foreach ($Key in $UninstallKeys) {
    $UninstallString = Get-ItemProperty -Path $Key -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like "*$AppName*" } |
        Select-Object -ExpandProperty UninstallString -ErrorAction SilentlyContinue
		if ($UninstallString) { break }
}
# If an uninstall string is found, proceed with the uninstallation
if ($UninstallString) {
    # If it's an array, take the first element
    if ($UninstallString -is [array]) {
        $UninstallString = $UninstallString[0]  # Take the first element if it's an array
    }

    # If it's an MSI-based installer, modify the command to include silent parameters
    if ($UninstallString -match "msiexec") {
        $UninstallString += " /quiet /norestart"
    } else {
        # If it's not an MSI-based installer, add the uninstall and cleanup flags
        $UninstallString = "$UninstallString /uninstall /cleanup"
    }
	Write-Log "Executing uninstall command: $UninstallString"
		$FirstPart = ($UninstallString -split '"')[1]
        $Arguments = "/REMOVEALLWITHCWA /QUIET /NOREBOOT"
    try {
        Start-Process -FilePath $FirstPart -ArgumentList $Arguments -NoNewWindow -Wait 
		Start-Sleep -Seconds 30
        Write-Log "Citrix Virtual Apps and Desktops application $CitrixVersion is uninstalled successfully by $env:USERNAME on $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    } catch {
        Write-Log  "Error occurred during uninstallation:`nMessage: $($_.Exception.Message)`nLine: $($_.InvocationInfo.ScriptLineNumber)`nCommand: $($_.InvocationInfo.Line)"
    }
	# Execute Receiver Cleanup Utility after uninstallation
	#Please download the VDACleanupUtility file from the Github and place it in your C Drive
	# Please update the below path as per your folder structure
    $CleanupUtilityPath = ".\VDACleanupUtility.exe"  
    $CleanupArguments = "/silent /noreboot"

    Write-Log "Executing Receiver Cleanup Utility: $CleanupUtilityPath $CleanupArguments "
    try {
        Start-Process -FilePath $CleanupUtilityPath -ArgumentList $CleanupArguments -NoNewWindow -Wait
        Write-Log "Receiver Cleanup Utility executed successfully by $env:USERNAME on $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    } catch {
        Write-Log "Write-Log "Error occurred during Cleanup Utility execution:`nMessage: $($_.Exception.Message)`nLine: $($_.InvocationInfo.ScriptLineNumber)`nCommand: $($_.InvocationInfo.Line)""
    }

    Start-Sleep -Seconds 10
	Remove-Item -Path "C:\Program Files\Citrix" -Recurse -Force -ErrorAction Ignore
	Remove-Item -Path "C:\Program Files (x86)\Citrix" -Recurse -Force -ErrorAction Ignore
	Write-Log "Citrix folder removed successfully by $env:USERNAME"
	Start-Sleep -Seconds 10
    Restart-Computer

} else {
    Write-Log "Application '$AppName' not found in the registry."
}
} else {
    Write-Log "Script execution aborted by the $env:USERNAME."
    
}