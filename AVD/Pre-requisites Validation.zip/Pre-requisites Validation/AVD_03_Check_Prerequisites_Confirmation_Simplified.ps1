<#
.SYNOPSIS
    Simplified Azure Virtual Desktop (AVD) Prerequisites Validation - Focuses on Deployment Blockers
    
    Validates ALL essential prerequisites for AVD Accelerator deployment while showing ONLY errors 
    and warnings in console output for faster issue identification and resolution.

.DESCRIPTION
    SIMPLIFIED MODE OPERATION:
    This script performs comprehensive validation of ALL AVD Accelerator prerequisites but displays
    ONLY failures and warnings in the console, eliminating clutter from successful checks. All 
    validation results (including passes) are saved in the complete Excel/CSV report.
    
    WHY USE THIS SCRIPT:
    - Quick identification of deployment blockers
    - Focused console output showing only what needs attention
    - Action-oriented recommendations displayed immediately
    - Complete audit trail preserved in full report
    - Ideal for troubleshooting and pre-deployment verification
    
    COMPREHENSIVE VALIDATIONS PERFORMED:
    1. PowerShell Modules - Required Azure PowerShell modules installation
    2. Azure Authentication - Connection to Azure with proper credentials
    3. Subscription Access - Valid subscription with enabled state
    4. User Permissions - Contributor or Owner role at subscription level
    5. Resource Providers - Registration of required Azure resource providers (including EncryptionAtHost)
    6. Network Connectivity - Connectivity to Azure endpoints AND AVD Accelerator script URLs (CRITICAL)
    7. Virtual Network - Existence of VNet for AVD deployment
    8. Network Topology - Hub-and-Spoke detection via UDR analysis
    9. Private Endpoint Policies - Validation that policies are DISABLED (deployment blocker)
    10. Custom DNS Configuration - DNS server settings and conditional forwarding validation
    11. Private DNS Zones - Required zones for Azure Files and Key Vault private endpoints
    12. AVD Enterprise Application - ObjectID retrieval for Start VM on Connect and Scaling Plans
    13. Domain Join Requirements - Guidance on account and OU permissions (informational)

    CRITICAL DEPLOYMENT BLOCKERS DETECTED:
    - Private endpoint network policies not disabled
    - Missing AVD Accelerator script URLs connectivity (GitHub, PowerShell Gallery)
    - Custom DNS without Azure conditional forwarders
    - Missing required resource provider registrations
    - Insufficient RBAC permissions (Contributor/Owner required)
    
    CONSOLE OUTPUT BEHAVIOR:
    - Errors (Fail) - Shown in RED with immediate remediation commands
    - Warnings - Shown in YELLOW with recommendations
    - Pass/Info - Suppressed from console (captured in report only)
    
    REPORT OUTPUT:
    Complete Excel/CSV report contains ALL validation results with color-coding:
    - Green rows: Pass
    - Red rows: Fail (requires immediate action)
    - Yellow rows: Warning (review recommended)
    - Blue rows: Info (informational guidance)

.PARAMETER SkipNetworkValidation
    Skip network connectivity and topology validation

.PARAMETER NonInteractive
    Run in non-interactive mode (uses current Azure context)

.PARAMETER ReportPath
    Custom path for report output (default: script directory)

.PARAMETER UseCSVExport
    Export report as CSV instead of Excel

.EXAMPLE
    .\AVD_03_Check_Prerequisites_Confirmation_Simplified.ps1
    
    Run complete interactive validation with authentication.
    Console shows only errors and warnings.
    Full report saved to script directory.

.EXAMPLE
    .\AVD_03_Check_Prerequisites_Confirmation_Simplified.ps1 -SkipNetworkValidation
    
    Skip network connectivity and topology validation checks.
    Useful when network is known to be configured correctly.

.EXAMPLE
    .\AVD_03_Check_Prerequisites_Confirmation_Simplified.ps1 -NonInteractive
    
    Use existing Azure session without authentication prompts.
    Ideal for automated/scheduled validation runs.

.EXAMPLE
    .\AVD_03_Check_Prerequisites_Confirmation_Simplified.ps1 -UseCSVExport -ReportPath "C:\Reports"
    
    Export results as CSV to custom path.
    Useful for environments without Excel/ImportExcel module.

.NOTES
    Version        : 3.1 - Simplified Console Output (Errors/Warnings Only)
    Author         : AVD Factory Team
    Last Updated   : December 9, 2025
    
    PREREQUISITES:
    - PowerShell 5.1 or later
    - Internet connectivity
    - Azure subscription access (Contributor or Owner role recommended)
    
    EXECUTION (Script is not signed):
    powershell -ExecutionPolicy Bypass -File "AVD_03_Check_Prerequisites_Confirmation_Simplified.ps1"
    
    OUTPUT FORMAT:
    - Console: Only errors and warnings with immediate remediation guidance
    - Report: Complete Excel/CSV with ALL results (pass/fail/warning/info) color-coded
    
    COMPARISON TO AVD_02:
    - AVD_02: Verbose output showing all validation results in console
    - AVD_03 (This): Simplified console showing only issues requiring attention
    - Both: Same comprehensive validation logic and complete reporting

.LINK
    https://github.com/Azure/avd-accelerator
    
.LINK
    https://learn.microsoft.com/azure/virtual-desktop/prerequisites
#>

[CmdletBinding()]
param(
    [Parameter(HelpMessage = "Skip network configuration validation")]
    [switch]$SkipNetworkValidation,
    
    [Parameter(HelpMessage = "Run in non-interactive mode")]
    [switch]$NonInteractive,
    
    [Parameter(HelpMessage = "Custom report output path")]
    [string]$ReportPath,
    
    [Parameter(HelpMessage = "Export report as CSV instead of Excel")]
    [switch]$UseCSVExport
)

# Global variables
$script:Report = @()
$global:UseCSVExport = $UseCSVExport

# Required PowerShell modules (essential for AVD Accelerator)
$RequiredModules = @(
    "Az.Accounts",
    "Az.Resources",
    "Az.Network",
    "Az.Compute",
    "Az.Storage",
    "ImportExcel"
)

# Required Azure Resource Providers (essential for AVD deployment)
$RequiredResourceProviders = @(
    "Microsoft.DesktopVirtualization",
    "Microsoft.Compute",
    "Microsoft.Network",
    "Microsoft.Storage",
    "Microsoft.KeyVault",
    "Microsoft.ManagedIdentity",
    "Microsoft.Authorization",
    "Microsoft.Insights"
)

# Essential AVD endpoints for connectivity validation
$AVDEndpoints = @(
    "management.azure.com",
    "login.microsoftonline.com",
    "prod.warmpath.msftcloudes.com"
)

# AVD Accelerator-specific script URLs (required during deployment)
$AVDAcceleratorEndpoints = @(
    "raw.githubusercontent.com",
    "wvdportalstorageblob.blob.core.windows.net",
    "www.powershellgallery.com",
    "onegetcdn.azureedge.net"
)

# AVD Enterprise Application ID (for Start VM on Connect and Scaling Plans)
$AVDEnterpriseAppId = "9cdead84-a844-4324-93f2-b2e6bb768d07"

# Required Private DNS Zones
$RequiredPrivateDNSZones = @(
    "privatelink.file.core.windows.net",
    "privatelink.vaultcore.azure.net"
)

#region Helper Functions

function Add-ReportEntry {
    param(
        [string]$Check,
        [string]$Result,
        [string]$Details,
        [string]$Recommendation = "",
        [string]$Mandatory = "Yes",  # Default to mandatory unless specified
        [string]$Category = "General",  # Category for grouping issues
        [switch]$SuppressConsoleOutput  # Skip console output (still adds to report)
    )
    
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    
    # SIMPLIFIED MODE: Only show Fail and Warning results in console (Pass and Info are suppressed)
    # All results are still captured in the full report
    if (-not $SuppressConsoleOutput -and ($Result -eq "Fail" -or $Result -eq "Warning")) {
        $color = switch ($Result) {
            "Fail" { "Red" }
            "Warning" { "Yellow" }
            default { "White" }
        }
        
        Write-Host "[$Result] $Check" -ForegroundColor $color
        if ($Details) {
            Write-Host "  $Details" -ForegroundColor Gray
        }
        if ($Recommendation) {
            Write-Host "  → $Recommendation" -ForegroundColor Yellow
        }
    }
    
    $script:Report += [PSCustomObject]@{
        Timestamp = $timestamp
        Mandatory = [string]$Mandatory
        Category = [string]$Category
        Check = [string]$Check
        Result = [string]$Result
        Details = [string]$Details
        Recommendation = [string]$Recommendation
    }
}

function Test-PowerShellModules {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING POWERSHELL MODULES " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    foreach ($module in $RequiredModules) {
        if (-not (Get-Module -ListAvailable -Name $module)) {
            try {
                Write-Host "Installing module: $module..." -ForegroundColor Yellow
                
                if ($module -eq "ImportExcel") {
                    try {
                        Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber -Repository PSGallery -ErrorAction Stop
                    } catch {
                        Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber -SkipPublisherCheck -ErrorAction Stop
                    }
                } else {
                    Install-Module -Name $module -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                }
                
                Add-ReportEntry -Check "Module Install: $module" -Result "Pass" -Details "Successfully installed" -Mandatory "Yes" -Category "PowerShell Modules"
            } catch {
                if ($module -eq "ImportExcel") {
                    Add-ReportEntry -Check "Module Install: $module" -Result "Warning" -Details "ImportExcel installation failed - will use CSV export" -Recommendation "Manual install: Install-Module ImportExcel -Force" -Mandatory "No" -Category "PowerShell Modules"
                    $global:UseCSVExport = $true
                } else {
                    Add-ReportEntry -Check "Module Install: $module" -Result "Fail" -Details "Installation failed: $($_.Exception.Message)" -Recommendation "Install-Module $module -Force -AllowClobber" -Mandatory "Yes" -Category "PowerShell Modules"
                    throw "Critical module installation failed: $module"
                }
            }
        } else {
            $mandatoryStatus = if ($module -eq "ImportExcel") { "No" } else { "Yes" }
            Add-ReportEntry -Check "Module Check: $module" -Result "Pass" -Details "Module already installed" -Mandatory $mandatoryStatus -Category "PowerShell Modules"
        }
    }
    
    # Import modules
    foreach ($module in $RequiredModules) {
        if ($module -eq "ImportExcel" -and $global:UseCSVExport) {
            continue
        }
        
        try {
            Import-Module $module -DisableNameChecking -Force -ErrorAction Stop
            $mandatoryStatus = if ($module -eq "ImportExcel") { "No" } else { "Yes" }
            Add-ReportEntry -Check "Module Import: $module" -Result "Pass" -Details "Successfully imported" -Mandatory $mandatoryStatus -Category "PowerShell Modules"
        } catch {
            if ($module -eq "ImportExcel") {
                $global:UseCSVExport = $true
                Add-ReportEntry -Check "Module Import: $module" -Result "Warning" -Details "Using CSV export fallback" -Mandatory "No" -Category "PowerShell Modules"
            } else {
                Add-ReportEntry -Check "Module Import: $module" -Result "Fail" -Details "Import failed: $($_.Exception.Message)" -Recommendation "Import-Module $module -Force" -Mandatory "Yes" -Category "PowerShell Modules"
                throw "Critical module import failed: $module"
            }
        }
    }
}

function Connect-AzureInteractive {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " AZURE AUTHENTICATION " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host ""
    
    if ($NonInteractive) {
        $context = Get-AzContext
        if ($context) {
            Add-ReportEntry -Check "Azure Authentication" -Result "Pass" -Details "Using existing context: $($context.Account.Id)" -Mandatory "Yes" -Category "Azure Access"
            return $true
        } else {
            Add-ReportEntry -Check "Azure Authentication" -Result "Fail" -Details "No Azure context in non-interactive mode" -Recommendation "Run Connect-AzAccount first" -Mandatory "Yes" -Category "Azure Access"
            return $false
        }
    }
    
    Write-Host "Select authentication method:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  1. Interactive Browser (Default)" -ForegroundColor White
    Write-Host "  2. Device Code (Recommended for MFA/Corporate)" -ForegroundColor White
    Write-Host "  3. Service Principal (Automated Scenarios)" -ForegroundColor White
    Write-Host ""
    
    $choice = Read-Host "Enter choice (1-3) [Default: 1]"
    if ([string]::IsNullOrWhiteSpace($choice)) { $choice = "1" }
    
    $connected = $false
    
    switch ($choice) {
        '1' {
            try {
                Write-Host "Opening browser for authentication..." -ForegroundColor Yellow
                Connect-AzAccount -ErrorAction Stop | Out-Null
                Add-ReportEntry -Check "Azure Authentication" -Result "Pass" -Details "Interactive browser authentication successful" -Mandatory "Yes" -Category "Azure Access"
                $connected = $true
            } catch {
                Add-ReportEntry -Check "Azure Authentication" -Result "Fail" -Details "Browser authentication failed: $($_.Exception.Message)" -Recommendation "Try device code authentication" -Mandatory "Yes" -Category "Azure Access"
            }
        }
        '2' {
            try {
                Write-Host "Initiating device code authentication..." -ForegroundColor Yellow
                Connect-AzAccount -UseDeviceAuthentication -ErrorAction Stop | Out-Null
                Add-ReportEntry -Check "Azure Authentication" -Result "Pass" -Details "Device code authentication successful" -Mandatory "Yes" -Category "Azure Access"
                $connected = $true
            } catch {
                Add-ReportEntry -Check "Azure Authentication" -Result "Fail" -Details "Device code failed: $($_.Exception.Message)" -Recommendation "Try browser authentication or check credentials" -Mandatory "Yes" -Category "Azure Access"
            }
        }
        '3' {
            $appId = Read-Host "Application (Client) ID"
            $tenantId = Read-Host "Tenant ID"
            $secret = Read-Host "Client Secret" -AsSecureString
            
            try {
                $credential = New-Object System.Management.Automation.PSCredential($appId, $secret)
                Connect-AzAccount -ServicePrincipal -ApplicationId $appId -TenantId $tenantId -Credential $credential -ErrorAction Stop | Out-Null
                Add-ReportEntry -Check "Azure Authentication" -Result "Pass" -Details "Service principal authentication successful" -Mandatory "Yes" -Category "Azure Access"
                $connected = $true
            } catch {
                Add-ReportEntry -Check "Azure Authentication" -Result "Fail" -Details "Service principal failed: $($_.Exception.Message)" -Recommendation "Verify application ID, tenant ID, and secret" -Mandatory "Yes" -Category "Azure Access"
            }
        }
    }
    
    return $connected
}

function Select-AzureSubscription {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " SUBSCRIPTION SELECTION " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host ""
    
    try {
        $subscriptions = Get-AzSubscription | Where-Object { $_.State -eq "Enabled" }
        
        if ($subscriptions.Count -eq 0) {
            Add-ReportEntry -Check "Subscription Access" -Result "Fail" -Details "No enabled subscriptions found" -Recommendation "Verify Azure account has subscription access" -Mandatory "Yes" -Category "Azure Access"
            return $false
        }
        
        if ($subscriptions.Count -eq 1) {
            $subscription = $subscriptions[0]
            Set-AzContext -SubscriptionId $subscription.Id | Out-Null
            Add-ReportEntry -Check "Subscription Selection" -Result "Pass" -Details "Using subscription: $($subscription.Name) ($($subscription.Id))" -Mandatory "Yes" -Category "Azure Access"
            return $true
        }
        
        # Multiple subscriptions - interactive selection
        Write-Host "Available Subscriptions:" -ForegroundColor White
        Write-Host ""
        for ($i = 0; $i -lt $subscriptions.Count; $i++) {
            $sub = $subscriptions[$i]
            Write-Host "  [$($i + 1)] $($sub.Name)" -ForegroundColor White
            Write-Host "      ID: $($sub.Id)" -ForegroundColor Gray
            Write-Host "      State: $($sub.State)" -ForegroundColor Gray
            Write-Host ""
        }
        
        do {
            $selection = Read-Host "Select subscription (1-$($subscriptions.Count))"
            $selectionInt = 0
            $valid = [int]::TryParse($selection, [ref]$selectionInt) -and $selectionInt -ge 1 -and $selectionInt -le $subscriptions.Count
            if (-not $valid) {
                Write-Host "Invalid selection. Please enter a number between 1 and $($subscriptions.Count)." -ForegroundColor Red
            }
        } while (-not $valid)
        
        $subscription = $subscriptions[$selectionInt - 1]
        Set-AzContext -SubscriptionId $subscription.Id | Out-Null
        Add-ReportEntry -Check "Subscription Selection" -Result "Pass" -Details "Selected: $($subscription.Name) ($($subscription.Id))" -Mandatory "Yes" -Category "Azure Access"
        return $true
        
    } catch {
        Add-ReportEntry -Check "Subscription Selection" -Result "Fail" -Details "Failed to access subscriptions: $($_.Exception.Message)" -Recommendation "Verify Azure permissions" -Mandatory "Yes" -Category "Azure Access"
        return $false
    }
}

function Test-UserPermissions {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING USER PERMISSIONS " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        $context = Get-AzContext
        $subscription = Get-AzSubscription -SubscriptionId $context.Subscription.Id
        $currentUser = $context.Account.Id
        
        # Get role assignments at subscription scope and above (inherited permissions)
        $subscriptionScope = "/subscriptions/$($subscription.Id)"
        $roleAssignments = Get-AzRoleAssignment -Scope $subscriptionScope -ErrorAction SilentlyContinue
        
        if (-not $roleAssignments) {
            # Fallback: Try getting all assignments for the user
            $roleAssignments = Get-AzRoleAssignment -SignInName $currentUser -ErrorAction SilentlyContinue
        }
        
        $hasRequiredRole = $false
        $assignedRoles = @()
        
        foreach ($assignment in $roleAssignments) {
            # Check if assignment is at subscription level or inherited (management group, tenant root)
            $isRelevantScope = $false
            
            if ($assignment.Scope -eq $subscriptionScope) {
                # Direct subscription assignment
                $isRelevantScope = $true
            }
            elseif ($assignment.Scope -notlike "/subscriptions/*") {
                # Management group or tenant root - these inherit to subscription
                $isRelevantScope = $true
            }
            elseif ($assignment.Scope -like "$subscriptionScope/*") {
                # Assignment at resource group level under this subscription
                $isRelevantScope = $true
            }
            
            if ($isRelevantScope -and $assignment.SignInName -eq $currentUser) {
                $assignedRoles += $assignment.RoleDefinitionName
                if ($assignment.RoleDefinitionName -in @("Owner", "Contributor")) {
                    $hasRequiredRole = $true
                }
            }
        }
        
        if ($hasRequiredRole) {
            Add-ReportEntry -Check "User Permissions" -Result "Pass" -Details "User has required permissions (Owner or Contributor)" -Recommendation "" -Mandatory "Yes" -Category "RBAC Permissions"
        } else {
            $roleList = if ($assignedRoles.Count -gt 0) { $assignedRoles -join ", " } else { "None" }
            Add-ReportEntry -Check "User Permissions" -Result "Fail" -Details "Missing Owner or Contributor role. Found: $roleList" -Recommendation "Assign Contributor or Owner role: New-AzRoleAssignment -SignInName $currentUser -RoleDefinitionName 'Contributor' -Scope '/subscriptions/$($subscription.Id)'" -Mandatory "Yes" -Category "RBAC Permissions"
        }
        
    } catch {
        Add-ReportEntry -Check "User Permissions" -Result "Fail" -Details "Failed to check permissions: $($_.Exception.Message)" -Recommendation "Verify user account and subscription access" -Mandatory "Yes" -Category "RBAC Permissions"
    }
}

function Test-ResourceProviders {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING RESOURCE PROVIDERS " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    foreach ($provider in $RequiredResourceProviders) {
        try {
            $providerInfo = Get-AzResourceProvider -ProviderNamespace $provider
            
            if ($providerInfo.RegistrationState -eq "Registered") {
                Add-ReportEntry -Check "Resource Provider: $provider" -Result "Pass" -Details "Registered and available" -Mandatory "Yes" -Category "Resource Providers"
            } elseif ($providerInfo.RegistrationState -eq "Registering") {
                Add-ReportEntry -Check "Resource Provider: $provider" -Result "Warning" -Details "Currently registering (may take a few minutes)" -Recommendation "Wait for registration to complete" -Mandatory "Yes" -Category "Resource Providers"
            } else {
                Add-ReportEntry -Check "Resource Provider: $provider" -Result "Fail" -Details "Not registered (State: $($providerInfo.RegistrationState))" -Recommendation "Register-AzResourceProvider -ProviderNamespace $provider" -Mandatory "Yes" -Category "Resource Providers"
                
                # Auto-register if possible
                try {
                    Write-Host "  Attempting to register $provider..." -ForegroundColor Yellow
                    Register-AzResourceProvider -ProviderNamespace $provider | Out-Null
                    Add-ReportEntry -Check "Resource Provider Registration: $provider" -Result "Info" -Details "Registration initiated (may take 5-10 minutes)" -Mandatory "Yes" -Category "Resource Providers"
                } catch {
                    Add-ReportEntry -Check "Resource Provider Registration: $provider" -Result "Fail" -Details "Auto-registration failed: $($_.Exception.Message)" -Mandatory "Yes" -Category "Resource Providers"
                }
            }
        } catch {
            Add-ReportEntry -Check "Resource Provider: $provider" -Result "Fail" -Details "Failed to check provider: $($_.Exception.Message)" -Recommendation "Verify subscription permissions" -Mandatory "Yes" -Category "Resource Providers"
        }
    }
}

function Test-NetworkConnectivity {
    if ($SkipNetworkValidation) {
        Add-ReportEntry -Check "Network Validation" -Result "Info" -Details "Network validation skipped by user request" -Mandatory "No" -Category "Network Configuration"
        return
    }
    
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING NETWORK CONNECTIVITY " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    # Test Azure essential endpoints
    foreach ($endpoint in $AVDEndpoints) {
        try {
            $result = Test-NetConnection -ComputerName $endpoint -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue
            
            if ($result) {
                Add-ReportEntry -Check "Connectivity: $endpoint" -Result "Pass" -Details "HTTPS (port 443) connectivity successful" -Mandatory "Yes" -Category "Network Configuration"
            } else {
                Add-ReportEntry -Check "Connectivity: $endpoint" -Result "Fail" -Details "Cannot reach endpoint on port 443" -Recommendation "Check firewall, proxy settings, and network security groups" -Mandatory "Yes" -Category "Network Configuration"
            }
        } catch {
            Add-ReportEntry -Check "Connectivity: $endpoint" -Result "Fail" -Details "Connection test failed: $($_.Exception.Message)" -Recommendation "Verify network configuration and DNS resolution" -Mandatory "Yes" -Category "Network Configuration"
        }
    }
    
    # Test AVD Accelerator-specific endpoints (CRITICAL for deployment)
    Write-Host ""
    
    foreach ($endpoint in $AVDAcceleratorEndpoints) {
        try {
            $result = Test-NetConnection -ComputerName $endpoint -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue
            
            if ($result) {
                Add-ReportEntry -Check "AVD Accelerator URL: $endpoint" -Result "Pass" -Details "Required for deployment script downloads" -Mandatory "Yes" -Category "Network Configuration"
            } else {
                Add-ReportEntry -Check "AVD Accelerator URL: $endpoint" -Result "Fail" -Details "DEPLOYMENT BLOCKER: Cannot reach AVD Accelerator script repository" -Recommendation "Allow HTTPS access to $endpoint (required for session host configuration scripts)" -Mandatory "Yes" -Category "Network Configuration"
            }
        } catch {
            Add-ReportEntry -Check "AVD Accelerator URL: $endpoint" -Result "Fail" -Details "DEPLOYMENT BLOCKER: Connection failed - $($_.Exception.Message)" -Recommendation "Verify firewall allows HTTPS to GitHub and Azure CDN endpoints" -Mandatory "Yes" -Category "Network Configuration"
        }
    }
}

function Test-PrivateEndpointPolicies {
    if ($SkipNetworkValidation) {
        return
    }
    
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING PRIVATE ENDPOINT NETWORK POLICIES " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        $vnets = Get-AzVirtualNetwork
        
        if ($vnets.Count -eq 0) {
            Add-ReportEntry -Check "Private Endpoint Policies" -Result "Info" -Details "No VNets found - check will be performed when VNets are created" -Mandatory "No" -Category "Network Configuration"
            return
        }
        
        $policyIssuesFound = $false
        
        foreach ($vnet in $vnets) {
            foreach ($subnet in $vnet.Subnets) {
                # Check PrivateEndpointNetworkPolicies
                if ($subnet.PrivateEndpointNetworkPolicies -eq "Enabled") {
                    $policyIssuesFound = $true
                    Add-ReportEntry -Check "Private Endpoint Policies: $($vnet.Name)/$($subnet.Name)" -Result "Fail" -Details "DEPLOYMENT BLOCKER: PrivateEndpointNetworkPolicies is ENABLED (must be Disabled)" -Recommendation "`$vnet = Get-AzVirtualNetwork -Name '$($vnet.Name)' -ResourceGroupName '$($vnet.ResourceGroupName)'; `$subnet = Get-AzVirtualNetworkSubnetConfig -Name '$($subnet.Name)' -VirtualNetwork `$vnet; `$subnet.PrivateEndpointNetworkPolicies = 'Disabled'; Set-AzVirtualNetwork -VirtualNetwork `$vnet" -Mandatory "Yes" -Category "Network Configuration"
                } else {
                    Add-ReportEntry -Check "Private Endpoint Policies: $($vnet.Name)/$($subnet.Name)" -Result "Pass" -Details "PrivateEndpointNetworkPolicies correctly set to Disabled" -Mandatory "Yes" -Category "Network Configuration"
                }
            }
        }
        
    } catch {
        Add-ReportEntry -Check "Private Endpoint Policies" -Result "Fail" -Details "Failed to validate policies: $($_.Exception.Message)" -Recommendation "Verify network read permissions" -Mandatory "Yes" -Category "Network Configuration"
    }
}

function Test-CustomDNSConfiguration {
    if ($SkipNetworkValidation) {
        return
    }
    
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING CUSTOM DNS CONFIGURATION " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        $vnets = Get-AzVirtualNetwork
        
        if ($vnets.Count -eq 0) {
            return
        }
        
        $customDnsDetected = $false
        
        foreach ($vnet in $vnets) {
            if ($vnet.DhcpOptions.DnsServers -and $vnet.DhcpOptions.DnsServers.Count -gt 0) {
                $customDnsDetected = $true
                $dnsServers = $vnet.DhcpOptions.DnsServers -join ", "
                
                # Check if Azure DNS (168.63.129.16) is in the list
                if ($vnet.DhcpOptions.DnsServers -contains "168.63.129.16") {
                    Add-ReportEntry -Check "Custom DNS: $($vnet.Name)" -Result "Pass" -Details "Custom DNS servers: $dnsServers (Azure DNS 168.63.129.16 included)" -Mandatory "No" -Category "Network Configuration"
                } else {
                    Add-ReportEntry -Check "Custom DNS: $($vnet.Name)" -Result "Warning" -Details "Custom DNS servers configured: $dnsServers | Azure DNS (168.63.129.16) NOT in list" -Recommendation "For private endpoints, ensure conditional forwarders to 168.63.129.16 are configured for file.core.windows.net and vaultcore.azure.net" -Mandatory "No" -Category "Network Configuration"
                }
            }
        }
        
        if (-not $customDnsDetected) {
            Add-ReportEntry -Check "Custom DNS Configuration" -Result "Pass" -Details "No custom DNS servers detected - using Azure-provided DNS (168.63.129.16)" -Mandatory "No" -Category "Network Configuration"
        }
        
    } catch {
        Add-ReportEntry -Check "Custom DNS Configuration" -Result "Warning" -Details "Failed to check DNS configuration: $($_.Exception.Message)" -Mandatory "No" -Category "Network Configuration"
    }
}

function Test-PrivateDNSZones {
    if ($SkipNetworkValidation) {
        return
    }
    
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING PRIVATE DNS ZONES " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        $privateDnsZones = Get-AzPrivateDnsZone -ErrorAction SilentlyContinue
        
        foreach ($requiredZone in $RequiredPrivateDNSZones) {
            $zoneExists = $privateDnsZones | Where-Object { $_.Name -eq $requiredZone }
            
            if ($zoneExists) {
                # Check if zone is linked to any VNets
                $links = Get-AzPrivateDnsVirtualNetworkLink -ResourceGroupName $zoneExists.ResourceGroupName -ZoneName $zoneExists.Name -ErrorAction SilentlyContinue
                
                if ($links -and $links.Count -gt 0) {
                    Add-ReportEntry -Check "Private DNS Zone: $requiredZone" -Result "Pass" -Details "Zone exists and linked to $($links.Count) VNet(s)" -Mandatory "No" -Category "Network Configuration"
                } else {
                    Add-ReportEntry -Check "Private DNS Zone: $requiredZone" -Result "Warning" -Details "Zone exists but not linked to any VNets" -Recommendation "Link zone to VNets using: New-AzPrivateDnsVirtualNetworkLink" -Mandatory "No" -Category "Network Configuration"
                }
            } else {
                Add-ReportEntry -Check "Private DNS Zone: $requiredZone" -Result "Info" -Details "Zone not found (will be created if using private endpoints)" -Recommendation "If using private endpoints, create zone: New-AzPrivateDnsZone -ResourceGroupName <rg> -Name $requiredZone" -Mandatory "No" -Category "Network Configuration"
            }
        }
        
    } catch {
        Add-ReportEntry -Check "Private DNS Zones" -Result "Warning" -Details "Failed to enumerate private DNS zones: $($_.Exception.Message)" -Mandatory "No" -Category "Network Configuration"
    }
}

function Test-AVDEnterpriseApplication {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING AVD ENTERPRISE APPLICATION " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        # Try to get the AVD enterprise application
        $avdApp = Get-AzADServicePrincipal -ApplicationId $AVDEnterpriseAppId -ErrorAction SilentlyContinue
        
        if ($avdApp) {
            Add-ReportEntry -Check "AVD Enterprise Application" -Result "Pass" -Details "Found: $($avdApp.DisplayName) (ObjectId: $($avdApp.Id))" -Recommendation "This ObjectId is required for Start VM on Connect and Scaling Plans features" -Mandatory "No" -Category "Azure Access"
        } else {
            Add-ReportEntry -Check "AVD Enterprise Application" -Result "Warning" -Details "Azure Virtual Desktop enterprise app not found in tenant" -Recommendation "Required for Start VM on Connect and Scaling Plans. Search in Entra ID > Enterprise Applications for AppId: $AVDEnterpriseAppId" -Mandatory "No" -Category "Azure Access"
        }
        
    } catch {
        Add-ReportEntry -Check "AVD Enterprise Application" -Result "Warning" -Details "Failed to query enterprise applications: $($_.Exception.Message)" -Recommendation "Ensure you have permissions to read Entra ID enterprise applications" -Mandatory "No" -Category "Azure Access"
    }
}

function Test-EncryptionAtHost {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " VALIDATING ENCRYPTION AT HOST FEATURE " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        # Check if EncryptionAtHost feature is registered
        $encryptionFeature = Get-AzProviderFeature -ProviderNamespace "Microsoft.Compute" -FeatureName "EncryptionAtHost" -ErrorAction SilentlyContinue
        
        if ($encryptionFeature) {
            if ($encryptionFeature.RegistrationState -eq "Registered") {
                Add-ReportEntry -Check "Encryption at Host Feature" -Result "Pass" -Details "Feature registered (required for Zero Trust deployments)" -Mandatory "No" -Category "Resource Providers"
            } elseif ($encryptionFeature.RegistrationState -eq "Registering") {
                Add-ReportEntry -Check "Encryption at Host Feature" -Result "Warning" -Details "Feature currently registering (may take up to 15 minutes)" -Recommendation "Wait for registration to complete" -Mandatory "No" -Category "Resource Providers"
            } else {
                Add-ReportEntry -Check "Encryption at Host Feature" -Result "Info" -Details "Feature not registered (State: $($encryptionFeature.RegistrationState))" -Recommendation "For Zero Trust: Register-AzProviderFeature -FeatureName 'EncryptionAtHost' -ProviderNamespace 'Microsoft.Compute'" -Mandatory "No" -Category "Resource Providers"
            }
        } else {
            Add-ReportEntry -Check "Encryption at Host Feature" -Result "Info" -Details "Feature not registered" -Recommendation "For Zero Trust deployments: Register-AzProviderFeature -FeatureName 'EncryptionAtHost' -ProviderNamespace 'Microsoft.Compute'" -Mandatory "No" -Category "Resource Providers"
        }
        
    } catch {
        Add-ReportEntry -Check "Encryption at Host Feature" -Result "Warning" -Details "Failed to check feature: $($_.Exception.Message)" -Mandatory "No" -Category "Resource Providers"
    }
}

function Show-DomainJoinGuidance {
    # Simplified mode: Add to report only, no verbose console output
    Add-ReportEntry -Check "Domain Join Requirements" -Result "Info" -Details "Account must NOT have MFA | Requires specific OU permissions | Use writable DCs only" -Recommendation "See: https://learn.microsoft.com/azure/virtual-desktop/prerequisites" -Mandatory "Yes" -Category "Azure Access"
}

function Test-NetworkTopology {
    if ($SkipNetworkValidation) {
        return
    }
    
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " ANALYZING NETWORK TOPOLOGY " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host "" -NoNewline
    Write-Host "  [Simplified Mode: Only showing errors and warnings]" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        $vnets = Get-AzVirtualNetwork
        
        if ($vnets.Count -eq 0) {
            Add-ReportEntry -Check "Virtual Networks" -Result "Warning" -Details "No virtual networks found in subscription" -Recommendation "Create a VNet for AVD deployment or verify subscription selection" -Mandatory "No" -Category "Network Configuration"
            return
        }
        
        Add-ReportEntry -Check "Virtual Networks" -Result "Pass" -Details "Found $($vnets.Count) virtual network(s)" -Mandatory "No" -Category "Network Configuration"
        
        # Console output limiting (only show first 10 items to keep audience engaged)
        $consoleItemCount = 0
        $consoleLimit = 10
        $totalItems = 0
        
        # Advanced Hub-and-Spoke detection using UDR (User-Defined Routes)
        $hubSpokeDetected = $false
        
        foreach ($vnet in $vnets) {
            $subnets = $vnet.Subnets
            $totalItems++
            
            if ($subnets.Count -gt 0) {
                $showInConsole = ($consoleItemCount -lt $consoleLimit)
                if ($showInConsole) { $consoleItemCount++ }
                
                Add-ReportEntry -Check "VNet Subnets: $($vnet.Name)" -Result "Pass" -Details "$($subnets.Count) subnet(s) configured" -Mandatory "No" -Category "Network Configuration" -SuppressConsoleOutput:(-not $showInConsole)
                
                # Check for UDRs indicating hub-spoke topology
                foreach ($subnet in $subnets) {
                    if ($subnet.RouteTable) {
                        try {
                            $routeTableId = $subnet.RouteTable.Id
                            $routeTableParts = $routeTableId -split '/'
                            $routeTableRg = $routeTableParts[4]
                            $routeTableName = $routeTableParts[-1]
                            
                            $routeTable = Get-AzRouteTable -ResourceGroupName $routeTableRg -Name $routeTableName
                            
                            # Check for default route (0.0.0.0/0) pointing to Virtual Appliance or VNet Gateway
                            $defaultRoute = $routeTable.Routes | Where-Object { 
                                $_.AddressPrefix -eq "0.0.0.0/0" -and 
                                $_.NextHopType -in @("VirtualAppliance", "VirtualNetworkGateway")
                            }
                            
                            if ($defaultRoute) {
                                $hubSpokeDetected = $true
                                $nextHopType = $defaultRoute.NextHopType
                                $nextHopIp = if ($defaultRoute.NextHopIpAddress) { $defaultRoute.NextHopIpAddress } else { "N/A" }
                                
                                $totalItems++
                                $showInConsoleRoute = ($consoleItemCount -lt $consoleLimit)
                                if ($showInConsoleRoute) { $consoleItemCount++ }
                                Add-ReportEntry -Check "Hub-and-Spoke Topology" -Result "Pass" -Details "Detected in subnet '$($subnet.Name)': Default route (0.0.0.0/0) to $nextHopType ($nextHopIp)" -Recommendation "" -Mandatory "No" -Category "Network Configuration" -SuppressConsoleOutput:(-not $showInConsoleRoute)
                            }
                        } catch {
                            $totalItems++
                            # Always show failures in console
                            Add-ReportEntry -Check "Route Table Analysis: $($subnet.Name)" -Result "Warning" -Details "Failed to analyze route table: $($_.Exception.Message)" -Mandatory "No" -Category "Network Configuration"
                        }
                    }
                }
            } else {
                $totalItems++
                $showInConsole = ($consoleItemCount -lt $consoleLimit)
                if ($showInConsole) { $consoleItemCount++ }
                
                Add-ReportEntry -Check "VNet Subnets: $($vnet.Name)" -Result "Warning" -Details "No subnets configured" -Recommendation "Create subnets for AVD session hosts" -Mandatory "No" -Category "Network Configuration" -SuppressConsoleOutput:(-not $showInConsole)
            }
        }
        
        # Show console limit message if applicable
        if ($totalItems -gt $consoleLimit) {
            $remainingItems = $totalItems - $consoleLimit
            Write-Host ""
            Write-Host "  [Console Output Limited: Showing first $consoleLimit items]" -ForegroundColor Cyan
            Write-Host "  Additional $remainingItems network validation results available in the report" -ForegroundColor Cyan
            Write-Host "  (Failures are always shown in console regardless of limit)" -ForegroundColor Yellow
            Write-Host ""
        }
        
        if (-not $hubSpokeDetected) {
            Add-ReportEntry -Check "Hub-and-Spoke Topology" -Result "Info" -Details "No hub-and-spoke topology detected (using direct internet egress or peering without centralized routing)" -Recommendation "For enterprise deployments, consider implementing hub-and-spoke with centralized firewall/NVA" -Mandatory "No" -Category "Network Configuration"
        }
        
    } catch {
        Add-ReportEntry -Check "Network Topology" -Result "Fail" -Details "Failed to analyze network: $($_.Exception.Message)" -Recommendation "Verify network read permissions" -Mandatory "No" -Category "Network Configuration"
    }
}

function Export-ValidationReport {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host " GENERATING VALIDATION REPORT " -ForegroundColor White
    Write-Host ("=" * 100) -ForegroundColor White
    Write-Host ""
    
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $scriptPath = if ($ReportPath) { $ReportPath } else { if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path } }
    
    if ($global:UseCSVExport) {
        $filename = "AVD_01_Check_Prerequisites_Confirmation_Simplified_$timestamp.csv"
        $fullPath = Join-Path -Path $scriptPath -ChildPath $filename
        
        try {
            $script:Report | Export-Csv -Path $fullPath -NoTypeInformation -Encoding UTF8
            Write-Host "Report exported to: $fullPath" -ForegroundColor Green
            Add-ReportEntry -Check "Report Export" -Result "Pass" -Details "CSV report saved to $fullPath" -Mandatory "No" -Category "General"
        } catch {
            Write-Host "Failed to export CSV report: $($_.Exception.Message)" -ForegroundColor Red
            Add-ReportEntry -Check "Report Export" -Result "Fail" -Details "CSV export failed: $($_.Exception.Message)" -Mandatory "No" -Category "General"
        }
    } else {
        $filename = "AVD_01_Check_Prerequisites_Confirmation_Simplified_$timestamp.xlsx"
        $fullPath = Join-Path -Path $scriptPath -ChildPath $filename
        
        try {
            # Export with color coding and autofilter
            $script:Report | Export-Excel -Path $fullPath `
                -WorksheetName "AVD Prerequisites" `
                -AutoSize `
                -BoldTopRow `
                -FreezeTopRow `
                -AutoFilter `
                -TableName "PrerequisitesTable" `
                -Title "AVD_01_Check_Prerequisites_Confirmation_Simplified" `
                -PassThru | ForEach-Object {
                    $ws = $_.Workbook.Worksheets["AVD Prerequisites"]
                    $totalRows = $ws.Dimension.Rows
                    
                    # Apply conditional formatting matching console colors
                    for ($row = 2; $row -le $totalRows; $row++) {
                        $resultCell = $ws.Cells[$row, 5]  # Result column (Timestamp, Mandatory, Category, Check, Result, Details, Recommendation)
                        $resultValue = $resultCell.Value
                        
                        switch ($resultValue) {
                            "Pass" {
                                # Soft green - pleasant and easy on the eyes
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::LightGreen)
                            }
                            "Fail" {
                                # Soft salmon - less harsh than red/coral
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::LightSalmon)
                            }
                            "Warning" {
                                # Peach puff - warmer and softer than bright yellow
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::PeachPuff)
                            }
                            "Info" {
                                # Powder blue - softer and more pleasant than cyan
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                $ws.Cells[$row, 1, $row, $ws.Dimension.Columns].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::PowderBlue)
                            }
                        }
                    }
                    
                    $_.Save()
                    $_.Dispose()
                }
            
            Write-Host "Report exported to: $fullPath" -ForegroundColor Green
            Add-ReportEntry -Check "Report Export" -Result "Pass" -Details "Excel report saved to $fullPath" -Mandatory "No" -Category "General"
        } catch {
            Write-Host "Failed to export Excel report: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host "Attempting CSV export as fallback..." -ForegroundColor Yellow
            
            $csvFilename = "AVD_01_Check_Prerequisites_Confirmation_Simplified_$timestamp.csv"
            $csvFullPath = Join-Path -Path $scriptPath -ChildPath $csvFilename
            
            try {
                $script:Report | Export-Csv -Path $csvFullPath -NoTypeInformation -Encoding UTF8
                Write-Host "CSV report exported to: $csvFullPath" -ForegroundColor Green
                Add-ReportEntry -Check "Report Export" -Result "Warning" -Details "Excel failed, CSV exported to $csvFullPath" -Mandatory "No" -Category "General"
            } catch {
                Add-ReportEntry -Check "Report Export" -Result "Fail" -Details "Both Excel and CSV export failed" -Mandatory "No" -Category "General"
            }
        }
    }
    
    return $fullPath
}

function Get-EnhancedRemediationGuidance {
    param(
        [string]$Category,
        [string]$Check,
        [string]$Details
    )
    
    # Provide enhanced guidance with specific examples
    $guidance = switch ($Category) {
        "PowerShell Modules" {
            switch -Wildcard ($Check) {
                "*Az.ImageBuilder*" { 
                    "Install-Module Az.ImageBuilder -Force -AllowClobber Install-Module Az.ImageBuilder -Force -AllowClobber -Scope CurrentUser Install-Module -Force -AllowClobber -Scope CurrentUser"
                }
                "*Install*" { 
                    $moduleName = ($Check -split ':')[1].Trim()
                    "Install-Module $moduleName -Force -AllowClobber -Scope CurrentUser" 
                }
                "*Import*" { 
                    $moduleName = ($Check -split ':')[1].Trim()
                    "Import-Module $moduleName -Force" 
                }
                default { "https://docs.microsoft.com/powershell/azure/install-az-ps" }
            }
        }
        
        "Network Configuration" {
            switch -Wildcard ($Check) {
                "*management.azure.com*" { 
                    "Test-NetConnection management.azure.com -Port 443 | Verify Azure Management endpoint access | https://docs.microsoft.com/azure/azure-resource-manager/management/overview" 
                }
                "*login.microsoftonline.com*" { 
                    "Test-NetConnection login.microsoftonline.com -Port 443 | Check authentication endpoint access | https://docs.microsoft.com/azure/active-directory/develop/" 
                }
                "*msftcloudes.com*" { 
                    "Test-NetConnection prod.warmpath.msftcloudes.com -Port 443 | Verify AVD diagnostic endpoint | https://docs.microsoft.com/azure/virtual-desktop/safe-url-list" 
                }
                "*AVD Accelerator URL*" {
                    "Verify firewall/proxy allows HTTPS to GitHub, Azure CDN, PowerShell Gallery | Required for session host configuration | https://github.com/Azure/avdaccelerator/blob/main/workload/docs/getting-started-baseline.md"
                }
                "*Private Endpoint Policies*" {
                    "CRITICAL: Disable private endpoint policies on subnets | \$vnet = Get-AzVirtualNetwork -Name '<vnet>'; \$subnet = Get-AzVirtualNetworkSubnetConfig -Name '<subnet>' -VirtualNetwork \$vnet; \$subnet.PrivateEndpointNetworkPolicies = 'Disabled'; Set-AzVirtualNetwork -VirtualNetwork \$vnet | https://docs.microsoft.com/azure/private-link/disable-private-endpoint-network-policy"
                }
                "*Custom DNS*" {
                    "Configure conditional forwarders for *.file.core.windows.net and *.vaultcore.azure.net to 168.63.129.16 | https://learn.microsoft.com/azure/virtual-desktop/prerequisites#networking-requirements"
                }
                "*Private DNS Zone*" {
                    "New-AzPrivateDnsZone -ResourceGroupName <rg> -Name <zone-name>; New-AzPrivateDnsVirtualNetworkLink -ResourceGroupName <rg> -ZoneName <zone> -VirtualNetworkId <vnet-id> | https://docs.microsoft.com/azure/private-link/private-endpoint-dns"
                }
                "*VNet*" { 
                    "New-AzVirtualNetwork -Name <vnet-name> -ResourceGroupName <rg-name> -Location <location> -AddressPrefix <cidr> | https://docs.microsoft.com/azure/virtual-network/quick-create-powershell" 
                }
                default { "https://docs.microsoft.com/azure/virtual-desktop/safe-url-list" }
            }
        }
        
        "RBAC Permissions" {
            switch -Wildcard ($Check) {
                "*Role Assignments*" { 
                    "https://docs.microsoft.com/azure/virtual-desktop/rbac"
                }
                "*Owner*" { 
                    "New-AzRoleAssignment -SignInName <user@domain.com> -RoleDefinitionName 'Owner' -Scope '/subscriptions/<subscription-id>' | https://docs.microsoft.com/azure/role-based-access-control/role-assignments-powershell" 
                }
                "*Contributor*" { 
                    "New-AzRoleAssignment -SignInName <user@domain.com> -RoleDefinitionName 'Contributor' -Scope '/subscriptions/<subscription-id>' | https://docs.microsoft.com/azure/role-based-access-control/role-assignments-powershell" 
                }
                "*Permissions*" { 
                    "New-AzRoleAssignment -SignInName <user@domain.com> -RoleDefinitionName 'Contributor' -Scope '/subscriptions/<subscription-id>' | https://docs.microsoft.com/azure/virtual-desktop/rbac" 
                }
                default { "https://docs.microsoft.com/azure/virtual-desktop/rbac" }
            }
        }
        
        "Resource Providers" {
            switch -Wildcard ($Check) {
                "*Provider*" {
                    $providerName = ($Check -split ':')[1].Trim()
                    "Register-AzResourceProvider -ProviderNamespace $providerName | https://docs.microsoft.com/azure/azure-resource-manager/management/resource-providers-and-types"
                }
                default { "https://docs.microsoft.com/azure/azure-resource-manager/management/resource-providers-and-types" }
            }
        }
        
        "Azure Access" {
            switch -Wildcard ($Check) {
                "*Authentication*" { 
                    "Connect-AzAccount -UseDeviceAuthentication | https://docs.microsoft.com/powershell/azure/authenticate-azureps" 
                }
                "*Subscription*" { 
                    "Set-AzContext -SubscriptionId <subscription-id> | https://docs.microsoft.com/powershell/module/az.accounts/set-azcontext" 
                }
                default { "https://docs.microsoft.com/powershell/azure/get-started-azureps" }
            }
        }
        
        default { 
            # Return recommendation if available, otherwise generic documentation link
            if ($Check -match "Module") { "https://docs.microsoft.com/powershell/azure/install-az-ps" }
            elseif ($Check -match "Network") { "https://docs.microsoft.com/azure/virtual-desktop/safe-url-list" }
            elseif ($Check -match "Permission|Role") { "https://docs.microsoft.com/azure/virtual-desktop/rbac" }
            else { "https://docs.microsoft.com/azure/virtual-desktop/prerequisites" }
        }
    }
    
    return $guidance
}

function Show-ValidationSummary {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor Cyan
    Write-Host " VALIDATION SUMMARY " -ForegroundColor Cyan
    Write-Host ("=" * 100) -ForegroundColor Cyan
    Write-Host ""
    
    $passCount = @($script:Report | Where-Object { $_.Result -eq "Pass" }).Count
    $failCount = @($script:Report | Where-Object { $_.Result -eq "Fail" }).Count
    $warningCount = @($script:Report | Where-Object { $_.Result -eq "Warning" }).Count
    $infoCount = @($script:Report | Where-Object { $_.Result -eq "Info" }).Count
    $totalChecks = $script:Report.Count
    
    Write-Host "Total Checks:  $totalChecks" -ForegroundColor White
    Write-Host "Passed:        $passCount" -ForegroundColor Green
    Write-Host "Failed:        $failCount" -ForegroundColor Red
    Write-Host "Warnings:      $warningCount" -ForegroundColor Yellow
    Write-Host "Information:   $infoCount" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Note: Console output above showed only FAILURES and WARNINGS." -ForegroundColor DarkGray
    Write-Host "      All results (including $passCount passes) are in the full report." -ForegroundColor DarkGray
    Write-Host ""
    
    # Show critical failures with structured format
    if ($failCount -gt 0 -or $warningCount -gt 0) {
        Write-Host ""
        Write-Host ("=" * 100) -ForegroundColor Red
        Write-Host " CRITICAL ISSUES REQUIRING ATTENTION " -ForegroundColor Red
        Write-Host ("=" * 100) -ForegroundColor Red
        Write-Host ""
        
        # Group failures by category
        $failures = $script:Report | Where-Object { $_.Result -eq "Fail" }
        $warnings = $script:Report | Where-Object { $_.Result -eq "Warning" }
        
        # Categorize issues
        $categories = @{}
        
        foreach ($failure in $failures) {
            $category = if ($failure.Check -match "Module") { "PowerShell Modules" }
                       elseif ($failure.Check -match "Permission|Role") { "RBAC Permissions" }
                       elseif ($failure.Check -match "Provider") { "Resource Providers" }
                       elseif ($failure.Check -match "Network|Connectivity") { "Network Configuration" }
                       elseif ($failure.Check -match "Authentication|Subscription") { "Azure Access" }
                       else { "General" }
            
            if (-not $categories.ContainsKey($category)) {
                $categories[$category] = @()
            }
            $categories[$category] += $failure
        }
        
        # Display categorized failures
        foreach ($category in $categories.Keys | Sort-Object) {
            Write-Host "[$category] Category Issues:" -ForegroundColor Red
            foreach ($issue in $categories[$category]) {
                Write-Host "  * $($issue.Check)" -ForegroundColor White
                Write-Host "    Issue: $($issue.Details)" -ForegroundColor Gray
                if ($issue.Recommendation) {
                    Write-Host "    Solution: $($issue.Recommendation)" -ForegroundColor Yellow
                }
                
                # Add enhanced guidance
                $guidance = Get-EnhancedRemediationGuidance -Category $issue.Category -Check $issue.Check -Details $issue.Details
                if ($guidance) {
                    Write-Host "    Guide: $guidance" -ForegroundColor Cyan
                }
                Write-Host ""
            }
        }
        
        Write-Host ("=" * 100) -ForegroundColor White
        Write-Host " OVERALL ASSESSMENT " -ForegroundColor White
        Write-Host ("=" * 100) -ForegroundColor White
        Write-Host ""
        
        if ($failCount -eq 0 -and $warningCount -gt 0) {
            Write-Host "[WARNING] Minor issues detected. Review warnings and recommendations before proceeding." -ForegroundColor Yellow
        } elseif ($failCount -le 2) {
            Write-Host "[ATTENTION] Critical issues detected. Address failures before deployment." -ForegroundColor Red
        } else {
            Write-Host "[BLOCKED] Multiple critical issues. Deployment cannot proceed until resolved." -ForegroundColor Red -BackgroundColor Black
        }
        
        Write-Host ""
        Write-Host "Next Steps:" -ForegroundColor White
        Write-Host "  1. Address the critical issues listed above" -ForegroundColor Gray
        Write-Host "  2. Re-run this validation script" -ForegroundColor Gray
        Write-Host "  3. Proceed with deployment once all issues are resolved" -ForegroundColor Gray
        Write-Host ""
        
        # Quick Action Items Summary
        Write-Host ("=" * 100) -ForegroundColor Yellow
        Write-Host " QUICK ACTION ITEMS SUMMARY " -ForegroundColor Yellow
        Write-Host ("=" * 100) -ForegroundColor Yellow
        Write-Host ""
        Write-Host "TOP PRIORITY ACTIONS:" -ForegroundColor Yellow
        Write-Host ""
        
        $actionPriority = 1
        
        # High priority: Failures
        foreach ($failure in $failures | Select-Object -First 3) {
            Write-Host "[$actionPriority] $(if ($failure.Check -match 'Module') { 'Install missing PowerShell module' } else { 'Fix critical issue' }) [HIGH]" -ForegroundColor Red
            if ($failure.Recommendation) {
                Write-Host "    Command: $($failure.Recommendation)" -ForegroundColor Gray
            } else {
                Write-Host "    Command: See detailed guidance above" -ForegroundColor Gray
            }
            Write-Host "    Issue: $($failure.Details)" -ForegroundColor Gray
            Write-Host ""
            $actionPriority++
        }
        
        # Medium priority: Warnings
        foreach ($warning in $warnings | Select-Object -First 3) {
            Write-Host "[$actionPriority] Address warning [MEDIUM]" -ForegroundColor Yellow
            Write-Host "    Command: $(if ($warning.Recommendation) { $warning.Recommendation } else { 'See detailed guidance above' })" -ForegroundColor Gray
            Write-Host "    Issue: $($warning.Check): $($warning.Details)" -ForegroundColor Gray
            Write-Host ""
            $actionPriority++
        }
        
        
    } else {
        # All checks passed
        Write-Host ""
        Write-Host ("=" * 100) -ForegroundColor Green
        Write-Host " DEPLOYMENT READINESS: PASSED " -ForegroundColor Green
        Write-Host ("=" * 100) -ForegroundColor Green
        Write-Host ""
        Write-Host "All prerequisite checks passed successfully!" -ForegroundColor Green
        Write-Host "Your environment is ready for AVD Accelerator deployment." -ForegroundColor Green
        Write-Host ""
        Write-Host ("=" * 100) -ForegroundColor Green
        Write-Host ""
    }
}

#endregion

#region Main Execution

try {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor Cyan
    Write-Host " AVD ACCELERATOR - PREREQUISITES CONFIRMATION (SIMPLIFIED) " -ForegroundColor Cyan
    Write-Host ("=" * 100) -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Date: $(Get-Date)" -ForegroundColor White
    Write-Host "Mode: $(if ($NonInteractive) { 'Non-Interactive' } else { 'Interactive' })" -ForegroundColor White
    Write-Host ""
    Write-Host "NOTE: Simplified mode shows ONLY errors and warnings in console." -ForegroundColor Yellow
    Write-Host "      All validation results (including passes) are saved in the full report." -ForegroundColor Yellow
    Write-Host ""
    
    # Step 1: Validate PowerShell Modules
    Test-PowerShellModules
    
    # Step 2: Azure Authentication
    $authSuccess = Connect-AzureInteractive
    
    if (-not $authSuccess) {
        Write-Host ""
        Write-Host "Authentication failed. Cannot proceed with Azure validations." -ForegroundColor Red
        Write-Host "Please resolve authentication issues and re-run the script." -ForegroundColor Yellow
        Write-Host ""
        Export-ValidationReport
        exit 1
    }
    
    # Step 3: Subscription Selection
    $subSuccess = Select-AzureSubscription
    
    if (-not $subSuccess) {
        Write-Host ""
        Write-Host "Subscription selection failed. Cannot proceed." -ForegroundColor Red
        Write-Host ""
        Export-ValidationReport
        exit 1
    }
    
    # Step 4: User Permissions
    Test-UserPermissions
    
    # Step 5: Resource Providers
    Test-ResourceProviders
    
    # Step 6: Encryption at Host Feature (Zero Trust)
    Test-EncryptionAtHost
    
    # Step 7: AVD Enterprise Application
    Test-AVDEnterpriseApplication
    
    # Step 8: Domain Join Requirements Guidance
    Show-DomainJoinGuidance
    
    # Step 9: Network Connectivity
    Test-NetworkConnectivity
    
    # Step 10: Network Topology
    Test-NetworkTopology
    
    # Step 11: Private Endpoint Policies (CRITICAL)
    Test-PrivateEndpointPolicies
    
    # Step 12: Custom DNS Configuration
    Test-CustomDNSConfiguration
    
    # Step 13: Private DNS Zones
    Test-PrivateDNSZones
    
    # Step 14: Export Report
    $reportPath = Export-ValidationReport
    
    # Step 15: Show Summary
    Show-ValidationSummary
    
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor Green
    Write-Host " VALIDATION COMPLETE " -ForegroundColor Green
    Write-Host ("=" * 100) -ForegroundColor Green
    Write-Host ""
    Write-Host "Simplified Mode: Console showed only errors and warnings." -ForegroundColor Yellow
    Write-Host "Full Report (all results): $reportPath" -ForegroundColor Cyan
    Write-Host ""
    
} catch {
    Write-Host ""
    Write-Host ("=" * 100) -ForegroundColor Red
    Write-Host " CRITICAL ERROR " -ForegroundColor Red
    Write-Host ("=" * 100) -ForegroundColor Red
    Write-Host ""
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Stack Trace:" -ForegroundColor Yellow
    Write-Host $_.ScriptStackTrace -ForegroundColor Gray
    Write-Host ""
    
    Add-ReportEntry -Check "Script Execution" -Result "Fail" -Details "Critical error: $($_.Exception.Message)" -Mandatory "Yes" -Category "General"
    
    try {
        Export-ValidationReport
    } catch {
        Write-Host "Failed to export error report: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    exit 1
} finally {
    # Cleanup: Disconnect from Azure
    try {
        if (Get-AzContext) {
            Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null
            Write-Host "Disconnected from Azure" -ForegroundColor Gray
            Write-Host ""
        }
    } catch {
        # Ignore disconnect errors
    }
}

#endregion
