# AVD Accelerator – Prerequisites (Full & Simplified Validation Scripts)
### Comprehensive and Streamlined Validation Tools for Azure Virtual Desktop Accelerator Deployments

This repository contains two PowerShell scripts designed to validate all prerequisites required for a successful **Azure Virtual Desktop (AVD) Accelerator** deployment:

- **AVD_02** – Full and comprehensive deep-dive validation  
- **AVD_03** – Simplified console output focusing only on warnings and errors  

Both scripts generate customer-friendly reports and assist engineers, architects, and customers in confirming Azure environment readiness.

---

# 1. AVD_02 – Comprehensive Prerequisites Confirmation  
### Deep-Dive Environment Validation for Pre-Deployment & Post-Deployment Readiness

This PowerShell script performs a **full-spectrum, highly detailed validation** of Azure infrastructure, networking, security, storage, and AVD-specific prerequisites.  
It is ideal for enterprise deployment planning, auditing, troubleshooting, and automated readiness confirmation.

---

## Purpose
This script validates the **complete set of requirements** needed for a successful AVD Accelerator deployment.  
It provides detailed visibility across:

- Azure configuration  
- Permissions and RBAC  
- Networking and routing architecture  
- Image management  
- Security and compliance  

---

## Validations Performed

### **1. PowerShell & Azure Environment**
- Detects required PowerShell module installation & versions  
- Confirms authentication to Azure (supports multiple login methods)  
- Validates subscription state and user access  
- Checks appropriate RBAC permissions  

### **2. Azure Resource Providers**
- Verifies all required provider registrations  
- Validates AVD, networking, compute, storage, and Image Builder providers  

### **3. Network Topology & Connectivity**
- Tests connectivity to Azure/AVD endpoints  
- Detects **hub-and-spoke architecture** via UDR analysis  
- Validates virtual network and subnet configurations  
- Identifies routing through NVAs or firewalls  
- Confirms private endpoint network policies for storage and Key Vault  

### **4. Storage & FSLogix Requirements**
- Validates storage account configuration for FSLogix  
- Confirms Azure Files support  
- Checks NTFS and regional requirements  

### **5. Image Management**
- Validates Azure Compute Gallery configuration  
- Ensures Image Builder functionality is enabled  
- Confirms required feature registrations  

### **6. Security & Compliance**
- Key Vault validations  
- Azure Security Center checks  
- Encryption and compliance readiness  

### **7. Result Reporting**
Generates an Excel workbook containing:  
- **Summary sheet**  
- **Detailed results** (color-coded: green/yellow/red/blue)  
- **Top 5 remediation actions** with exact commands  

---

## Output
- Color-coded Excel or CSV report  
- Summary of all validation checks  
- Top 5 prioritized remediation actions  
- Overall readiness evaluation  

---

# 2. AVD_03 – Prerequisites Validation (Simplified Mode)  
### Essential Validation with Console Output Showing Only Warnings & Errors

This script performs the same comprehensive validations as **AVD_02**, but **only displays warnings and errors** in the console.  
All pass/ informational results are stored in the generated report, keeping the console output clean and action-focused.

---

## Purpose
This script ensures that all essential prerequisites are met for AVD Accelerator deployment while maintaining a compact console output.  
It is ideal for:

- Automated pipelines  
- Troubleshooting  
- Fast operational checks  
- Customer-facing assessments  

---

## Validations Performed

### **1. PowerShell & Azure Environment**
- Verifies required PowerShell modules  
- Confirms Azure authentication  
- Validates subscription state  
- Confirms Contributor/Owner RBAC permissions  

### **2. Resource Providers**
- Validates required AVD resource providers  
- Confirms **EncryptionAtHost** provider registration  

### **3. Network & Connectivity**
- Checks connectivity to Azure endpoints  
- Validates access to AVD Accelerator URLs (GitHub, PowerShell Gallery)  
- Confirms VNet existence  
- Performs hub-and-spoke detection via UDR analysis  
- Ensures private endpoint network policies are disabled (**critical blocker**)  

### **4. DNS & Private Endpoints**
- Validates DNS server configuration  
- Confirms Azure conditional forwarders  
- Validates required Private DNS Zones:
  - Azure Files  
  - Key Vault  

### **5. AVD Enterprise Applications**
Retrieves Object IDs for:
- Start VM on Connect  
- Scaling Plans  

### **6. Domain Join Requirements (Informational)**
- Provides guidance on account permissions and OU structure  

---

## Critical Deployment Blockers
- Private endpoint network policies enabled  
- Missing connectivity to GitHub/PowerShell Gallery  
- Missing conditional forwarders in custom DNS  
- Missing required resource provider registrations  
- Insufficient RBAC permissions (Contributor/Owner required)  

---

## Output

### **Console**
-  Errors displayed in red  
-  Warnings displayed in yellow  
-  Pass/Info results **suppressed**  

### **Report**
- Excel or CSV with full detail and color coding  
- Complete audit trail  

---

# Version & Requirements

### **AVD_02 – Comprehensive**
- **Version:** 2.0  
- **PowerShell:** 5.1+  
- **Requirements:** Az modules installed, Subscription with **Reader or above**  

### **AVD_03 – Simplified**
- **Version:** 3.1  
- **PowerShell:** 5.1+  
- **Requirements:** Internet connectivity, Subscription with **Contributor or Owner**  

---

