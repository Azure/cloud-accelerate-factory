#!/usr/bin/pwsh
CLS
Write-Host  " Checking ressources..."
function Exit-Code {
    Write-Host "-Ending Execution"
    exit
}

function Create-Folder([string]$path) {
    if (Test-Path $path) {
        Write-Host "-Folder '$path' exists..."
    } else {
        New-Item -ItemType Directory -Path $path | Out-Null
        Write-Host "-$path folder created..."
    }
}

# Resolve script root reliably
$Folder = $PSScriptRoot
if (-not $Folder) { $Folder = Split-Path -Parent $MyInvocation.MyCommand.Path }

# --- Detect sqlplus (Oracle SQL*Plus) ---


function Get-SqlPlusPath {
    <#
    .SYNOPSIS
        Vérifie si sqlplus est installé et retourne son chemin complet.
        Fonction compatible Windows, Linux et macOS.
    .OUTPUTS
        [string] Chemin complet vers sqlplus, ou $null si non trouvé
    #>

    $sqlplusPath = $null

    if ($IsWindows) {
        # Vérifie via Get-Command
        $cmd = Get-Command sqlplus.exe -ErrorAction SilentlyContinue
        if ($cmd) { $sqlplusPath = $cmd.Source }

        # Vérifie via where.exe si non trouvé
        if (-not $sqlplusPath) {
            try {
                $whereResult = & where.exe sqlplus 2>$null
                if ($whereResult) { $sqlplusPath = $whereResult[0] }
            } catch { }
        }
    } else {
        # Linux/macOS
        try {
            $whichResult = & which sqlplus 2>$null
            if ($whichResult) { $sqlplusPath = $whichResult.Trim() }
        } catch { }

        # Vérifie chemins classiques si non trouvé
        if (-not $sqlplusPath) {
            $commonPaths = @("/usr/bin/sqlplus","/usr/local/bin/sqlplus","/opt/oracle/product/21c/dbhome_1/bin/sqlplus")
            foreach ($p in $commonPaths) {
                if (Test-Path $p) { $sqlplusPath = $p; break }
            }
        }
    }

    return $sqlplusPath
}

Write-Host "                                                                                       " -BackgroundColor DarkMagenta
Write-Host "       Welcome to Factory - Oracle_Info_Gathering_Automation                                " -ForegroundColor White -BackgroundColor DarkMagenta
Write-Host "                  (OSS DB Migration factory)                                            " -BackgroundColor DarkMagenta
Write-Host "                                                                                       " -BackgroundColor DarkMagenta
Write-Host ""

$sqlplusPath = Get-SqlPlusPath
if ($sqlplusPath) {
Write-Host "Oracle client (sqlplus) found at: $sqlplusPath . Continuing..." -ForegroundColor Green
} else {
            Write-Host "Oracle client (sqlplus) not found. Please install or add to PATH, then re-run." -BackgroundColor Red

        Exit-Code
}


Write-Host ""




Write-Host "Please select the assessment operation to perform" -ForegroundColor Green
Write-Host "===================================================================="
Write-Host "1. Perform Oracle server Information gathering"
Write-Host "2. Exit"

$validInputs = "1","2"
do {
    $inputresponse = Read-Host -Prompt "Enter value"
    if (-not $validInputs.Contains($inputresponse)) { Write-Host "Please select the choice between 1 - 2" }
} until ($validInputs.Contains($inputresponse))

if ($inputresponse -eq "2") { Exit-Code }


# =========================================================
# FONCTIONS UTILITAIRES
# =========================================================
function Exit-Fatal($Message) {
    Write-Host "ERROR - $Message" -ForegroundColor Red
    exit 1
}

function Ask-File($PromptMessage, $DefaultPath) {
    do {
        Write-Host ""
        $inputPath = Read-Host "$PromptMessage (ENTER pour utiliser défaut: $DefaultPath, 0 pour exit)"
        if ($inputPath -eq "0") { exit 0 }
        if ([string]::IsNullOrWhiteSpace($inputPath)) { $inputPath = $DefaultPath }
        if (-not (Test-Path $inputPath)) {
            Write-Host "File not found. Try again." -ForegroundColor Yellow
            continue
        }
        return $inputPath
    } until ($false)
}

function Ask-Folder($PromptMessage, $DefaultPath) {
    do {
        Write-Host ""
        $folder = Read-Host "$PromptMessage (ENTER pour utiliser défaut: $DefaultPath, 0 pour exit)"
        if ($folder -eq "0") { exit 0 }
        if ([string]::IsNullOrWhiteSpace($folder)) { $folder = $DefaultPath }
        try {
            if (-not (Test-Path $folder)) {
                New-Item -ItemType Directory -Path $folder -ErrorAction Stop | Out-Null
                Write-Host "Directory created: $folder" -ForegroundColor Green
            }
            return $folder
        }
        catch {
            Write-Host "Unable to create/access directory: $folder" -ForegroundColor Red
            Write-Host $_.Exception.Message -ForegroundColor Red
        }
    } until ($false)
}

function Test-SqlPlus {
    if (Get-Command sqlplus -ErrorAction SilentlyContinue) { return $true }
    try { if ($IsWindows) { if (& where.exe sqlplus 2>$null) { return $true } } else { if (& which sqlplus 2>$null) { return $true } } } catch {}
    return $false
}

function Write-ExecLog {
    param($LogFile, $Message, $Level="INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$ts [$Level] $Message" | Out-File -Append -Encoding utf8 -FilePath $LogFile
}

function New-OracleWrapperScript {
    param($SqlFile,$ResultFile)

    $tmp = [System.IO.Path]::GetTempFileName() + ".sql"

@"
set echo off
set feedback off
set heading on
set pagesize 500
set linesize 500
set trimout on
set trimspool on
spool $ResultFile
@$SqlFile
spool off
exit
"@ | Out-File -Encoding utf8 $tmp

    return $tmp
}

function Invoke-Oracle {
    param(
        $EZConnect,
        $SqlFile,
        $ResultFile,
        $LogFile,
        $TimeoutSec = 10
    )

    Write-ExecLog $LogFile "Starting execution on $EZConnect"
    $wrapper = New-OracleWrapperScript $SqlFile $ResultFile

    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "sqlplus"
        $psi.Arguments = "-S $EZConnect @$wrapper"
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null

        if (-not $proc.WaitForExit($TimeoutSec * 1000)) {
            $proc.Kill()
            Remove-Item $wrapper -ErrorAction SilentlyContinue
            Write-ExecLog $LogFile "execution failed after  $TimeoutSec seconds" "ERROR"
            return @{ Code=1; Output="ERROR - execution failed after  $TimeoutSec seconds" }
        }

        $output = $proc.StandardOutput.ReadToEnd() + $proc.StandardError.ReadToEnd()
        $code = $proc.ExitCode
    } catch {
        $output = $_.Exception.Message
        $code = 1
    }

    $output | Out-File -Append -Encoding utf8 -FilePath $LogFile
    Remove-Item $wrapper -ErrorAction SilentlyContinue
    return @{ Code=$code; Output=$output }
}

# =========================================================
# PRECHECK SQLPLUS
# =========================================================
if (-not (Test-SqlPlus)) { Exit-Fatal "sqlplus not found in PATH" }

# =========================================================
# DEFAULT PATHS
# =========================================================
$DefaultSQL    = "/home/oracle/infogather/ora_db_gather.sql"
$DefaultLogDir = "/home/oracle/infogather/LOG"
$DefaultResDir = "/home/oracle/infogather/RESULT"
$DefaultCSV    = "/home/oracle/infogather/Factory_Oracle_Server_Input_file.csv"

# =========================================================
# ASK FILES AND FOLDERS
# =========================================================
$SqlScript = Ask-File "Enter full path of SQL file" $DefaultSQL
$LogDir    = Ask-Folder "Enter full LOG directory path" $DefaultLogDir
$OutputDir = Ask-Folder "Enter full RESULT directory path" $DefaultResDir
$CsvFile   = Ask-File "Enter full path of CSV file" $DefaultCSV

# =========================================================
# LOAD CSV AND FILTER APPROVED
# =========================================================
try {
    $AllRows = Import-Csv $CsvFile

    $requiredCols = @("Host_Name","UserName","Service_Name","Approval_Status")
    $missingCols = $requiredCols | Where-Object { -not ($AllRows | Get-Member -Name $_) }
    if ($missingCols.Count -gt 0) { Exit-Fatal "CSV missing required columns: $($missingCols -join ', ')" }

    $Rows = $AllRows | Where-Object {
        $_.Approval_Status -and ($_.Approval_Status.Trim().ToUpper() -eq "YES") -and $_.Service_Name
    }
} catch {
    Exit-Fatal "Error reading CSV: $($_.Exception.Message)"
}

if ($Rows.Count -eq 0) { Exit-Fatal "No approved entries found in CSV" }

# =========================================================
# MAIN LOOP
# =========================================================
$Summary = @()
$DateStamp = Get-Date -Format "yyyyMMdd_HHmmss"

foreach ($row in $Rows) {
    $HostName = $row.Host_Name.Trim()
    $Port     = if ($row.Port) { $row.Port.Trim() } else { "1521" }
    $Service  = $row.Service_Name.Trim()
    $User     = $row.UserName.Trim()
    $Pass     = $row.UserPassword.Trim()








Write-Host ""
Write-Host "-----------------------------------------------------"
Write-Host "Looping the line $HostName $Service $Port    $User  $Pass  ...." -ForegroundColor Yellow
Write-Host ""







$HostName = $row.Host_Name
$Port     = if ($row.Port) { $row.Port.Trim() } else { "1521" }
$Service  = $row.Service_Name
$User     = $row.UserName
$Pass     = $row.UserPassword

# ---------------------------------------------------
# Mandatory fields validation
# ---------------------------------------------------
$missingFields = @()

if ([string]::IsNullOrWhiteSpace($HostName)) { $missingFields += "Host_Name" }
if ([string]::IsNullOrWhiteSpace($User))     { $missingFields += "UserName" }
if ([string]::IsNullOrWhiteSpace($Service))  { $missingFields += "Service_Name" }

if ($missingFields.Count -gt 0) {

    Write-Host "`nERROR: Missing mandatory field(s) in CSV file." -ForegroundColor Red
    Write-Host "The following field(s) are required:" -ForegroundColor Red
    Write-Host " - $($missingFields -join ', ')" -ForegroundColor Red

    Write-Host "`nPlease do one of the following before continuing:" -ForegroundColor Yellow
    Write-Host "1. Fill in the missing value(s) in the CSV file" -ForegroundColor Yellow
    Write-Host "2. Remove the invalid line from the CSV file" -ForegroundColor Yellow
    Write-Host "`nThen re-run the script." -ForegroundColor Yellow

    Exit 1
}

# Trim values after validation
$HostName = $HostName.Trim()
$Service  = $Service.Trim()
$User     = $User.Trim()
$Pass     = if ($Pass) { $Pass.Trim() } else { $null }









if (-not $Pass) {
    do {
        Write-Host ""
        $securePass = Read-Host -Prompt "Enter password for $User@$HostName/$Service (0 to exit)" -AsSecureString

        # Conversion correcte SecureString -> String
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
        $PassPlain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

        # Quitter si 0
        if ($PassPlain -eq "0") {
            Write-Host "Exiting..."
            exit 0
        }

        if ([string]::IsNullOrWhiteSpace($PassPlain)) {
            Write-Host "Password cannot be empty. Please try again." -ForegroundColor Yellow
            $Pass = $null
        } else {
            $Pass = $PassPlain
        }

    } until ($Pass)
}



    $EZConnect = "$User/$Pass@$HostName`:$Port/$Service"

Write-Host ""
Write-Host "-----------------------------------------------"

Write-Host "Testing connection on the database for $HostName/$Service ..."  -ForegroundColor  Yellow
Write-Host "EZConnect $EZConnect"


function Test-OracleConnection {
    param(
        [string]$SqlPlusPath,
        [string]$EZConnect,
        [int]$TimeoutSec = 20
    )

    $TestSQL = "whenever sqlerror exit 1;`nselect 'OK' from dual;`nexit;"

    try {
        if ($IsWindows) {
            $output = cmd /c "echo $TestSQL | `"$SqlPlusPath`" -S $EZConnect" 2>&1
        } else {
            $output = echo $TestSQL | & $SqlPlusPath -S $EZConnect 2>&1
        }

        $lines = $output -split "`n" | ForEach-Object { $_.Trim() }

        if ($lines -match "ORA-|TNS-|SP2-") {
            Write-Host "ERROR - Connection failed" -ForegroundColor Red
            $lines | Where-Object { $_ -match "ORA-|TNS-|SP2-" } |
                Select-Object -First 1 |
                ForEach-Object { Write-Host $_ -ForegroundColor Red }
            return $false
        }

        Write-Host "SUCCESS - Connection OK" -ForegroundColor Green
        Write-Host ""
        Write-Host "Executing the Sql Script...." -ForegroundColor Green

        return $true
    }
    catch {
        Write-Host "ERROR - $_" -ForegroundColor Red
        return $false
    }
}



$connectionOK = Test-OracleConnection `
    -SqlPlusPath $sqlplusPath `
    -EZConnect $EZConnect `
    -TimeoutSec 10

if (-not $connectionOK) {
    Write-Host "Skipping SQL execution for $HostName/$Service due to connection failure." -ForegroundColor Yellow

    $Summary += [pscustomobject]@{
        Host       = $HostName
        Service    = $Service
        Status     = "CONNECTION_FAILED"
        LogFile    = "N/A"
        ResultFile = "N/A"
    }

    continue   # ← passe à la ligne CSV suivante
}

$safe = ($HostName + "_" + $Service + "_" + $DateStamp) -replace "[^\w]", "_"

$ResultFile = Join-Path $OutputDir "result_${safe}.txt"
$LogFile    = Join-Path $LogDir    "exec_${safe}.log"

# Exécuter le script SQL
$res = Invoke-Oracle -EZConnect $EZConnect -SqlFile $SqlScript -ResultFile $ResultFile -LogFile $LogFile -TimeoutSec 10

# Capturer uniquement la première ligne d'erreur ORA-, TNS- ou SP2-
$oraErr = ($res.Output -split "`n" | ForEach-Object { $_.Trim() } |
           Where-Object { $_ -match "ORA-\d+|TNS-|SP2-" } |
           Select-Object -First 1)

if ($res.Code -eq 0 -and -not $oraErr) {
    Write-Host "$HostName / $Service : SUCCESS" -ForegroundColor Green
    Write-Host "   Log file   : $LogFile"
    Write-Host "   Result file: $ResultFile"
    Write-ExecLog $LogFile "SUCCESS"
    $Summary += [pscustomobject]@{ Host=$HostName; Service=$Service; Status="SUCCESS"; LogFile=$LogFile; ResultFile=$ResultFile }
} else {
    $shortErr = if ($oraErr) { $oraErr } else { "Connection Error" }
    Write-Host "$HostName / $Service : ERROR - $shortErr" -ForegroundColor Red
    Write-Host "   Log file   : $LogFile"
    Write-Host "   Result file: $ResultFile"
    Write-ExecLog $LogFile $shortErr "ERROR"
    $Summary += [pscustomobject]@{ Host=$HostName; Service=$Service; Status="FAILED"; LogFile=$LogFile; ResultFile=$ResultFile }
}

}



# =========================================================
# FINAL SUMMARY
# =========================================================
$SummaryFile = Join-Path $LogDir ("summary_$DateStamp.txt")

Write-Host ""
Write-Host "================ EXECUTION SUMMARY ================" -ForegroundColor Cyan
$Summary | Format-Table -AutoSize

# Export summary complet avec chemins
$Summary | ForEach-Object {
    "Host       : $($_.Host)"
    "Service    : $($_.Service)"
    "Status     : $($_.Status)"
    "Log File   : $($_.LogFile)"
    "Result File: $($_.ResultFile)"
    "----------------------------------------"
} | Out-File -FilePath $SummaryFile -Encoding utf8

Write-Host ""
Write-Host "Full summary saved to: $SummaryFile" -ForegroundColor Cyan

# Exit avec code 1 si au moins une erreur
if ($Summary.Status -contains "FAILED") { exit 1 }
exit 0
