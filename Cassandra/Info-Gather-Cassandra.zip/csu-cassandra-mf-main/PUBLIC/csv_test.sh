#!/bin/bash

CSV_FILE="/mohanv/servers_list.csv"

# SCRIPT_TO_EXECUTE="/mohanv/infogatherfile.sh"
COMMANDS="hostname; uptime; df -h"

cat $CSV_FILE | while read LINE; do
HOST=`echo $LINE | awk {'print $1'}`
USER=`echo $LINE | awk {'print $2'}`
PASSWD=`echo $LINE | awk {'print $3'}`

sshpass -p $PASSWD ssh -no StrictHostKeyChecking=no $USER@$HOST $COMMANDS > "/mohanv/${HOST}_output.txt" 2>&1
# sshpass -p "$PASSWD" ssh -no StrictHostKeyChecking=no "$USER@$HOST" sh < "$SCRIPT_TO_EXECUTE"> "/mohanv/${HOST}_output.txt" 2>&1

if [[ $? -eq 0 ]]; then
   echo "Output from $server_ip saved to /mohanv/${HOST}_output.txt"
  else 
   echo "Failed to execute script on $HOST."
   fi

done
