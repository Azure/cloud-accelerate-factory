#!/bin/bash

CSV_FILE="/mohanv/executed/servers_list.csv"
SCRIPT_TO_EXECUTE="/mohanv/executed/infogatherfile.sh"

cat "$CSV_FILE" | while read LINE; do
    HOST=$(echo $LINE | awk '{print $1}')
    USER=$(echo $LINE | awk '{print $2}')
    PASSWD=$(echo $LINE | awk '{print $3}')

    # Execute the remote script using sshpass with sudo
    sshpass -p "$PASSWD" ssh -to StrictHostKeyChecking=no $USER@$HOST "bash -s" < "$SCRIPT_TO_EXECUTE" > "/tmp/${HOST}_output.txt" 2>&1

    # Check if the command executed successfully
    if [[ $? -eq 0 ]]; then
        echo "Output from $HOST saved to /tmp/${HOST}_output.txt"
    else
        echo "Failed to execute script on $HOST."
    fi
done < "$CSV_FILE"


