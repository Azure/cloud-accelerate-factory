#!/bin/bash

CSV_FILE="/xxxxxxxxxxxx/Factory-Cassandra-input_File.csv"
SQL_FILE="/xxxxxxxxxxxx/Factory-Cassandra-dbgather.sql"
OUTPUT_DIR="/xxxxxxxxxxxx/PUBLIC"

# Ensure the CSV file exists
if [ ! -f "$CSV_FILE" ]; then
    echo "CSV file not found: $CSV_FILE"
    exit 1
fi

# Skip header and read each line from the CSV file
tail -n +2 "$CSV_FILE" | while IFS=',' read -r HOST DB_USER DB_PASSWD; do
    # Skip empty lines or lines with missing values
    if [ -z "$HOST" ] || [ -z "$DB_USER" ] || [ -z "$DB_PASSWD" ]; then
        continue
    fi

    # Create a unique output file for each host
    OUTPUT_FILE="${OUTPUT_DIR}/${HOST}__output.txt"
    echo "Logging to $OUTPUT_FILE..."

    # Execute the CQL script using cqlsh and capture output
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Running CQL script on $HOST" > "$OUTPUT_FILE"
    cqlsh "$HOST" -u "$DB_USER" -p "$DB_PASSWD" -f "$SQL_FILE" >> "$OUTPUT_FILE" 2>&1

    # Check the exit status of the cqlsh command
    if [ $? -ne 0 ]; then
        echo "Failed to execute CQL script on $HOST." >> "$OUTPUT_FILE"
        continue
    fi

    echo "########## Number of nodes in cluster Info Begins ##########" >> "$OUTPUT_FILE"
    nodetool status >> "$OUTPUT_FILE" 2>&1
    echo "########## Number of nodes in cluster Info Ends ###########" >> "$OUTPUT_FILE"

    echo "########## Ring information of the cluster Begins ##########" >> "$OUTPUT_FILE"
    nodetool ring >> "$OUTPUT_FILE" 2>&1
    echo "########## Ring information of the cluster Ends ##########" >> "$OUTPUT_FILE"

    echo "########## Table information Begins ##########" >> "$OUTPUT_FILE"
    nodetool tablestats | grep -E 'Keyspace|Table:|Number of partitions|Space used \(total\)' >> "$OUTPUT_FILE" 2>&1
    echo "########## Table information Ends ##########" >> "$OUTPUT_FILE"

    # Log the status of the operation
    if [ $? -eq 0 ]; then
        echo "Output from $HOST saved to $OUTPUT_FILE"
    else
        echo "An error occurred while gathering info from $HOST" >> "$OUTPUT_FILE"
    fi

done
