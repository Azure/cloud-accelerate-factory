# Usage: Info_gather

# filepath="/etc/dse/dse.yaml"
cassandrapath=""
password=""
hostname=`hostname -s`
logfile=""
startTime=`date '+%m/%d/%y %H:%M:%S'`

 exec> $logfile 2>&1

echo "##########Number of nodes and DCs in cluster Info Begins ##########"
nodetool status
echo "##########Number of nodes and DCs in cluster Info Ends###########"

echo "##########Table information Begins###########"
nodetool tablestats | grep -E 'Keyspace|Table:|Number of partitions|Space used \(total\)'
echo "##########Table information Ends###########"

echo "##########Node-to-node encryption Information begins##########"
cat "$cassandrapath" |grep 'server_encryption_options' --after-context=6
cat "$cassandrapath" |grep 'client_encryption_options' --after-context=6
echo "##########Node-to-node encryption Information Ends##########"

echo "##########Snitch Details Information Begins##########"
cat "$cassandrapath" | grep "endpoint_snitch"
cat /etc/cassandra/cassandra-rackdc.properties|grep 'These properties are used with' --after-context=6
# cat /etc/cassandra/cassandra-topology.properties
echo "##########Snitch Details Information Ends##########"

# echo "##########Auditing Information Begins##########"
# cat "$filepath" | grep "audit_logging_options" --after-context=3 ## In dsc only

# echo "##########Auditing Information Ends##########"

echo "##########Ring information of a cluster Begins##########"
nodetool ring

echo "##########Ring information of a cluster Begins##########"

echo "##########Memory & CPU  Information Begins##########"
free -h
lscpu |grep 'CPU(s):'
echo "##########Memory & CPU Information Ends##########"

# export CQLSH_PYTHON=/usr/local/bin/python3.8

echo "##########Cassandra/DSE version Information##########"
# dse -v
cqlsh -u cassandra -p $password  -e "Show version;"

echo "##########Replication factor details Information Begins##########"
cqlsh -u cassandra -p $password  -e "select keyspace_name, replication from system_schema.keyspaces;"
echo "##########Replication factor details Information Ends##########"

echo "##########Consistency level information Begins##########"
cqlsh -u cassandra -p $password  -e "CONSISTENCY;"
echo "##########Consistency level information Ends##########"

echo "##########TTL(time_to_live) information Begins##########"
cqlsh -u cassandra -p $password  -e "select keyspace_name, table_name, default_time_to_live from system_schema.tables;"
echo "##########TTL(time_to_live) information Ends##########"

echo "##########Customised role information Begins##########"
cqlsh -u cassandra -p $password  -e "select * from system_auth.roles;"
echo "##########Customised role information Ends##########"

echo "##########No of keyspaces Information Begins##########"
cqlsh -u cassandra -p $password  -e "select keyspace_name from system_schema.keyspaces;"
echo "##########No of keyspaces Information Ends##########"

echo "##########Materialised Views information Begins##########"
cqlsh -u cassandra -p $password  -e "select * from system_schema.views;"
echo "##########Materialised Views information Ends##########"

echo "##########Compaction history Begins##########"
cqlsh -u cassandra -p $password  -e "select * from system.compaction_history;"
echo "##########Compaction history Ends##########"

echo "##########Indexex information Begins##########"
# cqlsh -u cassandra -p $password  -e "select keyspace_name, table_name, index_name, column_name, sstable_count from system_views.indexes;"
cqlsh -u cassandra -p $password  -e "select * from system_schema.indexes;"
echo "##########Indexex information Ends##########"

endTime=`date '+%m/%d/%y %H:%M:%S'`

echo "##########Started at: $startTime and Completed at: $endTime##########"

