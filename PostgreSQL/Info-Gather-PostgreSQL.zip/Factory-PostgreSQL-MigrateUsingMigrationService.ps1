﻿#---------------------------------------------------------------------------------------------------------------------------*
#  Purpose        : Script to migrate larger numbers of databases using Migration service.
#  Schedule       : Ad-Hoc / On-Demand
#  Date           : 02-Feb-2025
#  Author         : Rackimuthu Kandaswamy, Madan Agrawal
#  Version        : 1.1
#   
#  INPUTS         : Server List and other parameters in CSV file; SSL_Modes = allow, disable, prefer, require, verify-ca, verify-full
#  VARIABLE       : NONE
#  PARENT         : NONE
#  CHILD          : NONE
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#
#  IMPORTANT NOTE : The script has to be run on Non-Mission-Critical systems ONLY and not on any production server...
#
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
# Usage:
# Powershell.exe -File .\Factory-PostgreSQL-MigrateUsingMigrationService.ps1
# https://learn.microsoft.com/en-us/azure/postgresql/migrate/migration-service/how-to-setup-azure-cli-commands-postgresql
# sourceType	Required parameter. Values can be - onpremises, AWS_RDS, AWS_AURORA, GCP_CloudSQL, AzureVM, PostgreSQLSingleServer




  function exitCode{
    Write-Host "-Ending Execution"
    Stop-Transcript
    exit
}

function createFolder([string]$newFolder) {
    if(Test-Path $newFolder)
    {
        Write-Host "-Folder'$newFolder' Exist..."
    }
    else
    {
        New-Item $newFolder -ItemType Directory
        Write-Host "-$newFolder folder created..."
    }
}

if ($psISE)
{
    $Folder = Split-Path -Path $psISE.CurrentFile.FullPath 
}
else
{
    $Folder=$PSScriptRoot
}


$postgrespath = where.exe psql
$Triggerpsql_File_Path=$Folder+"\Trigger_psql.bat"
$date = Get-Date -Format "yy-dd-MM-hh-mm"
$DbGather_Path=$Folder+"\PostgreSQL_Templates\pg_db_gather_db.sql"
$DbGather_Server_Path=$Folder+"\PostgreSQL_Templates\pg_db_gather_server.sql"
$DetailedInfo_Path=$Folder+"\PostgreSQL_Templates\pg_db_maintenance.sql"
$DbList_path=$Folder+"\PostgreSQL_Templates\DB_List.sql"



#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------


Clear-Host
Get-Job | Where-Object { $_.State -eq 'Completed' } | Remove-Job
write-host "                                                                                       " -BackgroundColor DarkMagenta
Write-Host "       Welcome to Factory - Migrate PostgreSQL DBs using Migration service             " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                     (OSS DB Migration factory)                                        " -BackgroundColor DarkMagenta
write-host "                                                                                       " -BackgroundColor DarkMagenta
Write-Host " "

if ($postgrespath -like "*\psql*") {
	Write-Host "PostgreSQL exists. Continuing execution..." -ForegroundColor Green
}
else {
	Write-Host "PostgreSQL is not installed or its path is not in the environment variables. Please install PostgreSQL, add its path to the environment variables, and rerun the script." -BackgroundColor Red
	break
}

Write-Host "Please select the assessment operation to perform" -ForegroundColor Green
Write-Host "===================================================================="
Write-Host "0. Update and store password in a protected form"
Write-Host "1. Perform PostgreSQL server Migration using Migration Service"
Write-Host "2. Exit"

$validInputs = "1", "2", "0"
do {
    $inputresponse = Read-Host -Prompt "Enter value"
    if(-not $validInputs.Contains($inputresponse)){write-host "Please select the choice between 0 - 3"}
} until ($validInputs.Contains($inputresponse))

$taskToPerform = $inputresponse

$exitvalue = "2"
if($exitvalue.Contains($taskToPerform))
{
exitcode
}


$updateandStorePwd = "0"
if($updateandStorePwd.Contains($taskToPerform))
{
# Read the input config CSV and validate
$inputfile = $PSScriptRoot+"\Factory_PostgreSQL_Server_Input_file.csv"

Write-Host "Input file is $inputfile." -ForegroundColor Green
Write-Host "======================================================================================="


if (-not(Test-Path -Path $inputfile -PathType Leaf)) {
     try {    
         Write-Host "======================================================================================="  
         Write-Host "Unable to read the input file [$inputfile]. Check file & its permission...  "  -ForegroundColor Red  
         Write-Host "======================================================================================="  
         Write-Host "Please see the error below & execution has been stopped          "  
         throw $_.Exception.Message                      
     }
     catch {
         throw $_.Exception.Message
     }
 }
else
{
     try {
         $sqllist_Read_CSV = Import-Csv -Path $inputfile #-WorksheetName Server_List
         $Approved_Rows = $sqllist_Read_CSV | Where-Object { $_.Approval_Status.toupper() -eq "YES" }

         $ConfigList = $Approved_Rows | Group-Object -Property 'Host_Name' | ForEach-Object {
    $_.Group | Select-Object -First 1
	}
         

         $Rowcount=0

          foreach($row in $ConfigList){

         $Host_name = $row.'Host_Name'
         $user_id = $row.'User_ID'

         $credentials = Get-Credential -UserName $User_ID -Message "Please provide valid credentials for $Host_Name"
         $Password = $credentials.GetNetworkCredential().Password
         $protected =  ConvertFrom-SecureString -SecureString $($credentials.Password)
         
         $protected | Out-File "$Host_name.data"
         Write-Host "Password updated for $Host_name"
         


           $DestinationServer = $row.'DestinationServer'
         $DestUID = $row.'DestUID'

         $credentials1 = Get-Credential -UserName $DestUID -Message "Please provide valid credentials for $DestinationServer"
         $Password1 = $credentials.GetNetworkCredential().Password
         $protected1 =  ConvertFrom-SecureString -SecureString $($credentials1.Password)
         
         $protected1 | Out-File "$DestinationServer.data"
         Write-Host "Password updated for $DestinationServer"


        }
        "{pwdForm:'protected'}" | Out-File state.json
        
           "{pwdForm1:'protected1'}" | Out-File state1.json 
    }
     catch {
         Write-Host "=================================================================================="  
         Write-Host "The file [$inputfile] does seems to be in correct format"  -ForegroundColor Red  
         Write-Host "=================================================================================="  
         Write-Host "Please see the error below &execution has been stopped          "  
         throw $_.Exception.Message
     }

     
}
exitCode

}




$today_date=Get-Date -Format "MM_dd_yyyy_HH_mm"
Start-Transcript -path  $Folder\Logs\Factory-PostgreSQL_Info_Gathering_Automation_Transcript_$today_date.txt -Append
Write-Host "======================================================================================= "
createFolder $Folder\Downloads\
createFolder $Folder\Output\
createFolder $Folder\migrate\

if (Test-Path "\state.json"){
   $pwdForm  = (gc .\state.json | ConvertFrom-Json).pwdForm
    if($pwdForm -eq 'protected'){
        Write-Host "Password form is set to protected, to update and protect password again run step 0, to revert to the clear-text form remove state.json file from the script directory"
    }
}

if (Test-Path "\state1.json"){
   $pwdForm1  = (gc .\state1.json | ConvertFrom-Json).pwdForm1
    if($pwdForm1 -eq 'protected1'){
        Write-Host "Password form is set to protected, to update and protect password again run step 0, to revert to the clear-text form remove state1.json file from the script directory"
    }
}

Write-Host ""
Write-Host "======================================================================================= "
#Write-Host "Input Section "   -ForegroundColor Green

  

# Read the input config CSV and validate
$inputfile = $Folder+"\Factory_PostgreSQL_Server_Input_file.csv"

Write-Host "Input file is $inputfile." -ForegroundColor Green
Write-Host "======================================================================================="


if (-not(Test-Path -Path $inputfile -PathType Leaf)) {
     try {    
         Write-Host "======================================================================================="  
         Write-Host "Unable to read the input file [$inputfile]. Check file & its permission...  "  -ForegroundColor Red  
         Write-Host "======================================================================================="  
         Write-Host "Please see the error below & execution has been stopped          "  
         throw $_.Exception.Message                      
     }
     catch {
         throw $_.Exception.Message
     }
 }
else
{
     try {
         $sqllist_Read_CSV = Import-Csv -Path $inputfile #-WorksheetName Server_List
         $Approved_Rows = $sqllist_Read_CSV | Where-Object { $_.Approval_Status.toupper() -eq "YES" }

         $ConfigList = $Approved_Rows | Group-Object -Property 'Host_Name' | ForEach-Object {$_.Group }
         

         $Rowcount=0

          foreach($row in $ConfigList){

         $Hostname = $row.'Host_Name'
          $Rowcount=$Rowcount+1

           }
      
    }
     catch {
         Write-Host "=================================================================================="  
         Write-Host "The file [$inputfile] does not have the woksheet named Server_List  "  -ForegroundColor Red  
         Write-Host "=================================================================================="  
         Write-Host "Please see the error below &execution has been stopped          "  
         throw $_.Exception.Message
     }

if($ConfigList.count -eq 0){

write-host "None of the hosts are approved to proceed . Terminating the execution" -ForegroundColor Red

exitcode

}
else
{

$tenant=$ConfigList.Tenant|Get-Unique

    if ([string]::IsNullOrWhitespace($tenant)){
Write-Host "Tenant listed Azure_Subscription worksheet is not valid. Kindly check and retrigger the automation  "  -BackgroundColor Red 
exitCode
}
elseif($tenant.count -gt 1)
{
Write-Host "Azure_Subscription.csv has multiple Tenant. This script doesn't support multiple Tenant but you can add multiple Subscription. `nKindly check and retrigger the automation for each Tenant separately."  -BackgroundColor Red 
exitCode

}
else
{
#AZ login to corresponsing Tenant and subscription
$loginoutput=az login --tenant $tenant --only-show-errors
#$loginoutput=az login --use-device-code --tenant $tenant --only-show-errors
}

if (!$loginoutput) 
{
    Write-Error "Error connecting to Tenant: $tenant"
    exitcode
}
$Subscriptions= $ConfigList.Subscription_ID|Sort-Object -Unique
  $loginoutput=az account set --subscription $Subscriptions 2>&1
           $stat = $LASTEXITCODE


If( $stat -ne 0)
    {
       # seems to have failed
       #$errorMessage = $Error[0].Exception.Message
         Write-Host "Failed to execute [az account set --subscription $Subscription]" -ForegroundColor Red
         Write-Host "The file [$inputfile] does not have valid Subscription.`n"  -ForegroundColor Red
        continue
    }
}

     $ColumnList=$ConfigList | Get-Member -MemberType NoteProperty | %{"$($_.Name)"}
     if (($ColumnList.Contains("Host_Name")) -and
        ($ColumnList.Contains("User_ID")) -and
        ($ColumnList.Contains("Password")) -and
        ($ColumnList.Contains("DB_Name")) -and
        ($ColumnList.Contains("Tenant")) -and
        ($ColumnList.Contains("Subscription_ID")) -and
        ($ColumnList.Contains("SSL_Mode"))  -and
        ($ColumnList.Contains("DestinationServer")) -and
        ($ColumnList.Contains("DestUID")) -and
          ($ColumnList.Contains("DestPass")) -and
        ($ColumnList.Contains("MigrationOption")) -and
        ($ColumnList.Contains("RuntimeServer")) -and
         ($ColumnList.Contains("SourceType")) -AND
          ($ColumnList.Contains("MigrationMode"))
        
        ){

        Write-Host "CSV validation is done successfully " 
        }
     else {Write-Host "There are missmatches in the CSV column . Kindly check and retrigger the automation "  -ForegroundColor Red 
           exitCode}
  }


    ##Input CSV validation is done


	Write-Host "=======================================================================================" 
    Write-Host "Here are the List of the Hosts the automation will proceed based on the user selection -" -ForegroundColor Green
    Write-Host "=======================================================================================" 

	$db_Selection_Display=@()
    $validInputs_Yes_No = @("y", "n","Y","N")

	Write-Host ($ConfigList | select @{Name='SourceServer'; Expression={$_.Host_Name}},DestinationServer,SourceType,MigrationMode | Format-Table | Out-String)
  
	Write-Host "=======================================================================================" 
    Write-Host "Please enter Y if you wish to continue , otherwise please press N to exit" -ForegroundColor Green
    Write-Host "=======================================================================================" 
    #$response1="n"

    do {
    $response1 = read-host "Please provide your inputs"
    if(-not $validInputs_Yes_No.Contains($response1)){write-host "Please Enter a valid input (Y or N )"}
    
    }until ($validInputs_Yes_No.Contains($response1.ToLower()))

    if ($response1 -eq "n")
    {
        exitcode
    }          
	
	$i = 0
	$Output_data =@()
    $Global:project_name = ""
    
    $Global:project_name = Read-Host "`nEnter the project name "
     $DBList_Log_File=$Folder+"\Output\"+$Global:project_name+"_"+$Host_name+"$DBName.log"
    $errDBList_Log_File=$Folder+"\Output\"+$Global:project_name+"_"+$Host_name+"$DBName.err"


    #Validating psql
    Write-Host "Checking for PSQL path" -ForegroundColor white
    $psql_validdation_file_path=$Folder+"\psql_validation.bat"
    $psql_Log_File=$Folder+"\Output\$Host_Name_psql_validation.log"
    $errpsql_Log_File=$Folder+"\Output\$Host_Name_psql_validation.err"
    $psqlCommand="psql --version"
    Invoke-Expression "$psqlCommand 2>&1 | Out-File -FilePath $psql_Log_File"
    $stat = $LASTEXITCODE
    If( $stat -ne 0)
    {
       # seems to have failed
       Write-Host "Failed to validate psql location" -ForegroundColor RED
       $errorMessage = $Error[0].Exception.Message
       $errorMessage | Out-File -FilePath $errpsql_Log_File -Append
       $error_m=Get-content -path $errpsql_Log_File | out-string
       continue
    }

    $error_msg=Get-content -path $psql_Log_File | out-string
    
    $error_msg1=$error_msg.tolower()

    if (Test-Path $psql_Log_File) {
    
    if ($error_msg1 -like ("*is not recognized as an internal or external command*")){

    write-host "Either Postgresql client tool is not installed on the server or psql Path is not set in environment variable" -ForegroundColor red 
    write-host ""
    write-host "Please configure as appropriate and re-run automation script"
    exitcode
    }
    else
    {
        Write-host "Psql validated successfully"  -ForegroundColor green
    }
    

    }else
    {
        write-host "Error in validating psql" -ForegroundColor red
        Write-Host "Please check and re-run the script"
        exitcode
    }


    Remove-Item $psql_Log_File


 $Flex_data=@()
	foreach ($row_Content in $ConfigList)
	{

        $Subscriptions=$row_Content.'Subscription_ID'
        $Tenant=$row_Content.Tenant
        $RG=$row_Content.'Resource_Group'
		$Host_Name=$row_Content.'Host_Name'

		  $SourceType=$row_Content.'SourceType'
		if ([string]::IsNullOrWhitespace($SourceType)){
			Write-Host "'SourceType' is not valid in the worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
      
		if ([string]::IsNullOrWhitespace($Host_Name)){
			Write-Host "'Host_Name' is not valid in the Server_List worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}

        $DestinationServer=$row_Content.'DestinationServer'
		if ([string]::IsNullOrWhitespace($DestinationServer)){
			Write-Host "'DestinationServer' is not valid in the Server_List worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
		
		$User_ID=$row_Content.'User_ID'
		if ([string]::IsNullOrWhitespace($User_ID)){
			Write-Host "'User_ID' is not valid in the Server_List worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
	    
        $Port=$row_Content.'Port'
        if ([string]::IsNullOrWhitespace($Port)){
			$Port = 5432
			Continue
		}

        If($SourceType -eq "PostgreSQLSingleServer")
        {
        $servername=$Host_Name.split('.')[0]
         $sourceDbServerResourceId = "/subscriptions/$subscriptions/resourceGroups/$RG/providers/Microsoft.DBforPostgreSQL/servers/$servername"
        }
        else
        {
        $servername=$Host_Name
         $sourceDbServerResourceId = $Host_name+":"+$Port+"@"+$User_ID
        }

			
		$DestUID=$row_Content.'DestUID'
		if ([string]::IsNullOrWhitespace($DestUID)){
			Write-Host "'DestName' is not valid in the worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
        $MigrationOption=$row_Content.'MigrationOption'
		if ([string]::IsNullOrWhitespace($MigrationOption)){
			Write-Host "'MigrationOption' is not valid in the worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
        
           

         $RuntimeServer=$row_Content.'RuntimeServer'
		if ([string]::IsNullOrWhitespace($RuntimeServer)){
			$runtimeFlag =0
		}
        else 
        {
        $runtimeFlag=1
        }

       

        $Migration_mode=$row_Content.'MigrationMode'
		if ([string]::IsNullOrWhitespace($Migration_mode)){
			Write-Host "'MigrationMode' is not valid in the worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
        

		$Password=$row_Content.'Password'
		if ([string]::IsNullOrWhitespace($Password)){
            $pwdProtected = $false
            if (Test-Path .\state.json)
            {
                $pwdProtected = (Get-Content .\state.json | ConvertFrom-Json).pwdForm -eq 'protected'
            }
            else{
                $pwdProtected = $false
            }
            if ($pwdProtected) {
                $protectedData = "$Host_Name.data"
                if(Test-Path $protectedData){
                    $secureStringPwd = Get-Content $protectedData | ConvertTo-SecureString
                    $credentials =  [PSCredential]::New($User_ID,$secureStringPwd)
                    $Password = $credentials.GetNetworkCredential().Password
                }
                else {
                    Write-Host "'Password' is not found in $protectedData file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
                }


            }
            else {
                $credentials = Get-Credential -UserName $User_ID -Message "Please provide valid credentials for $Host_Name"
                $Password = $credentials.GetNetworkCredential().Password
                if ([string]::IsNullOrWhitespace($Password)){
                    Write-Host "'Password' is not valid in the Server_List worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
                    Continue
                }
            }
		}
    

    $DestPass=$row_Content.'DestPass'
		if ([string]::IsNullOrWhitespace($DestPass)){
            $pwdProtected1= $false
            if (Test-Path .\state1.json)
            {
                $pwdProtected1 = (Get-Content .\state1.json | ConvertFrom-Json).pwdForm1 -eq 'protected1'
            }
            else{
                $pwdProtected1 = $false
            }
            if ($pwdProtected1) {
                $protectedData1 = "$DestinationServer.data"
                if(Test-Path $protectedData1){
                    $secureStringPwd1 = Get-Content $protectedData1 | ConvertTo-SecureString
                    $credentials1 =  [PSCredential]::New($DestUID,$secureStringPwd1)
                    $DestPass = $credentials1.GetNetworkCredential().Password
                }
                else {
                    Write-Host "'Password' is not found in $protectedData file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
                }


            }
            else {
                $credentials1 = Get-Credential -UserName $DestUID -Message "Please provide valid credentials for $DestinationServer"
                $DestPass = $credentials1.GetNetworkCredential().Password
                if ([string]::IsNullOrWhitespace($DestPass)){
                    Write-Host "'Password' is not valid in the Server_List worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
                    Continue
                }
            }
		}
    
    	$DB_Name=$row_Content.'DB_Name'

        	if ([string]::IsNullOrWhitespace($DB_Name)){
			Write-Host "'DB_Name' is not valid in the Server_List worksheet. Kindly check and retrigger the automation  "  -ForegroundColor Red 
			Continue
		}
        $SSL=$row_Content.'SSL_Mode'
		if(($SSL -eq "") -or ($SSL -eq $null) -or ($SSL -eq " ")) {
		
			Write-Host "'SSL Mode' is not valid in the Server_List worksheet. Kindly provide the right mode and retrigger the automation  "  -ForegroundColor Red 
			Continue
        }

	

 
    
   

	$ServerAutomation = "1"
	if($ServerAutomation.Contains($taskToPerform))
	{

		$DBParam_Log_File=$Folder+"\Output\$Host_Name_DBlog_$Log_Name.csv"

		#Execute PostgreSQL command 
		Write-Host "=======================================================================================" 

                #Intiating Database name extraction using \l

                Write-Host "Checking Source server connectivity: $Host_Name" -ForegroundColor Yellow
        
                $env:PGPASSWORD = $Password
                $escapedDBCommand = "`"dbname=$DB_Name sslmode=$SSL`""
                $psqlCommand="psql --username=$User_ID --host=$Host_Name --port=$Port --no-align --tuples-only --file=$DbList_path $escapedDBCommand"
              
                $dbnames=Invoke-Expression "$psqlCommand"

                $dbnames=$dbnames |Where-Object  {
                                                    $_ -notmatch 'template' -and
                                                    $_ -notmatch 'azure_maintenance' -and
                                                    $_ -notmatch 'azure_sys' -and
                                                    $_ -notmatch 'postgres'
                                                } |Sort-Object
                     
                 
                       
                $dbcount= $dbnames.count
                $stat = $LASTEXITCODE
              
                If( $stat -ne 0)
                {
                   # seems to have failed
		   Write-Host "Failed to connect database server on $Host_Name and find the issue in the location $Folder\Output folder" -ForegroundColor RED
                   $errorMessage = $Error[0].Exception.Message
                   $errorMessage | Out-File -FilePath $errDBList_Log_File -Append
		   $error_m=Get-content -path $DBList_Log_File | out-string
		   $Output_data += New-Object psobject -Property @{Host_Name=$Host_Name;Status="FAILED";LOG_File_Location=$DBList_Log_File;Error_Msg=$error_m}
		   $parameter_listing = "`nThe parameters are:`nUserID: $User_ID`nHostname: $Host_Name`nPassword:Kindly check in Input file`nDB_Name: $DB_Name`nPort: $Port`nSSL: $SSL"
		   Add-Content $DBList_Log_File $parameter_listing
		   continue
                }
                else
                {
                 Write-Host "Connection to Source server was successfull!!!" -ForegroundColor green
                }
                $DestServer=$DestinationServer+".postgres.database.azure.com"
            	Write-Host "=======================================================================================" 
                 Write-Host "Checking Destination server connectivity:   $DestServer"  -ForegroundColor Yellow
                
                   
                $env:PGPASSWORD = $DestPass
                $escapedDBCommand = "`"dbname=$DB_Name sslmode=$SSL`""
                $psqlCommand="psql --username=$DestUID --host=$DestServer --port=$Port --no-align --tuples-only --file=$DbList_path $escapedDBCommand"
             $DestDBlist=Invoke-Expression "$psqlCommand"

                $stat = $LASTEXITCODE
       
                If( $stat -ne 0)
                {
                   # seems to have failed
		            Write-Host "Failed to connect destination server $DestServer " -ForegroundColor RED
                   $errorMessage = $Error[0].Exception.Message
          
                   write-host "  $errorMessage"
		   exit
                }
                 else
                {
                 Write-Host "Connection to Destination server was successfull!!!" -ForegroundColor green
                }
     	Write-Host "=======================================================================================" 



# Check if the object count is greater than 8

    # Split the data into chunks of up to 8 objects each
    $chunks = [System.Collections.Generic.List[System.Object]]::new()
    $chunkSize = 8
    $fileNames=@()
    $i=0
    $FinalStatus = [PSCustomObject]@()
    $tasks = @()
    $num=0

  
  
    for ($i = 0; $i -lt $dbnames.Count; $i += $chunkSize) {
          if ($dbnames.count -gt 8)
          {
        $chunk = $dbnames[$i..[math]::Min($i + $chunkSize - 1, $dbnames.Count - 1)]
          $chunks.Add($chunk)
    }
    else
    {
    $chunk=$dbnames
        $chunks.Add($chunk)
    }
    }

    # Export each chunk to a separate JSON file
    for ($j = 0; $j -lt $chunks.Count; $j++) {
          
            $fileName = $Folder+"\Migrate\"+$servername + "_$($j + 1).json"
            $fileNames+=$fileName
            $ServerList=az postgres flexible-server list
            $psqlServer = $ServerList | ConvertFrom-Json
      foreach ($item in $psqlServer) {
        $Flex= $item.fullyQualifiedDomainName.split(".")[0]
        If($Flex -eq $DestinationServer)
        {
        $FlexRG=$item.resourceGroup
           $Flex_data += New-Object psobject -Property @{Name=$Flex;FlexRG=$FlexRG}
        break
        }
        }
  
       If($runtimeFlag -eq 1)
       {
        foreach ($item in $psqlServer) {
        $RunServer= $item.fullyQualifiedDomainName.split(".")[0]
        If($RunServer -eq $RuntimeServer)
        {
        $RunServerID=$item.id
        Write-Output "fullyQualifiedDomainName: $($item.fullyQualifiedDomainName), id: $($item.id)"
            $data = @{
                properties = @{
                    sourceDbServerResourceId = "$sourceDbServerResourceId"
                     migrationRuntimeResourceId = "$RunServerID"
                   secretParameters = @{
                        adminCredentials = @{
                            sourceServerPassword = "$Password"
                            targetServerPassword = "$DestPass"
                        }
                        sourceServerUserName = "$User_ID"
                        targetServerUserName = "$DestUID"
                    }
                    dbsToMigrate = @($chunks[$j] )
                    overwriteDbsInTarget = "true"
                     sourceType = "$sourceType"
                }
                }
        Break
             }}}
         else
         {

               $data = @{
                    properties = @{
                        sourceDbServerResourceId = "$sourceDbServerResourceId"
                       secretParameters = @{
                            adminCredentials = @{
                                sourceServerPassword = "$Password"
                                targetServerPassword = "$DestPass"
                            }
                            sourceServerUserName = "$User_ID"
                            targetServerUserName = "$DestUID"
                        }
                        dbsToMigrate = @($chunks[$j] )
                        overwriteDbsInTarget = "true"
                          sourceType = "$sourceType"
                    }
           }
        }
        $data | ConvertTo-Json -Depth 3|Out-File -FilePath $fileName -Encoding ascii
        
        Write-Host "Input JSON document for Migration Service exported to $fileName" 
     
    }
       write-host "Number of JSON file created:"$fileNames.count -ForegroundColor green
       write-host "Number of DATABASES to migrate:"$dbnames.Count  -ForegroundColor green

       Write-Host "=======================================================================================" 
       Write-Host "Please enter Y if you wish to continue , otherwise please press N to exit" -ForegroundColor Green
       Write-Host "=======================================================================================" 
       #$response1="n"

       If (($fileNames.count -gt 1) -and ($Migration_mode -ieq "online")) 
       {
       Write-host "Source server have more than 8 databases and doesn't qualify for online migration." -ForegroundColor Red
       Write-host "`nPlease update input file and retrigger the offline migration." -ForegroundColor Red
       continue
       }

    do {
    $response1 = read-host "Please provide your inputs"
    if(-not $validInputs_Yes_No.Contains($response1)){write-host "Please Enter a valid input (Y or N )"}
    
    }until ($validInputs_Yes_No.Contains($response1.ToLower()))

    if ($response1 -eq "n")
    {
        exitcode
    }          

	Write-Host "=======================================================================================" 
	Write-Host "========================Initiating Migration===========================================" 




foreach ($file in $fileNames)
{

$MigName= $Global:project_name+$file.Split('\')[-1].split('.')[0]+$num
	Write-Host "=======================================================================================" 
write-host "processing JSON file:"$file -ForegroundColor Yellow

write-host "`nexecuting: az postgres flexible-server migration create --subscription $subscriptions --resource-group $FlexRG --name $DestinationServer --migration-name $MigName --properties $file --migration-mode $Migration_mode --migration-option $MigrationOption" -ForegroundColor Yellow

  $name1=Start-Job -name $DestServer -ScriptBlock {
        param (
        [string] $subscriptions1,
          [string]$FlexRG1,
            [string]$DestinationServer1,
              [string]$MigName1,
                [string]$file1,
                  [string]$Migration_mode1,
                    [string]$MigrationOption1
    )
      az postgres flexible-server migration create --subscription $subscriptions1 --resource-group $FlexRG1 --name $DestinationServer1 --migration-name $MigName1 --properties $file1 --migration-mode $Migration_mode1 --migration-option $MigrationOption1
    } -ArgumentList $subscriptions,$FlexRG,$DestinationServer,$MigName,$file,$Migration_mode,$MigrationOption
$num++

}}}


        Write-Host "======================================================================================="  
        Write-Host "Below is The migration status for All Approved server"  -ForegroundColor Green  
        Write-Host "=======================================================================================`n"



while ($true) {
    $incompleteJobs = Get-Job | Where-Object { $_.State -ne 'Completed' -and $_.State -ne 'Failed' -and $_.State -ne 'Stopped' }
         Get-Job | Format-Table -AutoSize
    if ($incompleteJobs.Count -eq 0) {
        Write-host "`n ✅ Your jobs have been Successfuly submitted to Azure for execution. You may monitor the progress via the Azure portal or remain at this screen for updates." -ForegroundColor Yellow
        break
    }

    Write-host "`n ⏳ Waiting for BELOW jobs to complete... ($($incompleteJobs.Count) remaining)" -ForegroundColor Yellow
    $incompleteJobs| Format-Table -AutoSize
    Start-Sleep -Seconds 10
}


While($true) 
{ 
$status_data = @()
foreach ($Flex in $Flex_data)
{

$status=az postgres flexible-server migration list -n $Flex.Name -g $Flex.FlexRG |ConvertFrom-Json


if ($status.count -eq 1) 
{
$status_data += New-Object psobject -Property @{sourceDbServer=$status.sourceDbServerResourceId;targetDbServer=$status.targetDbServerResourceId.split("/")[-1];sourceType=$status.sourceType;migrationMode=$status.migrationMode;currentStatus=$status.currentStatus.state}
}

}
$status_data | Format-Table -AutoSize

if ($status_data | Where-Object { $_.currentStatus -match 'InProgress' }) {
    Write-Host "At least one migration is in progress."
} else {
    Write-Host "No migrations are currently in progress."
Break
}
 Start-Sleep -Seconds 10
}
exitcode
