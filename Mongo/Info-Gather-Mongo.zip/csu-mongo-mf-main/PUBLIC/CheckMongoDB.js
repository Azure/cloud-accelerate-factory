// Utility: Check if document has $-prefixed fields
function hasDollarFields(doc) {
  for (let key in doc) {
    if (key.startsWith("$")) return true;
    if (typeof doc[key] === "object" && doc[key] !== null) {
      if (hasDollarFields(doc[key])) return true;
    }
  }
  return false;
}

db.getMongo().getDBs().databases.forEach(function (dbInfo) {
  const dbName = dbInfo.name;
  const dbRef = db.getSiblingDB(dbName);
  const excludedDBs = ['admin', 'config', 'local'];

  print(`\n==============================`);
  print(`** DATABASE: ${dbName}`);
  print(`==============================`);

  // 1. Clustered collections with expireAfterSeconds
  print(`\n** START OF SECTION 1 DATABASE: ${dbName} : Clustered Collections with expireAfterSeconds`);
  try {
    dbRef.getCollectionInfos({}).forEach(function (coll) {
      if (coll.options?.clusteredIndex && coll.options.expireAfterSeconds) {
        print(`CLUSTERED ** Collection: ${coll.name}, ExpireAfterSeconds: ${coll.options.expireAfterSeconds}`);
      }
    });
  } catch (e) {
    print(`** Error: ${e}`);
  }
  print(`\n** END OF SECTION 1 DATABASE: ${dbName} : Clustered Collections with expireAfterSeconds`);

  // 2. Capped & Time-Series Collections
  print(`\n** START OF SECTION 2 DATABASE: ${dbName} : Capped & Time-Series Collections`);
  try {
    dbRef.getCollectionInfos({}).forEach(function (coll) {
      const name = coll.name;
      const options = coll.options || {};
      if (options.capped) {
        print(`CAPPED ** Collection: ${name}`);
      }
      if (options.timeseries) {
        print(`TIME-SERIES ** Collection: ${name}, TimeField: ${options.timeseries.timeField}`);
      }
    });
  } catch (e) {
    print(`** Error: ${e}`);
  }
  print(`\n** END OF SECTION 2 DATABASE: ${dbName} : Capped & Time-Series Collections`);

  // 3. Documents with $-prefixed fields
  print(`\n** START OF SECTION 3 DATABASE: ${dbName} : Documents with $-prefixed Fields`);
  try {
    dbRef.getCollectionNames().forEach(function (collName) {
      try {
        const cursor = dbRef.getCollection(collName).find({}).limit(100);
        cursor.forEach(doc => {
          if (hasDollarFields(doc)) {
            print(`$-FIELD ** Collection: ${collName}, _id: ${doc._id}`);
          }
        });
      } catch (err) {
        print(`** Skipped ${collName} due to error: ${err}`);
      }
    });
  } catch (e) {
    print(`** Error: ${e}`);
  }
  print(`\n** END OF SECTION 3 DATABASE: ${dbName} : Documents with $-prefixed Fields`);

  // 4. Queryable Encryption
  print(`\n** START OF SECTION 4 DATABASE: ${dbName} : Queryable Encryption Enabled Collections`);
  try {
    dbRef.getCollectionInfos({}).forEach(function (coll) {
      if (coll.options?.encryptedFields) {
        print(`QE ENABLED ** Collection: ${coll.name}`);
        printjson(coll.options.encryptedFields);
      }
    });
  } catch (e) {
    print(`** Error: ${e}`);
  }
  print(`\n** END OF SECTION 4 DATABASE: ${dbName} : Queryable Encryption Enabled Collections`);

  // 5. Mixed Unique and Non-Unique Indexes
  print(`\n** START OF SECTION 5 DATABASE: ${dbName} : Mixed Unique and Non-Unique Indexes`);
  try {
    dbRef.getCollectionInfos({ type: "collection" }).forEach(function (coll) {
      const collName = coll.name;
      try {
        const indexMap = {};
        const indexes = dbRef.getCollection(collName).getIndexes();
        indexes.forEach(idx => {
          const keyStr = JSON.stringify(idx.key);
          indexMap[keyStr] = indexMap[keyStr] || [];
          indexMap[keyStr].push({ name: idx.name, unique: !!idx.unique });
        });

        for (let key in indexMap) {
          const defs = indexMap[key];
          const hasUnique = defs.some(d => d.unique);
          const hasNonUnique = defs.some(d => !d.unique);
          if (defs.length > 1 && hasUnique && hasNonUnique) {
            print(`MIXED INDEX ** Collection: ${collName}, Field(s): ${key}`);
            printjson(defs);
          }
        }
      } catch (e) {
        print(`** Error reading indexes from ${collName}: ${e}`);
      }
    });
  } catch (e) {
    print(`** Error: ${e}`);
  }
  print(`\n** END OF SECTION 5 DATABASE: ${dbName} : Mixed Unique and Non-Unique Indexes`);

  // 6. Documents with empty timestamps
  print(`\n** START OF SECTION 6 DATABASE: ${dbName} : Empty Timestamp Documents`);
  try {
    dbRef.getCollectionInfos({ type: "collection" }).forEach(function (coll) {
      const collName = coll.name;
      try {
        const count = dbRef.getCollection(collName).countDocuments({
          timestamp: { $in: [null, "", {}] }
        });

        if (count > 0) {
          print(`EMPTY TIMESTAMP ** Collection: ${collName}, Docs: ${count}`);
        }
      } catch (err) {
        print(`** Error scanning ${collName} for timestamps: ${err}`);
      }
    });
  } catch (e) {
    print(`** Error: ${e}`);
  }
  print(`\n** END OF SECTION 6 DATABASE: ${dbName} : Empty Timestamp Documents`);

  // 7. Get All Users Information                
  if (excludedDBs.includes(dbName)) return;
  print(`\n** START OF SECTION 7 DATABASE: ${dbName} : User Information`);
  try {
    const dbRef = db.getSiblingDB(dbName);

    // Show users
    const users = dbRef.getUsers();
    print(`\nUsers in ${dbName}:`);
    printjson(users);

    // Show roles
    const roles = dbRef.getRoles({ showBuiltinRoles: false });
    print(`\nCustom Roles in ${dbName}:`);
    printjson(roles);

  } catch (e) {
    print(`\n** ERROR for DB: ${dbName} ➤ ${e}`);
  }
  print(`\n** END OF SECTION 7 DATABASE: ${dbName} : User Information`);
  print(`============================== END DB: ${dbName} ==============================\n`);
});
