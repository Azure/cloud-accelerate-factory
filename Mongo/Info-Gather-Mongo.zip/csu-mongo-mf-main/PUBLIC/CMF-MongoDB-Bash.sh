#!/bin/bash
#---------------------------------------------------------------------------------------------------------------------------*
# Purpose        : Script to fetch Information from MongoDB.
# Schedule       : Ad-Hoc / On-Demand
# Start Date     : 03-July-2024
# Author         : Rackimuthu Kandaswamy , Arun (Converted to Bash)
# Version        : 1.1
#
# INPUTS         : Server List and other parameters in CSV file; SSL_Modes = allow, disable, prefer, require, verify-ca, verify-full
# VARIABLE       : NONE
# PARENT         : NONE
# CHILD          : NONE
#---------------------------------------------------------------------------------------------------------------------------*

function exit_code() {
    echo "-Ending Execution"
    exit
}

function create_folder() {
    local new_folder="$1"
    if [ -d "$new_folder" ]; then
        echo "-Folder '$new_folder' exists..."
    else
        mkdir -p "$new_folder"
        echo "-$new_folder folder created..."
    fi
}

folder=$(dirname "$0")
today_date=$(date +"%m_%d_%Y_%H_%M_%S")

# Create necessary folders
create_folder "$folder/Logs"
create_folder "$folder/Output"

# Start logging using tee (both screen and file)
exec > >(tee -a "$folder/Logs/CMF-Mongo_Info_Gathering_Automation_Transcript_$today_date.txt") 2>&1

# Start of transcript
echo "Transcript started at $(date)"
echo "========================="

# Check MongoDB version
if command -v mongosh &>/dev/null; then
    mongod_command="mongosh"
elif command -v mongo &>/dev/null; then
    mongod_command="mongo"
else
    echo "Neither mongosh nor mongo is installed. Exiting..."
    exit_code
fi

mongover=$($mongod_command --version 2>/dev/null)
echo "=============================="
echo "Mongo version is $mongover"
echo "=============================="

# Logging
log_file_valid="$folder/Output/MongoDB_validation.log"
log_file_err="$folder/Output/MongoDB_validation.err"
echo "Checking for MongoDB path"

$mongod_command --version &> "$log_file_valid"

if [ $? -ne 0 ]; then
    echo "Failed to validate MongoDB location"
    echo "$(< "$log_file_err")"
    exit_code
else
    echo "MongoDB validated successfully"
fi

echo "Please press Y to continue MongoDB Info-Gathering. Press N to terminate the execution."
read -p "Please provide your input: " response

if [[ "$response" != "y" && "$response" != "Y" ]]; then
    exit_code
fi

# Read input file
inputfile="$folder/CMF_Mongo_Input_File.csv"
echo "Input file is $inputfile."

if [ ! -f "$inputfile" ]; then
    echo "Unable to read the input file [$inputfile]. Check file & its permission..."
    exit_code
fi

# While loop to read input until 'exit' is typed
for i in `tail -n +2 $inputfile`
do
    Host_Name=`echo $i | awk -F ',' '{print $1}'`
    Port=`echo $i | awk -F ',' '{print $2}'`
    User_ID=`echo $i | awk -F ',' '{print $3}'`
    Password=`echo $i | awk -F ',' '{print $4}'`
    Auth_DB=`echo $i | awk -F ',' '{print $5}'`
    TLS_Certificate_Path=`echo $i | awk -F ',' '{print $6}'`
    CA_Certificate_Path=`echo $i | awk -F ',' '{print $7}'`
    Approval_Status=`echo $i | awk -F ',' '{print $8}'`
    echo $Host_Name $Port $User_ID $Password $Auth_db $TLS_Certificate_Path $CA_Certificate_Path $Approval_Status

    if [ "$Approval_Status" != "Yes" ]; then
        continue
    fi

    log_file_cluster="$folder/Output/Cluster_${Host_Name}_${Port}_${today_date}.log"
    log_file_user="$folder/Output/User_${Host_Name}_${Port}_${today_date}.log"
    echo "Initiating Info-Gathering for $Host_Name"
    echo "Log File is $log_file_cluster"

    # Interactive password validation
    if [ -z "$Password" ]; then
        echo -n "Password is blank. Please enter the password: "
        read -s Password  # Read the password securely (without displaying it)
        echo  # To move to a new line after the password input
        if [ -z "$Password" ]; then
            echo "Password cannot be empty. Exiting."
            exit 1
        fi
    fi

    # Get the list of all databases
    databases=$(mongosh --quiet --host $Host_Name --port $Port --authenticationDatabase $Auth_db -u $User_ID -p $Password --eval 'db.getMongo().getDBNames()')

    # Loop through each database and dump users and roles
    for db in $(echo $databases | tr -d '[],"' | tr ' ' '\n'); do
      # Skip system databases
      if [[ "$db" != "admin" && "$db" != "config" && "$db" != "local" ]]; then
        echo "Dumping users and roles for database: $db"
        # Dump system.users and system.roles for each database
        db=$(echo "$db" | sed "s/'//g")
        $mongod_command $Host_Name:$Port/$db -u $User_ID -p $Password --authenticationDatabase $Auth_DB --eval "show users" >>  $log_file_user
      fi
    done

    if [ -s "$LOG_FILE_USER" ]; then
        echo "Users & Roles Information gathered successfully for $Host_Name"
    else
        echo "Failed to gather Users & Roles information for $Host_Name"
    fi

    if [[ "$TLS_Certificate_Path" != "NA" && "$CA_Certificate_Path" != "NA" ]]; then
	echo "TLS"
        $mongod_command --host "$Host_Name" --port "$Port" --tls --tlsCAFile "$TLS_Certificate_Path" --tlsCertificateKeyFile "$CA_Certificate_Path" getMongoData.js > "$log_file_cluster"
    else
	echo "OTH"
        $mongod_command --host "$Host_Name" --port "$Port" -u "$User_ID" -p "$Password" getMongoData.js > "$log_file_cluster"
    fi

    if [ -s "$log_file_cluster" ]; then
        echo "Information gathered successfully for $Host_Name"
    else
        echo "Failed to gather information for $Host_Name"
    fi
done 

echo "Below is the final status of MongoDB Script Execution:"
exec &>/dev/tty
exit_code

