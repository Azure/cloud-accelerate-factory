﻿#---------------------------------------------------------------------------------------------------------------------------*
#  Purpose        : Script to fetch Information from MongoDB.
#  Schedule       : Ad-Hoc / On-Demand
#  Start Date     : 03-July-2024
#  Author         : Rackimuthu Kandaswamy , Arun
#  Version        : 1.1
#   
#  INPUTS         : Server List and other parameters in CSV file; SSL_Modes = allow, disable, prefer, require, verify-ca, verify-full
#  VARIABLE       : NONE
#  PARENT         : NONE
#  CHILD          : NONE
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
#
#  IMPORTANT NOTE : The script has to be run on Non-Mission-Critical systems ONLY and not on any production server...
#
#---------------------------------------------------------------------------------------------------------------------------*
#---------------------------------------------------------------------------------------------------------------------------*
# Usage:
# Powershell.exe -File .\CMF-MongoDB-Linux.ps1
#


CLS

  function exitCode{
    Write-Host "-Ending Execution"
    exit
}

function createFolder([string]$newFolder) {
    if(Test-Path $newFolder)
    {
        Write-Host "-Folder'$newFolder' Exist..."
    }
    else
    {
        New-Item $newFolder -ItemType Directory
        Write-Host "-$newFolder folder created..."
    }
}

$folder = $PSScriptRoot
$date = Get-Date -UFormat "%m_%d_%Y_%H_%M_%S"

#---------------------------------------------------------PROGRAM BEGINS HERE----------------------------------------------------------


CLS
write-host "                                                                                       " -BackgroundColor DarkMagenta
Write-Host "       Welcome to CMF - MongoDB_Info_Gathering_Automation                              " -ForegroundColor white -BackgroundColor DarkMagenta
write-host "                  (OSS DB Migration factory)                                           " -BackgroundColor DarkMagenta
write-host "                                                                                       " -BackgroundColor DarkMagenta
Write-Host " "

$today_date=Get-Date -Format "MM_dd_yyyy_HH_mm"
$folder = $PSScriptRoot

Start-Transcript -path  $folder\Logs\CMF-Mongo_Info_Gathering_Automation_Transcript_$today_date.txt -Append
 
createFolder $folder/Logs
createFolder $folder/Output

Write-Host "Checking for MongoDB path" -ForegroundColor White
$MongoDB_Log_File="$Folder/Output/MongoDB_validation.log"
$errMongoDB_Log_File="$Folder/Output/MongoDB_validation.err"

# Function to check if a command is available
function Check-Command($command) {
    return (Get-Command $command -ErrorAction SilentlyContinue) -ne $null
}

# Check for mongosh and mongod availability
if (Check-Command "mongosh") {
    $mongodCommand = "mongosh"
    Write-Output "mongosh is available."
} else {
    Write-Output "mongosh is installed. Exiting..."
    exit 1
}

# Display the selected command
Write-Output "Using mongosh command: $mongodCommand"

$mongoDBCommand=" $mongodCommand  --version"

Invoke-Expression "$mongoDBCommand 2>&1 | Out-File -FilePath $MongoDB_Log_File"
$stat = $LASTEXITCODE

If($stat -ne 0)
{
    # seems to have failed
    Write-Host "Failed to validate mongosh client location" -ForegroundColor RED
    $errorMessage = $Error[0].Exception.Message
    $errorMessage | Out-File -FilePath $errMongoDB_Log_File -Append
    $error_m = Get-content -path $errMongoDB_Log_File | out-string
    continue
}
$content_check=Get-content -path $MongoDB_Log_File
if (Test-Path $MongoDB_Log_File) {
    
    $content_check1=$content_check.ToLower()
    if (($content_check1 -like "*command not found*")){ 
        Write-host $content_check -ForegroundColor red
        write-host "Mongosh client is not installed, please install and re-execute the script...!!!" -BackgroundColor Red
        exitcode
    }
    else
    {
        Write-host "Mongosh client validated successfully" -ForegroundColor Green
    }
    

}
Write-host ""

$validInputs_Yes_No = "y", "n"
     
Write-Host    "Please press Y to continue MongoDB Info-Gathering .Press N to terminate the execution " -ForegroundColor Green
Write-Host "======================================================================================="
    
do {
    $response = read-host "Please provide your inputs"
    if(-not $validInputs_Yes_No.Contains($response)){write-host "Please Enter a valid input (Y or N )"}
    
}until ($validInputs_Yes_No.Contains($response.ToLower()))

if($response -eq "n"){exitcode}

# Read the input config CSV and validate
$inputfile = $folder + "/CMF_Mongo_Input_File.csv"

Write-Host "`nInput file is $inputfile." -ForegroundColor Green
Write-Host "======================================================================================="


if (-not(Test-Path -Path $inputfile -PathType Leaf)) {
     try {    
         Write-Host "======================================================================================="  
         Write-Host "Unable to read the input file [$inputfile]. Check file & its permission...  "  -ForegroundColor Red  
         Write-Host "======================================================================================="  
         Write-Host "Please see the error below & execution has been stopped          "  
         throw $_.Exception.Message                      
     }
     catch {
         throw $_.Exception.Message
     }
}
else
{
     try {
        $inputdata = Import-Csv -Path $inputfile
        $Approved_Rows = $inputdata | Where-Object { $_.Approval_Status.toupper() -eq "YES" }
        $ConfigList = $Approved_Rows | Group-Object -Property 'Port' | ForEach-Object { $_.Group | Select-Object -First 1 }
         
        $Rowcount=0

        foreach($row in $ConfigList){
            $Port = $row.'Port'
            $Rowcount=$Rowcount+1
        }
    }
     catch {
         Write-Host "=================================================================================="  
         Write-Host "The file [$inputfile] does not have the woksheet named Server_List  "  -ForegroundColor Red  
         Write-Host "=================================================================================="  
         Write-Host "Please see the error below &execution has been stopped          "  
         Write-Host $_.Exception.Message -ForegroundColor Magenta
         throw $_.Exception.Message
     }

if($ConfigList.count -eq 0){

Write-Host "None of the hosts are approved to proceed . Terminating the execution" -ForegroundColor Red

exitcode

}

     $ColumnList=$ConfigList | Get-Member -MemberType NoteProperty | %{"$($_.Name)"}
     if (($ColumnList.Contains("Host_Name")) -and
        ($ColumnList.Contains("Port")) -and
        ($ColumnList.Contains("User_ID")) -and
        ($ColumnList.Contains("Password")) -and
        ($ColumnList.Contains("Auth_DB")) -and
	($ColumnList.Contains("TLS_Certificate_Path")) -and
	($ColumnList.Contains("CA_Certificate_Path")) -and
	($ColumnList.Contains("Approval_Status"))){

	        Write-Host "Input validation is done successfully " 
        }
     else {
            Write-Host "There are missmatches in the Input columns. Kindly check and retrigger the automation "  -ForegroundColor Red 
            exitCode
     }
}
Write-Host "=======================================================================================" 
Write-Host "Here are the List of the Hosts the automation will proceed based on the user selection -" -ForegroundColor Green
Write-Host "=======================================================================================" 

$db_Selection_Display=@()

 Write-Host ($ConfigList | select Host_Name | Format-Table | Out-String)
  
  Write-Host "=======================================================================================" 
    Write-Host "Please enter Y if you wish to continue , otherwise please press N to exit" -ForegroundColor Green
    Write-Host "=======================================================================================" 
    do {
    $response1 = read-host "Please provide your inputs"
    if(-not $validInputs_Yes_No.Contains($response1)){write-host "Please Enter a valid input (Y or N )"}
    
    }until ($validInputs_Yes_No.Contains($response1.ToLower()))

 if($response1 -eq "n"){exitcode}

$i = 0
$Output_data =@()

foreach ($row_Content in $ConfigList) 
{
    $Host_Name=$row_Content.'Host_Name'
    if ([string]::IsNullOrWhitespace($Host_Name)){
        Write-Host "'Host_Name' is not valid in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
        Continue
    }
    $User_ID=$row_Content.'User_ID'
    if ([string]::IsNullOrWhitespace($User_ID)){
        Write-Host "'User_ID' is not valid in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
        Continue
    }
	[Int]$Port=$row_Content.'Port'
	if ([string]::IsNullOrWhitespace($Port)){
	    Write-Host "'Port' is not valid in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
	    Continue
	}
	$Password=$row_Content.'Password'
        if ([string]::IsNullOrWhitespace($Password)){
            $PasswordRead = Read-Host "Enter MongoDB Password for ${Host_Name}:${Port} " -AsSecureString
            $Password = [System.Net.NetworkCredential]::new("", $PasswordRead).Password
    }
	foreach ($char in $specialChars) {
    		$escapedChar = "\" + $char  # Add a backslash before the character
		$Password = $Password -replace [regex]::Escape($char), $escapedChar
	}
        $Auth_DB=$row_Content.'Auth_DB'
        if ([string]::IsNullOrWhitespace($Auth_DB)){
            Write-Host "'Auth_DB' is not valid in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
            Continue
    }
	$TLS_Certificate_Path=$row_Content.'TLS_Certificate_Path'
    if ([string]::IsNullOrWhitespace($TLS_Certificate_Path)){
        Write-Host "'TLS' is not valid in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red 
        Continue
    }
	$CA_Certificate_Path=$row_Content.'CA_Certificate_Path'
    if ([string]::IsNullOrWhitespace($CA_Certificate_Path)){
        Write-Host "'CA_Certificate_Path' is not valid in the input file. Kindly check and retrigger the automation  "  -ForegroundColor Red
        Continue
    }
	$Log_File_Cluster="$($Folder)/Output/Cluster_$($Host_name)_$($Port)_$($date).log"
	$Log_File_User="$($Folder)/Output/User_$($Host_name)_$($Port)_$($date).log"

	Write-Host "=======================================================================================" 
	Write-host "Inititating Info-Gathering for " $Host_Name -ForegroundColor Green
	Write-Host "Log File is $Log_File_Cluster" -foregroundcolor green


        #echo "Pass is $Password"
        # Get the list of all databases
	if(($TLS_Certificate_Path -ne "NA") -or ($CA_Certificate_Path -ne "NA")) {
	  $connectionString = "mongodb://${User_ID}:${Password}@${Host_Name}:${Port}/${Auth_DB}?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"
          $command = @(
              "mongosh",
              "`"$connectionString`"",
              "--tls",
              "--tlsCAFile", "`"$CA_Certificate_Path`"",
              "--tlsCertificateKeyFile", "`"$TLS_Certificate_Path`"",
              "--authenticationDatabase", "`"$Auth_DB`"",
              "--quiet",
              "--eval", "'db.getMongo().getDBNames().forEach(dbname => print(dbname));'"
          ) -join " "
          $databases = Invoke-Expression $command
	}
	else {
	  $connectionString = "mongodb://${User_ID}:${Password}@${Host_Name}:${Port}/${Auth_DB}?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"
          $command = @(
              "mongosh",
              "`"$connectionString`"",
              "--authenticationDatabase", "`"$Auth_DB`"",
              "--quiet",
              "--eval", "'db.getMongo().getDBNames().forEach(dbname => print(dbname));'"
          ) -join " "
          $databases = Invoke-Expression $command
	}

        # Remove unwanted characters from the output
        $databases = $databases -replace '[\[\]",]', ''

        # Convert the database list into an array
        $dbArray = $databases -split " " | Where-Object { $_.Trim() -ne "" }
   
        # Display the cleaned array (optional)
        #Write-Output "Cleaned Database Array:"
        #$dbArray

        # Loop through each database and dump users and roles
        foreach ($db in $dbArray) {
            # Skip system databases
            if ($db -ne "admin" -and $db -ne "config" -and $db -ne "local") {
                Write-Output "Dumping users and roles for database: $db"

                # Dump system.users for each database
	        if(($TLS_Certificate_Path -ne "NA") -or ($CA_Certificate_Path -ne "NA")) {
	          $connectionString = "mongodb://${User_ID}:${Password}@${Host_Name}:${Port}/${db}?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"
                  $command = @(
                      "mongosh",
                      "`"$connectionString`"",
                      "--tls",
                      "--tlsCAFile", "`"$CA_Certificate_Path`"",
                      "--tlsCertificateKeyFile", "`"$TLS_Certificate_Path`"",
                      "--authenticationDatabase", "`"$Auth_DB`"",
                      "--quiet",
		      "--eval", "'show users;'"
                  ) -join " "
                  Invoke-Expression $command | Out-File -Append -FilePath $Log_File_User
	        }
	        else {
	          $connectionString = "mongodb://${User_ID}:${Password}@${Host_Name}:${Port}/${db}?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"
                  $command = @(
                      "mongosh",
                      "`"$connectionString`"",
                      "--authenticationDatabase", "`"$Auth_DB`"",
                      "--quiet",
		      "--eval", "'show users;'"
                  ) -join " "
                  Invoke-Expression $command | Out-File -Append -FilePath $Log_File_User
        	}
            }
        }

	if(($TLS_Certificate_Path -ne "NA") -or ($CA_Certificate_Path -ne "NA")) {
	        $connectionString = "mongodb://${User_ID}:${Password}@${Host_Name}:${Port}/${Auth_DB}?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"
                $command = @(
                      "mongosh",
                      "`"$connectionString`"",
                      "--tls",
                      "--tlsCAFile", "`"$CA_Certificate_Path`"",
                      "--tlsCertificateKeyFile", "`"$TLS_Certificate_Path`"",
                      "--authenticationDatabase", "`"$Auth_DB`"",
                      "--quiet",
                      " getMongoData.js"
                ) -join " "
                Invoke-Expression $command | Out-File -Append -FilePath $Log_File_Cluster -Encoding UTF8
	}
	else {
	        $connectionString = "mongodb://${User_ID}:${Password}@${Host_Name}:${Port}/${Auth_DB}?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"
                $command = @(
                      "mongosh",
                      "`"$connectionString`"",
                      "--authenticationDatabase", "`"$Auth_DB`"",
                      "--quiet",
                      " getMongoData.js"
                ) -join " "
                Invoke-Expression $command | Out-File -Append -FilePath $Log_File_Cluster -Encoding UTF8
	}
	
	if (Test-Path $Log_File_Cluster) {
		$size = Get-Content -Path $Log_File_Cluster -Raw
    		if($size -match '"command":') {
        		Write-host "Information Gathered is stored at "$Log_File_Cluster
	       		Write-host "Info-Gathering Successfully  completed for " $Host_Name -ForegroundColor Green
        		$Output_data += New-Object psobject -Property @{Host_Name=$Host_Name;Status="SUCCESS";LOG_File_Location=$Log_File_Cluster;Error_msg="NA"}
		}
    		else{
        		$error_msg=Get-content -path $Log_File_Cluster | Out-String
	        	$Output_data += New-Object psobject -Property @{Host_Name=$Host_Name;Status="FAILED";LOG_File_Location=$Log_File_Cluster;Error_Msg=$error_msg}
	        	write-host $error_msg -ForegroundColor red    	
    		}
	}
	else {
		Write-Host "File not Found $Log_File_Cluster"
    		$Output_data += New-Object psobject -Property @{Host_Name=$Host_Name;Status="FAILED";LOG_File_Location="NA";Error_Msg="NA"}
	}
}

Write-Host "" 
Write-Host "======================================================================================="  
Write-Host "Below is The final status of MySQL Script Execution "  -ForegroundColor Green  
Write-Host "======================================================================================="

Write-Host ($Output_data | select Host_Name,Status,Error_Msg| Format-Table -AutoSize -wrap| Out-String)  

if ($Output_data -ne "")
{
    $Output_data | select Host_Name,Status,LOG_File_Location,Error_Msg | Export-Csv "$Folder\Output\Output.csv" -NoTypeInformation    
    }

Stop-Transcript
exitcode
