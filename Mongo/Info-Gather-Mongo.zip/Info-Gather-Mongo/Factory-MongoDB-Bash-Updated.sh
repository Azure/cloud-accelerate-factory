#!/bin/bash

function exit_code() {
    echo "-Ending Execution"
    exit
}

function create_folder() {
    local new_folder="$1"
    if [ -d "$new_folder" ]; then
        echo "-Folder '$new_folder' exists..."
    else
        mkdir -p "$new_folder"
        echo "-$new_folder folder created..."
    fi
}

# Detect OS type and base folder
folder="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Detect OS and set folder paths 
if [[ "$OSTYPE" == "msys"* || "$OSTYPE" == "cygwin"* || "$OSTYPE" == "win32" ]]; then
    logs_folder="${folder}\\Logs"
    output_folder="${folder}\\Output"
elif [[ "$OSTYPE" == "linux-gnu"* || "$OSTYPE" == "darwin"* ]]; then
    logs_folder="${folder}/Logs"
    output_folder="${folder}/Output"
else
    echo "Unsupported OS: $OSTYPE"
    exit 1
fi

# Create folders
create_folder "$logs_folder"
create_folder "$output_folder"

# Detect available MongoDB client 
mongo_cmd=""
if command -v mongosh >/dev/null 2>&1; then
    mongo_cmd="mongosh"
elif command -v mongo >/dev/null 2>&1; then
    mongo_cmd="mongo"
else
    echo "Neither 'mongosh' nor 'mongo' found in PATH."
    exit 1
fi

echo "Operating System: $OSTYPE"
echo "MongoDB Client: $mongo_cmd"

today_date=$(date +"%m_%d_%Y_%H_%M_%S")

# Logging to transcript
if [[ "$mongo_cmd" == *".exe" ]]; then
   exec > >(tee -a "$folder\\Logs\\Factory-Mongo_Info_Gathering_Automation_Transcript_$today_date.txt") 2>&1
else
   exec > >(tee -a "$folder/Logs/Factory-Mongo_Info_Gathering_Automation_Transcript_$today_date.txt") 2>&1
fi

echo "Transcript started at $(date)"
echo "========================="

# Log setup
if [[ "$mongo_cmd" == *".exe" ]]; then
  log_file_valid="$folder\\Output\\MongoDB_validation.log"
  log_file_err="$folder\\Output\\MongoDB_validation.err"
  inputfile="$folder\\Factory_Mongo_Input_File.csv"
else
  log_file_valid="$folder/Output/MongoDB_validation.log"
  log_file_err="$folder/Output/MongoDB_validation.err"
  inputfile="$folder/Factory_Mongo_Input_File.csv"
fi

echo "Checking for mongosh or mongo client version path"
$mongo_cmd --version &> "$log_file_valid"
if [ $? -ne 0 ]; then
    echo "Failed to validate mongosh client location"
    echo "$(< "$log_file_err")"
    exit_code
else
    $mongo_cmd --version
    echo "Mongo client validated successfully"
fi

echo "Input file is $inputfile"
if [ ! -f "$inputfile" ]; then
    echo "Unable to read the input file [$inputfile]. Check file & its permission..."
    exit_code
fi

for i in `tail -n +2 $inputfile`
do
    Host_Name=`echo $i | awk -F ',' '{print $1}'`
    Port=`echo $i | awk -F ',' '{print $2}'`
    Approval_Status=`echo $i | awk -F ',' '{print $8}'`
    if [ "$Approval_Status" == "Yes" ]; then
        Output_host+=$(printf "\n %s,%s \n" "$Host_Name" "$Port")
    fi
done

echo -e "$Output_host"
echo " "
read -p "Press Y to continue MongoDB Info-Gathering. Press N to terminate: " response
if [[ "$response" != "y" && "$response" != "Y" ]]; then
    exit_code
fi

Output_data=''

for i in `tail -n +2 $inputfile`
do
 Host_Name=`echo $i | awk -F ',' '{print $1}'`
 Port=`echo $i | awk -F ',' '{print $2}'`
 User_ID=`echo $i | awk -F ',' '{print $3}'`
 Password=`echo $i | awk -F ',' '{print $4}'`
 Auth_DB=`echo $i | awk -F ',' '{print $5}'`
 TLS_Certificate_Path=`echo $i | awk -F ',' '{print $6}'`
 CA_Certificate_Path=`echo $i | awk -F ',' '{print $7}'`
 Approval_Status=`echo $i | awk -F ',' '{print $8}'`

 if [ "$Approval_Status" == "Yes" ]; then
    echo ""
    echo "Initiating Info-Gathering for $Host_Name"

    if [ "$Password" == "IN" ]; then
        read -s -p "Enter MongoDB Password for $Host_Name:" Password
        echo
        if [ -z "$Password" ]; then
            echo "Password cannot be empty. Exiting."
            exit 1
        fi
    fi

    if [[ -n "$User_ID" && -n "$Password" ]]; then
       Connection_USER="$User_ID:$Password@"
    elif [[ -z "$User_ID" && -z "$Password" ]]; then
       Connection_USER=""
    else
       echo "Error: User_ID and Password must be both set or both empty."
    fi

    if [[ "$Host_Name" == *".mongodb.net"* ]]; then
      if [[ -n "$Port" ]]; then
        echo "ERROR: Port must be empty for .mongodb.net SRV connection."
      fi
    fi

    Connection_PARAM="?serverSelectionTimeoutMS=120000&connectTimeoutMS=20000&socketTimeoutMS=30000&readPreference=secondaryPreferred"

    if [[ "$Host_Name" == *".mongodb.net"* ]]; then
       Connection_URI="mongodb+srv://${Connection_USER}${Host_Name}/${Auth_DB}${Connection_PARAM}"
    else
       Connection_URI="mongodb://${Connection_USER}${Host_Name}:${Port}/${Auth_DB}${Connection_PARAM}"
    fi

    if [[ -n "$CA_Certificate_Path" && -n "$TLS_Certificate_Path" ]]; then
       Connection_TLS=" --tls --tlsCAFile \"$CA_Certificate_Path\" --tlsCertificateKeyFile \"$TLS_Certificate_Path\""
    elif [[ -z "$CA_Certificate_Path" && -z "$TLS_Certificate_Path" ]]; then
       Connection_TLS=""
    else
       echo "Error: CA_Certificate_Path and TLS_Certificate_Path must both be set or both empty."
    fi

    Connection_AUTHDB=" --authenticationDatabase $Auth_DB --quiet "
    Mongo_Cmd_base="$mongo_cmd \"$Connection_URI\" $Connection_TLS $Connection_AUTHDB"

    echo "Checking DB version for $Host_Name ..."
    Error_Msg=$(eval "$Mongo_Cmd_base --eval 'db.version()' 2>&1")
    if [ $? -ne 0 ]; then
         Status="FAILED:VERSION_CHECK"
         Output_data+=$(printf "\n %s,%s,%s \n" "$Host_Name" "$Status")
	 continue
    else
         echo "DB version check passed for $Host_Name"
    fi

    run_mongo_js() {
        local jsfile="$1"
        local logfile="$2"
        if [[ "$mongo_cmd" == "mongo" || "$mongo_cmd" == "mongo.exe" ]]; then
            eval "$Mongo_Cmd_base --eval 'var _printJSON=false;' \"$jsfile\" >> \"$logfile\" 2>&1"
        else
            eval "$Mongo_Cmd_base --eval 'var _printJSON=false;' --file \"$jsfile\" >> \"$logfile\" 2>&1"
        fi
        return $?
    }

    log_file_cluster="$folder/Output/Cluster_${Host_Name}_${today_date}.log"
    log_file_db="$folder/Output/Database_${Host_Name}_${today_date}.log"
    log_file_size="$folder/Output/DBSize_${Host_Name}_${today_date}.log"

    if [ -f "${folder}/getMongoData.js" ]; then
        if ! run_mongo_js "${folder}/getMongoData.js" "$log_file_cluster"; then
            Status="FAILED:GET_MONGO_JS"
            Output_data+=$(printf "\n %s,%s,%s \n" "$Host_Name" "$Status" "$log_file_cluster")
        fi
    fi

    if [ -f "${folder}/Checksize.js" ]; then
        if ! run_mongo_js "${folder}/Checksize.js" "$log_file_size"; then
            Status="FAILED:CHECK_DB_SIZE_JS"
            Output_data+=$(printf "\n %s,%s,%s \n" "$Host_Name" "$Status" "$log_file_size")
        fi
    fi

    if [[ "$mongo_cmd" == "mongo" || "$mongo_cmd" == "mongo.exe" ]]; then
        js_file="${folder}/CheckMongoDBLowerVersion.js"
    else
        js_file="${folder}/CheckMongoDB.js"
    fi

    if [ -f "$js_file" ]; then
        if ! run_mongo_js "$js_file" "$log_file_db"; then
            Status="FAILED:CHECK_MONGO_DB"
            Output_data+=$(printf "\n %s,%s,%s \n" "$Host_Name" "$Status" "$log_file_db")
        fi
    fi

    if [ -s "$log_file_cluster" ] && [ -s "$log_file_db" ] && [ -s "$log_file_size" ]; then
       echo "Cluster Info stored at $log_file_cluster"
       echo "Database Info stored at $log_file_db"
       echo "DBSize Info stored at $log_file_size"
       Status="SUCCESS"
       Output_data+=$(printf "\n %s,%s,%s \n" "$Host_Name" "$Status")
    else
       if ! grep -q "$Host_Name" <<< "$Output_data"; then
           Status="FAILED:NO_OUTPUT"
           Output_data+=$(printf "\n %s,%s,%s \n" "$Host_Name" "$Status")
       fi
    fi
 fi
done

echo "Below is the final status of MongoDB Script Execution:"
echo -e "Host_Name\t\t\tStatus\t\t\tError_Message"
echo -e "$Output_data" | awk -F, '{printf "%-30s %-20s %-60s \n", $1, $2, $3}'

echo "Transcript End at $(date)"
echo "========================="
exec &>/dev/tty
exit_code

